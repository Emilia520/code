import Vue from 'vue';
import VueRouter from 'vue-router';
Vue.use(VueRouter);
/* Layout */
import Layout from 'component/layout/app/layout.vue';
export default function createRouter(store) {
  console.log(store);
  console.log('store user', store.getters.name, store.getters.role);
  var power =store.getters.role;
  var number = parseInt(power);
  console.log(number);
  return new VueRouter({
    mode: 'history',
    base: '/',
    routes: [
    {
      path: '/login',
      component: () =>
        import('@/view/login/index'),
      hidden: true
    },
    {
      path: '/',
      component: Layout,
      redirect: '/dashboard',
      name: 'dashboard',
      // hidden: true,
      title: '首页',
      children: [{
        path: 'dashboard',
        meta: {
          title: '首页',
          icon: 'el-icon-s-home'
        },
        component: () =>
            import('@/view/dashboard/index')
      }]
    },
    {
      path: '/classroom/information',
      component: Layout,
      redirect: '/information',
      name: 'userInfo',
      // hidden: true,
      title: '个人信息',
      children: [{
        path: 'userInfo',
        meta: {
          title: '个人信息',
          icon: 'el-icon-user'
        },
        component: () =>
            import('@/view/classroom/information/userInfo')
      }]
    },
    {
      path: '/classroom/',
      component: Layout,
      redirect: '/classroom',
      name: 'classroom',
      // hidden: true,
      title: '课室使用情况',
      children: [{
        path: 'classroom',
        meta: {
          title: '课室使用情况',
          icon: 'el-icon-s-grid'
        },
        component: () =>
            import('@/view/classroom/classroom')
      }]
    },
    {
      path: '/classroom/appointment',
      component: Layout,
      redirect: '/appointment',
      name: 'appointment',
      // hidden: true,
      title: '课室预约',
      children: [{
        path: 'index',
        meta: {
          title: '课室预约',
          icon: 'el-icon-s-order'
        },
        component: () =>
            import('@/view/classroom/appointment/index')
      }]
    },
    {
      path: '/classroom/record',
      component: Layout,
      redirect: '/record',
      name: 'record',
      // hidden: true,
      title: '预约记录查询',
      children: [{
        path: 'index',
        meta: {
          title: '预约记录查询',
          icon: 'el-icon-edit-outline'
        },
        component: () =>
            import('@/view/classroom/record/index')
      }]
    },
    {
      path: '/classroom/admin',
      component: Layout,
      redirect: '/admin',
      name: 'admin',
      // hidden: true,
      title: '管理员预约审批',
      hidden: number === 3 || number === 4,
      children: [{
        path: 'examine',
        meta: {
          title: '管理员预约审批',
          icon: 'el-icon-s-claim'
        },
        component: () =>
            import('@/view/classroom/admin/examine')
      }]
    },
    {
      path: '/classroom/history',
      component: Layout,
      redirect: '/history',
      name: 'history',
      // hidden: true,
      title: '审批记录',
      hidden: number === 3 || number === 4,
      children: [{
        path: 'exhistory',
        meta: {
          title: '审批记录',
          icon: 'el-icon-time'
        },
        component: () =>
            import('@/view/classroom/history/exhistory')
      }]
    },
    {
      path: '/classroom/role',
      component: Layout,
      redirect: '/role',
      name: 'role',
      // hidden: true,
      title: '用户信息',
      hidden: number === 3 || number === 4,
      children: [{
        path: 'userRole',
        meta: {
          title: '用户信息管理',
          icon: 'el-icon-postcard'
        },
        component: () =>
            import('@/view/classroom/role/userRole')
      }]
    },
    {
      path: '/classroom/appReord',
      component: Layout,
      redirect: '/appReord',
      name: 'appReord',
      // hidden: true,
      title: '用户信息',
      hidden: number === 3 || number === 4,
      children: [{
        path: 'index',
        meta: {
          title: '用户预约记录查询',
          icon: 'el-icon-search'
        },
        component: () =>
            import('@/view/classroom/appReord/index')
      }]
    },
    // {
    //   path: 'banner',
    //   name: 'banner',
    //   component: () =>
    //     import('@/view/qxbBrandSale/brandList/index'),
    //   meta: {
    //     title: '预约首页',
    //     icon: 'banner'
    //   }
    // },
    // {
    //   path: '/resources',
    //   component: Layout,
    //   redirect: '/resources/chucksmanage',
    //   name: '资源推荐位',
    //   meta: {
    //     title: '资源推荐位',
    //     icon: 'example'
    //   },
    //   hidden: number === 3 || number === 4,
    //   children: [
        /* {
          path: 'bannermanage',
        name: 'bannermanage',
        component: () =>
            import('@/view/bannerManage/index'),
        meta: {
          title: '首页banner运营',
          icon: 'banner'
        }
      },*/
    

        // {
        //   path: '/banner/bannerList/:client_id',
        //   component: () => import('@/view/banner/bannerList/'),
        //   name: 'bannerList',
        //   hidden: true,
        //   meta: {
        //     title: 'banner列表',
        //     icon: 'shuffling-banner'
        //   }
        // },
    //     /* {
    //    path: 'infomation',
    //    name: 'infomation',
    //    component: () =>
    //          import('@/view/infomation/index'),
    //    meta: {
    //      title: '资讯入口运营',
    //      icon: 'enter'
    //    }
    //  },*/
    //   ]
    // },


    // {
    //   path: '/userManage',
    //   component: Layout,
    //   redirect: '/userManage/userMessage',
    //   name: 'usermanage',
    //   meta: {
    //     title: '会员管理',
    //     icon: 'el-icon-menu'
    //   },
    //   // hidden: store.getters.role === 4 || store.getters.role === 5,
    //   hidden: number===4,
    //   children: [
    //     {
    //     path: '/shopmessage',
    //     component: () =>
    //         import('@/view/userManage/shopMessage/index'), // Parent router-view
    //     name: 'shopmessage',
    //     meta: {
    //       title: '小店管理',
    //       icon: 'shop'
    //     }
    //   },
    //    {
    //     path: '/usermessage',
    //     component: () =>
    //         import('@/view/userManage/userMessage/index'), // Parent router-view
    //     name: 'usermessage',
    //     meta: {
    //       title: '会员信息',
    //       icon: 'userlist'
    //     }
    //   },
    //   {
    //     path: '/userupdate',
    //     component: () =>
    //           import('@/view/userManage/userUpdate/index'), // Parent router-view
    //     name: 'userupdate',
    //     meta: {
    //       title: '会员升级订单',
    //       icon: 'update'
    //     }
    //   },
    //   {
    //     path: '/orderincome',
    //     component: () =>
    //           import('@/view/userManage/orderIncome/index'), // Parent router-view
    //     name: 'orderincome',
    //     meta: {
    //       title: '订单&收益',
    //       icon: 'income'
    //     }
    //   }
    //   ]
    // },
    // {
    //   path: '/dataStatistics',
    //   component: Layout,
    //   redirect: '/dataStatistics/pullNewerStatistics',
    //   name: 'dataStatistics',
    //   meta: {
    //     title: '数据统计',
    //     icon: 'news'
    //   },
    //   hidden:number === 5,
    //   children: [{
    //     path: '/pullNewerStatistics',
    //     component: () =>
    //         import('@/view/dataStatistics/pullNewerStatistics/index'), // Parent router-view
    //     name: 'pullNewerStatistics',
    //     meta: {
    //       title: '拉新数据',
    //       icon: 'ironManage',
    //     },
    //     // hidden: store.getters.role === 2
    //   },
    //   ]
    // },
    // {
    //   path: '/pdd',
    //   component: Layout,
    //   // redirect: '/pdd/promoteInfoGen',
    //   name: 'robotManager',
    //   meta: {
    //     title: '机器人群运营',
    //     icon: 'self-adaption'
    //   },
    //   children: [
    //     {
    //       path: '/promoteInfoGen',
    //       component: () =>
    //           import('@/view/pddManage/promoteInfoGen/index'),
    //       name: 'promoteInfoGen',
    //       meta: {
    //         title: '推广信息生成',
    //         icon: 'she'
    //       }
    //     },
    //     {
    //       path: '/goodsManage',
    //       component: () =>
    //           import('@/view/pddManage/goodsManage/index'), // Parent router-view
    //       name: 'goodsManage',
    //       meta: {
    //         title: '机器人商品运营',
    //         icon: 'logistics'
    //       },
    //       hidden: store.getters.role === 5
    //     },
    //     {
    //       path: '/robotMsgRecord',
    //       component: () =>
    //           import('@/view/pddManage/robotMsgRecord/index'), // Parent router-view
    //       name: 'robotMsgRecord',
    //       meta: {
    //         title: '群消息发送记录',
    //         icon: 'sort'
    //       },
    //       hidden: store.getters.role === 5
    //     },
    //     {
    //       path: '/reportForms',
    //       component: () =>
    //           import('@/view/pddManage/reportForms/index'), // Parent router-view
    //       name: 'reportForms',
    //       hidden: store.getters.role === 5,
    //       meta: {
    //         title: '数据报表',
    //         icon: 'form'
    //       }
    //     },
    //     {
    //       path: '/groupManage',
    //       component: () =>
    //           import('@/view/pddManage/groupManage/index'), // Parent router-view
    //       name: 'groupManage',
    //       hidden: store.getters.role === 5,
    //       meta: {
    //         title: '微信群管理',
    //         icon: 'userlist'
    //       }
    //     },
    //     {
    //       path: '/robotManage',
    //       component: () =>
    //           import('@/view/pddManage/robotManage/index'), // Parent router-view
    //       name: 'robotManage',
    //       hidden: store.getters.role === 5,
    //       meta: {
    //         title: '机器人管理',
    //         icon: 'userlist'
    //       }
    //     },
    //     {
    //       path: '/categoryManage',
    //       component: () =>
    //           import('@/view/pddManage/categoryManage/index'), // Parent router-view
    //       name: 'categoryManage',
    //       hidden: store.getters.role === 5,
    //       meta: {
    //         title: '群分类管理',
    //         icon: 'userlist'
    //       }
    //     },
    //     {
    //       path: '/robotManage/robotWXGroups',
    //       component: () =>
    //         import('@/view/pddManage/robotManage/robotWXGroups/index'),
    //       name: 'robotWXGroups',
    //       hidden: true,
    //       meta: {
    //         title: '关联微信群',
    //         icon: 'wechat'
    //       }
    //     }
    //   ]
    // },
    // {
    //   path: '/choiceList',
    //   component: Layout,
    //   name: 'choiceListPanel',
    //   hidden: store.getters.role === 5,
    //   meta: {
    //     title: '选品运营',
    //     icon: 'choice 1-1'
    //   },
    //   children: [
    //     {
    //       path: '/choiceListMain',
    //       component: () => import('@/view/choiceList/index'),
    //       name: 'choiceListMain',
    //       meta: {
    //         title: '商品选品',
    //         icon: 'choice 2-1'
    //       }
    //     },
    //     {
    //       path: '/choiceListOpt',
    //       component: () => import('@/view/choiceList/choiceOpt/index'),
    //       name: 'choiceListOpt',
    //       meta: {
    //         title: '我的选品库',
    //         icon: 'My assets'
    //       }
    //     },
    //     // {
    //     //   path: '/choiceDetail/:id',
    //     //   component: () => import('@/view/choiceList/choiceDetail/index'),
    //     //   name: 'choiceDetail',
    //     //   hidden: true,
    //     //   meta: {
    //     //     title: '选品库详情',
    //     //     icon: '',
    //     //   }
    //     // },
    //     {
    //       path: '/homeChoice',
    //       component: () => import('@/view/choiceList/homeChoice/index'),
    //       name: 'homeChoice',
    //       meta: {
    //         title: '每日优选',
    //         icon: 'goodsBrand'
    //       }
    //     },
    //   ]
    // },
    //  {
    //   path: '/shoppingTuan',
    //   component: Layout,
    //   name: 'shoppingTuan',
    //   hidden: store.getters.role === 5,
    //   meta: {
    //     title: '校品团',
    //     icon: 'group'
    //   },
    //   children: [
    //     {
    //       path: '/shoppingTuan/activityList',
    //       component: () => import('@/view/shoppingTuan/activityList/index'),
    //       name: 'activityList',
    //       meta: {
    //         title: '活动列表',
    //         icon: 'Alist',
    //         keepAlive: true
    //       }
    //     },
    //     {
    //       path: '/shoppingTuan/activityDetail/:id',
    //       component: () => import('@/view/shoppingTuan/activityDetail/index'),
    //       name: 'activityDetail',
    //       hidden: true,
    //       meta: {
    //         title: '活动详情',
    //         icon: 'details'
    //       }
    //     },
    //     {
    //       path: '/shoppingTuan/hotDetail/:id',
    //       component: () => import('@/view/shoppingTuan/hotDetail/index'),
    //       name: 'hotDetail',
    //       hidden: true,
    //       meta: {
    //         title: '爆款详情',
    //         icon: 'Adetails',
    //         keepAlive: true
    //       }
    //     },
    //     {
    //       path: '/shoppingTuan/choiceOpt',
    //       component: () => import('@/view/shoppingTuan/choiceOpt/index'),
    //       name: 'choiceOpt',
    //       meta: {
    //         title: '爆款列表',
    //         icon: 'blist',
    //         keepAlive: true
    //       }
    //     },
    //     {
    //       path: '/shoppingTuan/chooseGoods',
    //       component: () => import('@/view/shoppingTuan/chooseGoods/index'),
    //       name: 'chooseGoods',
    //       meta: {
    //         title: '商品选品',
    //         icon: 'choiceBrand',
    //         keepAlive: true
    //       }
    //     },
    //   ]
    // },
    //  {
    //   path: '/qxbBrandSale',
    //   component: Layout,
    //   name: 'qxbBrandSale',
    //   hidden: store.getters.role === 5,
    //   meta: {
    //     title: '雀享优品品牌特卖',
    //     icon: 'Special sale'
    //   },
    //   children: [
    //     {
    //       path: '/qxbBrandSale/activityList',
    //       component: () => import('@/view/qxbBrandSale/activityList/index'),
    //       name: 'qxbActivityList',
    //       meta: {
    //         title: '活动列表',
    //         icon: 'Aclist',
    //         keepAlive: true
    //       }
    //     },
    //     {
    //       path: '/qxbBrandSale/productList',
    //       component: () => import('@/view/qxbBrandSale/productList/index'),
    //       name: 'qxbBrandSaleProductList',
    //       meta: {
    //         title: '商品列表',
    //         icon: 'brandList',
    //       }
    //     },
    //     {
    //       path: '/qxbBrandSale/choiceOpt',
    //       component: () => import('@/view/qxbBrandSale/choiceOpt/index'),
    //       name: 'qxbChoiceOpt',
    //       meta: {
    //         title: '爆款列表',
    //         icon: 'blist',
    //         keepAlive: true
    //       }
    //     },
    //     {
    //       path: '/qxbBrandSale/hotDetail/:id',
    //       component: () => import('@/view/qxbBrandSale/hotDetail/index'),
    //       name: 'qxbHotDetail',
    //       hidden: true,
    //       meta: {
    //         title: '爆款详情',
    //         icon: 'Adetails',
    //         keepAlive: true
    //       }
    //     },
    //     {
    //       path: '/qxbBrandSale/qxbChooseGoods',
    //       component: () => import('@/view/qxbBrandSale/qxbChooseGoods/index'),
    //       name: 'qxbChooseGoods',
    //       meta: {
    //         title: '商品选品',
    //         icon: 'choiceBrand',
    //         keepAlive: true
    //       }
    //     },
    //     {
    //       path: '/qxbBrandSale/seckillList',
    //       component: () => import('@/view/qxbBrandSale/seckillList/index'),
    //       name: 'qxbBrandSaleSecKill',
    //       meta: {
    //         title: '秒杀选品',
    //         icon: 'Seckill',
    //         keepAlive: true
    //       }
    //     },
    //     {
    //       path: '/qxbBrandSale/seckillList/detail',
    //       component: () => import('@/view/qxbBrandSale/seckillList/detail/index'),
    //       name: 'qxbBrandSaleSeckillDetail',
    //       hidden: true,
    //       meta: {
    //         title: '秒杀详情',
    //         icon: 'Spike details',
    //       }
    //     },
    //     {
    //       path: '/qxBrandSale/brandList',
    //       component: () => import('@/view/qxbBrandSale/brandList/index'),
    //       name: 'qxbBrandBrandList',
    //       meta: {
    //         title: '品牌列表',
    //         icon: 'brandSale_brand',
    //         keepAlive: true
    //       }
    //     }, 
       

    //   ]
    // },
    // {
    //   path: '/orders/afterSale',
    //   name: 'orders',
    //   component: Layout,
    //   meta: {
    //     title: '特卖订单',
    //     icon: 'order',
    //   },
    //   children: [
    //     {
    //       path: '/orders/afterSale/afterSaleOrderList',
    //       component: () => import('@/view/orders/afterSale/index'),
    //       name: 'afterSaleOrderList',
    //       meta: {
    //         title: '售后订单',
    //         icon: 'order_afterSale',
    //         keepAlive: true
    //       }
    //     },
    //     {
    //       path: '/orders/afterSale/afterSaleOrderDetail',
    //       component: () => import('@/view/orders/afterSale/afterSaleDetail/index'),
    //       name: 'afterSaleOrderDetail',
    //       hidden: true,
    //       meta: {
    //         title: '售后单详情',
    //         icon: 'soleOut',
    //       }
    //     },
    //     {
    //       path: '/orders/logisticsImport/main',
    //       component: () => import('@/view/orders/logisticsImport/index'),
    //       name: 'logisticsImport',
    //       meta: {
    //         title: '导入订单物流',
    //         icon: 'order_logistics',
    //       }
    //     },
    //     {
    //       path: '/orders/afterSale/applyAfterSale',
    //       component: () => import('@/view/orders/afterSale/applyAfterSale/index'),
    //       name: 'applyAfterSale',
    //       meta: {
    //         title: '申请售后',
    //         icon: 'order_applyAfterSale',
    //       }
    //     },
    //   ]
    // },
    // {
    //   path: '/goods/import',
    //   name: 'importGoods',
    //   component: Layout,
    //   meta: {
    //     title: 'AAAA',
    //     icon: 'ImportBrand',
    //   },
    //   children: [
    //     {
    //       path: '/goods/import/captainPackage',
    //       component: () => import('@/view/goods/import/index'),
    //       name: 'captainPackage',
    //       meta: {
    //         title: '团长礼包【298】222',
    //         icon: '',
    //         // keepAlive: true
    //       }
    //     } 
        
    //   ]
    // },

    // {
    //   path: '/proprietaryActivity',
    //   name: 'proprietaryActivity',
    //   component: Layout,
    //   meta: {
    //     title: '自营活动',
    //     icon: '',
    //   },
    //   children: [
    //     {
    //       path: '/proprietaryActivity/activityList',
    //       component: () => import('@/view//proprietaryActivity/activityList/index'),
    //       name: 'activityList',
    //       meta: {
    //         title: '砍价活动列表',
    //         icon: '',
    //         // keepAlive: true
    //       }
    //     },
    //     {
    //       path: '/proprietaryActivity/activityGoodsList/:id',
    //       component: () => import('@/view//proprietaryActivity/activityList/activityGoodsList'),
    //       name: 'activityGoodsList',
    //       hidden: true,
    //       meta: {
    //         title: '砍价商品列表',
    //         icon: '',
    //         // keepAlive: true
    //       }
    //     },
    //   ]
    // },
    // {
    //   path: '/selfOptCoupon',
    //   name: 'selfOptCoupon',
    //   component: Layout,
    //   meta: {
    //     title: '优惠券配置',
    //     icon: 'coupon_icon',
    //   },
    //   children: [
    //     {
    //       path: '/selfOptCoupon/couponList',
    //       component: () => import('@/view/selfOptCoupon/couponList/index'),
    //       name: 'selfOptCouponList',
    //       meta: {
    //         title: '优惠券列表',
    //         icon: 'coupon_icon',
    //       }
    //     },
    //     {
    //       path: '/selfOptCoupon/addCoupon',
    //       component: () => import('@/view/selfOptCoupon/addCoupon/index'),
    //       name: 'selfOptCouponAdd',
    //       hidden: true,
    //       meta: {
    //         title: '添加优惠券',
    //         icon: '',
    //       }
    //     },
    //   ]
    // }
    ]
   },
  );
}

