<!--<template>
  <Layout>
    <transition name="fade" mode="out-in">
      <router-view></router-view>
    </transition>
  </Layout>
</template>
<script type="text/babel">
  import Layout from 'component/layout/app/index.vue';
  export default {
    components: {
      Layout
    },
    mounted() {

    }
  };
</script>-->

<template>
  <div id="app">
    <!-- <router-view></router-view> -->
    <keep-alive>
      <router-view v-if="($route.meta && $route.meta.keepAlive)">
          <!-- 这里是会被缓存的视图组件，比如 page1,page2 -->
      </router-view>
    </keep-alive>

    <router-view v-if="!($route.meta && $route.meta.keepAlive)">
        <!-- 这里是不被缓存的视图组件，比如 page3 -->
    </router-view>
  </div>
</template>

<script>
export default {
  name: 'App'
};
</script>
