'use strict';
import Vue from 'vue';
import Vuex from 'vuex';
import app from './modules/app';
import user from './modules/user';
import actions from './actions';
import getters from './getters';
import mutations from './mutations';

Vue.use(Vuex);

export default function createStore(initState = {}) {

  const state = {
    articleList: [],
    article: {},
    ...initState
  };

  return new Vuex.Store({
    modules: {
      app,
      user,
      demo: {
        state,
        actions,
        getters: {},
        mutations
      }
    },
    getters
  });
}