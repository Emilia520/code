import request from 'utils/request_new';

// 获取省信息
export function getRegions() {
  return request({
    url: '/api/location/regions',
    method: 'get'
  });
}

