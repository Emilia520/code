import request from 'utils/request_new';

export function couponList(params) {
  return request({
    url: '/api/selfOptCoupon/list',
    method: 'post',
    data: params
  });
}

export function addCoupon(params) {
  return request({
    url: '/api/selfOptCoupon/addCoupon',
    method: 'post',
    data: params
  });
}

export function updateCoupon(params) {
  return request({
    url: '/api/selfOptCoupon/update',
    method: 'post',
    data: params
  });
}

export function productsOverallIDs(params) {
  return request({
    url: '/api/selfOptCoupon/productsOverallIDs',
    method: 'post',
    data: params
  });
}

export function couponAttachments(params) {
  return request({
    url: '/api/selfOptCoupon/attachment',
    method: 'post',
    data: params
  });
}

export function couponSearchKeywords(params) {
  return request({
    url: '/api/selfOptCoupon/couponSearchKeywords',
    method: 'post',
    data: params
  });
}
