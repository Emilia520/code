import request from 'utils/request_new';
export function reAccount(params) {
    return request({
      url: '/api/register/reAccount',
      method: 'post',
      data: params
    });
}
// export function reInformation(params) {
//   return request({
//     url: '/api/register/reInformation',
//     method: 'post',
//     data: params
//   });
// }

