import request from 'utils/request_new';

// 获取拉新情况数据
export function getNewerInfo(params) {
  return request({
    url: '/api/statistics/newerInfo',
    method: 'post',
    data: params
  });
}