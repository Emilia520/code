import request from 'utils/request_new';
export function historyList(params) {
    return request({
      url: '/api/exhistory/historyList',
      method: 'post',
      data: params
    });
}

export function selectAppiont(params) {
  return request({
    url: '/api/exhistory/selectAppiont',
    method: 'post',
    data: params
  });
}