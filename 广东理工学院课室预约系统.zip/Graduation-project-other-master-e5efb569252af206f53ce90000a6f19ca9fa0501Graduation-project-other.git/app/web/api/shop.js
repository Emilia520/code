import request from 'utils/request_new';

// 获取行业信息
export function getBusiness() {
  return request({
    url: '/api/shop/business',
    method: 'get'
  });
}

// 获取小店信息
export function getShopInfos(params) {
  return request({
    url: '/api/shop/infos',
    method: 'post',
    data: params
  });
}

// 导出小店信息
export function exportShop() {
  return request({
    url: '/api/shop/export',
    method: 'get'
  });
}
