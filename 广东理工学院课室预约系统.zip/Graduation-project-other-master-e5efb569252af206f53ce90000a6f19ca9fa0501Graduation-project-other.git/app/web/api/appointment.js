import request from 'utils/request_new';
export function insertTime(params) {
    return request({
      url: '/api/appointment/insertTime',
      method: 'post',
      data: params
    });
}
export function recordAppiont(params) {
  return request({
    url: '/api/appointment/recordAppiont',
    method: 'post',
    data: params
  });
}

export function judgeAppiont(params) {
  return request({
    url: '/api/appointment/judgeAppiont',
    method: 'post',
    data: params
  });
}
