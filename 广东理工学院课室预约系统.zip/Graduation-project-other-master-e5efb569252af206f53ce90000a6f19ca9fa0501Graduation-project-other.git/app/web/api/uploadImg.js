import config from 'config';
// import request from 'utils/request_new'

// export function uploadImg(params) {
//   return request({
//     url: '/hrz/rpc/admin/common/img/upload',
//     method: 'post',
//     params
//   })
// }

const uploadImg = config.API_HOST + '/api/image/upload';
const getImage = config.API_HOST + '/api/image/getImage';
const uploadImgNew = config.img_host + '/helper/uploadCdn';

export {
  uploadImg,
  getImage,
  uploadImgNew
};
