import request from 'utils/request_new';

// 批量结算
export function solveAllNewpullIncome(params) {
  return request({
    url: '/hrz/rpc/admin/tbLaixin/batchSettlement',
    method: 'post',
    params
  });
}

// 单个结算结算
export function solveNewpullIncome(params) {
  return request({
    url: '/hrz/rpc/admin/tbLaixin/settlementWithdraw',
    method: 'post',
    params
  });
}

// 筛选功能
export function selectNewpullIncome(params) {
  return request({
    url: '/hrz/rpc/admin/tbLaixin/list',
    method: 'get',
    params
  });
}
