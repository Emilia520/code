import request from 'utils/request_new';
// 获取商品列表
export function getGoodsList(data) {
  return request({
    url: '/api/tb1688/goodsList',
    method: 'post',
    data
  });
}
// 获取分类列表
export function getCatList() {
  return request({
    url: '/api/tb1688/catList',
    method: 'get'
  });
}