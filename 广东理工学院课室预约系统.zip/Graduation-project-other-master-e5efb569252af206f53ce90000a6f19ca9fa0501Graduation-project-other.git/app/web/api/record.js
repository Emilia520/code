import request from 'utils/request_new';
export function historyRecord(params) {
    return request({
      url: '/api/record/historyRecord',
      method: 'post',
      data: params
    });
}

export function updateState(params) {
  return request({
    url: '/api/record/updateState',
    method: 'post',
    data: params
  });
}

export function findRecord(params) {
  return request({
    url: '/api/record/findRecord',
    method: 'post',
    data: params
  });
}