import request from 'utils/request_new';
import constant from '../../utils/constant';

export function addChoiceList(listName) {
  return request({
    url: '/api/choiceList/addChoiceList',
    method: 'post',
    data: { list_name: listName },
  });
}

export function choiceList(listName) {
  return request({
    url: '/api/choiceList/choiceList',
    method: 'post',
    data: { list_name: listName },
  });
}

export function addToChoiceList(choiceList, itemList) {
  return request({
    url: '/api/choiceList/optChoiceListItem',
    method: 'post',
    data: {
      choice_list: choiceList,
      item_list: itemList,
      opt: constant.choiceListItemOpt.ADD
    },
  });
}

export function deleteChoiceList(choiceList) {
  return request({
    url: '/api/choiceList/deleteChoiceList',
    method: 'post',
    data: {
      choice_list: choiceList,
    },
  });
}

export function getDetail(data) {
  return request({
    url: '/api/choiceList/getDetail',
    method: 'post',
    data
  });
}

export function addCalendar(params) {
  return request({
    url: '/api/choiceList/addCalendar',
    method: 'post',
    params,
  });
}

export function choiceListCalendar(params) {
  return request({
    url: '/api/choiceList/choiceListCalendar',
    method: 'post',
    params,
  });
}