import request from 'utils/request_new';
export function listReord(params) {
    return request({
      url: '/api/appReord/listReord',
      method: 'post',
      data: params
    });
}

export function ownList(params) {
    return request({
      url: '/api/appReord/ownList',
      method: 'post',
      data: params
    });
}