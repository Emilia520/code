import request from 'utils/request_new';
// 获取拼多多官方商品列表
export function revokeMsg(data) {
  return request({
    url: '/api/robot/revokeMsg',
    method: 'post',
    data
  });
}

// 获取发送群消息列表
export function getGroupMsgList(data) {
  return request({
    url: '/api/robot/groupMsgList',
    method: 'post',
    data
  });
}

// 上传定时发送消息任务
export function uploadCalendarMsg(data) {
  return request({
    url: '/api/robot/uploadCalendarMsg',
    method: 'post',
    data
  });
}

// 生成推广信息
export function genPromotionInfo(data) {
  return request({
    url: '/api/robot/genPromotionInfo',
    method: 'post',
    data
  });
}

// 获取机器人列表
export function getRobotList() {
  return request({
    url: '/api/robot/list',
    method: 'get'
  });
}

// 添加机器人群
export function addGroup(data) {
  return request({
    url: '/api/robot/addGroup',
    method: 'post',
    data
  });
}

// 更新机器人群
export function updateGroup(data) {
  return request({
    url: '/api/robot/updateGroup',
    method: 'post',
    data
  });
}

// 获取机器人群分类信息
export function getGroupCategoryList() {
  return request({
    url: '/api/robot/groupCategory/get',
    method: 'get'
  });
}

// 更新机器人群分类信息
export function updateGroupCategoryInfo(data) {
  return request({
    url: '/api/robot/groupCategory/update',
    method: 'post',
    data
  });
}

// 添加机器人群分类信息
export function addGroupCategoryInfo(data) {
  return request({
    url: '/api/robot/groupCategory/add',
    method: 'post',
    data
  });
}

export function addRobotGroups(data) {
  return request({
    url: '/api/robot/addRobotGroups',
    method: 'post',
    data
  });
}

export function loadRobotGroupsForDB(data) {
  return request({
    url: '/api/robot/loadRobotGroupsForDB',
    method: 'post',
    data
  });
}