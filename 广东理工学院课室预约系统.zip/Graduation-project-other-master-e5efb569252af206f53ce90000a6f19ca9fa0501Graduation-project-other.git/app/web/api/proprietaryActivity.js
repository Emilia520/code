import request from 'utils/request_new';

export function getActivityList(params) {
  return request({
    url: '/api/proprietaryActivity/getActivityList',
    method: 'post',
    data: params
  });
}
export function getActivityListById(params) {
  return request({
    url: '/api/proprietaryActivity/getActivityListById',
    method: 'post',
    data: params
  });
}

export function updateActivityListById(params) {
  return request({
    url: '/api/proprietaryActivity/updateActivityListById',
    method: 'post',
    data: params
  });
}
export function createActivity(params) {
  return request({
    url: '/api/proprietaryActivity/createActivity',
    method: 'post',
    data: params
  });
}
export function getGoodsList(params) {
  return request({
    url: '/api/proprietaryActivity/getGoodsList',
    method: 'post',
    data: params
  });
}
export function getGoodsById(params) {
  return request({
    url: '/api/proprietaryActivity/getGoodsById',
    method: 'post',
    data: params
  });
}
export function updateGoods(params) {
  return request({
    url: '/api/proprietaryActivity/updateGoods',
    method: 'post',
    data: params
  });
}

export function deleteGoods(params) {
  return request({
    url: '/api/proprietaryActivity/deleteGoods',
    method: 'post',
    data: params
  });
}
export function createGoods(params) {
  return request({
    url: '/api/proprietaryActivity/createGoods',
    method: 'post',
    data: params
  });
}
export function checkGoods(params) {
  return request({
    url: '/api/proprietaryActivity/checkGoods',
    method: 'post',
    data: params
  });
}
export function updateActivityListRoleById(params) {
  return request({
    url: '/api/proprietaryActivity/updateActivityListRoleById',
    method: 'post',
    data: params
  });
}

