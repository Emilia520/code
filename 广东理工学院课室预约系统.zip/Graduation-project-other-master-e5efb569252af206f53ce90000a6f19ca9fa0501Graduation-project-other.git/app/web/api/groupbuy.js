import request from 'utils/request_new';
// 获取校品团活动分类
export function getCatList() {
  return request({
    url: '/api/groupbuy/actcats',
    method: 'post',
  });
}
// 获取活动列表
export function getActivityList(params) {
  return request({
    url: '/api/groupbuy/actList',
    method: 'post',
    data: params
  });
}
// 置顶某个活动
export function stickActivity(params) {
  return request({
    url: '/api/groupbuy/stick',
    method: 'post',
    data: params
  });
}
// 更新上下架状态
export function updateSaleState(params) {
  return request({
    url: '/api/groupbuy/updateSaleState',
    method: 'post',
    data: params
  });
}
// 更新商品上下架状态
export function updateSaleStateOnGoods(params) {
  return request({
    url: '/api/groupbuy/updateSaleStateOnGoods',
    method: 'post',
    data: params
  });
}
// 更新活动排序
export function updateActivitySort(params) {
  return request({
    url: '/api/groupbuy/updateActivitySort',
    method: 'post',
    data: params
  });
}
// 获取商品列表
export function getGoodsList(params) {
  return request({
    url: '/api/groupbuy/goodsList',
    method: 'post',
    data: params
  });
}
// 更新商品价格信息
export function updateGoodsInfo(params) {
  return request({
    url: '/api/groupbuy/updateGoodsInfo',
    method: 'post',
    data: params
  });
}
// 添加爆款
export function addHotGoods(params) {
  return request({
    url: '/api/groupbuy/addHot',
    method: 'post',
    data: params
  });
}
// 取消爆款
export function delHotGoods(params) {
  return request({
    url: '/api/groupbuy/delHot',
    method: 'post',
    data: params
  });
}
// 获取售后订单列表
export function afterSaleList(params) {
  return request({
    url: '/api/groupbuy/afterSale/list',
    method: 'post',
    data: params
  });
}

// 创建爆款品牌栏目
export function createHotGoodsList(params) {
  return request({
    url: '/api/groupbuy/createHotGoodsList',
    method: 'post',
    data: params
  });
}

// 删除爆款列表
export function delGoodsHotList(params) {
  return request({
    url: '/api/groupbuy/delGoodsHotList',
    method: 'post',
    data: params
  });
}
// 删除爆款列表
export function deleteGoodsHotList(params) {
  return request({
    url: '/api/groupbuy/deleteGoodsHotList',
    method: 'post',
    data: params
  });
}
// 删除爆款列表
export function addGoodsHotList(params) {
  return request({
    url: '/api/groupbuy/addGoodsHotList',
    method: 'post',
    data: params
  });
}
// 更新爆款列表
export function updateSortGoodsHotList(params) {
  return request({
    url: '/api/groupbuy/updateSortGoodsHotList',
    method: 'post',
    data: params
  });
}
// 更新爆款列表
export function updateGoodsHotList(params) {
  return request({
    url: '/api/groupbuy/updateGoodsHotList',
    method: 'post',
    data: params
  });
}
// 更新分享列表
export function updateShareHotList(params) {
  return request({
    url: '/api/groupbuy/updateShareHotList',
    method: 'post',
    data: params
  });
}
// 创建分享列表
export function createShareHotList(params) {
  return request({
    url: '/api/groupbuy/createShareHotList',
    method: 'post',
    data: params
  });
}
// 查询活动列表
export function selectActivity(params) {
  return request({
    url: '/api/groupbuy/selectActivity',
    method: 'post',
    data: params
  });
}
// 单品文案分享
export function selectShare(params) {
  return request({
    url: '/api/groupbuy/selectShare',
    method: 'post',
    data: params
  });
}
// 更新添加活动
export function andHotAct(params) {
  return request({
    url: '/api/groupbuy/andHotAct',
    method: 'post',
    data: params
  });
}
// 删除商品列表的某个商品
export function delGoods(params) {
  return request({
    url: '/api/groupbuy/delGoods',
    method: 'post',
    data: params
  });
}
// 查找爆款列表
export function findGoodsHotList(params) {
  return request({
    url: '/api/groupbuy/findGoodsHotList',
    method: 'post',
    data: params
  });
}
// 添加爆款列表商品
export function addGoodsToHotList(params) {
  return request({
    url: '/api/groupbuy/addGoodsToHotList',
    method: 'post',
    data: params
  });
}
// 添加爆款列表商品
export function findHotGoods(params) {
  return request({
    url: '/api/groupbuy/findHotGoods',
    method: 'post',
    data: params
  });
}
// 通过售后审核
export function approveAfterSale(params) {
  return request({
    url: '/api/groupbuy/afterSale/approve',
    method: 'post',
    data: params
  });
}
// 拒绝售后审核
export function rejectAfterSale(params) {
  return request({
    url: '/api/groupbuy/afterSale/reject',
    method: 'post',
    data: params
  });
}
// 拒绝售后审核
export function updateAfterSaleImages(params) {
  return request({
    url: '/api/groupbuy/afterSale/updateImages',
    method: 'post',
    data: params
  });
}
// 拒绝售后审核
export function uploadLogistics(params) {
  return request({
    url: '/api/groupbuy/afterSale/uploadLogistics',
    method: 'post',
    data: params
  });
}
// 售后退款
export function refundAfterSale(params) {
  return request({
    url: '/api/groupbuy/afterSale/refund',
    method: 'post',
    data: params
  });
}

// 售后退款
export function updateActivityAddPriceRatio(params) {
  return request({
    url: '/api/groupbuy/updateActivityRatio',
    method: 'post',
    data: params
  });
}

// 售后原因列表
export function afterSaleReasonList() {
  return request({
    url: '/api/groupbuy/afterSale/reasons',
    method: 'post',
  });
}

// 更新订单状态
export function updateOrderStatus(params) {
  return request({
    url: '/api/groupbuy/updateOrderAfterSaleStatus',
    method: 'post',
    data: params,
  });
}

// 更新商家寄回单号
export function updateStoreDeliveryInfo(params) {
  return request({
    url: '/api/groupbuy/afterSale/updateDeliveryInfo',
    method: 'post',
    data: params,
  });
}

export function updateSellerDeliveryInfo(params) {
  return request({
    url: '/api/groupbuy/afterSale/updateSellerDeliveryInfo',
    method: 'post',
    data: params,
  });
}

export function updateACKAfterSaleOrder(params) {
  return request({
    url: '/api/groupbuy/afterSale/update',
    method: 'post',
    data: params,
  });
}

export function updateMiniProgramVisibility(params) {
  return request({
    url: '/api/groupbuy/updateActivityWxVisibility',
    method: 'post',
    data: params,
  });
}

export function getMiniProgramGroupVisibility(params) {
  return request({
    url: '/api/groupbuy/getMiniProgramGroupVisibility',
    method: 'post',
    data: params,
  });
}

export function updateTag(params) {
  return request({
    url: '/api/groupbuy/updateTag',
    method: 'post',
    data: params,
  });
}

// 所有活动时间范围内活动的有效商品列表
export function allOnSaleGoods(params) {
  return request({
    url: '/api/groupbuy/allOnSaleGoods',
    method: 'post',
    data: params,
  });
}

export function restartAfterSale(params) {
  return request({
    url: '/api/groupbuy/restartAfterSale',
    method: 'post',
    data: params,
  });
}

export function applyAfterSale(data) {
  return request({
    url: '/api/groupbuy/applyAfterSale',
    method: 'post',
    data,
  });
}

export function cancelAfterSale(data) {
  return request({
    url: '/api/groupbuy/cancelAfterSale',
    method: 'post',
    data,
  });
}

export function alreadyRefund(data) {
  return request({
    url: '/api/groupbuy/alreadyRefund',
    method: 'post',
    data,
  });
}

export function listCaptainGoods(data) {
  return request({
    url: '/api/groupbuy/listCaptainGoods',
    method: 'post',
    data,
  });
}

export function updateCaptainGoods(data) {
  return request({
    url: '/api/groupbuy/updateCaptainGoods',
    method: 'post',
    data,
  });
}

export function createCaptainGoods(data) {
  return request({
    url: '/api/groupbuy/createCaptainGoods',
    method: 'post',
    data,
  });
}

export function listOwnActNoOwnGoodsAct(data) {
  return request({
    url: '/api/groupbuy/listOwnActNoOwnGoodsAct',
    method: 'post',
    data,
  });
}

export function updateOwnActNoOwnGoodsAct(data) {
  return request({
    url: '/api/groupbuy/updateOwnActNoOwnGoodsAct',
    method: 'post',
    data,
  });
}

export function createOwnActNoOwnGoodsAct(data) {
  return request({
    url: '/api/groupbuy/createOwnActNoOwnGoodsAct',
    method: 'post',
    data,
  });
}

export function listTag(data) {
  return request({
    url: '/api/groupbuy/listTag',
    method: 'post',
    data,
  });
}

export function listTagForWXMiniProgram(data) {
  return request({
    url: '/api/groupbuy/listTagForWXMiniProgram',
    method: 'post',
    data,
  });
}

export function listBrand(data) {
  return request({
    url: '/api/groupbuy/listBrand',
    method: 'post',
    data,
  });
}

export function createBrand(data) {
  return request({
    url: '/api/groupbuy/createBrand',
    method: 'post',
    data,
  });
}

export function createNoOwnGoods(data) {
  return request({
    url: '/api/groupbuy/createNoOwnGoods',
    method: 'post',
    data,
  });
}

export function productForAfterSaleOrder(data) {
  return request({
    url: '/api/groupbuy/productForAfterSaleOrder',
    method: 'post',
    data,
  });
}

export function listOwnActGoods(data) {
  return request({
    url: '/api/groupbuy/listOwnActGoods',
    method: 'post',
    data,
  });
}

export function updateGoodsSort(data) {
  return request({
    url: '/api/groupbuy/updateGoodsSort',
    method: 'post',
    data,
  });
}

export function deleteGoodsSort(data) {
  return request({
    url: '/api/groupbuy/deleteGoodsSort',
    method: 'post',
    data,
  });
}

export function batchGoodsBindOwnBrand(data) {
  return request({
    url: '/api/groupbuy/batchGoodsBindOwnBrand',
    method: 'post',
    data,
  });
}

export function ownActOwnGoodsActList(data) {
  return request({
    url: '/api/groupbuy/ownActOwnGoodsActList',
    method: 'post',
    data,
  });
}

export function ownActAdd(data) {
  return request({
    url: '/api/groupbuy/ownActAdd',
    method: 'post',
    data,
  });
}

export function ownActOwnGoodsList(data) {
  return request({
    url: '/api/groupbuy/ownActOwnGoodsList',
    method: 'post',
    data,
  });
}

export function ownGoodsAdd(data) {
  return request({
    url: '/api/groupbuy/ownGoodsAdd',
    method: 'post',
    data,
  });
}

export function ownGoodsSkuSee(data) {
  return request({
    url: '/api/groupbuy/ownGoodsSkuSee',
    method: 'post',
    data,
  });
}

export function ownGoodsSkuEdit(data) {
  return request({
    url: '/api/groupbuy/ownGoodsSkuEdit',
    method: 'post',
    data,
  });
}

export function ownGoodsSkuAdd(data) {
  return request({
    url: '/api/groupbuy/ownGoodsSkuAdd',
    method: 'post',
    data,
  });
}

export function ownGoodsEdit(data) {
  return request({
    url: '/api/groupbuy/ownGoodsEdit',
    method: 'post',
    data,
  });
}