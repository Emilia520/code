import request from 'utils/request_new';

export function getSeckillList(params) {
  return request({
    url: '/api/seckill/list',
    method: 'post',
    data: params
  });
}

export function createSeckillLists(params) {
  return request({
    url: '/api/seckill/create',
    method: 'post',
    data: params
  });
}

export function addProductToSeckillList(params) {
  return request({
    url: '/api/seckill/addProduct',
    method: 'post',
    data: params
  });
}

export function updateProductInSeckillList(params) {
  return request({
    url: '/api/seckill/updateProduct',
    method: 'post',
    data: params
  });
}

export function removeProductFromSeckillList(params) {
  return request({
    url: '/api/seckill/removeProduct',
    method: 'post',
    data: params
  });
}

