import request from 'utils/request_new';
export function userAppiont(params) {
    return request({
      url: '/api/examine/userAppiont',
      method: 'post',
      data: params
    });
}

export function successAppiont(params) {
    return request({
      url: '/api/examine/successAppiont',
      method: 'post',
      data: params
    });
}

export function failedAppiont(params) {
  return request({
    url: '/api/examine/failedAppiont',
    method: 'post',
    data: params
  });
}

export function selectOther(params) {
  return request({
    url: '/api/examine/selectOther',
    method: 'post',
    data: params
  });
}