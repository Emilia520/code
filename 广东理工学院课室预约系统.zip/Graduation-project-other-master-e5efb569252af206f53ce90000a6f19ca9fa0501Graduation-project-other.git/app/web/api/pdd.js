import request from 'utils/request_new';
// 获取拼多多官方商品列表
export function getGoodsList(data) {
  return request({
    url: '/api/pdd/goodsList',
    method: 'post',
    data
  });
}

// 获取拼多多商品标签类目列表
export function getOptList(data) {
  return request({
    url: '/api/pdd/optList',
    method: 'post',
    data
  });
}

// 获取拼多多商品类目列表
export function getCategoryList(data) {
  return request({
    url: '/api/pdd/categoryList',
    method: 'post',
    data
  });
}

// 获取拼多多商品类目列表
export function sendGroupMsgImmediately(data) {
  return request({
    url: '/api/pdd/sendRealtimeMsg',
    method: 'post',
    data
  });
}

// 上传定时发送消息任务
export function uploadRobotMsg(data) {
  return request({
    url: '/api/pdd/uploadRobotMsg',
    method: 'post',
    data
  });
}

// 获取拼多多主题推广列表
export function getThemeList(data) {
  return request({
    url: '/api/pdd/themeList',
    method: 'post',
    data
  });
}

// 获取拼多多单主题推广商品详情列表
export function getThemeGoodsList(data) {
  return request({
    url: '/api/pdd/themeGoodsList',
    method: 'post',
    data
  });
}

// 获取拼多多单订单数据列表
export function getOrderData(data) {
  return request({
    url: '/api/pdd/getOrderData',
    method: 'post',
    data
  });
}

// 获取拼多多单订单状态数据列表
export function getOrderStatusData(data) {
  return request({
    url: '/api/pdd/getOrderStatusData',
    method: 'post',
    data
  });
}

// 获取拼多多单订单概要数据列表
export function getPddOrderChartData(data) {
  return request({
    url: '/api/pdd/orderChartData',
    method: 'post',
    data
  });
}

// 获取机器人群相关信息
export function getWXGroupInfo(data) {
  return request({
    url: '/api/pdd/getWXGroupInfo',
    method: 'post',
    data
  });
}