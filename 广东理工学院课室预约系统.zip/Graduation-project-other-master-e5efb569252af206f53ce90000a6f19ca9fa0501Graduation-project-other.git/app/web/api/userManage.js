import request from 'utils/request_new';

// 用户信息展示查询
export function getUserMessage(params) {
  return request({
    // url: '/hrz/rpc/admin/account/findAccountInfo',
    url: '/api/user/info',
    method: 'get',
    params
  });
}

// 用户升级订单查询
export function getUserUpdate(params) {
  return request({
    url: '/hrz/rpc/admin/walletOrderUpgrade/list',
    method: 'get',
    params
  });
}

// 用户升级
export function upQxbCaptain(params) {
  return request({
    url: '/api/user/upQxbCaptain',
    method: 'post',
    data: params
  });
}

// 用户升级合伙人
export function upQxbPartner(params) {
  return request({
    url: '/api/user/upQxbPartner',
    method: 'post',
    data: params
  });
}

// 获取省市区
export function findRegion(params) {
  return request({
    url: '/api/user/findRegion',
    method: 'post',
    data: params
  });
}
// 检查邀请码
export function checkCode(params) {
  return request({
    url: '/api/user/checkCode',
    method: 'post',
    data: params
  });
}

// 检查手机号
export function checkPhone(params) {
  return request({
    url: '/api/user/checkPhone',
    method: 'post',
    data: params
  });
}

// 创建用户
export function createUser(params) {
  return request({
    url: '/api/user/createUser',
    method: 'post',
    data: params
  });
}

// 订单和收益
export function getOrderIncome(params) {
  return request({
    url: '/hrz/rpc/admin/orderUser/list',
    method: 'get',
    params
  });
}

