import request from 'utils/request_new';
// 获取有效群列表
export function getWXGroupList() {
  return request({
    url: '/api/yjiyun/wxGroupList',
    method: 'get',
  });
}

// 获取机器人关联的微信群
export function queryRobotGroups(data) {
  return request({
    url: '/api/yjiyun/queryRobotGroups',
    method: 'post',
    data
  });
}

