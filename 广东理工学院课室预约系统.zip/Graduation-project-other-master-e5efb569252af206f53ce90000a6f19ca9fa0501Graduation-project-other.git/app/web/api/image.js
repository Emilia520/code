import request from 'utils/request_new';

// 生成团购海报
export function genGroupbuyPoster(params) {
  return request({
    url: '/api/image/genGroupbuyPoster',
    method: 'post',
    data: params
  });
}