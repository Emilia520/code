import request from 'utils/request_new';

// 修改FiveEnter
export function editInfomation(params) {
  return request({
    url: '/api/infomation/replace',
    method: 'post',
    params
  });
}

// 新增FiveEnter
export function addInfomation(params) {
  return request({
    url: '/api/infomation/replace',
    method: 'post',
    params
  });
}

// 删除FiveEnter
export function deleteInfomation(params) {
  return request({
    url: '/api/infomation/delete',
    method: 'post',
    params
  });
}

// 筛选功能
// export function selectFiveEnter(params) {
//   return request({
//     url: '/hrz/rpc/admin/entrance/findEntrancePage',
//     method: 'get',
//     params
//   });
// }

// 获取单个FiveEnter信息
// export function getOneFiveEnter(params) {
//   return request({
//     url: '/hrz/rpc/admin/entrance/findOneEntrance',
//     method: 'get',
//     params
//   });
// }
