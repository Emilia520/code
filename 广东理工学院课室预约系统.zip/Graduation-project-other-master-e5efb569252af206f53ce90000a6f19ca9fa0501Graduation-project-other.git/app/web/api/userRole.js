import request from 'utils/request_new';
export function userInfo(params) {
    return request({
      url: '/api/userRole/userInfo',
      method: 'post',
      data: params
    });
}

export function selectInfo(params) {
  return request({
    url: '/api/userRole/selectInfo',
    method: 'post',
    data: params
  });
}

export function userRecord(params) {
  return request({
    url: '/api/userRole/userRecord',
    method: 'post',
    data: params
  });
}