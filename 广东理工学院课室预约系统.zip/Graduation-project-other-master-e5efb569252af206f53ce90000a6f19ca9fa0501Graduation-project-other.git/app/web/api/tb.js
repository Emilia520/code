import request from 'utils/request_new';
// 获取淘宝官方商品列表
export function getGoodsList(data) {
  return request({
    url: '/api/tb/goodsList',
    method: 'post',
    data
  });
}
// 获取淘宝热销高佣商品列表
export function getHotSaleList(data) {
  return request({
    url: '/api/tb/hotSaleList',
    method: 'post',
    data
  });
}
// 获取淘宝订单概要数据列表
export function getTbOrderChartData(data) {
  return request({
    url: '/api/tb/orderChartData',
    method: 'post',
    data
  });
}
