import request from 'utils/request_new';

// 创建售后订单
export function createBill(params) {
  return request({
    url: '/api/aikucun/afterSale/create',
    method: 'post',
    data: params
  });
}
// 查询售后订单
export function queryBill(params) {
  return request({
    url: '/api/aikucun/afterSale/query',
    method: 'post',
    data: params
  });
}
