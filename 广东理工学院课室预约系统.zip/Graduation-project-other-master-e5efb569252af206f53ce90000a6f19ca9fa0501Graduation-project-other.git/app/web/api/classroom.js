import request from 'utils/request_new';
export function checkClass(params) {
    return request({
      url: '/api/classroom/checkClass',
      method: 'post',
      data: params
    });
}
export function deletClass(params) {
  return request({
    url: '/api/classroom/deletClass',
    method: 'post',
    data: params
  });
}

export function addClass(params) {
  return request({
    url: '/api/classroom/addClass',
    method: 'post',
    data: params
  });
}

export function selectAll(params) {
  return request({
    url: '/api/classroom/selectAll',
    method: 'post',
    data: params
  });
}

export function updateState(params) {
  return request({
    url: '/api/classroom/updateState',
    method: 'post',
    data: params
  });
}