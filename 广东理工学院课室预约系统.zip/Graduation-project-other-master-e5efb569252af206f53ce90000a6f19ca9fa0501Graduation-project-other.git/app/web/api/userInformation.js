import request from 'utils/request_new';
export function searchMs(params) {
    return request({
      url: '/api/userInformation/searchMs',
      method: 'post',
      data: params
    });
}

export function changeMS(params) {
  return request({
    url: '/api/userInformation/changeMS',
    method: 'post',
    data: params
  });
}

export function updatePs(params) {
  return request({
    url: '/api/userInformation/updatePs',
    method: 'post',
    data: params
  });
}