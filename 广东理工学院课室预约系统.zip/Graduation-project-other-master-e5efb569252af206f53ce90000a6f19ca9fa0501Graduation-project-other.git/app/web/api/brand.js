import request from 'utils/request_new';

// 品牌列表
export function brandList(params) {
  return request({
    url: '/api/groupbuy/brand/brandList',
    method: 'post',
    data: params
  });
}

export function brandTypes() {
  return request({
    url: '/api/groupbuy/brand/brandTypes',
    method: 'post'
  });
}

export function labelList() {
  return request({
    url: '/api/groupbuy/brand/brandLebals',
    method: 'post'
  });
}

export function brandListAddTag() {
  return request({
    url: '/api/groupbuy/brand/brandListAddTag',
    method: 'post'
  });
}

export function _brandInfo(params) {
  return request({
    url: '/api/groupbuy/brand/brandInfo',
    method: 'post',
    data: params
  });
}

export function noAddBrandDBList(params) {
  return request({
    url: '/api/groupbuy/brand/noAddBrandDBList',
    method: 'post',
    data: params
  });
}

export function brandInfo(params) {
  return request({
    url: '/api/groupbuy/brand/brandInfo',
    method: 'post',
    data: params
  });
}
export function brandLebals(params) {
  return request({
    url: '/api/groupbuy/brand/brandLebals',
    method: 'post',
    data: params
  });
}

export function _listTag() {
  return request({
    url: '/api/groupbuy/brand/listTag',
    method: 'post'
  });
}

export function _brandMVBanned(params) {
  return request({
    url: '/api/groupbuy/brand/brandMVBanned',
    method: 'post',
    data: params
  });
}

export function brandCreate(params) {
  return request({
    url: '/api/groupbuy/brand/brandCreate',
    method: 'post',
    data: params
  });
}

export function listTag(params) {
  return request({
    url: '/api/groupbuy/brand/listTag',
    method: 'post',
    data: params
  });
}

export function _brandListAddTag(params) {
  return request({
    url: '/api/groupbuy/brand/brandListAddTag',
    method: 'post',
    data: params
  });
}

export function _brandUpdate(params) {
  return request({
    url: '/api/groupbuy/brand/brandUpdate',
    method: 'post',
    data: params
  });
}

export function _brandBind(params) {
  return request({
    url: '/api/groupbuy/brand/brandBind',
    method: 'post',
    data: params
  });
}

export function getTagName(params) {
  return request({
    url: '/api/groupbuy/brand/getTagName',
    method: 'post',
    data: params
  });
}

export function searchName(params) {
  return request({
    url: '/api/groupbuy/brand/searchName',
    method: 'post',
    data: params
  });
}

export function noAddGetInformtion(params) {
  return request({
    url: '/api/groupbuy/brand/noAddGetInformtion',
    method: 'post',
    data: params
  });
}

export function deleteSinceBrand(params) {
  return request({
    url: '/api/groupbuy/brand/deleteSinceBrand',
    method: 'post',
    data: params
  });
}

export function getMd5(params) {
  return request({
    url: '/api/groupbuy/brand/getMd5',
    method: 'post',
    data: params
  });
}

export function sendMessage(params) {
  return request({
    url: '/api/groupbuy/brand/sendMessage',
    method: 'post',
    data: params
  });
}