import request from 'utils/request_new';

// 修改banner
export function editBanner(params) {
  return request({
    url: '/api/home/banner/update',
    method: 'post',
    data: params
  });
}

// 获得当前版本信息
export function getClient(params) {
  return request({
    url: '/api/home/getClient',
    method: 'post',
    data: params
  });
}

// 获得当前版本banner信息
export function getBannerList(params) {
  return request({
    url: '/api/home/getBannerList',
    method: 'post',
    data: params
  });
}

// 创建当前版本
export function createClientList(params) {
  return request({
    url: '/api/home/createClientList',
    method: 'post',
    data: params
  });
}

// 获得当前版本banner信息
export function createBannerList(params) {
  return request({
    url: '/api/home/createBannerList',
    method: 'post',
    data: params
  });
}

// 删除当前版本banner信息
export function updateBannerList(params) {
  return request({
    url: '/api/home/updateBannerList',
    method: 'post',
    data: params
  });
}

// 当前版本banner信息
export function getBannerById(params) {
  return request({
    url: '/api/home/getBannerById',
    method: 'post',
    data: params
  });
}

// 編輯当前banner信息
export function editBannerList(params) {
  return request({
    url: '/api/home/editBannerList',
    method: 'post',
    data: params
  });
}

// 获得当前版本banner信息
export function getBanner(params) {
  return request({
    url: '/api/home/getBanner',
    method: 'post',
    data: params
  });
}

// 获得redis信息
export function getRedisKeys(params) {
  return request({
    url: '/api/home/getRedisKeys',
    method: 'post',
    data: params
  });
}
// 删除rediskey
export function delRedisKeys(params) {
  return request({
    url: '/api/home/delRedisKeys',
    method: 'post',
    data: params
  });
}

// 修改版本信息
export function updateClient(params) {
  return request({
    url: '/api/home/updateClient',
    method: 'post',
    data: params
  });
}

// 新增banner
export function addBanner(params) {
  return request({
    url: '/api/home/banner/add',
    method: 'post',
    data: params
  });
}

// 删除banner
export function deleteBanner(params) {
  return request({
    url: '/api/home/banner/delete',
    method: 'get',
    params
  });
}

// 筛选功能
export function selectBanner(params) {
  return request({
    url: '/api/home/banner',
    method: 'post',
    data: params
  });
}
