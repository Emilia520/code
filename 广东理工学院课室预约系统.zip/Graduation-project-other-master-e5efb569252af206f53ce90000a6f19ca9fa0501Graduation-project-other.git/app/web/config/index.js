export default {
  API_HOST: process.env.NODE_ENV === 'development' ? 'http://' + window.location.host : 'https://' + window.location.host,
  img_host: 'https://xttapi.lexj.com',
  coupon_host: 'https://api.fenxianglife.com',
  java_host: process.env.NODE_ENV === 'development' ? 'https://apitest.quexb.com' : 'https://xttapi.lexj.com',
};
