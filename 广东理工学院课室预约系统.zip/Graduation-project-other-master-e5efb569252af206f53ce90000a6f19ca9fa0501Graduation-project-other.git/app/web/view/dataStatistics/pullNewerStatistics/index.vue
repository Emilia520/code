<template>
  <div class="app-container">
    <el-row>
      <el-col :span="24">
        <div class="header-title">拉新数据</div>
      </el-col>
      <el-col :span="24">
        <el-tabs @tab-click="onTabClick" style="height: 50px;">
            <el-tab-pane label="淘宝拉新"></el-tab-pane>
            <el-tab-pane label="天猫拉新"></el-tab-pane>
            <el-tab-pane label="支付宝拉新"></el-tab-pane>
            <el-tab-pane label="京东白条拉新"></el-tab-pane>
            <el-tab-pane label="电信卡拉新"></el-tab-pane>
        </el-tabs>
      </el-col>
      <!-- 筛选条件 start -->
      <el-col :span="24">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
            <el-form-item label="活动名称">
              <el-select v-model="formInline.activity_id" size="mini" placeholder="请选择">
                <el-option
                    v-for="item in activities"
                    :key="item.id"
                    :label="item.label"
                    :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="推广状态">
              <el-select v-model="formInline.action_id" size="mini" placeholder="请选择">
                <el-option
                    v-for="item in actions"
                    :key="item.id"
                    :label="item.label"
                    :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="会员所在地">
                <el-select v-model="formInline.sel_provinces" 
                    size="mini" 
                    value-key="id" 
                    multiple 
                    collapse-tags
                    placeholder="请选择省" 
                    @visible-change="onProvinceVisibleChange">
                    <el-option
                        v-for="item in regions"
                        :key="item.id"
                        :label="item.province"
                        :value="item">
                    </el-option>
                </el-select>

                <el-select v-model="formInline.sel_cities"
                    size="mini"
                    value-key="id"
                    @visible-change="onCityVisibleChange"
                    multiple
                    collapse-tags
                    style="margin-left: 20px;"
                    placeholder="请选择市">
                    <el-option
                        v-for="item in cities"
                        :key="item.id"
                        :label="item.city"
                        :value="item">
                    </el-option>
                </el-select>

                <el-select
                    v-model="formInline.sel_areas"
                    size="mini"
                    value-key="id"
                    @visible-change="onAreaVisibleChange"
                    multiple
                    collapse-tags
                    style="margin-left: 20px;"
                    placeholder="请选择区">
                    <el-option
                        v-for="item in areas"
                        :key="item.id"
                        :label="item.area"
                        :value="item">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="会员手机">
                <el-input v-model="formInline.phone" placeholder="手机号码" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="会员等级">
                <el-select v-model="formInline.role_id" placeholder="请选择" size="mini">
                    <el-option label="所有等级" value=""></el-option>
                    <el-option label="超级会员Lv1" value="1"></el-option>
                    <el-option label="超级会员Lv2" value="2"></el-option>
                    <el-option label="合伙人" value="3"></el-option>
                    <el-option label="校园合伙人" value="4"></el-option>
                    <el-option label="校园大使" value="5"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" size="mini" @click="onSubmit">筛选</el-button>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" size="mini" @click="onDownload">下载表格</el-button>
            </el-form-item>
        </el-form>
      </el-col>
      <!-- 筛选条件 end -->
      <!-- 表格 start -->
      <el-col :span="24">
        <el-table
          :data="tableData"
          border
          style="width: 100%"
          v-loading="loading">
          <el-table-column
            label="会员id"
            width="80">
            <template slot-scope="scope">
              <div>{{scope.row.id}}</div>
            </template>
          </el-table-column>
          <el-table-column
            label="会员所在地"
            width="160">
            <template slot-scope="scope">
              <div>{{scope.row.province}}-{{scope.row.city}}-{{scope.row.area}}</div>
            </template>
          </el-table-column>
          <el-table-column
            label="会员昵称"
            width="120">
            <template slot-scope="scope">
              <div>{{scope.row.name}}</div>
            </template>
          </el-table-column>
          <el-table-column
            label="会员手机"
            width="120">
            <template slot-scope="scope">
              <div>{{scope.row.phone}}</div>
            </template>
          </el-table-column>
          <el-table-column
            label="会员角色"
            width="120">
            <template slot-scope="scope">
              <div v-if="scope.row.role_id==1">超级会员Lv1</div>
              <div v-else-if="scope.row.role_id==2">超级会员Lv2</div>
              <div v-else-if="scope.row.role_id==3">合伙人</div>
              <div v-else-if="scope.row.role_id==4">校园合伙人</div>
              <div v-else-if="scope.row.role_id==5">校园大使</div>
            </template>
          </el-table-column>
          <el-table-column
            label="会员邀请码"
            width="120">
            <template slot-scope="scope">
              <div>{{scope.row.code}}</div>
            </template>
          </el-table-column>
          <el-table-column
            prop="mobile"
            label="被推广者手机"
            width="120">
          </el-table-column>
          <el-table-column
            label="推广明细"
            width="300">
            <template slot-scope="scope">
              <div v-for="value in scope.row.detail.split(',')">{{value}}</div>
            </template>
          </el-table-column>
        </el-table>     
      </el-col>
      <!-- 表格 end -->
      <!-- 分页 start -->
      <el-col :span="24">
        <div class="pagination" style="margin-top:20px;">
          <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="formInline.pageNum" :page-sizes="[10, 20, 30, 40]" :page-size="formInline.pageSize" layout="total, sizes, prev, pager, next" :total="totalcount">
          </el-pagination>
        </div>
      </el-col>
      <!-- 分页 end -->
    </el-row>
  </div>
</template>

<script>
import { getNewerInfo } from '@/api/statistics';
import { getRegions } from '@/api/location';
import { timestampToTime } from 'utils/chanageTime';

export default {
  data() {
    return {
      tbActions: [{ id: 1, label: '注册', value: 1 },
        { id: 2, label: '激活', value: 2 },
        { id: 3, label: '首购', value: 3 },
        { id: 4, label: '收货', value: 4 },
        { id: 5, label: '绑卡', value: 15 },
        { id: 6, label: '所有状态', value: '' }],
      tmActions: [{ id: 1, label: '领取红包', value: 5 },
        { id: 2, label: '收购', value: 6 },
        { id: 3, label: '确认收货', value: 7 },
        { id: 4, label: '所有状态', value: '' }],
      alipayActions: [{ id: 1, label: '首登', value: 13 },
        { id: 2, label: '实名', value: 14 },
        { id: 3, label: '所有状态', value: '' }],
      jdActions: [{ id: 1, label: '激活', value: 16 },
        { id: 2, label: '所有状态', value: '' }],
      ctccActions: [{ id: 1, label: '激活', value: 20 },
        { id: 2, label: '所有状态', value: '' }],
      actions: [],
      tbActivities: [{ id: 1, label: '2018淘宝11月拉新', value: 1 },
        { id: 2, label: '2018淘宝12月拉新', value: 5 },
        { id: 3, label: '所有活动', value: '' }],
      tmActivities: [{ id: 1, label: '2018天猫11月拉新', value: 3 },
        { id: 2, label: '2018天猫12月拉新', value: 7 },
        { id: 3, label: '所有活动', value: '' }],
      alipayActivities: [{ id: 1, label: '2018支付宝11月拉新', value: 2 },
        { id: 2, label: '2018支付宝12月拉新', value: 6 },
        { id: 3, label: '所有活动', value: '' }],
      jdActivities: [{ id: 1, label: '2018京东11月拉新', value: 4 },
        { id: 2, label: '2018京东白条12月拉新', value: 8 },
        { id: 3, label: '所有活动', value: '' }],
      ctccActivities: [{ id: 1, label: '2018电信卡12月拉新', value: 12 },
        { id: 2, label: '所有活动', value: '' }],
      ativities: [],
      totalcount: 0,
      loading: false,
      formInline: {
        action_id: '',
        activity_id: '',
        activity_type: '',
        pageNum: 1,
        pageSize: 10,
        role_id: '',
        phone: '',
        sel_provinces: [],
        sel_cities: [],
        sel_areas: []
      },
      tableData: [],
      regions: [],
      cities: [],
      areas: [],
      formLabelWidth: '120px',
    };
  },
  created() {
    // 筛选页面初始化
    this.actions = this.tbActions;
    this.activities = this.tbActivities;
    this.formInline.pageNum = 1;
    this.formInline.pageSize = 10;
    this.getRegionInfos();
    this.getList();
  },
  methods: {
    formInlineParams() {
      return {
        activity_id: this.formInline.activity_id,
        action_id: this.formInline.action_id,
        activity_type: this.formInline.activity_type,
        role_id: this.formInline.role_id,
        provinces: this.generateIdArray(this.formInline.sel_provinces),
        cities: this.generateIdArray(this.formInline.sel_cities),
        areas: this.generateIdArray(this.formInline.sel_areas),
        phone: this.formInline.phone,
        pageNum: this.formInline.pageNum,
        pageSize: this.formInline.pageSize
      };
    },
    onDownload() {
      const formParams = this.formInlineParams();
      formParams.pageNum = 1;
      formParams.pageSize = 100000;
      const params = Object.keys(formParams).map(function(key) {
        // body...
        return encodeURIComponent(key) + '=' + encodeURIComponent(formParams[key]);
      }).join('&');
      location.href = '/api/statistics/newerInfo/export?' + params;
    },
    onSubmit() {
      this.getList();
    },
    getRegionInfos() {
      // 请求地区列表
      getRegions().then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.regions = res.data;
        }
      });
    },
    getList() {
      this.loading = true;
      const params = this.formInlineParams();

      getNewerInfo(params).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.tableData = res.data;
          this.totalcount = res.totalCount;
        }
        this.loading = false;
      });
    },
    // 分页
    handleSizeChange(pageSize) {
      this.formInline.pageSize = pageSize;
      this.getList();
    },
    // 页码变化时触发
    handleCurrentChange(page) {
      this.formInline.pageNum = page;
      this.getList();
    },
    onProvinceVisibleChange(visible) {
      // 如果收起来的时候选择了省，要把已经选择的市和区的数据删除掉，避免选择的市区不在该省内
    //   if (!visible && this.formInline.sel_provinces.length > 0) {
    //     this.formInline.sel_cities = [];
    //     this.formInline.sel_areas = [];
    //     this.cities = [];
    //     this.areas = [];
    //   }
    },
    onCityVisibleChange(visible) {
      // 展现时计算应该展现的城市，如果已经选择了省，则只展现相关的市
      if (visible) {
        let provinces = this.regions;
        this.cities = [];
        // 展开城市选择时如果已经选择了省，只能显示该省所属的市
        if (this.formInline.sel_provinces.length > 0) {
          provinces = this.formInline.sel_provinces;
        }

        for (const i in provinces) {
          const province = provinces[i];
          this.cities = this.cities.concat(province.cities);
        }
      }
    },
    onAreaVisibleChange(visible) {
      // 展现时计算应该展现的区，如果已经选择了市，则只展现相关的区
      if (visible) {
        let cities = [];
        this.areas = [];
        if (this.formInline.sel_cities.length > 0) {
          // 优先以有已经选择的城市为准
          cities = this.formInline.sel_cities;
        } else if (this.cities.length > 0) {
          // 其次以城市列表为准
          cities = this.cities;
        } else if (this.formInline.sel_provinces.length > 0) {
          // 再有就是如果选择了省，只显示该省所有城市的区
          for (const i in this.formInline.sel_provinces) {
            const province = this.formInline.sel_provinces[i];
            if (province.cities != null) {
              cities = cities.concat(province.cities);
            }
          }
        } else {
          // 如果还是没有就展现所有区
          for (const i in this.regions) {
            const region = this.regions[i];
            if (region.cities != null) {
              cities = cities.concat(region.cities);
            }
          }
        }

        for (const i in cities) {
          const city = cities[i];
          if (city.areas != null) {
            this.areas = this.areas.concat(city.areas);
          }
        }
      }
    },
    onTabClick(value) {
      if (value.index == '0') {
        this.actions = this.tbActions;
        this.activities = this.tbActivities;
        this.formInline.activity_type = 0;
      } else if (value.index == '1') {
        this.actions = this.tmActivities;
        this.activities = this.tmActivities;
        this.formInline.activity_type = 1;
      } else if (value.index == '2') {
        this.actions = this.alipayActions;
        this.activities = this.alipayActivities;
        this.formInline.activity_type = 2;
      } else if (value.index == '3') {
        this.actions = this.jdActions;
        this.activities = this.jdActivities;
        this.formInline.activity_type = 3;
      } else {
        this.actions = this.ctccActions;
        this.activities = this.ctccActivities;
        this.formInline.activity_type = 4;
      }
      this.formInline.activity_id = '';
      this.formInline.action_id = '';
    },
    generateIdArray(oriArr) {
      const targetArr = [];
      for (const i in oriArr) {
        const obj = oriArr[i];
        targetArr.push(obj.id);
      }

      return targetArr;
    }
  }
};
</script>

<style scoped>
  
</style>
