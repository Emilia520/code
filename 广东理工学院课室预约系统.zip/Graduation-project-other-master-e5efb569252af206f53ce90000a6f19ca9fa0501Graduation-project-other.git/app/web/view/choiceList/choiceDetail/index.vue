<template>
  <div class="app-container">
    <el-row>
      <el-col :span="24">
        <div class="head-area">
            <div class="editable">
                <span class="editable-content">{{listName}}</span>
                <svg-icon icon-class="pen" />
                <a href="javascript:void(0);" class="editable-toggle"></a>
                <input value="111" class="editable-input" style="display: none;">
            </div>
            <div class="detail">
                <span>{{createDate}}</span>
                <span style="margin-left: 41px">商品个数：{{totalCount}}/200个</span>
            </div>
        </div>
      </el-col>
      <!-- 表格 start -->
      <el-col :span="24">
        <el-table
          :data="tableData"
          style="width: 100%"
          v-loading="loading">
          <el-table-column
            label="商品信息"
            width="310">
            <template slot-scope="scope">
                <div class="item-info-wrapper">
                    <div class="item-img">
                        <img :src="scope.row.goods_photo" style="width:100px;height:100px;">
                    </div>
                    <ul class="attr">
                        <li>
                            <a target="_blank" href="http://item.taobao.com/item.htm?id=535858963423">
                                <span>{{scope.row.goods_name}}</span>
                            </a>
                        </li>
                        <li class="coupon-info">
                            <span><i>券</i>{{scope.row.coupon_discount / 100}}元</span>
                            <span>余{{scope.row.coupon_remain_quantity}}张</span>
                        </li>
                        <li>
                            <svg-icon icon-class="mall" style="width:15px;height:15px;" />
                            <span>{{scope.row.shop_name}}</span>
                        </li>
                    </ul>
                </div>
            </template>
          </el-table-column>
          <el-table-column
            label="价格"
            width="120">
            <template slot-scope="scope">
                <div class="number">¥{{scope.row.zk_final_price / 100 - scope.row.coupon_discount / 100}}</div>
            </template>
          </el-table-column>
          <el-table-column
            label="佣金"
            width="120">
            <template slot-scope="scope">
                <div class="number">¥{{(scope.row.zk_final_price / 100 - scope.row.coupon_discount / 100) * scope.row.commission_rate / 1000}}</div>
                <div class="number">{{scope.row.commission_rate / 10}}%</div>
            </template>
          </el-table-column>
          <el-table-column
            label="销量"
            width="120">
            <template slot-scope="scope">
                <div class="number">{{scope.row.sold_quantity}}件</div>
            </template>
          </el-table-column>
          <el-table-column
            label="操作"
            width="120">
            <template slot-scope="scope">
                <el-button class="op-btn" type="primary" size="mini" plain 
                  :disabled="(tableData.indexOf(scope.row) + formInline.page) === 1" 
                  @click="shiftUp(scope.row)">上 移</el-button>
                <el-button class="op-btn" type="primary" size="mini" plain 
                  :disabled="(tableData.indexOf(scope.row) + (formInline.page - 1) * formInline.pageSize) + 1 === totalCount" 
                  @click="shiftDown(scope.row)">下 移</el-button>
                <el-button class="op-btn" type="danger" size="mini" plain 
                  @click="delGoods(scope.row)">删 除</el-button>
            </template>
          </el-table-column>
        </el-table>     
      </el-col>
      <!-- 表格 end -->
    </el-row>
  </div>
</template>

<script>
import { getDetail } from '@/api/choiceList';
import { dateFtt } from '../../../framework/utils/utils';

export default {
  data() {
    return {
      listName: '',
      createDate: '',
      tableData: [],
      totalCount: 0,
      formInline: {
        id: this.$route.params.id,
        page: 1,
        pageSize: 10
      }
    };
  },
  created() {
    this.getList();
  },
  methods: {
    getList() {
      this.loading = true;
      const params = this.formInline;
      // 请求列表
      getDetail(params).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.listName = res.data.list_name;
          this.createDate = dateFtt('yyyy年MM月dd日', new Date(res.data.create_time * 1000));
          this.tableData = res.data.goodsList;
          this.totalCount = res.data.goodsCount;
        }
        this.loading = false;
      });
    }
  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .head-area {
    width: 630px;
    position: relative;
    margin-left: 10px;
    display: block;
    font-size: 12px;
    line-height: 1.42857;
    font-family: "Microsoft YaHei", 微软雅黑, STXihei, 华文细黑, Georgia, "Times New Roman", Arial, sans-serif;
        -webkit-font-smoothing: antialiased;

    .editable {
        color: rgb(51, 51, 51);

        .editable-content {
            font-size: 20px;
        }
    }

    .detail {
        margin-top: 6px;
        color: #999;
    }
  }

  .item-info-wrapper {
      position: relative;
      padding: 14px 10px;
      text-align: left;
      font-size: 12px;
      color:#666;
      line-height: 1.42857;
      font-family: "Microsoft YaHei", 微软雅黑, STXihei, 华文细黑, Georgia, "Times New Roman", Arial, sans-serif;
          -webkit-font-smoothing: antialiased;
      .item-img {
          float: left;
          width: 100px;
          height: 100px;
      }
      .attr {
          max-width: 171px;
          margin-left: 115px;
          height: 100px;
          li {
              margin-bottom: 5px;
              padding: 2px 4px;
              a {
                  outline: 0;
                  text-decoration: none;
              }
          }
          .coupon-info {
            height: 16px;
            align-items: center;
            box-sizing: border-box;
            span:first-child {
                border: 1px solid #e3544c;
                color: #e3544c;
                font-weight: bold;
                padding-right: 2px;
                margin-right: 10px;
            }
            span {
                height: 16px;
                line-height: 16px;
                font-size: 12px;
                i {
                    background-color: #e3544c;
                    color: #fff;
                    font-weight: normal;
                    padding: 0 3px;
                    font-style: normal;
                }
            }
          }
      }
      ul {
          list-style-type: none;
          list-style-image: none;
          margin: 0;
          padding: 0;
      }
      li {
          display: list-item;
          text-align: -webkit-match-parent;
      }
  }

  .number {
      color: rgb(51, 51, 51);
      line-height: 1.42857;
      font-size: 12px;
      font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
  }

  .op-btn {
      margin-left: 10px;
      margin-bottom: 10px;
  }
</style>
