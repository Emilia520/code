<template>
    <div class="calendar-base">
        <calendar-grid>
            <template slot="calendarUnit" slot-scope="scope">
                <div v-if="calendar[scope.timeStamp] !== undefined">
                    <choice-list-card :data="calendar[scope.timeStamp]"></choice-list-card>
                </div>
                <div class="add-button-card" v-on:click="" v-else-if="scope.timeStamp !== null">
                    <div class="date-num-container">
                        <span class="date-num"> {{ new Date(scope.timeStamp * 1000).getDate()}}</span>
                        <span class="date-unit"> 日</span>
                    </div>
                    <div class="add-button-container">
                        <i class="el-icon-circle-plus"></i>
                        <div class="add-button-title">导入选品库</div>
                    </div>
                </div>
            </template>
        </calendar-grid>
    </div>
</template>

<script>
  const assert = require('assert');
  import { addCalendar } from '../../../api/choiceList';
  import { choiceListCalendar } from '../../../api/choiceList';

  import CalendarGrid from '@/component/Calendar';
  import ChoiceListCard from '@/component/ChoiceListCard';

  export default {
    name: 'homeChoice',
    components: { CalendarGrid, ChoiceListCard },
    data: () => ({
      date: null, // 当前表格关联的日期
      tagID: 1,
      serviceID: 1,
      optDateTime: 0, // 正在操作的日期时间戳

      calendar: {},
    }),
    methods: {
      updateCalendar() {
        if (this.date === null) {
          this.date = new Date();
        }

        const timeRange = this.timeRange(this.date);
        assert(timeRange.length === 2);

        choiceListCalendar({
          tagID: this.tagID,
          serviceID: this.serviceID,
          beginTime: timeRange[0],
          endTime: timeRange[1],
        }).then(res => {
          if (res.code !== 10000) {
            this.$message({ type: 'error', message: res.data.msg || '获取选品日历失败' });
            return;
          }

          Object.assign(this.calendar, res.data);
        });
      },

      /**
       * 返回日期对应月第一天和最后一天
       * @param date 指定的日期
       * @returns {Array} 第一个成员是当月第一天的时间戳，第二个是最后一天的时间戳
       */
      timeRange(date) {
        if (!date) {
          return null;
        }

        const begin = new Date(date.getFullYear(), date.getMonth());
        const end = new Date(date.getFullYear(), date.getMonth() + 1, -1);

        console.log('begin ', begin);
        console.log('end ', end);

        return [begin.getTime() / 1000, end.getTime() / 1000];
      },

      showAddEntryForDate(timeStamp) {
        this.optDateTime = timeStamp;
      }
    }
  };
</script>

<style lang="scss" scoped>
    .calendar-base {
        font-family: "Microsoft YaHei", "微软雅黑", STXihei, "华文细黑", Georgia, "Times New Roman", Arial, sans-serif;

        .add-button-card {
            min-width: 342px;
            min-height: 212px;
            color: #666;

            .date-num-container {
                padding-top: 20px;
                padding-right: 20px;
                text-align: right;

                .date-num {
                    font-size: 32px;
                    font-weight: bold;
                }

                .date-unit {
                    font-size: 12px;
                }
            }

            .add-button-container {
                margin-top: 30px;

                .el-icon-circle-plus {
                    font-size: 18px;
                    margin-bottom: 20px;
                }

                .add-button-title {
                    font-size: 14px;
                }
            }
        }

        .add-button-card:hover {
            color: white;
            background-color: #409EFF;
        }
    }

</style>