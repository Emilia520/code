<template xmlns:v-on="http://www.w3.org/1999/xhtml">
    <div class="base" style="padding-top:20px; padding-left: 20px;">
        <div style="margin-bottom: 30px;">
            <span style="font-size: 20px; color: #333;">我的选品库</span>
            <span style="font-size: 12px; color: #999;">(共{{ choiceListData.length}}个)</span>
        </div>
        <div class="list-container">
            <el-card style="margin:10px; background-color: #FAFAFC" shadow="hover">
                <div style="width: 301px; height: 203px; text-align: center;" v-on:click="showQuickAdd=true"
                     v-show="!showQuickAdd">
                    <i style="width: 50px; height: 50px; margin-top: 70px; font-size:30px" class="el-icon-plus"></i>
                    <div style="font-size: 14px; color: #666;">新建分组</div>
                </div>
                <div class="quick-add-container" v-show="showQuickAdd">
                    <div class="input-title">新建选品库</div>
                    <el-input class="input" :placeholder="defaultListName()" v-model="addingChoiceListName"></el-input>
                    <div class="input-button-container">
                        <el-button class="input-ok" type="primary" size="mini" @click="createChoiceList">创建
                        </el-button>
                        <el-button class="input-cancel" type="info" size="mini" @click="showQuickAdd=false">取消
                        </el-button>
                    </div>
                </div>
            </el-card>
            <div v-show="choiceListData.length !== 0" v-for="data in choiceListData" :key="data.choice_list_id">
                <choice-list-card class="choice-list-card" :data="data" @delete="removeChoiceList" @click="showDetail">
                </choice-list-card>
            </div>
        </div>
    </div>
</template>

<script>
  import ChoiceListCard from '@/component/ChoiceListCard';
  import { choiceList } from '../../../api/choiceList';
  import { deleteChoiceList } from '../../../api/choiceList';
  import { addChoiceList } from '../../../api/choiceList';
  import { dateFtt } from '../../../framework/utils/utils';

  export default {
    components: { ChoiceListCard },
    name: 'choiceOpt',
    data() {
      return {
        loading: false,
        showQuickAdd: false, // 是否显示快速添加按钮

        choiceListData: [], // 选品列表
        addingChoiceListName: null, // 新增选品库列表的名称
      };
    },
    created() {
      this.fetchChoiceList();
    },
    methods: {
      fetchChoiceList() {
        this.loading = true;

        choiceList(null).then(res => {
          this.loading = false;
          this.choiceListData = res.data.code === 10000 ? res.data.data : [];
        });
      },

      /**
       * 删除指定的选品队列
       * @param choiceList
       */
      removeChoiceList(choiceList) {
        this.$confirm('该操作会导致关联投放位上的数据同时清空，是否确认删除？', '确认删除', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          deleteChoiceList(choiceList).then(res => {
            if (res.data.code !== 10000) {
              this.$message({ type: 'error', message: res.data.msg || '删除选品列表失败' });
              return;
            }

            const index = this.choiceListData.findIndex(item => {
              return item.choice_list_id === choiceList.choice_list_id;
            });

            if (index >= 0 && index < this.choiceListData.length) {
              this.choiceListData.splice(index, 1);
            }
          });
        }).catch(() => {});
      },

      defaultListName() {
        return `创建于 ${dateFtt('yyyy-MM-dd hh:mm:ss', new Date())}`;
      },

      createChoiceList() {
        const name = this.addingChoiceListName || this.defaultListName();

        addChoiceList(name).then(res => {
          if (res.data.code === 10000) {
            this.choiceListData.unshift({ choice_list_id: res.data.data.insert_id, list_name: name });
            this.addingChoiceListName = null;
            this.showQuickAdd = false;
          } else {
            this.$message({ type: 'error', message: res.data.msg || '添加选品列表失败' });
          }
        });
      },

      showDetail(data) {
        this.$router.push({
          name: 'choiceDetail',
          params: {
            id: data.choice_list_id
          }
        });
      }
    }
  };
</script>

<style lang="scss" scoped>

    .base {
        font-family: "Microsoft YaHei", "微软雅黑", STXihei, "华文细黑", Georgia, "Times New Roman", Arial, sans-serif;
    }

    .list-container {
        display: flex;
        flex-wrap: wrap;
    }

    .choice-list-card {
        margin: 10px;
    }

    .quick-add-container {
        width: 302px;
        height: 203px;
        padding: 30px 5px 20px 5px;

        .input-title {
            font-size: 28px;
            color: #409EFF;
        }

        .input {
            margin-top: 20px;
            font-size: 13px;
        }

        .input-button-container {
            margin-top: 20px;
            text-align: center;

            .input-ok {
                min-width: calc(50% - 8px);
                min-height: 36px;
            }

            .input-cancel {
                min-width: calc(50% - 8px);
                min-height: 36px;
                margin-left: 10px;
            }
        }
    }

</style>