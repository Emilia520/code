<template>
    <div v-loading="loading" class="app-container">
        <div class="filter-container">
            <div class="filter-option-key">筛选日期</div>
            <el-date-picker
                    :disabled="filterForm.fixedRange"
                    v-model="filterForm.dateRange"
                    type="daterange"
                    format="yyyy-MM-dd"
                    value-format="timestamp"
                    range-separator=" ~ "
                    :picker-options="dateOptions"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期"
                    @change="getList"/>
            <div class="filter-options-fix-date">
                <el-checkbox v-model="filterForm.fixedRange" @change="getList">仅显示App可见记录</el-checkbox>
            </div>
        </div>
        <div class="content-container">
            <div class="seckill-date-list-container" v-if="seckillDataList.length !== 0"
                 v-for="seckillData in seckillDataList">
                <div class="seckill-date-container">
                    <div class="seckill-date-title">
                        <div class="seckill-date">{{_dateStrForSeckillData(seckillData)}}</div>
                        <div class="seckill-date-summary">当天共 {{seckillData.seckill_list.length}} 场秒杀</div>
                    </div>
                    <div v-if="seckillData.seckill_list.length !== 0" class="seckill-list-container"
                         v-for="seckillList in seckillData.seckill_list">
                        <div class="seckill-container-root" @click.stop="_showDetail(seckillList, seckillData.date)">
                            <svg-icon class="seckill-showing" v-if="_onShow(seckillList)" icon-class="seckill_onShow">显示中</svg-icon>
                            <div class="seckill-container">
                                <div class="seckill-time-list-container">
                                    <div class="seckill-time-container">
                                        <svg-icon class='seckill-time-icon' icon-class="seckill_begin_time"/>
                                        <div class="seckill-time">{{_timeStrForSeckillDate(seckillList.show_time)}}
                                        </div>
                                    </div>
                                    <div class="seckill-time-sep"> --</div>
                                    <div class="seckill-time-container">
                                        <svg-icon class='seckill-time-icon' icon-class="seckill_end_time"/>
                                        <div class="seckill-time">{{`${_timeStrPrefix(seckillList.show_time,
                                            seckillList.stop_time)}${_timeStrForSeckillDate(seckillList.stop_time)}`}}
                                        </div>
                                    </div>
                                </div>
                                <div class="seckill-products-container">
                                    <span class="seckill-products-count">共 <em style="color: #579ff8;">{{seckillList.product_list.length}} </em> 件商品, </span>
                                    <span class="seckill-products-failed">{{_countStrForUnavailableProducts(seckillList.product_list)}}</span>
                                </div>
                                <div class="seckill-list-detail">编辑秒杀 <i class="el-icon-d-arrow-right"></i></div>
                            </div>
                        </div>
                    </div>
                    <div v-if="seckillData.seckill_list.length === 0" class="seckill-list-container-empty">
                        <div class="seckill-list-empty-tips">空白的秒杀时段不会存入数据库，请开始选品吧～</div>
                    </div>
                    <div class="seckill-opt-container">
                        <div v-if='seckillData.seckill_list.length === 0' class="seckill-add-opt"
                             @click="_addStandardTimeSeckillList(seckillData)">
                            <svg-icon class='seckill-add-icon' icon-class="seckill_add_multiple"></svg-icon>
                            <span>添加标准时段秒杀</span>
                        </div>
                    </div>
                </div>
            </div>
            <div v-if="seckillDataList.length === 0" class="empty-tips">
                <svg-icon class="seckill-empty-icon" icon-class="seckill_empty"/>
                <div>没有秒杀配置，马上开始选品～</div>
            </div>
            <div class="add-seckill-container">
                <div v-if="!addSeckillDateVisibility" class="add-seckill-date">
                    <svg-icon class="add-seckill-date-icon" icon-class="seckill_add_date"/>
                    <el-button class="add-seckill-date-button" type="text" @click="addSeckillDateVisibility=true">
                        添加秒杀配置
                    </el-button>
                </div>
                <div v-if="addSeckillDateVisibility" class="add-seckill-date-edit">
                    <div class="add-seckill-date-option">
                        <span class="add-seckill-date-option-key">备注</span>
                        <el-input v-model="editingSeckillDate.remark" placeholder="描述备注（可选）"></el-input>
                    </div>
                    <div class="add-seckill-date-option">
                        <span class="add-seckill-date-option-key">日期</span>
                        <el-date-picker
                                v-model="editingSeckillDate.date"
                                type="date"
                                format="yyyy-MM-dd"
                                value-format="timestamp"
                                style="min-width: 250px;"
                        >
                        </el-date-picker>
                    </div>
                    <div class="add-seckill-date-opt">
                        <el-button class="add-seckill-date-opt-button" type="success" @click="_addSeckillDate" plain>
                            确定
                        </el-button>
                        <el-button class="add-seckill-date-opt-button" type="info"
                                   @click="addSeckillDateVisibility=false" plain>取消
                        </el-button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
  import { createSeckillLists, getSeckillList } from '../../../api/seckill';
  import { dateFtt } from '../../../framework/utils/utils';

  export default {
    created() {
      this.getList();
    },
    activated() {
      this.getList();
    },
    data() {
      return {
        loading: false,
        addSeckillDateVisibility: false,
        seckillDataList: [],
        editingSeckillDate: {},
        editingSeckill: {
          timeRange: [null, null],
        },
        filterForm: {
          fixedRange: true,
          dateRange: null,
        },
        dateOptions: {
          shortcuts: [{
            text: '最近一周',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 86400000 * 7);
              picker.$emit('pick', [start, end]);
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 86400000 * 30);
              picker.$emit('pick', [start, end]);
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 86400000 * 90);
              picker.$emit('pick', [start, end]);
            }
          }]
        },
      };
    },
    methods: {
      getList() {
        if (this.filterForm.fixedRange || !Array.isArray(this.filterForm.dateRange) || this.filterForm.dateRange.length !== 2) {
          // 向数据库查询当天前后一天的数据
          const now = new Date();
          const yesterday = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate() - 1)).getTime();
          const tomorrow = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate() + 1)).getTime() + 86399000; // 23:59:59
          this._getListByDate({ dateRange: [yesterday, tomorrow] });
        } else {
          const startDate = new Date(this.filterForm.dateRange[0]);
          const endDate = new Date(this.filterForm.dateRange[1]);
          const startTime = new Date(Date.UTC(startDate.getFullYear(), startDate.getMonth(), startDate.getDate()));
          const endTime = new Date(Date.UTC(endDate.getFullYear(), endDate.getMonth(), endDate.getDate() + 1)); // 要包含结尾那天整天的结果
          this._getListByDate({ dateRange: [startTime.getTime(), endTime.getTime() - 1000] });
        }
      },

      _getListByDate(params) {
        this.loading = true;
        getSeckillList(params).then(response => {
          this.loading = false;

          const resData = response.data;
          if (resData.code === 10000) {
            this.seckillDataList = resData.data;
            console.log(this.seckillDataList);
          } else {
            this.$message.error(response.msg || '获取秒杀列表失败');
          }
        });
      },

      // 添加秒杀日期
      _addSeckillDate() {
        if (!this.editingSeckillDate.date) {
          this.$message.error('请选择日期');
          return;
        }

        const repeatedDate = this.seckillDataList.find(item => {
          return item.date === this.editingSeckillDate.date;
        });

        if (repeatedDate) {
          this.$message.error('该日期已有秒杀记录，请直接编辑');
          return;
        }

        this.loading = true;
        const time = this.editingSeckillDate.date;
        getSeckillList({ timeRange: [time, time] }).then(response => {
          this.loading = false;
          const resData = response.data;
          if (resData.code === 10000 && resData.data.length !== 0) {
            const date = new Date(resData.data[0].date);
            const selectedDate = new Date(time);

            if (date.getMonth() === selectedDate.getMonth() && date.getDate() === selectedDate.getDate()) {
              this.editingSeckillDate = {};
              this.addSeckillDateVisibility = false;

              this.$confirm('该日期已由秒杀记录，是否调整搜索条件以显示该日期记录？', '添加日期', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'info'
              }).then(() => {
                this._alterTimeRangeAndFetch(time);
              }).catch(() => {});

              return;
            }
          }

          // 找到合适位置插入到数组
          const index = this.seckillDataList.findIndex(item => {
            return item.date > this.editingSeckillDate.date;
          });

          const tempStore = {};
          Object.assign(tempStore, this.editingSeckillDate);
          tempStore.seckill_list = [];

          if (index >= 0) {
            this.seckillDataList.splice(index, 0, tempStore);
          } else {
            this.seckillDataList.push(tempStore);
          }

          this.editingSeckillDate = {};
          this.addSeckillDateVisibility = false;

          if (!this._inCurrentTimeRange(time)) {
            this._alterTimeRangeAndFetch(time);
          } else {
            this.$message.success('添加成功，请编辑日期内容');
          }
        });
      },

      // 批量添加秒杀
      _addStandardTimeSeckillList(seckillDate) {
        const sep1BeginTime = new Date(seckillDate.date + 10 * 3600000).getTime() / 1000;
        const sep1EndTime = new Date(seckillDate.date + 22 * 3600000 - 1000).getTime() / 1000;
        const sep2BeginTime = new Date(seckillDate.date + 12 * 3600000).getTime() / 1000;
        const sep2EndTime = new Date(seckillDate.date + 34 * 3600000 - 1000).getTime() / 1000;
        const sep3BeginTime = new Date(seckillDate.date + 18 * 3600000).getTime() / 1000;
        const sep3EndTime = new Date(seckillDate.date + 36 * 3600000 - 1000).getTime() / 1000;
        const sep4BeginTime = new Date(seckillDate.date + 22 * 3600000).getTime() / 1000;
        const sep4EndTime = new Date(seckillDate.date + 42 * 3600000 - 1000).getTime() / 1000;

        const times = [
          {
            beginTime: sep1BeginTime,
            endTime: sep1EndTime
          },
          {
            beginTime: sep2BeginTime,
            endTime: sep2EndTime
          },
          {
            beginTime: sep3BeginTime,
            endTime: sep3EndTime
          },
          {
            beginTime: sep4BeginTime,
            endTime: sep4EndTime
          },
        ];

        this.loading = true;
        createSeckillLists({ times }).then(response => {
          this.loading = false;
          const resData = response.data;

          if (resData.code !== 10000) {
            this.$message.error(resData.msg || '插入记录失败');
          } else {
            this.$message.success('更新成功');
            this.getList();
          }
        });
      },

      // 构成日期字符串
      _dateStrForSeckillData(seckillData) {
        if (typeof seckillData.date !== 'number') {
          return '';
        }

        return dateFtt('yyyy.MM.dd', new Date(seckillData.date));
      },

      // 时间字符串
      _timeStrForSeckillDate(timestamp) {
        if (typeof timestamp !== 'number') {
          return '';
        }

        return new Date(timestamp * 1000).toLocaleTimeString();
      },

      // 时间字符串前缀
      _timeStrPrefix(beginTime, endTime) {
        let beginDate = new Date(beginTime * 1000);
        let endDate = new Date(endTime * 1000);

        beginDate = new Date(beginDate.getFullYear(), beginDate.getMonth(), beginDate.getDate());
        endDate = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate());
        const dist = Math.ceil((beginDate.getTime() - endDate.getTime()) / 86400000);
        const distVal = Math.abs(dist);

        if (distVal < 1) {
          return '';
        }

        if (distVal === 1) {
          return dist > 0 ? '昨日' : '次日';
        }

        return `${distVal}天${dist > 0 ? '前' : '后'}`;
      },

      // 统计有多少不可用的商品
      _unavailableProducts(products) {
        let sum = 0;
        products.forEach((item) => { sum += (item.seckill_product_status === 0 ? 1 : 0); });
        return sum;
      },

      // 不可用商品提示
      _countStrForUnavailableProducts(products) {
        const count = this._unavailableProducts(products);
        return count === 0 ? '无失效商品' : `共 ${count} 个失效商品`;
      },

      // 显示详情
      _showDetail(seckillList, date) {
        this.$router.push({
          name: 'qxbBrandSaleSeckillDetail',
          params: {
            seckillList,
            date
          }
        });
      },

      _inCurrentTimeRange(timestamp) {
        if (!this.filterForm.fixedRange && this.filterForm.dateRange.length === 2) {
          return timestamp >= this.filterForm.dateRange[0] && timestamp <= this.filterForm.dateRange[1];
        }

        const today = this._todayInDate();
        return Math.abs(timestamp - today.getTime()) < 86400000;
      },

      _todayInDate() {
        const now = new Date();
        return new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));
      },

      _onShow(seckillList) {
        const now = Date.now() / 1000;
        return now >= seckillList.show_time && now <= seckillList.stop_time;
      },

      // 调整搜索时间范围
      _alterTimeRangeAndFetch(targetTime) {
        let timeRange = [];
        if (!this.filterForm.fixedRange && this.filterForm.dateRange.length === 2) {
          timeRange = [Math.min(this.filterForm.dateRange[0], targetTime), Math.max(this.filterForm.dateRange[1], targetTime)];
        } else {
          const now = new Date();
          const yesterday = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate() - 1)).getTime();
          const tomorrow = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate() + 1)).getTime() + 86399000; // 23:59:59

          timeRange = [Math.min(yesterday, targetTime), Math.max(tomorrow, targetTime)];
        }

        this.filterForm.fixedRange = false;
        this.filterForm.dateRange = timeRange;
        this._getListByDate(timeRange);
      },
    }
  };
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .app-container {
        font-family: "华文宋体", Helvetica, serif;

        .filter-container {
            width: 100%;
            min-height: 180px;
            padding-bottom: 30px;
            display: flex;
            flex-direction: column;
            justify-content: space-around;

            .filter-options-fix-date {
                border: 1px #EEE solid;
                width: 350px;
                display: flex;
                flex-direction: column;
                justify-content: center;
                min-height: 40px;
                padding: 10px;
                border-radius: 5px;

                &:hover {
                    border: 1px #579ff8 solid;
                }
            }
        }

        .seckill-date-list-container {
            width: 60%;
            border: 1px #EEE solid;
            border-radius: 10px;
            min-height: 100px;
            padding: 20px;
            margin-bottom: 30px;

            &:hover {
                box-shadow: 0 2px 5px 0 rgba(2, 15, 29, -4.82);
            }

            .seckill-date-title {
                display: flex;
                flex-direction: row;
                justify-content: space-between;
                align-items: center;
                border-bottom: 1px dashed #EEE;
                margin-bottom: 15px;
                height: 35px;

                .seckill-date {
                    font-size: 18px;
                    color: #282828;
                    margin-bottom: 15px;
                }

                .seckill-date-summary {
                    font-size: 13px;
                    color: #555;
                }
            }
            
            .seckill-container-root {
                position: relative;
                .seckill-showing {
                    position: absolute;
                    top:-10px;
                    right: 10px;
                    width: 50px;
                    height: 50px;
                }

                .seckill-container {
                    margin-bottom: 20px;
                    display: flex;
                    flex-direction: row;
                    justify-content: space-between;
                    align-items: center;
                    border-radius: 10px;
                    background-color: #EEE;
                    padding: 20px;

                    &:hover {
                        background-color: rgba(87, 159, 248, 0.35);
                    }

                    .seckill-time-list-container {
                        display: flex;
                        flex-direction: row;
                        justify-content: space-between;
                        align-items: center;
                        min-width: 250px;

                        .seckill-time-container {
                            display: flex;
                            flex-direction: column;
                            justify-content: flex-start;
                            align-items: center;

                            .seckill-time {
                                font-size: 15px;
                                color: #555;
                            }

                            .seckill-time-icon {
                                width: 24px;
                                height: 24px;
                                margin-bottom: 5px;
                            }
                        }

                        .seckill-time-sep {
                            margin: 0 20px;
                            color: #555;
                        }
                    }

                    .seckill-products-container {
                        color: #555;
                        font-size: 15px;
                    }

                    .seckill-list-detail {
                        margin-top: 25px;
                        font-size: 13px;
                        color: #579ff8;
                    }
                }
            }
            .seckill-opt-container {
                display: flex;
                flex-direction: row;
                justify-content: center;
                align-items: center;

                .seckill-add-opt {
                    color: #555;
                    font-size: 14px;
                    display: flex;
                    flex-direction: row;
                    align-items: center;

                    & :hover {
                        color: #579ff8;
                    }

                    .seckill-add-icon {
                        width: 24px;
                        height: 24px;
                        margin-right: 5px;
                    }
                }
            }
            
            .seckill-list-container-empty {
                margin: 50px 0;
                text-align: center;
                font-size: 14px;
                color: #999;
            }
        }

        .empty-tips {
            padding: 100px;
            text-align: center;
            color: #555;
            font-size: 15px;
            font-weight: bold;

            .seckill-empty-icon {
                width: 100px;
                height: 100px;
                margin-bottom: 30px;
            }
        }

        .add-seckill-container {
            min-height: 60px;
            display: flex;
            justify-content: center;
            align-items: center;

            .add-seckill-date {
                display: flex;
                flex-direction: row;
                justify-content: center;
                align-items: center;

                .add-seckill-date-button {
                    color: #555;
                    font-size: 15px;

                    &:hover {
                        color: #75a9f0;
                    }
                }

                .add-seckill-date-icon {
                    width: 25px;
                    height: 25px;
                    margin-right: 10px;
                }
            }

            .add-seckill-date-edit {
                min-width: 300px;

                .add-seckill-date-option {
                    display: flex;
                    flex-direction: row;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 10px;

                    .add-seckill-date-option-key {
                        min-width: 50px;
                    }
                }
            }

            .add-seckill-date-opt {
                display: flex;
                justify-content: space-around;
                align-items: center;
                padding-left: 50px;

                .add-seckill-date-opt-button {
                    min-width: 100px;
                }
            }
        }
    }

</style>

