<template>
    <div class="app-container" v-loading="loading">
        <div class="back-container">
            <el-button circle class="back-button" icon="el-icon-back" type="info" @click="$router.back()"></el-button>
            <div class="seckill-info">
                <span class="seckill-date">{{_dateStr()}}</span>
                <span class="seckill-time-range">
                    秒杀场次:
                    {{_timeStrForSeckillDate(seckillList.show_time)}}
                    至
                    {{`${_timeStrPrefix(seckillList.show_time, seckillList.stop_time)}${_timeStrForSeckillDate(seckillList.stop_time)}`}}
                </span>
            </div>
        </div>
        <div class="seckill-container">
            <div class="seckill-content-container" v-for="product in seckillList.product_list">
                <seckill-selected-product-card :productInfo="product" @onEdit="onEditSelectedProduct"
                                               @onDelete="onDeleteProduct"/>
            </div>
        </div>
        <div class="filter-entrance">
            <el-button type="text" @click="filterVisible=!filterVisible">{{filterVisible ? '收起筛选器' : '展开筛选器'}}
            </el-button>
            <product-filter v-if="filterVisible" @getList="getProductList"/>
        </div>
        <div class="product-list-container">
            <div class="product-list" v-for="product in productList" :key="product.id">
                <seckill-product-card :selected="_hasSelect(product)" :productInfo="product" @onEdit="onEditProduct"
                                      @onSelect="onSelectProduct"/>
            </div>
        </div>
        <div class="pagination" style="margin-top:20px;">
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :total="totalCount"
                           :current-page="formInline.page" :page-sizes="[50, 100, 150]" :page-size="formInline.pageSize"
                           layout="total, sizes, prev, pager, next"/>
        </div>
        <div class='edit-dialog-container'>
            <el-dialog :visible.sync="editDialogVisible" class="edit-dialog">
                <el-form :model="editForm" ref="editForm">
                    <el-form-item label="商品描述" label-width="400" prop="name">
                        <el-input v-model="editForm.name" placeholder="商品描述" size="mini" clearable></el-input>
                    </el-form-item>
                    <el-form-item label="排序" label-width="400" prop="sort">
                        <el-input v-model.number="editForm.sort" placeholder="排序" size="mini" clearable></el-input>
                    </el-form-item>
                    <el-form-item v-if="$store.getters.role < 3 && editForm.goods && editForm.goods.type === 0"
                                  label="加价" abel-width="400" prop="addPrice">
                        <el-input v-model.number="editForm.addPrice" placeholder="加价" size="mini" clearable></el-input>
                    </el-form-item>
                    <el-form-item v-if="$store.getters.role < 3" label="佣金" label-width="400" prop="akcProfit">
                        <el-input v-model.number="editForm.akcProfit" placeholder="佣金" size="mini" clearable></el-input>
                    </el-form-item>
                    <el-form-item label="商品首图" class="time-width" label-width="120px">
                        <el-upload
                                class="avatar-uploader"
                                :action="uploadImg"
                                :show-file-list="false"
                                :on-success="handleAvatarSuccess"
                                :list-type="editForm.image ? '' : 'picture-card'">
                            <img v-if="editForm.image" :src="editForm.image" class="avatar" width="120" height="120"
                                 alt="">
                            <i v-else class="el-icon-plus"></i>
                        </el-upload>
                    </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                    <el-button @click="editDialogVisible = false">取 消</el-button>
                    <el-button type="primary" @click="confirmForm('editForm')">确 定</el-button>
                </div>
            </el-dialog>
        </div>
        <div class="add-dialog-container">
            <el-dialog :visible.sync="addDialogVisible">
                <div class="add-dialog-title">配置秒杀商品</div>
                <div class="option-list">
                    <div class="option">
                        <span class="option-key">秒杀价</span>
                        <el-input class="option-input" v-model="addForm.seckill_price" placeholder="请输入秒杀价"/>
                    </div>
                    <div class="option">
                        <span class="option-key">秒杀佣金</span>
                        <el-input class="option-input" v-model="addForm.seckill_profit" placeholder="请输入秒杀佣金"/>
                    </div>
                    <div class="option">
                        <span class="option-key">秒杀库存</span>
                        <el-input class="option-input" v-model="addForm.seckill_inventory" placeholder="请输入秒杀库存"/>
                    </div>
                    <div class="option">
                        <span class="option-key">秒杀排序</span>
                        <el-input class="option-input" v-model="addForm.sort" placeholder="请输入秒杀排序"/>
                    </div>
                </div>
                <div class="option-opt" slot="footer">
                    <el-button type="info" @click="cancelAdding">取消</el-button>
                    <el-button type="primary" @click="confirmAdding">确定</el-button>
                </div>
            </el-dialog>
        </div>
    </div>
</template>

<script>
  import SeckillSelectedProductCard from '@/component/Seckill/seckillSelectedProductCard';
  import SeckillProductCard from '@/component/Seckill/seckillProductCard';
  import ProductFilter from '@/component/AiKuCun/productFilter';
  import GoodsCard from '@/component/AiKuCun/goodsCard';

  import { allOnSaleGoods, updateGoodsInfo } from '../../../../api/groupbuy';
  import {
    getSeckillList,
    addProductToSeckillList,
    updateProductInSeckillList
  } from '../../../../api/seckill';
  import { uploadImg } from '../../../../api/uploadImg';

  export default {
    components: { SeckillSelectedProductCard, SeckillProductCard, ProductFilter, GoodsCard },
    created() {
      this.seckillList = this.$route.params.seckillList;
      this.date = this.$route.params.date;
      this.getDetail();
      this.getOnShowSeckillProducts();
      console.log(this.seckillList);
    },
    data() {
      return {
        date: 0,
        loading: false,
        filterVisible: false,
        editDialogVisible: false,
        addDialogVisible: false,
        seckillList: {},
        productList: [],
        selectedProductIDs: [],
        totalCount: 0,
        uploadImg,
        formInline: {
          page: 1,
          pageSize: 50,
          productName: null,
          filterSoldOut: true,
          onSale_only: true,
          hyk_only: false,
          allow_predicate: false,
          easyForMarketing: false,
          categories: [],
          discount: [null, null],
          discountFilter: null,
          discountSort: 0,
          addPrice: [null, null],
          addPriceFilter: null,
          addPriceSort: 0, // 0 无排序, 1 正序, 2 逆序
          price: [null, null],
          priceFilter: null,
          priceSort: 0,
          clickNum: [null, null],
          clickFilter: null,
          clickSort: 0,
          endTimeSort: 0,
        },
        editForm: {
          id: 0,
          goods: null,
          name: '',
          akcPrice: 0,
          akcSettlementPrice: 0,
          settlementPrice: 0,
          addPrice: 0,
          akcProfit: 0,
          image: '',
          sort: 0
        },
        addForm: {
          product_id: null,
          seckill_id: null,
          seckill_price: 0,
          seckill_profit: 0,
          seckill_inventory: 0,
          sort: 0,
          remark: null,
          product: null,
        },
      };
    },
    methods: {
      getProductList(params) {
        this.loading = true;

        if (params) {
          this.formInline = params;
        }

        console.log(this.formInline);

        allOnSaleGoods(this.formInline).then(response => {
          const resData = response.data;
          this.loading = false;
          if (resData.code === 10000) {
            this.totalCount = resData.count;
            this.productList = resData.data;
          }
        });
      },

      getDetail() {
        this.loading = true;
        getSeckillList({ seckill_id: this.seckillList.seckill_id }).then(response => {
          this.loading = false;
          const resData = response.data;
          if (resData.code !== 10000) {
            this.$message.warning('读取数据失败，使用缓存');
          } else {
            const data = resData.data;
            if (!Array.isArray(data) || data.length !== 1) {
              this.$message.error('数据库返回数据数量有误，请联系开发人员');
            } else {
              this.$message.success('更新数据成功');
              const seckill = data[0];
              this.date = seckill.date;
              this.seckillList = seckill.seckill_list[0];
            }
          }
        });
      },

      // 获取App上正在展示的秒杀商品
      getOnShowSeckillProducts() {
        const now = new Date();
        const yesterday = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate() - 1)).getTime();
        const tomorrow = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate() + 1)).getTime() + 86399000; // 23:59:59

        this.loading = true;
        getSeckillList({ dateRange: [yesterday, tomorrow] }).then(response => {
          const resData = response.data;
          if (resData.code === 10000) {
            resData.data.forEach(seckillDate => {
              seckillDate.seckill_list.forEach(seckillList => {
                seckillList.product_list.forEach(product => {
                  this.selectedProductIDs.push(product.id);
                });
              });
            });

            getSeckillList({ dateRange: [this.seckillList.show_time * 1000, this.seckillList.stop_time * 1000] }).then(response => {
              this.loading = false;
              const resData = response.data;
              if (resData.code === 10000) {
                resData.data.forEach(seckillDate => {
                  seckillDate.seckill_list.forEach(seckillList => {
                    seckillList.product_list.forEach(product => {
                      this.selectedProductIDs.push(product.id);
                    });
                  });
                });
              }
            });
            console.log(this.selectedProductIDs);
          } else {
            this.loading = false;
            this.$message.error(response.msg || '获取秒杀列表失败');
          }
        });
      },

      _dateStr() {
        return new Date(this.date).toLocaleDateString();
      },

      // 时间字符串
      _timeStrForSeckillDate(timestamp) {
        if (typeof timestamp !== 'number') {
          return '';
        }

        return new Date(timestamp * 1000).toLocaleTimeString();
      },

      // 时间字符串前缀
      _timeStrPrefix(beginTime, endTime) {
        let beginDate = new Date(beginTime * 1000);
        let endDate = new Date(endTime * 1000);

        beginDate = new Date(beginDate.getFullYear(), beginDate.getMonth(), beginDate.getDate());
        endDate = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate());
        const dist = Math.ceil((beginDate.getTime() - endDate.getTime()) / 86400000);
        const distVal = Math.abs(dist);

        if (distVal < 1) {
          return '';
        }

        if (distVal === 1) {
          return dist > 0 ? '昨日' : '次日';
        }

        return `${distVal}天${dist > 0 ? '前' : '后'}`;
      },

      handleSizeChange(pageSize) {
        this.formInline.pageSize = pageSize;
        this.getProductList();
      },

      handleCurrentChange(page) {
        this.formInline.page = page;
        this.getProductList();
      },

      onEditProduct(product) {
        console.log(product);
        this.editForm.goods = product;
        this.editForm.id = product.id;
        this.editForm.name = product.name;
        this.editForm.akcPrice = product.akc_price;
        this.editForm.akcSettlementPrice = product.akc_settlement_price;
        this.editForm.addPrice = product.add_price;
        this.editForm.akc_price = product.akc_price;
        this.editForm.akcProfit = product.akc_profit;
        this.editForm.sort = this.appType === 1 ? product.qxb_sort : product.sort;
        this.editForm.image = product.picture[0];
        this.editDialogVisible = true;
      },

      onEditSelectedProduct(editInfo) {
        console.log(editInfo);
        const params = {
          seckill_id: this.seckillList.seckill_id,
          product_id: editInfo.product_id,
          seckill_info: editInfo,
        };

        const product = editInfo.product;
        if (editInfo.seckill_price > product.settlement_price) {
          this.$message.error('输入的秒杀价不能高于会场价');
          return;
        }

        this.loading = true;
        updateProductInSeckillList(params).then(response => {
          this.loading = false;
          const resData = response.data;
          if (resData.code !== 10000) {
            this.$message.error(resData.msg || '更新失败');
          } else {
            this.$message.success('更新成功');
            this.getDetail();
          }
        });
      },

      onSelectProduct(product) {
        if (this._hasSelect(product)) {
          this.$message.info('商品正在上线的秒杀活动中');
          return;
        }

        console.log(product);
        this.addForm.product_id = product.id;
        this.addForm.seckill_id = this.seckillList.seckill_id;
        this.addForm.seckill_price = 0;
        this.addForm.seckill_profit = 0;
        this.addForm.seckill_inventory = 0;
        this.addForm.sort = 0;
        this.addForm.remark = '';
        this.addForm.product = product;
        this.addDialogVisible = true;
      },

      onDeleteProduct(product) {
        // 懒得该名， 该接口是将秒杀商品表中status设置为0，
        // 不是原来的直接删除记录
        this.loading = true;
        const seckill_info = { status: 0 };
        updateProductInSeckillList({
          seckill_id: this.seckillList.seckill_id,
          product_id: product.product_id,
          seckill_info
        }).then(response => {
          this.loading = false;
          const resData = response.data;
          if (resData.code !== 10000) {
            this.$message.error(resData.msg || '更新失败');
          } else {
            this.$message.success('更新成功');
            this.getDetail();
          }
        });
      },

      confirmForm() {
        this.loading = true;
        const addPrice = this.editForm.addPrice;
        const settlementPrice = this.editForm.akc_price + addPrice;
        const goods = this.editForm.goods;
        const name = this.editForm.name;
        const image = this.editForm.image;
        const sort = this.editForm.sort;
        const akcProfit = this.editForm.akcProfit;
        const pictures = goods.picture.slice();
        const akcTagPrice = goods.akc_tag_price;
        pictures[0] = image;
        updateGoodsInfo({
          appType: this.appType,
          id: this.editForm.id,
          name,
          addPrice,
          akcProfit,
          sort,
          settlementPrice,
          akcTagPrice,
          picture: JSON.stringify(pictures)
        }).then(response => {
          this.loading = false;
          const res = response.data;
          if (res.code === 10000) {
            this.$message({
              message: '操作成功',
              type: 'success'
            });
            goods.add_price = parseFloat(parseFloat(addPrice).toFixed(2));
            goods.settlement_price = parseFloat(parseFloat(settlementPrice).toFixed(2));
            goods.name = name;
            goods.picture = pictures;
            if (this.appType === 1) {
              goods.qxb_sort = sort;
            } else {
              goods.sort = sort;
            }
            this.editDialogVisible = false;
            this.getList();
          } else {
            this.$message({
              message: '操作失败',
              type: 'fail'
            });
          }
          this.loading = false;
        });
      },

      handleAvatarSuccess(res) {
        this.editForm.image = res.data;
      },

      cancelAdding() {
        this.addForm = {};
        this.addDialogVisible = false;
      },

      confirmAdding() {
        this.loading = true;
        addProductToSeckillList({
          seckillID: this.seckillList.seckill_id,
          productList: [this.addForm]
        }).then(response => {
          this.loading = false;

          const resData = response.data;
          if (resData.code !== 10000) {
            const productD = resData.data.product_id;
            const msg = productD ? `插入数据失败: ${resData.msg}, 失败商品ID: ${productD}` : resData.msg;
            this.$message.error(msg || '更新失败');
          } else {
            this.cancelAdding();
            this.$message.success('更新成功');
            this.getDetail();
          }
        });
      },

      _hasSelect(product) {
        return this.seckillList.product_list.find(item => item.id === product.id) !== undefined ||
          this.selectedProductIDs.indexOf(product.id) !== -1;
      },
    },
  };
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
    .app-container {
        font-family: "华文宋体", Helvetica, serif;

        .back-container {
            display: flex;
            flex-direction: row;
            margin: 20px 0 20px 20px;
            align-items: center;

            .seckill-info {
                margin-left: 30px;
                color: #999;

                .seckill-date {
                    font-size: 20px;
                }

                .seckill-time-range {
                    margin-left: 50px;
                    font-size: 14px;
                }
            }
        }

        .seckill-container {
            display: flex;
            flex-direction: row;
            justify-content: flex-start;
            flex-wrap: wrap;

            .seckill-content-container {
            }
        }

        .product-list-container {
            display: flex;
            flex-direction: row;
            justify-content: flex-start;
            flex-wrap: wrap;
        }

        .add-dialog-container {
            .add-dialog-title {
                font-size: 18px;
                font-weight: bold;
                margin-bottom: 40px;
            }

            .option {
                display: flex;
                flex-direction: row;
                align-items: center;
                color: #999;
                margin-bottom: 10px;

                .option-key {
                    width: 100px;
                }

                .option-input {
                    max-width: 250px;
                }
            }
        }
    }

</style>