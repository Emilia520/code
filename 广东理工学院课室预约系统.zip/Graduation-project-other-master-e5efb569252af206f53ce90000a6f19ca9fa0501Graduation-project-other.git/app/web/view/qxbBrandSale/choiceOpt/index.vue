<template xmlns:v-on="http://www.w3.org/1999/xhtml">
    <div class="app-container">
        <template>
            <el-backtop target=".app-container ">
                <div class="back-ball">
                    回到顶部
                </div>
            </el-backtop>
        </template>
        <el-tabs type="border-card" v-model="activeName">
            <el-tab-pane label="单品爆款推广选品库" name="1">
                <akc-choice-opt ref="choiceOpt" :appType="appType">
                </akc-choice-opt>
            </el-tab-pane>
            <el-tab-pane label="精选活动推广" name="2">
                <akc-hot-detail ref="hotDetail" :hotId="hotId" :appType="2">
                </akc-hot-detail>
            </el-tab-pane>
            <el-tab-pane label="每日分享素材" name="3">
                <akc-share-detail ref="shareDetail" :hotId="hotId">
                </akc-share-detail>
            </el-tab-pane>
            <el-tab-pane label="活动单品排行榜" name="4">
                <akc-choice-opt ref="choiceOpt" :appType="4">
                </akc-choice-opt>
            </el-tab-pane>
            <el-tab-pane label="活动精选活动" name="5">
                <akc-hot-detail ref="hotDetail" :hotId="hotId" :appType="5">
                </akc-hot-detail>
            </el-tab-pane>
        </el-tabs>
    </div>
</template>
<script>
  import AkcChoiceOpt from '@/component/AiKuCun/choiceOpt';
  import AkcHotDetail from '@/component/AiKuCun/hotDetail';
  import AkcShareDetail from '@/component/AiKuCun/shareDetail';

  export default {
    components: { AkcChoiceOpt, AkcHotDetail, AkcShareDetail },
    data() {
      return {
        appType: 1,
        text: '',
        hotId: 0,
        shareTime: '',
        activeName: '1'
      };
    },
    created() {
      this.activeName = this.$route.params.tab || '1';
      console.log(this.activeName);
    },
    methods: {}
  };
</script>

<style lang="scss" scoped>
    .app-container {
        height: 100vh;
        height: 880px;
        overflow: hidden;
        overflow-x: hidden;
        overflow-y: scroll;
    }
</style>