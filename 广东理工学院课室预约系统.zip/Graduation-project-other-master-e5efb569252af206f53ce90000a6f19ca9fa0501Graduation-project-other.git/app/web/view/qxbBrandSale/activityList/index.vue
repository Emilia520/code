<template>
        <div class="app-container">
            <div class="header-title">活动列表</div>
            <akc-act-list class='akcList' ref="akcActList" :appType="appType" :onSelectActivity="onSelectActivity" :hasSelectActivity="hasSelectActivity" />
            <el-backtop >
                <div>回到顶部</div>
            </el-backtop>
        </div>

</template>

<script>
import AkcActList from '@/component/AiKuCun/activityList';

export default {
  components: { AkcActList },
  props: {
    onSelectActivity: {
      type: Function,
      default: null,
    },
    hasSelectActivity: {
      type: Function,
      default: null,
    }
  },
  data() {
    return {
      appType: 1
    };
  },
  created() {
    // 筛选页面初始化
    // this.$refs.akcActList.getList();
  },
  mounted() {
  },
  methods: {

  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>

    .app-container {
        overflow: scroll;
        height: 100%;
    }

</style>
