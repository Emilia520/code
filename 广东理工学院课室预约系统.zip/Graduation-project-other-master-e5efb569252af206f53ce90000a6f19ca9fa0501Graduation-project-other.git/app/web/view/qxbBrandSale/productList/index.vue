<template>
    <div v-loading="loading" class="app-container">
        <div class="app-header">
            <el-button type="button" size="small"  @click="excelList()">一键导出商品信息</el-button>
            <div class="filter-container">
                <span class="filter-key">商品信息</span>
                <el-input class="name-input" placeholder="请输入商品名称或商品ID" v-model="formInline.productName" clearable/>
            </div>
            <div class="filter-container">
                <span class="filter-key">折扣率</span>
                <el-select class='filter-filter' v-model="formInline.discountFilter" placeholder="请选择">
                    <el-option v-for="type in sortTypes"
                               :key="type"
                               :label="type"
                               :value="type">
                    </el-option>
                </el-select>
                <el-input class="filter-input" :placeholder="_isRangeFilter('discountFilter') ? '最低折扣' : '筛选折扣'" v-model="formInline.discount[0]" clearable/>
                <el-input v-if="_isRangeFilter('discountFilter')" class="filter-input" placeholder="最高折扣" v-model="formInline.discount[1]" clearable/>
                <el-select class='filter-filter' v-model="formInline.discountSort" placeholder="排序" @change="getList">
                    <el-option v-for="type in sortMethods"
                               :key="type.id"
                               :label="type.name"
                               :value="type.id">
                    </el-option>
                </el-select>
            </div>
            <div class="filter-container">
                <span class="filter-key">加价</span>
                <el-select class="filter-filter" v-model="formInline.addPriceFilter" placeholder="请选择">
                    <el-option v-for="type in sortTypes"
                               :key="type"
                               :label="type"
                               :value="type">
                    </el-option>
                </el-select>
                <el-input class="filter-input" :placeholder="_isRangeFilter('addPriceFilter') ? '最低加价' : '筛选加价'" v-model="formInline.addPrice[0]" clearable/>
                <el-input v-if="_isRangeFilter('addPriceFilter')" class="filter-input" placeholder="最高加价" v-model="formInline.addPrice[1]" clearable/>
                <el-select class='filter-filter' v-model="formInline.addPriceSort" placeholder="排序" @change="getList">
                    <el-option v-for="type in sortMethods"
                               :key="type.id"
                               :label="type.name"
                               :value="type.id">
                    </el-option>
                </el-select>
            </div>
            <div class="filter-container">
                <span class="filter-key">价格</span>
                <el-select class="filter-filter" v-model="formInline.priceFilter" placeholder="请选择">
                    <el-option v-for="type in sortTypes"
                               :key="type"
                               :label="type"
                               :value="type">
                    </el-option>
                </el-select>
                <el-input class="filter-input" :placeholder="_isRangeFilter('priceFilter') ? '最低价格' : '筛选价格'" v-model="formInline.price[0]" clearable/>
                <el-input v-if="_isRangeFilter('priceFilter')" class="filter-input" placeholder="最高价格" v-model="formInline.price[1]" clearable/>
                <el-select class='filter-filter' v-model="formInline.priceSort" placeholder="排序" @change="getList">
                    <el-option v-for="type in sortMethods"
                               :key="type.id"
                               :label="type.name"
                               :value="type.id">
                    </el-option>
                </el-select>
            </div>
            <div class="filter-container">
                <span class="filter-key">点击数</span>
                <el-select class="filter-filter" v-model="formInline.clickFilter" placeholder="请选择">
                    <el-option v-for="type in sortTypes"
                               :key="type"
                               :label="type"
                               :value="type">
                    </el-option>
                </el-select>
                <el-input class="filter-input" :placeholder="_isRangeFilter('clickFilter') ? '最低点击数' : '筛选点击数'" v-model="formInline.clickNum[0]" clearable/>
                <el-input v-if="_isRangeFilter('clickFilter')" class="filter-input" placeholder="最高点击数" v-model="formInline.clickNum[1]" clearable/>
                <el-select class='filter-filter' v-model="formInline.clickSort" placeholder="排序" @change="getList">
                    <el-option v-for="type in sortMethods"
                               :key="type.id"
                               :label="type.name"
                               :value="type.id">
                    </el-option>
                </el-select>
            </div>
            <div class="filter-container">
                <span class="filter-key">活动持续时间（小时）</span>
                <el-select class="filter-filter" v-model="formInline.durationFilter" placeholder="请选择">
                    <el-option v-for="type in sortTypes" :key="type" :label="type" :value="type" />
                </el-select>
                <el-input class="filter-input" :placeholder="_isRangeFilter('durationFilter') ? '最低持续时间' : '筛选持续时间'" v-model="formInline.durationNum[0]" clearable/>
                <el-input v-if="_isRangeFilter('durationFilter')" class="filter-input" placeholder="最高持续时间" v-model="formInline.durationNum[1]" clearable/>
                <el-select class='filter-filter' v-model="formInline.durationSort" placeholder="排序" @change="getList">
                    <el-option v-for="type in sortMethods" :key="type.id" :label="type.name" :value="type.id" />
                </el-select>
            </div>
            <div class="filter-container">
                <span class="filter-key">佣金（元）</span>
                <el-select class="filter-filter" v-model="formInline.commissionFilter" placeholder="请选择">
                    <el-option v-for="type in sortTypes" :key="type" :label="type" :value="type" />
                </el-select>
                <el-input class="filter-input" :placeholder="_isRangeFilter('commissionFilter') ? '最低持续时间' : '筛选持续时间'" v-model="formInline.commissionNum[0]" clearable/>
                <el-input v-if="_isRangeFilter('commissionFilter')" class="filter-input" placeholder="最高持续时间" v-model="formInline.commissionNum[1]" clearable/>
                <el-select class='filter-filter' v-model="formInline.commissionSort" placeholder="排序" @change="getList">
                    <el-option v-for="type in sortMethods" :key="type.id" :label="type.name" :value="type.id" />
                </el-select>
            </div>
            <div class="filter-container">
                <span class="filter-key">结束日期</span>
                <el-select class='filter-filter' v-model="formInline.endTimeSort" placeholder="排序" @change="getList">
                    <el-option v-for="type in sortMethods"
                               :key="type.id"
                               :label="type.name"
                               :value="type.id">
                    </el-option>
                </el-select>
            </div>
            <div class="filter-container-checkbox">
                <el-checkbox v-model="formInline.filterSoldOut" @change="getList">只看有库存</el-checkbox>
                <el-checkbox v-model="formInline.onSale_only" @change="getList">只看上架</el-checkbox>
                <!-- <el-checkbox v-model="formInline.hyk_only" @change="getList">只看好衣库</el-checkbox>
                <el-checkbox v-model="formInline.akc_only" @change="getList">只看爱库存</el-checkbox> -->
               
            </div>
            <div  class="filter-container-checkbox">
              <el-radio-group v-model="chooseSup" @change="changeChoose">
                <el-radio :label="0">全部</el-radio>
                <el-radio :label="1">只看好衣库</el-radio>
                <el-radio :label="2">只看爱库存</el-radio>
              </el-radio-group>
            </div>
            <div class="filter-container-checkbox">
                <el-checkbox v-model="formInline.easyForMarketing" @change="getList">佣金比和规格数优先</el-checkbox>
                <div class="filter-container-checkbox-tips">勾选后结果按佣金比和SKU从高到低排序，但筛选过程会多耗时一些</div>
            </div>
            <div class="filter-container">
                <el-button class="filter-button" type="primary" @click="filterProducts">筛选</el-button>
            </div>
            <div class="filter-tips">数据默认按照商品"排序"字段从大到小排序</div>
            <div class="category-list-container" v-for="subList in categoryList" :key="categoryList.indexOf(subList)">
                <el-checkbox-group class="category-container" v-model="formInline.categories" v-for="category in subList" :key="category.id" @change="getList">
                    <el-checkbox style="min-width: 100px;" :label="category.id"> {{ category.tag_name }}</el-checkbox>
                </el-checkbox-group>
            </div>
        </div>
        <div class="product-list-container">
            <div class="product-container" v-for="product in productList" :key="product.id">
              <goods-card :productInfo="product" @onEdit="onEditProduct"/>
            </div>
        </div>
        <div class="pagination" style="margin-top:20px;">
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :total="totalCount"
                           :current-page="formInline.page" :page-sizes="[50, 100, 150]" :page-size="formInline.pageSize"
                           layout="total, sizes, prev, pager, next"/>
        </div>
        <div class='edit-dialog-container'>
            <el-dialog :visible.sync="editDialogVisible" class="edit-dialog">
                <el-form :model="addForm" :rules="rules" ref="addForm">
                    <el-form-item label="商品描述" label-width="400" prop="name">
                        <el-input v-model="addForm.name" placeholder="商品描述" size="mini" clearable></el-input>
                    </el-form-item>
                    <el-form-item label="排序" label-width="400" prop="sort">
                        <el-input v-model.number="addForm.sort" placeholder="排序" size="mini" clearable></el-input>
                    </el-form-item>
                    <el-form-item v-if="$store.getters.role < 3 && addForm.goods && (addForm.goods.type === 0 || addForm.goods.type === 4)" label="加价" abel-width="400" prop="addPrice">
                        <el-input v-model.number="addForm.addPrice" placeholder="加价" size="mini" clearable></el-input>
                    </el-form-item>
                    <el-form-item v-if="$store.getters.role < 3" label="佣金" label-width="400" prop="akcProfit">
                        <el-input v-model.number="addForm.akcProfit" placeholder="佣金" size="mini" clearable></el-input>
                    </el-form-item>
                    <el-form-item label="商品首图" class="time-width" label-width="120px">
                        <el-upload
                                class="avatar-uploader"
                                :action="uploadImg"
                                :show-file-list="false"
                                :on-success="handleAvatarSuccess"
                                :list-type="addForm.image ? '' : 'picture-card'">
                            <img v-if="addForm.image" :src="addForm.image" class="avatar" width="120" height="120"
                                 alt="">
                            <i v-else class="el-icon-plus"></i>
                        </el-upload>
                    </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                    <el-button @click="editDialogVisible = false">取 消</el-button>
                    <el-button type="primary" @click="confirmForm('addForm')">确 定</el-button>
                </div>
            </el-dialog>
        </div>
    </div>
</template>

<script>
  import { allOnSaleGoods, updateGoodsInfo, getCatList } from '@/api/groupbuy';
  import { uploadImg } from '@/api/uploadImg';
  import GoodsCard from '@/component/AiKuCun/goodsCard';

  export default {
    components: { GoodsCard },
    created() {
      this.getList();
      this.getCategoryList();
    },
    data() {
      return {
        chooseSup : 0,
        loading: false,
        editDialogVisible: false,
        productList: [],
        categoryList: [],
        appType: 1,
        totalCount: 0,
        uploadImg,
        formInline: {
          page: 1,
          pageSize: 50,
          productName: null,
          filterSoldOut: true,
          onSale_only: true,
          hyk_only: false,
          akc_only: false,
          allow_predicate: true,
          easyForMarketing: false,
          categories: [],
          discount: [null, null],
          discountFilter: null,
          discountSort: 0,
          addPrice: [null, null],
          addPriceFilter: null, 
          addPriceSort: 0, // 0 无排序, 1 正序, 2 逆序
          price: [null, null],
          priceFilter: null,
          priceSort: 0,
          clickNum: [null, null],
          clickFilter: null,
          durationFilter: null,
          durationNum: [null, null],
          durationSort: 0,
          commissionFilter: null,
          commissionNum: [null, null],
          commissionSort: 0,
          clickSort: 0,
          endTimeSort: 0,
        },
        addForm: {
          id: 0,
          goods: null,
          name: '',
          akcPrice: 0,
          akcSettlementPrice: 0,
          settlementPrice: 0,
          addPrice: 0,
          akcProfit: 0,
          image: '',
          sort: 0
        },
        sortTypes: ['=', '>', '>=', '<', '<=', '~', null],
        sortMethods: [{ id: 0, name: '无排序' }, { id: 1, name: '升序' }, { id: 2, name: '降序' }
        ],
        rules: {
          addPrice: [{ required: true, message: '请输入加价金额', trigger: 'blur' },
            { type: 'number', min: 0, max: 999, message: '金额为数字值，且范围为0～999' }],
          akcProfit: [{ required: true, message: '请输入佣金金额', trigger: 'blur' },
            { type: 'number', min: 0, max: 999, message: '金额为数字值，且范围为0～999' }],
          sort: [{ required: true, message: '请输入排序（数字越大越靠前）', trigger: 'blur' },
            { type: 'number', min: 0, max: 999999, message: '排序为数字值，且范围为0～999999' }],
          name: [{ required: true, message: '请输入商品标题描述', trigger: 'blur' }],
          image: [{ required: true, message: '请上传商品首图', trigger: 'blur' }]
        },
      };
    },
    methods: {
      excelList(){
        const params = this.formInline;
        const a = {};
        Object.keys(params).forEach(key  => {
          const value = params[key];
          if (typeof value !== 'undefined' && value !== null) {
            if (Array.isArray(value)) {
               if(value.findIndex(item => item !== null) !== -1) {
                 a[key] = JSON.stringify(value);
               }
            }else {
              a[key] = value;
            }
          }
        });
        const query = Object.keys(a).map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(a[key])}`).join('&');
        window.location.href = `/api/groupbuy/exportGoodsList?${query}`;
      },
      getList() {
        this.loading = true;

        allOnSaleGoods(this.formInline).then(response => {
          const resData = response.data;
          console.log('goods list', resData);
          this.loading = false;
          if (resData.code === 10000) {
            this.totalCount = resData.count;
            this.productList = resData.data;
          }
        });
      },
      changeChoose(label) {
        this.formInline.hyk_only = label === 1;
        this.formInline.akc_only = label === 2;
        this.getList();
      },

      confirmSearch() {
        this.formInline.page = 1;
        this.getList();
      },

      // 获取活动分类列表
      getCategoryList() {
        this.loading = true;

        getCatList({ appType: 1 }).then(response => {
          const resData = response.data;
          console.log('cat list', resData);
          this.loading = false;
          if (resData.code === 10000) {
            this.categoryList = this._shortenCategories(resData.data);
          }
        });
      },

      handleSizeChange(pageSize) {
        this.formInline.pageSize = pageSize;
        this.getList();
      },

      handleCurrentChange(page) {
        this.formInline.page = page;
        this.getList();
      },

      onEditProduct(product) {
        console.log(product);
        this.addForm.goods = product;
        this.addForm.id = product.id;
        this.addForm.name = product.name;
        this.addForm.akcPrice = product.akc_price;
        this.addForm.akcSettlementPrice = product.akc_settlement_price;
        this.addForm.addPrice = product.add_price;
        this.addForm.akc_price = product.akc_price;
        this.addForm.akcProfit = product.akc_profit;
        this.addForm.sort = this.appType === 1 ? product.qxb_sort : product.sort;
        this.addForm.image = product.picture[0];
        this.editDialogVisible = true;
      },

      confirmForm(formName) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.loading = true;
            const addPrice = this.addForm.addPrice;
            const settlementPrice = this.addForm.akc_price + addPrice;
            const goods = this.addForm.goods;
            const name = this.addForm.name;
            const image = this.addForm.image;
            const sort = this.addForm.sort;
            const akcProfit = this.addForm.akcProfit;
            const pictures = goods.picture.slice();
            const akcTagPrice = goods.akc_tag_price;
            pictures[0] = image;
            updateGoodsInfo({
              appType: this.appType,
              id: this.addForm.id,
              name,
              addPrice,
              akcProfit,
              sort,
              settlementPrice,
              akcTagPrice,
              picture: JSON.stringify(pictures)
            }).then(response => {
              const res = response.data;
              if (res.code === 10000) {
                this.$message({
                  message: '操作成功',
                  type: 'success'
                });
                goods.add_price = parseFloat(parseFloat(addPrice).toFixed(2));
                goods.settlement_price = parseFloat(parseFloat(settlementPrice).toFixed(2));
                goods.name = name;
                goods.picture = pictures;
                if (this.appType === 1) {
                  goods.qxb_sort = sort;
                } else {
                  goods.sort = sort;
                }
                this.editDialogVisible = false;
                this.getList();
              } else {
                this.$message({
                  message: '操作失败',
                  type: 'fail'
                });
              }
              this.loading = false;
            });
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },

      handleAvatarSuccess(res, file) {
        this.addForm.image = res.data;
      },

      filterProducts() {
        this.formInline.page = 1;
        this.getList();
      },

      _isRangeFilter(keyword) {
        if (!this.formInline.hasOwnProperty(keyword)) {
          return false;
        }

        return this.formInline[keyword] === '~';
      },

      _shortenCategories(categoryList) {
        let end = 0;
        const result = [];

        categoryList = categoryList.filter(item => item.tag_name !== '最后疯抢');

        do {
          const len = Math.min(8, categoryList.length - end);
          const subList = categoryList.slice(end, end + len);
          result.push(subList);
          end += len;
        } while (end <= categoryList.length - 1);

        return result;
      },
    },
  };
</script>

<style lang="scss" scoped>
    .app-container {
        font-family: "Microsoft YaHei", "微软雅黑", STXihei, "华文细黑", Georgia, "Times New Roman", Arial, sans-serif;

        .product-list-container {
            display: flex;
            flex-direction: row;
            justify-content: flex-start;
            flex-wrap: wrap;
        }

        .app-header {
            .filter-container {
                display: flex;
                flex-direction: row;
                align-items: center;
                margin-top: 10px;

                .filter-key {
                    font-size: 15px;
                    margin-right: 10px;
                    min-width: 60px;
                }

                .filter-filter {
                    width: 110px;
                    margin-right: 5px;
                }

                .filter-sort {
                    min-width: 100px;
                }

                .name-input {
                    width: 350px;
                    margin-right: 5px;
                }

                .filter-input {
                    width: 120px;
                    margin-right: 5px;
                }

                .filter-button {
                    min-width: 420px;
                }
            }

            .filter-tips {
                font-size: 12px;
                color: lightcoral;
                margin-top: 5px;
                margin-bottom: 20px;
            }

            .filter-container-checkbox {
                width: 600px;
                padding: 20px;
                border: solid #eee 1px;
                margin-top: 10px;

                &:hover {
                    border: solid #579ff8 1px;
                }

                .filter-container-checkbox-tips {
                    font-size: 12px;
                    color: lightcoral;
                    margin-top: 5px;
                }
            }

            .category-list-container {
                display: flex;
                flex-direction: row;
                align-items: flex-start;

                .category-container {
                    margin-top: 5px;
                }
            }
        }
    }


</style>