<template>
  <div class="app-container" v-loading="loading">
    <div class="createdButton" v-if="show">
      <el-button plain @click="createdBrand(0)">新建品牌</el-button>
    </div>
    <div class="oneSetButton" v-if="secondShow">
       <el-button
          plain
          @click="chooseLableShow()"
        >一键设置品牌运营标签
      </el-button>
    </div>
    <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
      <el-tab-pane label="待入库" name="first">

        <el-dialog title="新建品牌" :visible.sync="createBrand" class="createdBrand">
          <el-form :model="form"  ref="form">
            <el-form-item  label="品牌名称" :required="true">      
                <el-input
                  class="filter-option-input"
                  v-model="form.brand_name"
                  placeholder="请输入品牌名称"
                  clearable
                  maxlength="16"
                  style="flex:1">             
                </el-input>
            </el-form-item>
            <el-form-item label="品牌分类" :required="true">         
                <el-select v-model="form.type_code" placeholder="请选择">
                  <el-option
                    v-for="item in brandTypeList"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  ></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="是否自动上下架" :required="true">

                <el-radio v-model="form.auto_up_status" label="1" :key="1" :value="1">上架</el-radio>
                <el-radio v-model="form.auto_up_status" label="0" :key="0" :value="0">下架</el-radio>

            </el-form-item>
            <el-form-item label="品牌运营标签">
           
                <el-checkbox-group v-model="formLabelIds">
                  <el-checkbox
                    v-for="label of formLabel"
                    :label="label.id"
                    :key="label.id"
                  >{{ label.label_name }}</el-checkbox>
                </el-checkbox-group>
            
            </el-form-item>

            <el-form-item  label="上传icon" :required="true">
              <div class="updateIcon">
                <br/>
                <el-upload
                  action="https://xttapi.lexj.com/helper/uploadCdn"
                  :show-file-list="false"
                  :on-success="handleIcon"
                  :list-type="imgIcon.resources ? '' : 'picture-card'"
                >
                  <div class="container">
                    <img v-if="imgIcon.resources" :src="imgIcon.resources" class="avatar" alt style="width:75%"/>
                    <i v-else class="el-icon-plus"></i>
                  </div>
                </el-upload>
              </div>
            </el-form-item>

            <el-form-item label="品牌介绍">
             
                <div style="margin: 20px 0;"></div>
                <el-input
                  type="textarea"
                  placeholder="请输入内容"
                  v-model="form.describe"
                  maxlength="200"
                  show-word-limit
                ></el-input>
          
            </el-form-item>

            <el-form-item label="通用banner">
              <div class="updateBanner">
                 <br/>
                <el-upload
                  action="https://xttapi.lexj.com/helper/uploadCdn"
                  :show-file-list="false"
                  :on-success="handleImageSuccess"
                  :list-type="imgnewBanner.resources ? '' : 'picture-card'"
                >
                  <div class="container">
                    <img
                      v-if="imgnewBanner.resources"
                      :src="imgnewBanner.resources"
                      class="avatar"
                      alt
                    />
                    <i v-else class="el-icon-plus"></i>
                  </div>
                </el-upload>

                <el-dialog :visible.sync="dialogVisible">
                  <img width="100%" :src="dialogImageUrl" alt />
                </el-dialog>
              </div>
            </el-form-item>
            <el-form-item label="特定分类banner">
              <div class="speciallyBanner">
                 <br/>         
                <el-button plain size="small" @click="cleanBanner()">新增分类</el-button>
              </div>
              <el-row>
                <el-col
                  :span="11"
                  v-for="(resource, index) in form.brand_resources"
                  v-show="showBrandList"
                  :key="index"
                  style="height: 400px"
                >
                  <el-card :body-style="{ padding: '0px', height: '100%' }" shadow="hover">
                    <div style="padding: 14px;height: 100%;">
                      <span>{{resource.tag_name}}</span>
                      <el-button plain size="small" @click="deleteBanner(index)" style="position: relative;left: 130px;">删除</el-button>
                      <el-upload
                        action="https://xttapi.lexj.com/helper/uploadCdn"
                        :show-file-list="false"
                        :on-success="handleSpListSuccess"
                        :list-type="resource.resources ? '' : 'picture-card'"
                      >
                        <div class="container">
                          <img
                            @click="spCurrentIndex = index; currentResource = resource"
                            v-if="resource.resources"
                            :src="resource.resources"
                            style="width: 100%; display: block;"
                            class="avatar"
                            alt
                          />
                          <i v-else class="el-icon-plus"></i>
                        </div>
                      </el-upload>
                    </div>
                  </el-card>
                </el-col>
              </el-row>
            </el-form-item>
            <div class="created-SaveButton">
              <br/>
              <el-button plain size="small" @click="createdSave(form)">保存</el-button>
            </div>
          </el-form>
        </el-dialog>
        <el-form :model="form.spBanner">
          <div class="speciallyBanner-popup">
            <el-dialog title :visible.sync="speciallyBanner">
              <span>选择分类：</span>
              <el-select v-model="form.tag_id" clearable placeholder="请选择">
                <el-option
                  v-for="item in speciallyBanners"
                  :key="item.id"
                  :label="item.tag_name"
                  :value="item.id"
                  :disabled="item.disabled"
                ></el-option>
              </el-select>
              <br />
             <div class="bannerType">
                <el-upload
                  action="https://xttapi.lexj.com/helper/uploadCdn"
                  :show-file-list="false"
                  :on-success="handleSpSuccess"
                  :list-type="spnewBanner.resources ? '' : 'picture-card'"
                >
                  <div class="container">
                    <img v-if="spnewBanner.resources" :src="spnewBanner.resources" class="avatar" alt />
                    <i v-else class="el-icon-plus"></i>
                  </div>
                </el-upload>
             </div>
            
              <el-button type="primary" @click="spcreateBanner(spnewBanner)" style="margin-left: 72px;">确认新增</el-button>
            </el-dialog>
          </div>
        </el-form>
        <el-table :data="tableData" border stripe style="width: 100%;">
          <el-table-column prop="id" label="序号" width="100"></el-table-column>
          <el-table-column prop="brand_name" label="渠道品牌名" width="auto"></el-table-column>
          <el-table-column label="活动名/分类" width="auto">
            <template slot-scope="scope">
              <div :key="item.id" v-for="item in scope.row.actInfo" style="display:flex">
                <el-link @click="showGoods(item.activityId)">
                  {{ item.name}}
                  <i class="el-icon-view el-icon--right" />
                </el-link>
                <p style="margin-left: 10px">{{'('+item.tag_name+')'}}</p>
              </div>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="auto">
            <template slot-scope="scope">
              <el-button @click="blindBrandName(scope.row)">绑定品牌</el-button>
              <el-button @click="createdBrand_bind(scope.row.id,scope.row)">新建品牌</el-button>
            </template>
          </el-table-column>
        </el-table>

        <!-- 綁定品牌 -->
        <!-- <el-dialog title="绑定品牌库中品牌" :visible.sync="dialogFormVisible">
          <el-form :model="form">
            <el-form-item label="品牌ID:" :label-width="formLabelWidth"  :required="true">
              <el-input
                class="filter-option-input"
                v-model="formInline.searchbrand_id"
                placeholder="请输入品牌ID"
                clearable
                maxlength="20"
                style="width: 188px"
              ></el-input>

              <el-button
                icon="el-icon-success"
                @click="searchBindBrand({brand_id:formInline.searchbrand_id})"
              ></el-button>
            </el-form-item>

            <el-form-item
              label="品牌名称："
              :label-width="formLabelWidth"
              style="position: relative;left: 20px;"
            >
              <span class="blindbrandname">{{bindBrand.brand_name}}</span>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="bindBrandMethod" :disabled="this.searchCheck">确 定</el-button>
            <el-button @click="bindBrandCancle()">取 消</el-button>
          </div>
        </el-dialog> -->

        <el-dialog title="修改商品所属品牌" :visible.sync="dialogFormVisible" width="30%">
          <el-form :model="form">
            <el-form-item label="品牌名称" :label-width="formLabelWidth">
            <el-select v-model="formInline.searchbrand_id" filterable remote placeholder="请输入关键词" :remote-method="remoteMethod" :loading="loading">
                <el-option v-for="item in options" :key="item.id" :label="item.brand_name" :value="item.id" />
            </el-select>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="bindBrandMethod()" >确 定</el-button>
            <el-button @click="bindBrandCancle()">取 消</el-button>
          </div>
        </el-dialog>


        <el-dialog title="商品列表" :fullscreen="true" :visible.sync="showGoodsList">
          <el-col :span="24">
            <akc-goods-list ref="goodsListxxx" />
          </el-col>
        </el-dialog>
      </el-tab-pane>


      <el-tab-pane label="已入库" name="second">
    
        <el-dialog title="设置品牌标签" :visible.sync="chooseLable">
          <el-checkbox-group v-model="brandLablesIds">
            <el-checkbox
              v-for="label of brandLables"
              :label="label.id"
              :key="label.id"
            >{{ label.label_name }}</el-checkbox>
          </el-checkbox-group>
          <div slot="footer" class="dialog-footer">
            <el-button
              type="primary"
              @click="batchUpdateBrandLabel({labelIds:brandLablesIds, _brandIds:brandIds})"
            >确 定</el-button>
            <el-button @click="chooseLable = false">取 消</el-button>
          </div>
        </el-dialog>

        <!-- 搜索已入库的品牌信息 -->
        <div class="filter-container">
          <div class="filter-option" @keyup.enter="selectBrandList(selectParam, 0)">
            <span class="filter-option-key">品牌ID：</span>
            <el-input
              class="filter-option-input"
              v-model="selectParam.brand_id"
              placeholder="请输入品牌ID"
              clearable
            ></el-input>
          </div>
          <div class="filter-option" @keyup.enter="selectBrandList(selectParam, 0)">
            <span class="filter-option-key">品牌名称：</span>
            <el-input
              class="filter-option-input"
              v-model="selectParam.brand_name"
              placeholder="请输入品牌名称"
              clearable
            ></el-input>
          </div>
          <div class="filter-option">
            <span class="filter-option-key">品牌分类：</span>
            <el-select clearable v-model="selectParam.type_code" placeholder="请选择">
              <el-option
                v-for="item in brandTypeList"
                :label="item.label"
                :value="item.type_code"
                :key="item.type_code"
              />
            </el-select>
          </div>
          <div class="filter-option">
            <span class="filter-option-key">自动上下架：</span>
            <el-select clearable v-model="selectParam.auto_status" placeholder="请选择">
              <el-option
                v-for="item in selectupdate"
                :label="item.desc"
                :value="item.auto_up_status"
                :key="item.desc"
              />
            </el-select>
          </div>
          <div class="searchButton">
            &nbsp;&nbsp;&nbsp;&nbsp;
            <el-button
              type="primary"
              @click="selectBrandList(selectParam, 0)"
              plain
              style="position: relative;bottom: 14px;left: 7px;"
              
            >搜索</el-button>
          </div>
        </div>
        <el-table
          ref="multipleTable"
          :data="brandList"
          border
          stripe
          tooltip-effect="dark"
          style="width: 100%"
          @selection-change="handleSelectionChange"
        >
          <el-table-column type="selection" width="55" />
          <el-table-column prop="id" label="品牌ID" width="120" />
          <el-table-column prop="brand_name" label="品牌名" width="120" />
          <el-table-column prop="type_name" label="品牌类型" width="120" />
          <el-table-column prop="supplier_brand" label="渠道品牌名" width="120" />
          <el-table-column prop="tag" label="分类" width="120" />
          <el-table-column prop="labels" label="品牌运营标签" width="120" />
          <el-table-column prop="auto_up_status_str" label="是否自动上架" width="120" />
          <el-table-column label="操作" show-overflow-tooltip>
            <template slot-scope="scope">
              <el-button plain type="small" @click="brandInfoMethod(scope.row)">查看</el-button>
              <el-button plain size="small" @click="editBrand(scope.row)">编辑</el-button>
              <el-button plain size="small" @click="statusChangeDownConfirm(scope.row)">拉黑</el-button>
              <el-button plain size="small" @click="cancleSinceBrandDialog(scope.row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
        <!-- 删除弹窗 -->
         <el-dialog title :visible.sync="cancleDialog" width="30%" style="text-align: center;">
          <span style="font-weight: bold;font-size:20px">是否删除该品牌:</span>    
          <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="cancleSinceBrand(templateCancle)">确 定</el-button>
            <el-button @click="_cancleSinceBrandDialog()">取 消</el-button>
          </div>
        </el-dialog>
        <!-- 拉黑弹窗 -->
        <el-dialog title :visible.sync="blackWindow" width="30%" style="text-align: center;">
          <span style="font-weight: bold;font-size:20px">是否确认该品牌进入黑名单:</span>
          <br />
          <span>(品牌进入黑名单后可去黑名单漂白)</span>
          <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="statusChangeDown(blackInfo)">确 定</el-button>
            <el-button @click="blackWindow = false">取 消</el-button>
          </div>
        </el-dialog>
      </el-tab-pane>

      <el-dialog title="查看品牌" :visible.sync="lookBrand">
        <el-form :model="brandInfo">
          <el-form-item label="品牌ID">
            <el-input :disabled="true" v-model="brandInfo.id" />
          </el-form-item>
          <el-form-item label="品牌名称">
            <el-input :disabled="true" v-model="brandInfo.brand_name" />
          </el-form-item>
          <el-form-item label="品牌类型">
            <el-select :disabled="true" v-model="brandInfo.typeName" />
          </el-form-item>
          <el-form-item label="是否自动上下架">
            <el-select :disabled="true" v-model="brandInfo.auto_up_status_str" />
          </el-form-item>
          <el-form-item label="标签信息">
            <el-checkbox-group disabled>
              <el-checkbox-button
                v-for="label in brandInfo.lebalName"
                :key="label.id"
              >{{ label.label_name}}</el-checkbox-button>
            </el-checkbox-group>
          </el-form-item>
          <el-form-item label="品牌介绍">
            <el-input :disabled="true" v-model="brandInfo.describe" />
          </el-form-item>
          <el-form-item label="品牌ICON">
            <br/>
            <div class="sinceIcon"> 
              <img v-if="brandInfo.icon" :src="brandInfo.icon" alt />
            </div>
          </el-form-item>
          <el-form-item label="品牌通用banner">
            <br/>
            <div class="sinceCurrency">
              <img v-if="showEditbanner.resources" :src="showEditbanner.resources"  alt />
            </div>
          </el-form-item>
          <el-form-item label="特定分类banner">
            <br/>
            <el-row>
              <el-col
                :span="8"
                v-for="resource in brandInfo.bannerResource"
                :key="resource.id"
                style="height: 400px"
              >
                <el-card :body-style="{ padding: '0px', height: '80%' }" shadow="hover" style="margin:15px">
                  <div style="padding: 14px;height: 100%;">
                    <span>{{resource.tag_name}}</span>
                    <img
                      v-if="resource.resources"
                      :src="resource.resources"
                      style="{ width: 100%;display: block;}"
                      alt
                    />
                  </div>
                </el-card>
              </el-col>
            </el-row>
          </el-form-item>
        </el-form>
      </el-dialog>

      <el-dialog title="编辑品牌" :visible.sync="edit">
        <br />

        <el-form :model="brandInfo">
          <el-form-item label="品牌ID">
            <el-input :disabled="true" v-model="brandInfo.id" />
          </el-form-item>
          <el-form-item label="品牌名称">
            <el-input v-model="brandInfo.brand_name" />
          </el-form-item>
          <el-form-item label="品牌类型">
            <el-select v-model="brandInfo.type_code" style="flex:1">
              <el-option
                v-for="item in brandTypeList"
                :key="item.type_code"
                :label="item.type"
                :value="item.type_code"
              />
            </el-select>
          </el-form-item>

          <el-form-item label="是否自动上下架">
            <el-select v-model="brandInfo.auto_up_status" style="flex:1">
              <el-option :key="1" label="自动上架" :value="1" />
              <el-option :key="0" label="默认下架" :value="0" />
            </el-select>
          </el-form-item>
          <el-form-item label="品牌标签">
            <el-checkbox-group v-model="brandAddLabel">
              <el-checkbox
                v-for="label of brandLables"
                :label="label.id"
                :key="label.id"
              >{{ label.label_name }}</el-checkbox>
            </el-checkbox-group>
          </el-form-item>
          <el-form-item label="品牌描述">
            <el-input v-model="brandInfo.describe" />
          </el-form-item>
          <el-form-item label="品牌ICON">
            <div class="sinceIcon">
              <el-upload
                action="https://xttapi.lexj.com/helper/uploadCdn"
                :show-file-list="false"
                :on-success="handleICONImgSuccess"
                :list-type="brandInfo.icon ? '' : 'picture-card'"
              >
                <div class="container">
                  <img v-if="brandInfo.icon" :src="brandInfo.icon" alt />
                  <i v-else class="el-icon-plus"></i>
                </div>
              </el-upload>
            </div>
          </el-form-item>
          <el-form-item label="品牌通用banner">
            <br />
            <div class="sinceCurrency" style="font-size:30px">
              <el-upload
                action="https://xttapi.lexj.com/helper/uploadCdn"
                :show-file-list="false"
                :on-success="handleEditBanner"
                :list-type="showEditbanner ? '' : 'picture-card'"
              >
                <div class="container">
                  <img
                    v-if="showEditbanner.resources"
                    :src="showEditbanner.resources"
                    alt
                  />
                  <i v-else class="el-icon-plus"></i>
                </div>
              </el-upload>
            </div>
          </el-form-item>
          <el-form-item label="特定分类banner">
            <br />
            <!-- 新增新的banner列表 -->
            <el-button plain size="small" @click="cleanSinceBanner()">新增分类</el-button>
            <el-row>
              <el-col
                :span="11"
                v-for="(resource, index) in brandInfo.bannerResource"
                :key="index"
                style="height: 400px"
                
              >
                <el-card :body-style="{ padding: '0px', height: '100%' }" shadow="hover" style="margin:15px">
                  <div style="padding: 14px;height: 100%;">
                    <span style>{{resource.tag_name}}</span>
                    <el-button plain size="small" @click="deleteSinceAdd(index)" style="position: relative;left: 130px;">删除</el-button>
                      <el-upload
                        action="https://xttapi.lexj.com/helper/uploadCdn"
                        :show-file-list="false"
                        :on-success="handleUpdateBannerImgSuccess"
                        :list-type="resource.resources ? '' : 'picture-card'"
                      >
                        <div class="container">
                          <img
                            @click="currentIndex = index; currentResource = resource"
                            v-if="resource.resources"
                            :src="resource.resources"
                            style="width: 100%; display: block;"
                            class="avatar"
                            alt
                          />
                          <i v-else class="el-icon-plus"></i>
                        </div>
                      </el-upload>
                  </div>
                </el-card>
              </el-col>
            </el-row>
          </el-form-item>
          <el-form-item>
            <el-button plain type="primary" @click="updateMethod(brandInfo)" style="margin-top: 40px">确认修改</el-button>
          </el-form-item>
        </el-form>
      </el-dialog>
      <!-- 已入库新增分类 -->
      <el-dialog title :visible.sync="AddspeciallyBanner">
        <span>选择分类：</span>
        <el-select v-model="newBanner.tag_id" clearable placeholder="请选择">
          <el-option v-for="item in listTag" :key="item.id" :label="item.tag_name" :value="item.id" :disabled="item.disabled"></el-option>
        </el-select>
        <br />
          <div class="bannerType">
            <el-upload
              action="https://xttapi.lexj.com/helper/uploadCdn"
              :show-file-list="false"
              :on-success="handleCreateBannerImgSuccess"
              :list-type="newBanner.resources ? '' : 'picture-card'"
            >
              <div class="container">
                <img v-if="newBanner.resources" :src="newBanner.resources" class="avatar" alt />
                <i v-else class="el-icon-plus"></i>
              </div>
            </el-upload>
          </div>
        <el-button type="primary" @click="createBanner(newBanner)" style="margin-left: 72px">确认新增</el-button>
      </el-dialog>

      <el-tab-pane label="黑名单" name="third">
        <div class="filter-container" @keyup.enter="selectBrandList(selectParam, 1)">
          <div class="filter-option">
            <span class="filter-option-key">品牌ID：</span>
            <el-input
              class="filter-option-input"
              v-model="selectParam.brand_id"
              placeholder="请输入品牌ID"
              clearable
            ></el-input>
          </div>
          <div class="filter-option" @keyup.enter="selectBrandList(selectParam, 1)">
            <span class="filter-option-key">品牌名称：</span>
            <el-input
              class="filter-option-input"
              v-model="selectParam.brand_name"
              placeholder="请输入品牌名称"
              clearable
            >
            </el-input>
          </div>
          <div>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <el-button type="primary" @click="selectBrandList(selectParam, 1)" plain>搜索</el-button>
          </div>
        </div>

        <el-table :data="brandList" stripe border style="width: 100%">
          <el-table-column prop="id" label="品牌ID" width="auto" />
          <el-table-column prop="brand_name" label="品牌名" width="auto" />
          <el-table-column prop="supplier_brand" label="渠道品牌名" width="auto"></el-table-column>
          <el-table-column prop="type_name" label="品牌类型" width="auto"></el-table-column>

          <el-table-column prop="operate" label="操作" width="auto">
            <template slot-scope="scope">
              <el-button plain size="small" @click="brandInfoMethod(scope.row)">查看</el-button>
              <el-button plain size="small" @click="washWhite(scope.row)">漂白</el-button>
            </template>
          </el-table-column>
        </el-table>

        <el-dialog title :visible.sync="Bleach" width="30%" style="text-align: center;">
          <span style="font-weight: bold;font-size:20px">是否将该品牌漂白:</span>
          <br />
          <span>(漂白后可以在库里边查看)</span>
          <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="statusChangeUp(changeWhite)">确 定</el-button>
            <el-button @click="Bleach = false">取 消</el-button>
          </div>
        </el-dialog>

      </el-tab-pane>
    </el-tabs>
    <div class="pagination" style="margin-top:20px;text-align: center;">
      <el-pagination
        @size-change="_handleSizeChange"
        @current-change="_handleCurrentChange"
        :total="_currentTotalCount()"
        :hide-on-single-page="value"
        :current-page="_currentPage()"
        :page-sizes="[10, 20, 30]"
        :page-size="_currentPageSize()"
        layout="total, sizes, prev, pager, next"
      />
    </div>
  </div>
</template>

<script>
import {
  brandList,
  brandTypes,
  labelList,
  _brandInfo,
  noAddBrandDBList,
  brandInfo,
  brandLebals,
  _listTag,
  _brandMVBanned,
  brandCreate,
  listTag,
  _brandListAddTag,
  _brandUpdate,
  _brandBind,
  getTagName,
  searchName,
  noAddGetInformtion,
  deleteSinceBrand
} from '@/api/brand';
import AkcGoodsList from '@/component/AiKuCun/goodsList';
import axios from 'axios';
export default {
  components: { AkcGoodsList },
  data() {
    return {
      goodsList: [],
      showGoodsList: false,
      needBind: 0,
      newBanner: {},
      imgIcon: {},
      imgnewBanner: {},
      spnewBanner: {},
      editBanner: {},
      page: 1,
      pageSize: 40,
      brandIds: [],
      listTag: [],
      currentBrandTypeId: null,
      brandType: {},
      show: true, // 新建按钮
      secondShow: false, // 已入库一键设置按钮
      edit2: false,
      lookBrand: false,
      brandInfo: {
        label: []
      },
      options: [],
      searchName: [], // 待入库绑定品牌模糊搜索
      brandAddLabel: [],
      selectParam: {},
      formLabel: [],
      formLabelIds: [],
      brandLables: [],
      brandLablesIds: [],
      changeWhite: {},
      searchCheck: true, // 绑定品牌查询后确认按钮
      chooseLable: false,
      showBrandList: true,
      loading: false,
      formLabelWidth: '150px',
      createBrand: false,
      createSaveButton: false,
      edit: false, // 编辑弹窗页面
      speciallyBanner: false,
      AddspeciallyBanner: false,
      dialogFormVisible: false, // 绑定品牌
      oneKeySet: false, // 一键设置运营标签
      cancleDialog: false, // 已入库删除按钮
      blackWindow: false, // 拉黑
      Bleach: false, // 漂白
      dialogVisible: false, // 上传图片
      disabled: false, // 上传图片
      dialogImageUrl: '', // 上传图片
      currentIndex: 0,
      imgCurrentIndex: 0,
      spCurrentIndex: 0,
      input: '',
      text: '',
      textarea: '',
      edittextarea: '',
      radio: '1',
      editupdate: '3',


      brandList: [], // 已入库、黑名单
      brandActivity: [], // 活动名和分类名
      brandTypeList: [],
      checkList: [],
      brandIcon: [], // 品牌标签列表
      brandResources: [], // 上传Banner
      bindBrand: {}, // 绑定品牌
      templateCancle: {}, // 已入库删除按钮
      uploadBanner: {}, // 上传Banner
      uploadSpBanner: {}, // 上传特定Banner
      showEditbanner: {},
      refreshData: {}, // 已入库删除后刷新
      formInline: {
        page: 1,
        pageSize: 10,
        type_code: 0,
        is_banned: 0,
        auto_status: 1,
        brand_id: null,
        brand_name: null,
        banned: false,
        brand_status: false,
        grade: [0, 0, 0]
      },
      activeName: 'first',

      form: {
        brand_name: '',
        type_code: '',
        auto_up_status: [],
        brand_resources: [],
        label: []
      },

      speciallyBanners: [], // 特定banner内的多选列表

      pageIndexes: {
        first: {
          page: 1,
          pageSize: 10,
          totalCount: 0
        },
        second: {
          page: 1,
          pageSize: 10,
          totalCount: 0
        },
        third: {
          page: 1,
          pageSize: 10,
          totalCount: 0
        }
      },

      tableData: [], // 待入库

      selectupdate: [
        {
          auto_up_status: '1',
          desc: '自动上架'
        },
        {
          auto_up_status: '0',
          desc: '默认下架'
        }
      ],
      value: ''
    };
  },

  created() {
    this.bannerType();
  
  },
  mounted() {
    this.init();
    this.searchNameList();
    this._getList({
      page: this.formInline.page,
      pageSize: this.formInline.pageSize
    });
  },

  methods: {
    //  sendMessage(){
    //      let url ="http://dingxin.market.alicloudapi.com/dx/sendSms"; 
    //      axios.post(url, {
               
    //     }, {
    //        headers:{'Content-Type':'application/x-www-form-urlencoded; charset=utf-8',
    //         'Authorization':'APPCODE 788bb08246a14a3badd3c929f93be2bc'
    //        },
    //        params:{mobile:"15099830231",param:"code:55555",tpl_id:"TP1711063"}
    //     }
    //     ).then(res => {
    //         console.log('------->'+JSON.stringify(res));
    //     });
    // },
    getMessage(){
      sendMessage().then(response =>{
          const res = response.data;
          
      });
    },
    init() {
      // 获取首页商品列表
      this.handleClick({ name: 'first' }, null);
      // 获取标签列表
      this.listLabel();
      // 获取品牌类型列表
      this._brandType();
      // 获取活动分类列表
      this.listTagM();
    },
    listGoods(params) {
      setTimeout(() => {
        this.$refs.goodsListxxx.didPresent(params.id, true);
      }, 0);
    },
    bindBrandMethod() {
      if (
        this.formInline.searchbrand_id !== null &&
        !isNaN(this.formInline.searchbrand_id)
      ) {
        const bindBrand = {
          brandId: this.formInline.searchbrand_id,
          supplierBrandId: this.currentBrandInfo.id
        };
        this._2brandBind(bindBrand);
        this.dialogFormVisible = false;
      } else {
        this.$message('输入错误');
        this.dialogFormVisible = false;
      }
    },
    showGoods(params) {
      this.showGoodsList = true;
      this.listGoods({ id: params });
    },
    _2brandBind(bindBrand) {
      _brandBind(bindBrand).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.$message('绑定品牌成功');
          // this.handleClick({ name: "first" }, null);
          this._getList();
          this.options = [];
          this.bindBrand = {};
          this.formInline = {
            searchbrand_id: 0
          };
          this.searchCheck = !this.searchCheck;
        } else {
          this.$message.error(resData.msg || '绑定品牌失败');
          this.formInline = {
            searchbrand_id: 0
          };
        }
      });
    },
    listLabel() {
      labelList().then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.brandLables = resData.data;
          this.formLabel = resData.data;
        } else {
          this.$message.error(resData.msg || '获取品牌标签失败');
        }
      });
    },
    async createBanner(params) {

      const compareID = 0;
      // 已入库banner
      if (
        typeof params.tag_id !== 'undefined' &&
        typeof params.resources !== 'undefined' &&
        typeof params.tag_id !== null
      ) {

        const tagBannerName = await this.getAddTagNames({ id: params.tag_id });
        params.tag_name = tagBannerName.tag_name;
        this.brandInfo.bannerResource.push(params);
        this.AddspeciallyBanner = false;

        const listTag_id = this.listTag.map(item => item.id);
        const brandInfo_id = this.brandInfo.bannerResource.map(i => i.tag_id);
        if (brandInfo_id !== null && brandInfo_id !== undefined) {
          for (let i = 0; i < brandInfo_id.length; i++) {
            const indexT = listTag_id.indexOf(brandInfo_id[i]);
            this.listTag[indexT].disabled = true;
          }
        }


      } else {
        this.$message('参数不全');
      }
      this.newBanner = {};
    },
    updateMethod(params) {
      params.lebalIds = this.brandAddLabel;
      params.bannerResource.push(this.showEditbanner);
      _brandUpdate(params).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.edit = false;

          this.selectBrandList(this.selectParam, 0);
        }
      });
    },

    async spcreateBanner(params) {
      // 待入库特定banner

      params.tag_id = this.form.tag_id;
      if (
        typeof params.resources !== 'undefined' &&
        typeof params.tag_id !== 'undefined' &&
        params.tag_id !== ''
      ) {
        const tagInfo = await this.getTagNames({ id: params.tag_id });
        params.tag_name = tagInfo.tag_name;
        this.form.brand_resources.push(params);
        this.speciallyBanner = !this.speciallyBanner;
        this.form.tag_id = '';
      } else {
        this.$message('参数不全');

        this.speciallyBanner = !this.speciallyBanner;
      }
      this.spnewBanner = {};

      const speciallyBanners_id = this.speciallyBanners.map(item => item.id);
      const brandResources_id = this.form.brand_resources.map(i => i.tag_id);
      if (brandResources_id !== null && brandResources_id !== undefined) {
        for (let i = 0; i < brandResources_id.length; i++) {
          const indexT = speciallyBanners_id.indexOf(brandResources_id[i]);
          this.speciallyBanners[indexT].disabled = true;
        }
      }


    },

    _formatActivityInfo(actInfo) {
      let result = '';
      actInfo.forEach(item => (result += `${item.name} ${item.tag_name}\n`));
      return result;
    },
    handleEditBanner(res, file, fileList) {
      this.showEditbanner = {
        tag_id: 0,
        tag_name: '通用',
        resources: res.data
      };
    },

    handleIcon(res, file, fileList) {
      const banner = Object.assign({}, this.imgIcon);
      banner.resources = res.data;
      this.imgIcon = banner;
      this.form.icon = res.data;
    },

    handleImageSuccess(res, file, fileList) {
      const banner = Object.assign({}, this.imgnewBanner);
      banner.resources = res.data;
      this.imgnewBanner = banner;
      this.form.brandResources = res.data;
      this.brandResources.push(
        (this.uploadBanner = { tag_id: 0, resources: this.form.brandResources })
      );
    },
    handleImageListSuccess(res, file, fileList) {
      const resources = this.form.bannerResource;
      const resource = resources[this.imgCurrentIndex];
      resource.resources = res.data;
      resources.splice(this.imgCurrentIndex, 1, resource);
      this.form.bannerResource = resources;
    },
    handleSpSuccess(res, file, fileList) {
      // 特定banner
      const banner = Object.assign({}, this.spnewBanner);
      banner.resources = res.data;
      this.spnewBanner = banner;
      // this.form.brandsp_resources = res.data;
      // this.brand_resources.push(this.uploadSpBanner={tag_id:this.form.tag_id,resources:this.form.brandsp_resources});
    },
    handleSpListSuccess(res, file, fileList) {
      // 特定banner列表
      const resources = this.form.bannerResource;
      const resource = resources[this.spCurrentIndex];
      resource.resources = res.data;
      resources.splice(this.spCurrentIndex, 1, resource);
      this.form.bannerResource = resources;
    },

    handleICONImgSuccess(res, file, fileList) {
      this.brandInfo.icon = res.data;
    },
    handleCreateBannerImgSuccess(res, file, fileList) {
      const banner = Object.assign({}, this.newBanner);
      banner.resources = res.data;
      this.newBanner = banner;
    },
    handleUpdateBannerImgSuccess(res, file, fileList) {
      const resources = this.brandInfo.bannerResource;
      const resource = resources[this.currentIndex];
      resource.resources = res.data;
      resources.splice(this.currentIndex, 1, resource);
      this.brandInfo.bannerResource = resources;
    },
    listTagM() {
      _listTag().then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          resData.data.map((item, index) => this.listTag.push(Object.assign({}, item, { disabled: false })));
          // this.listTag = resData.data;
        }
      });
    },
    brandInfoMethod(params) {
      this.lookBrand = true;
      this.showEditbanner = {};
      _brandInfo({ brand_id: params.id }).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.brandInfo = resData.data;
          if (resData.code === 10000) {
            this.brandInfo = resData.data;
            const resour = this.brandInfo.bannerResource;

            if (resour !== null) {
              for (const i of resour) {
                if (i.tag_id === 0) {
                  this.showEditbanner = i;
                  const index = resour.indexOf(this.showEditbanner);
                  if (index !== -1) {
                    resour.splice(index, 1);
                  }
                  this.brandInfo.bannerResource = resour;
                  break;
                }
              }
            }
          }
        }
      });
    },

    ownBrandList(params) {
      this.refreshData = params;
      this.brandList = [];
      params.page =
          typeof params.page === null || params.page < 1 || isNaN(params.page) ? 1 : params.page;
      params.pageSize =
          typeof params.pageSize === null || params.pageSize < 1 || isNaN(params.pageSize) ? 10 : params.pageSize;
      brandList(params).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.brandList = resData.data;
          this.totalCount = resData.totalCount[0].sinceNum;
        }
      });
    },
    searchNameList() {
      searchName().then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.searchName = resData.data;
          // console.log(JSON.stringify(this.searchName));
        }
      });
    },
    remoteMethod(query) {
      if (query !== '') {
        this.loading = true;
        setTimeout(() => {
          this.loading = false;
          this.options = this.searchName.filter(item => {
            return item.brand_name.toLowerCase().indexOf(query.toLowerCase()) > -1;
          });
        }, 200);
      } else {
        this.options = [];
      }
    },

    selectBrandList(params, is_banned) {
      params.is_banned = is_banned;
      this.ownBrandList(params);
    },
    batchUpdateBrandLabel(params) {
      _brandListAddTag(params).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.handleClick({ name: 'second' }, null);
          this.chooseLable = false;
        } else {
          this.$message(resData.msg);
        }
      });
    },
    chooseLableShow() {
      if (this.brandIds.length === 0) {
        this.chooseLable = false;
        this.$message('请选择需要设置的品牌');
      } else {
        this.chooseLable = true;
        this.brandLablesIds = [];
      }
    },
    _getList() {
      this.loading = true;
      this.formInline.page = this._currentPage();
      this.formInline.pageSize = this._currentPageSize();

      noAddBrandDBList(this.formInline).then(response => {
        this.loading = false;
        const resData = response.data;
        if (resData.code === 10000) {
          this.$message.success('加载成功');
          this.totalCount = resData.totalCount[0].num;
          this.tableData = resData.data;
        } else {
          this.$message.error(resData.msg || '获取数据失败');
        }
      });
    },


    createdBrand_bind(needBind, form) { // 新建品牌(绑定品牌旁边)
      noAddGetInformtion({ id: needBind }).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.form = {
            brand_resources: [],
            label: [],
            brand_name: resData.data[0].brand_name,
            describe: resData.data[0].description
          };
          this.imgIcon.resources = resData.data[0].brand_logo_url;
          this.form.icon = this.imgIcon.resources;


        }
      });
      this.createBrand = true;
      this.needBind = needBind;
      this.formLabelIds = [];
      this.imgnewBanner = {};
      this.brandIcon = [];// 品牌标签列表
      this.form.brand_resources = [];
      this.imgIcon = {};

      // eslint-disable-next-line no-return-assign
      this.speciallyBanners.map(item => item.disabled = false);
    },

    createdBrand(needBind, form) {

      // 创建品牌
      this.createBrand = true;
      this.needBind = needBind;
      this.formLabelIds = [];
      this.imgIcon = {};
      this.imgnewBanner = {};
      this.brandIcon = [];
      if (this.$refs[form] !== undefined) {
        this.$refs[form].resetFields();
      }

      this.form = {
        brand_resources: [],
        label: []
      };
      this.form.brand_resources = [];
      // eslint-disable-next-line no-return-assign
      this.speciallyBanners.map(item => item.disabled = false);
    },

    createdSave(form) {
      this.createSaveButton = true;
      this.form.brand_resources = this.form.brand_resources.concat(this.brandResources);
      this.brandResources = [];
      this.form.labels = this.form.label.concat(this.formLabelIds);
      if (this.form.brand_resources === null || this.form.brand_resources === undefined) {
        this.showBrandList = false;
      }
      brandCreate(form).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {

          this.form = {
            brand_resources: [],
            label: []
          };
          this.formLabelIds = [];
          // this.imgIcon = {};
          this.imgnewBanner = {};
          this.brandIcon = [];
          if (Number(this.needBind) > 0) {
            this._2brandBind({
              brandId: resData.data,
              supplierBrandId: this.needBind
            });
            this.needBind = 0;
          }
          this.createBrand = false;
          this._getList();
          this.showBrandList = true;
        } else {
          this.$message(response.data.msg);
          // this.form = {
          //   brand_resources: [],
          //   label: []
          // };
          this.formLabelIds = [];
          // this.imgIcon = {};
          this.imgnewBanner = {};
          this.brandIcon = [];
          this.showBrandList = true;
        }
      });
    },
    deleteBanner(params) {
      // 待入库删除按钮
      const speciallyBanners_id = this.speciallyBanners.map(item => item.id);
      const brandResources_id = this.form.brand_resources.map(i => i.tag_id);
      if (brandResources_id !== null && brandResources_id !== undefined) {
        for (let i = 0; i < brandResources_id.length; i++) {
          const indexT = speciallyBanners_id.indexOf(brandResources_id[i]);
          this.speciallyBanners[indexT].disabled = false;
        }
      }


      this.form.brand_resources.splice(params, 1);
    },
    cancleSinceBrandDialog(params) {
    // 已入删除按钮库弹窗start
      this.templateCancle = {};
      this.templateCancle = params;
      this.cancleDialog = !this.cancleDialog;
    },
    _cancleSinceBrandDialog() {
      // 已入删除按钮库弹窗取消时初始化
      this.cancleDialog = !this.cancleDialog;
      this.templateCancle = {};
    },
    cancleSinceBrand(params) {
      // 已入库删除按钮
      deleteSinceBrand(params).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.cancleDialog = !this.cancleDialog;
          this.templateCancle = {};
          this.$message('删除成功');
          this.ownBrandList(this.refreshData);
          this.refreshData = {};
        }
      });
    },
    deleteSinceAdd(params) {
      // 已入库banner删除按钮
      const listTag_id = this.listTag.map(item => item.id);
      const brandInfo_id = this.brandInfo.bannerResource.map(i => i.tag_id);
      if (brandInfo_id !== null && brandInfo_id !== undefined) {
        for (let i = 0; i < brandInfo_id.length; i++) {
          const indexT = listTag_id.indexOf(brandInfo_id[i]);
          this.listTag[indexT].disabled = false;
        }

      }

      this.brandInfo.bannerResource.splice(params, 1);

    },

    handleRemove(file) {
      // 上传图片
    },
    handlePictureCardPreview(file) {
      // 上传图片
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    handleDownload(file) {
      // 上传图片
    },

    blindBrandName(params) {
      // 绑定品牌

      this.currentBrandInfo = params;
      this.dialogFormVisible = true;
      this.searchCheck = true;
      this.bindBrand = {};
      this.formInline = {};
    },
    bindBrandCancle() {
      // 绑定品牌取消
      this.dialogFormVisible = false;
      this.bindBrand = {};
      this.formInline = {};
    },
    editBrand(params) {
      // 编辑品牌
      this.edit = true;
      this.showEditbanner = {};
      _brandInfo({ brand_id: params.id }).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.brandInfo = resData.data;
          const resour = this.brandInfo.bannerResource;

          if (resour !== null) {
            for (const i of resour) {
              if (i.tag_id === 0) {
                this.showEditbanner = i;
                const index = resour.indexOf(this.showEditbanner);
                if (index !== -1) {
                  resour.splice(index, 1);
                }
                this.brandInfo.bannerResource = resour;
                break;
              }
            }
          }

          this.currentBrandTypeId = this.brandInfo.typeId;
          this.brandInfo.brandTypes = this.brandTypeList;
          this.brandAddLabel = this.brandInfo.lebalIds ? this.brandInfo.lebalIds : [];
        }
      });

      // eslint-disable-next-line no-return-assign
      this.listTag.map(x => x.disabled = false);


    },
    setBrandIcon() {
      // 一键设置品牌运营标签
      this.oneKeySet = true;
    },
    statusChangeDownConfirm(params) {
      this.blackWindow = true;
      this.blackInfo = params;
    },

    statusChangeDown(params) {
      this.brandStatusChange({
        brand_id: params.id,
        is_banned: 1,
        handName: 'second'
      });
    },
    statusChangeUp(params) {
      this.brandStatusChange({
        brand_id: params.id,
        is_banned: 0,
        handName: 'third'
      });
      this.Bleach = false;
      this.changeWhite = {};
    },
    brandStatusChange(params) {
      _brandMVBanned(params).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.$message('成功');
          this.blackWindow = false;
          this.selectBrandList(
            this.selectParam,
            params.is_banned === 1 ? 0 : 1
          );
        } else {
          this.$message(resData.meg);
        }
      });
    },
    washWhite(params) {
      // 漂白
      this.changeWhite = params;
      this.Bleach = true;
    },

    _handleSizeChange(pageSize) {
      this.pageIndexes[this.activeName].pageSize = pageSize;
      switch (this.activeName) {
        case 'first':
          this._getList();
          break;

        case 'second':
          this.ownBrandList(Object.assign(this.selectParam, {
            is_banned: 0,
            // page: this.pageIndexes[this.activeName].page,
            pageSize: this.pageIndexes[this.activeName].pageSize,
            totalCount: this.formInline.totalCount
          }));
          break;
        case 'third':
          this.ownBrandList(Object.assign(this.selectParam, {
            // page: this.pageIndexes[this.activeName].page,
            pageSize: this.pageIndexes[this.activeName].pageSize,
            totalCount: this.formInline.totalCount,
            is_banned: 1
          }));
          break;
        default:
          this.$message.error('获取商品列表失败');
      }
    },

    _handleCurrentChange(page) {
      this.pageIndexes[this.activeName].page = page;
      switch (this.activeName) {
        case 'first':
          this._getList();
          break;

        case 'second':

          this.ownBrandList(Object.assign(this.selectParam, {
            is_banned: 0,
            page: this.pageIndexes[this.activeName].page,
            pageSize: this.pageIndexes[this.activeName].pageSize,
            totalCount: this.formInline.totalCount
          }));
          break;
        case 'third':
          this.ownBrandList(Object.assign(this.selectParam, {
            page: this.pageIndexes[this.activeName].page,
            pageSize: this.pageIndexes[this.activeName].pageSize,
            totalCount: this.formInline.totalCount,
            is_banned: 1
          }));
          break;
        default:
          this.$message.error('获取商品列表失败');
      }
    },

    _currentPage() {
      return this.pageIndexes[this.activeName].page;
    },
    _currentPageSize() {
      return this.pageIndexes[this.activeName].pageSize;
    },

    _currentTotalCount() {
      this.pageIndexes[this.activeName].totalCount = this.totalCount;
      return this.pageIndexes[this.activeName].totalCount;
    },
    handleClick(tab, event) {
      this.formInline.page = 1;

      switch (tab.name) {
        case 'first':
          this.show = true;
          this.secondShow = false;
          this.pageIndexes[tab.name].page = 1;
          this._getList();
          this.selectParam = {};
          break;

        case 'second':
          this.selectParam = {};
          this.show = false;
          this.secondShow = true;
          this.pageIndexes[tab.name].page = 1;
          this.ownBrandList({
            is_banned: 0,
            page: this.formInline.page,
            pageSize: this.formInline.pageSize,
            totalCount: this.formInline.totalCount
          });
          break;
        case 'third':
          this.selectParam = {};
          this.show = false;
          this.secondShow = false;
          this.pageIndexes[tab.name].page = 1;
          this.ownBrandList({
            is_banned: 1,

            page: this.formInline.page,
            pageSize: this.formInline.pageSize,
            totalCount: this.formInline.totalCount
          });
          break;
        default:
          this.$message.error('获取商品列表失败');
      }
    },
    handleSelectionChange(val) {
      this.brandIds = [];
      for (let i = 0; i < val.length; i++) {
        this.brandIds.push(val[i].id);
      }
    },

    _brandType() {
      brandTypes().then(response => {
        const res = response.data;
        if (res.code === 10000) {
          for (const iterator of res.data) {
            const brandOpt = {};
            brandOpt.label = iterator.type_name;
            brandOpt.type = iterator.type_name;

            brandOpt.value = iterator.type_code;
            brandOpt.id = iterator.id;
            brandOpt.type_code = iterator.type_code;
            this.brandTypeList.push(brandOpt);
          }
        }
      });
    },
    searchBindBrand(params) {
      if (typeof params.brand_id !== 'undefined' && params.brand_id !== '' && !isNaN(params.brand_id) && params.brand_id !== null) {
        brandInfo(params).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.bindBrand = res.data;
            if (this.bindBrand !== null && this.bindBrand !== undefined) {
              this.searchCheck = !this.searchCheck;
            } else {
              this.$message('没有此ID');
              // this.dialogFormVisible = false;
              this.bindBrand = {};
              this.formInline = {};
            }
          }
        });
      } else {
        this.$message('必填项不能为空 或 输入错误');
        // this.dialogFormVisible = false;
        this.bindBrand = {};
        this.formInline = {};
      }

    },

    cleanBanner() {
      // 待入库新增分类初始化
      this.spnewBanner = {};
      delete this.form.tag_id;
      this.speciallyBanner = true;
    },
    cleanSinceBanner() {
      // 已入库新增分类初始化
      this.newBanner = {};
      delete this.newBanner.tag_id;
      this.AddspeciallyBanner = true;

      const listTag_id = this.listTag.map(item => item.id);
      const brandInfo_id = this.brandInfo.bannerResource.map(i => i.tag_id);
      if (brandInfo_id !== null && brandInfo_id !== undefined) {
        for (let i = 0; i < brandInfo_id.length; i++) {
          const indexT = listTag_id.indexOf(brandInfo_id[i]);
          this.listTag[indexT].disabled = true;
        }
      }
    },

    bannerType() {
      // 特定banner分类
      listTag().then(response => {
        const res = response.data;
        if (res.code === 10000) {
          // this.speciallyBanners = res.data;
          res.data.map((item, index) => this.speciallyBanners.push(Object.assign({}, item, { disabled: false })));

        }
      });
    },
    // 根据id查询tag_name(待入库)
    async getTagNames(params) {
      const response = await getTagName(params);
      const res = response.data;
      if (res.code === 10000) {
        return res.data;
      }
    },
    // 根据id查询tag_name(已入库)
    async getAddTagNames(params) {
      const response = await getTagName(params);
      const res = response.data;
      if (res.code === 10000) {
        return res.data;
      }
    }
  }
};
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.createdButton {
  position: absolute;
  top: 16px;
  right: 205px;
  z-index: 100;
}
.oneSetButton{
  position: absolute;
  top: 16px;
  right: 205px;
  z-index: 100;
}
.app-container {
  font-family: "微软雅黑", Microsoft YaHei;
  img {
    width: 100%;
    height: 100%;
  }
  .brandIcon {
    display: flex;
    margin-top: 15px;
  }
  .updateIcon {
    margin: 15px 0px 15px 0px;
    span {
      margin-right: 15px;
    }
  }
  .updateBanner {
    margin: 20px 0px 15px 0px;
    span {
      margin-right: 15px;
    }
  }
  .speciallyBanner {
    margin: 15px 0px 15px 0px;
    span {
      margin-right: 15px;
    }
  }
  .bannerType{
    margin: 35px 0px 20px 74px;
  }
  .editBrand {
    display: flex;
    span {
      margin: 10px 10px 0px 0px;
    }
  }
  .edit-Brandname {
    display: flex;
    margin: 35px 0px 20px 0px;
    span {
      margin: 15px 10px 0px 0px;
    }
  }
  .edit-Brandtype {
    display: flex;
    span {
      margin: 15px 10px 0px 0px;
    }
  }
  .edit-BrandUpdate {
    margin: 20px 10px 0px 0px;
  }
  .edit-updateIcon {
    margin: 20px 10px 0px 0px;
    span {
      margin-right: 25px;
    }
  }
  .edit-BrandIntroduction {
    display: flex;
    margin: 20px 0px 0px 0px;
    span {
      margin: 18px 12px 0px 0px;
    }
  }
  .searchButton{
    margin-top: 16px;
  }
  .sinceIcon{
    width:30%;
    margin:20px;
  }
  .sinceCurrency{
    width: 70%;
    margin: 30px;
  }
  .blindbrandname {
    min-width: 100px;
    color: #555;
    font-size: 15px;
  }
  .filter-container {
    display: flex;
    span {
      text-align: center;
    }
    .filter-option {
      display: flex;
      flex-direction: row;
      align-items: center;
      margin-bottom: 10px;

      .filter-option-key {
        min-width: 100px;
        color: #555;
        font-size: 15px;
      }

      .filter-option-input {
        max-width: 300px;
      }
    }
  }
  .el-card {
    height: 100%;
  }
}
</style>