<template>
  <akc-hot-detail ref="hotDetail" :text="$route.params.text" :hotId="$route.params.id" :shareTime="$route.params.shareTime" :appType="$route.params.appType">
  </akc-hot-detail>
</template>

<script>
import AkcHotDetail from '@/component/AiKuCun/hotDetail';

export default {
  components: { AkcHotDetail },
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  
</style>
