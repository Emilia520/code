<template>
  <div class="app-container">
    <el-row>
      <el-col :span="24">
        <div class="header-title">机器人群数据报表</div>
      </el-col>
    </el-row>
    <el-row>
      <el-tabs type="border-card" @tab-click="onTabClick">
        <el-tab-pane label="拼多多按天订单" style="height:600px" v-loading="loading">
          <!-- 筛选条件 start -->
          <el-form :inline="true" :model="formInlineTab1" class="demo-form-inline">
            <el-form-item label="订单时间" class="time-width">
              <el-date-picker
              v-model="selectTimesTab1"
              type="daterange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              size="mini"
              align="right">
              </el-date-picker>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" size="mini" @click="onSubmit('orderChartPdd')">筛选</el-button>
            </el-form-item>
          </el-form>
          <!-- 筛选条件 end -->
          <div id="orderChartPdd" style="width:100%;height:500px;box-sizing:border-box;line-height:500px;"></div>
        </el-tab-pane>
        <el-tab-pane label="淘宝按天订单" style="height:600px" v-loading="loading">
          <!-- 筛选条件 start -->
          <el-form :inline="true" :model="formInlineTab1" class="demo-form-inline">
            <el-form-item label="订单时间" class="time-width">
              <el-date-picker
              v-model="selectTimesTab1"
              type="daterange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              size="mini"
              align="right">
              </el-date-picker>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" size="mini" @click="onSubmit('orderChartTb')">筛选</el-button>
            </el-form-item>
          </el-form>
          <!-- 筛选条件 end -->
          <div id="orderChartTb" style="width:100%;height:500px;box-sizing:border-box;line-height:500px;"></div>
        </el-tab-pane>
        <el-tab-pane label="订单详情" v-loading="loading">
          <!-- 筛选条件 start -->
          <el-col :span="24">
            <el-form :inline="true" :model="formInlineTab1" class="demo-form-inline">
              <el-form-item label="订单时间" class="time-width">
                <el-date-picker
                v-model="selectTimesTab3"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                size="mini"
                align="right">
                </el-date-picker>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" size="mini" @click="onSubmit('groupOrderData')">筛选</el-button>
              </el-form-item>
            </el-form>
          </el-col>
          <!-- 筛选条件 end -->
          <!-- 订单数据列表 start -->
          <el-col :span="24">
            <el-table
              :data="dataListTab3"
              border
              style="width: 100%"
              @sort-change="orderSort">
              <el-table-column
                prop="group_name"
                label="群名称"
                width="200"
                sortable>
              </el-table-column>
              <el-table-column
                prop="pdd_order_count"
                label="拼多多订单量"
                width="130"
                sortable>
              </el-table-column>
              <el-table-column
                prop="tb_order_count"
                label="淘宝订单量"
                width="130"
                sortable>
              </el-table-column>
              <el-table-column
                prop="pdd_order_amount_sum"
                label="拼多多订单流水"
                width="150"
                sortable>
              </el-table-column>
              <el-table-column
                prop="pdd_commission_sum"
                label="拼多多佣金"
                width="120"
                sortable>
              </el-table-column>
              <el-table-column
                prop="tb_order_amount_sum"
                label="淘宝订单流水"
                width="150"
                sortable>
              </el-table-column>
              <el-table-column
                prop="tb_commission_sum"
                label="淘宝佣金"
                width="120"
                sortable>
              </el-table-column>
            </el-table>     
          </el-col>
          <!-- 表格 end -->
          <!-- 分页 start -->
          <el-col :span="24">
            <div class="pagination" style="margin-top:20px;">
              <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="formInlineTab3.page" :page-sizes="[100, 200, 300, 400]" :page-size="formInlineTab3.page_size" layout="total, sizes, prev, pager, next" :total="totalcountTab3">
              </el-pagination>
            </div>
          </el-col>
          <!-- 分页 end -->
        </el-tab-pane>
        <el-tab-pane label="群相关信息" v-loading="loading">
          <!-- 数据列表 start -->
          <el-col :span="24">
            <el-table
              :data="dataListTab4"
              border
              style="width: 100%"
              @sort-change="orderSort">
              <el-table-column
                prop="name"
                label="昵称"
                width="160">
              </el-table-column>
              <el-table-column
                prop="pid"
                label="广告位"
                width="160"
                sortable>
              </el-table-column>
              <el-table-column
                prop="remark"
                label="群活码名称"
                width="220"
                sortable>
              </el-table-column>
              <el-table-column
                prop="group_name"
                label="群名称"
                width="220"
                sortable>
              </el-table-column>
              <el-table-column
                prop="group_member_count"
                label="群人数"
                width="100"
                sortable>
              </el-table-column>
              <el-table-column
                prop="category"
                label="群类型"
                width="100"
                sortable>
              </el-table-column>
            </el-table>     
          </el-col>
          <!-- 表格 end -->
          <!-- 分页 start -->
          <el-col :span="24">
            <div class="pagination" style="margin-top:20px;">
              <el-pagination @size-change="handleSizeChangeTab4" @current-change="handleCurrentChangeTab4" :current-page="formInlineTab4.page" :page-sizes="[100, 200, 300, 400]" :page-size="formInlineTab4.page_size" layout="total, sizes, prev, pager, next" :total="totalcountTab4">
              </el-pagination>
            </div>
          </el-col>
          <!-- 分页 end -->
        </el-tab-pane>
      </el-tabs>
    </el-row>
  </div>
</template>

<script>
import { getOrderData, getOrderStatusData, getPddOrderChartData, getWXGroupInfo } from '@/api/pdd';
import { getTbOrderChartData } from '@/api/tb';
import { timestampToTime } from 'utils/chanageTime';
import * as echarts from 'echarts';

export default {
  data() {
    return {
      curTab: 0,
      totalcountTab3: 0,
      totalcountTab4: 0,
      loading: false,
      formInlineTab1: {},
      selectTimesTab1: [new Date(new Date().getTime() - 1296000000), new Date()], // 默认最近15天的数据
      selectTimesTab2: [new Date(new Date().getTime() - 1296000000), new Date()], // 默认最近15天的数据
      selectTimesTab3: [],
      formInlineTab3: {
        page: 1,
        page_size: 100,
      },
      formInlineTab4: {
        page: 1,
        page_size: 100,
      },
      dataListTab1: [],
      dataListTab2: [],
      dataListTab3: [],
      dataListTab4: [],
    };
  },
  created() {
    // 筛选页面初始化
    this.formInlineTab3.page = 1;
    this.formInlineTab3.page_size = 100;
    this.getOrderChartPdd();
  },
  methods: {
    onSubmit(type) {
      if (type == 'orderChartPdd') {
        this.getOrderChartPdd();
      } else if (type == 'orderChartTb') {
        this.getOrderChartTb();
      } else if (type == 'groupOrderData') {
        this.getList();
      }
    },
    getOrderChartPdd() {
      this.loading = true;
      const params = {};
      if (this.selectTimesTab1.length > 1) {
        const startDate = this.selectTimesTab1[0];
        const endDate = this.selectTimesTab1[1];
        params.start_time = new Date(startDate).getTime() / 1000;
        params.end_time = new Date(endDate).getTime() / 1000;
      }

      getPddOrderChartData(params).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.dataListTab1 = res.data;
          this.updateChart('pdd', this.dataListTab1, 'orderChartPdd');
        }

        this.loading = false;
      });
    },
    getOrderChartTb() {
      this.loading = true;
      const params = {};
      if (this.selectTimesTab2.length > 1) {
        const startDate = this.selectTimesTab2[0];
        const endDate = this.selectTimesTab2[1];
        params.start_time = new Date(startDate).getTime() / 1000;
        params.end_time = new Date(endDate).getTime() / 1000;
      }

      getTbOrderChartData(params).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.dataListTab2 = res.data;
          this.updateChart('tb', this.dataListTab2, 'orderChartTb');
        }

        this.loading = false;
      });
    },
    getList() {
      this.loading = true;
      const params = this.formInlineTab3;
      if (this.selectTimesTab3.length > 1) {
        const startDate = this.selectTimesTab3[0];
        const endDate = this.selectTimesTab3[1];
        params.start_time = new Date(startDate).getTime() / 1000;
        params.end_time = new Date(endDate).getTime() / 1000;
      }
      // 请求列表
      getOrderData(params).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.dataListTab3 = res.data;
          this.totalcountTab3 = res.totalCount;
        }
        this.loading = false;
      });
    },
    getRobotGroupInfo() {
      this.loading = true;
      const params = this.formInlineTab4;
      // 请求列表
      getWXGroupInfo(params).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.dataListTab4 = res.data;
          this.totalcountTab4 = res.totalCount;
        }
        this.loading = false;
      });
    },
    getPddStatusStr(status) {
      let str = '神秘状态';
      if (status === -1) {
        str = '未支付';
      } else if (status === 0) {
        str = '已支付';
      } else if (status === 1) {
        str = '已成团';
      } else if (status === 2) {
        str = '确认收货';
      } else if (status === 3) {
        str = '审核成功';
      } else if (status === 4) {
        str = '审核失败';
      } else if (status === 5) {
        str = '已经结算';
      } else if (status === 8) {
        str = '非多多进宝商品';
      }

      return str;
    },
    getTbStatusStr(status) {
      let str = '神秘状态';
      if (status === 3) {
        str = '订单结算';
      } else if (status === 12) {
        str = '订单付款';
      } else if (status === 13) {
        str = '订单失效';
      } else if (status === 14) {
        str = '订单成功';
      }
      return str;
    },
    getStatusStr(pf, status) {
      let str = '神秘状态';
      if (pf == 'tb') {
        str = this.getTbStatusStr(status);
      } else if (pf == 'pdd') {
        str = this.getPddStatusStr(status);
      }
      return str;
    },
    getOrderStatusDesc(pf) {
      let arr = [];
      if (pf == 'tb') {
        arr = ['订单结算', '订单付款', '订单失效', '订单成功'];
      } else if (pf == 'pdd') {
        arr = ['未支付', '已支付', '已成团', '确认收货', '审核成功', '审核失败', '已经结算', '非多多进宝商品'];
      }
      return arr;
    },
    // 分页
    handleSizeChange(page_size) {
      this.formInlineTab3.page_size = page_size;
      this.getList();
    },
    // 页码变化时触发
    handleCurrentChange(page) {
      this.formInlineTab3.page = page;
      this.getList();
    },
    // 分页
    handleSizeChangeTab4(page_size) {
      this.formInlineTab4.page_size = page_size;
      this.getRobotGroupInfo();
    },
    // 页码变化时触发
    handleCurrentChangeTab4(page) {
      this.formInlineTab4.page = page;
      this.getRobotGroupInfo();
    },
    onTabClick(val) {
      if (val.index == '0' && this.dataListTab1.length === 0) {
        this.curTab = 0;
        this.getOrderChartPdd();
      } else if (val.index == '1' && this.dataListTab3.length === 0) {
        this.curTab = 1;
        this.getOrderChartTb();
      } else if (val.index == '2' && this.dataListTab4.length === 0) {
        this.curTab = 2;
        this.getList();
      } else if (val.index == '3' && this.dataListTab4.length === 0) {
        this.curTab = 2;
        this.getRobotGroupInfo();
      }
    },
    orderSort(val) {
      console.log('orderSort', val);
      const order = { key: val.prop, desc: (val.order == 'descending') };
      if (this.curTab === 2) {
        this.formInlineTab4.order = order;
        this.getRobotGroupInfo();
      }
    },

    updateChart(pf, dataList, chartId) {
      const orderStatusDescs = this.getOrderStatusDesc(pf);
      const orderCountSeries = [];
      const orderAmountSeries = [];
      const orderDates = [];
      let curDate = '';
      // 先计算横坐标的数量
      for (const i in dataList) {
        const obj = dataList[i];
        if (curDate != obj.order_date) {
          curDate = obj.order_date;
          orderDates.push(curDate);
        }
      }
      // 创建统计需要的初始数据
      const orderCountSum = {
        name: '总订单量',
        type: 'bar',
        barWidth: 15,
        data: new Array(orderDates.length).fill(0)
      };
      const orderAmountSum = {
        name: '总订单金额',
        type: 'bar',
        barWidth: 15,
        yAxisIndex: 1,
        data: new Array(orderDates.length).fill(0)
      };
      for (const i in orderStatusDescs) {
        orderCountSeries.push({
          name: orderStatusDescs[i],
          type: 'bar',
          stack: '订单量',
          barWidth: 5,
          data: new Array(orderDates.length).fill(0)
        });
        orderAmountSeries.push({
          name: orderStatusDescs[i],
          type: 'bar',
          stack: '订单金额',
          barWidth: 5,
          yAxisIndex: 1,
          data: new Array(orderDates.length).fill(0)
        });
      }

      if (orderDates.length > 0) {
        let index = 0;
        // 把获取到的数据转化为构造好的统计结构
        curDate = orderDates[0];
        for (const i in dataList) {
          const obj = dataList[i];
          const statusStr = this.getStatusStr(pf, obj.order_status);
          if (curDate != obj.order_date) {
            curDate = obj.order_date;
            ++index;
          }

          orderCountSum.data[index] += obj.order_count;
          orderAmountSum.data[index] += obj.order_amount_sum;
          const subIndex = orderStatusDescs.indexOf(statusStr);
          if (subIndex !== -1) {
            orderCountSeries[subIndex].data[index] = obj.order_count;
            orderAmountSeries[subIndex].data[index] = obj.order_amount_sum;
          }
        }

        orderAmountSum.data = orderAmountSum.data.map(item => {
          return item.toFixed(2);
        });
        orderCountSeries.unshift(orderCountSum);
        orderAmountSeries.unshift(orderAmountSum);

        const chart = echarts.init(document.getElementById(chartId));
        chart.setOption({
          tooltip: {
            trigger: 'axis',
            axisPointer: { // 坐标轴指示器，坐标轴触发有效
              type: 'cross',
              crossStyle: {
                color: '#999'
              }
            }
          },
          toolbox: {
            feature: {
              dataView: { show: true, readOnly: false },
              magicType: { show: true, type: ['line', 'bar'] },
              restore: { show: true },
              saveAsImage: { show: true }
            }
          },
          legend: {
            data: ['总订单量', '总订单金额'].concat(orderStatusDescs)
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: [
            {
              type: 'category',
              data: orderDates
            }
          ],
          yAxis: [
            {
              type: 'value',
              name: '订单量',
              axisLabel: {
                formatter: '{value} 单'
              }
            },
            {
              type: 'value',
              name: '订单额',
              axisLabel: {
                formatter: '{value} 元'
              }
            }
          ],
          series: orderCountSeries.concat(orderAmountSeries)
        });
      }
    },
  }
};
</script>

<style scoped>

</style>
