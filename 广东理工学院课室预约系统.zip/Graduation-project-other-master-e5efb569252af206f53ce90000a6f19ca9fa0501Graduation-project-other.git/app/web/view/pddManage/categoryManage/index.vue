<template>
  <div class="app-container">
    <el-row>
      <el-col :span="24">
        <div class="header-title">机器人群分类列表</div>
      </el-col>
      <el-col :span="24">
        <el-button type="primary" size="small" @click="addCategory" style="margin-bottom:10px">
          添加分类
        </el-button>
      </el-col>
        <!-- 数据列表 start -->
      <el-col :span="24" v-loading="loading">
        <el-table
          :data="tableData"
          border
          style="width: 100%">
          <el-table-column
            prop="id"
            label="id"
            width="80">
          </el-table-column>
          <el-table-column
            prop="name"
            label="群分类名称"
            width="130">
          </el-table-column>
          <el-table-column>
            <template slot-scope="scope">
              <el-button type="primary" size="small" @click="edit(scope.row)" style="margin-top:10px">
                编辑
              </el-button>
            </template>
          </el-table-column>
        </el-table>     
      </el-col>
    </el-row>
    <!-- 筛选列表 end -->
    <!-- 弹层 start -->
      <el-col :span="24">
        <el-dialog title="添加分类" :visible.sync="addDialogFormVisible" width="300" @close="cancelAddForm">
          <el-form :model="addForm" :rules="addRules" ref="addForm">
            <el-form-item label="分类名称" prop="name">
              <el-input v-model="addForm.name" placeholder="分类名称" size="mini" clearable></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="cancelAddForm('addForm')">取 消</el-button>
            <el-button type="primary" @click="confirmAddForm('addForm')">确 定</el-button>
          </div>
        </el-dialog>
      </el-col>
      <el-col :span="24">
        <el-dialog title="更新分类" :visible.sync="updateDialogFormVisible" width="300" @close="cancelUpdateForm">
          <el-form :model="updateForm" :rules="updateRules" ref="updateForm">
            <el-form-item label="ID" label-width="120px" prop="id">
              <el-input :disabled="true" v-model="updateForm.id" placeholder="ID" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="分类名称" label-width="120px" prop="name">
              <el-input v-model="updateForm.name" placeholder="分类名称" size="mini" clearable></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="cancelUpdateForm('updateForm')">取 消</el-button>
            <el-button type="primary" @click="confirmUpdateForm('updateForm')">更 新</el-button>
          </div>
        </el-dialog>
      </el-col>
      <!-- 弹层 end -->
  </div>
</template>

<script>
import { getGroupCategoryList, updateGroupCategoryInfo, addGroupCategoryInfo } from '@/api/robot';

export default {
  data() {
    return {
      loading: false,
      addDialogFormVisible: false,
      updateDialogFormVisible: false,
      addForm: {
        name: ''
      },
      updateForm: {
        groupInfo: {},
        id: 0,
        name: ''
      },
      addRules: {
        name: [{ required: true, message: '请输入分类名称', trigger: 'blur' }]
      },
      updateRules: {
        id: [{ required: true, message: '分类ID', trigger: 'blur' }],
        name: [{ required: true, message: '请输入分类名称', trigger: 'blur' }]
      },
      tableData: []
    };
  },
  created() {
    this.getList();
  },
  methods: {
    getList() {
      this.loading = true;
      getGroupCategoryList().then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.tableData = res.data;
        }

        this.loading = false;
      });
    },
    addCategory() {
      this.addDialogFormVisible = true;
    },
    edit(data) {
      this.updateForm.groupInfo = data;
      this.updateForm.id = data.id;
      this.updateForm.name = data.name;
      this.updateDialogFormVisible = true;
    },
    cancelAddForm(formName) {
      this.addDialogFormVisible = false;
    },
    cancelUpdateForm(formName) {
      this.updateDialogFormVisible = false;
    },
    confirmAddForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.loading = true;
          const name = this.addForm.name;
          addGroupCategoryInfo({ name }).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.$message({
                message: '操作成功',
                type: 'success'
              });
              // this.$refs[formName].resetFields();
              this.addDialogFormVisible = false;
              this.getList();
            } else {
              this.$message({
                message: '操作失败',
                type: 'fail'
              });
            }
            this.loading = false;
          });
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    confirmUpdateForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.loading = true;
          const id = this.updateForm.id;
          const name = this.updateForm.name;
          updateGroupCategoryInfo({ id, name }).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.$message({
                message: '操作成功',
                type: 'success'
              });

              this.updateForm.groupInfo.name = this.updateForm.name;
              this.updateDialogFormVisible = false;
            } else {
              this.$message({
                message: '操作失败',
                type: 'fail'
              });
            }
            this.loading = false;
          });
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    }
  }
};
</script>
