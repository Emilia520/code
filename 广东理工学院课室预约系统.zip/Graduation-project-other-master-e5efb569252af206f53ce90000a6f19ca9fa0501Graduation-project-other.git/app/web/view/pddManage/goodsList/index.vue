<template>
  <div class="app-container">
    <el-row>
      <el-col :span="24">
        <div class="header-title">多多客官方商品列表</div>
      </el-col>
      <el-col :span="24">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
          <el-form-item label="排序方式">
            <el-select v-model="formInline.sort_type" placeholder="请选择" size="mini">
              <el-option label="综合排序" value="0"></el-option>
              <el-option label="按佣金比率升序" value="1"></el-option>
              <el-option label="按佣金比例降序" value="2"></el-option>
              <el-option label="按价格升序" value="3"></el-option>
              <el-option label="按价格降序" value="4"></el-option>
              <el-option label="按销量升序" value="5"></el-option>
              <el-option label="按销量降序" value="6"></el-option>
              <el-option label="优惠券金额排序升序" value="7"></el-option>
              <el-option label="优惠券金额排序降序" value="8"></el-option>
              <el-option label="券后价升序排序" value="9"></el-option>
              <el-option label="券后价降序排序" value="10"></el-option>
              <el-option label="按照加入多多进宝时间升序" value="11"></el-option>
              <el-option label="按照加入多多进宝时间降序" value="12"></el-option>
              <el-option label="按佣金金额升序排序" value="13"></el-option>
              <el-option label="按佣金金额降序排序" value="14"></el-option>
              <el-option label="店铺描述评分升序" value="15"></el-option>
              <el-option label="店铺描述评分降序" value="16"></el-option>
              <el-option label="店铺物流评分升序" value="17"></el-option>
              <el-option label="店铺物流评分降序" value="18"></el-option>
              <el-option label="店铺服务评分升序" value="19"></el-option>
              <el-option label="店铺服务评分降序" value="20"></el-option>
              <el-option label="描述评分击败同类店铺百分比升序" value="27"></el-option>
              <el-option label="描述评分击败同类店铺百分比降序" value="28"></el-option>
              <el-option label="物流评分击败同类店铺百分比升序" value="29"></el-option>
              <el-option label="物流评分击败同类店铺百分比降序" value="30"></el-option>
              <el-option label="服务评分击败同类店铺百分比升序" value="31"></el-option>
              <el-option label="服务评分击败同类店铺百分比降序" value="32"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="商品关键词">
            <el-input v-model="formInline.keyword" placeholder="商品关键词" size="mini" clearable></el-input>
          </el-form-item>
          <el-form-item label="商品标签类目">
            <el-cascader
            size="mini"
            change-on-select
            :options="opts"
            @change="handleOptChange"
            :props="optProps">
            </el-cascader>
          </el-form-item>
          <el-form-item label="商品类目">
            <el-cascader
            size="mini"
            change-on-select
            :options="cats"
            @change="handleCatChange"
            :props="catProps">
            </el-cascader>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onSubmit">筛选</el-button>
          </el-form-item>
        </el-form>
      </el-col>
      <!-- 筛选条件 end -->
      <!-- 表格 start -->
      <el-col :span="24">
          <el-table
            :data="tableData"
            border
            style="width: 100%"
            v-loading="loading">
            <el-table-column
              prop="goods_id"
              label="商品编号"
              width="120">
            </el-table-column>
            <el-table-column
              prop="goods_name"
              label="商品名称"
              width="120">
            </el-table-column>
            <!-- <el-table-column
              prop="goods_desc"
              label="商品描述"
              width="120">
            </el-table-column> -->
            <el-table-column
              prop="goods_image_url"
              height="150"
              label="商品主图url"
              width="120">
            </el-table-column>
            <el-table-column
              height="150"
              label="商品缩略图"
              width="120">
              <template slot-scope="scope">
                <img :src="scope.row.goods_thumbnail_url" alt="" style="width:100px;height:100px;">
              </template>
            </el-table-column>
            <el-table-column
              height="150"
              label="商品主图"
              width="200">
              <template slot-scope="scope">
                <img :src="scope.row.goods_image_url" alt="" style="width:200px;height:100px;">
              </template>
            </el-table-column>
            <el-table-column
              prop="sold_quantity"
              label="已售卖件数"
              width="120">
            </el-table-column>
            <el-table-column
              label="最小拼团价"
              width="120">
              <template slot-scope="scope">
                <div>{{scope.row.min_group_price / 100}}元</div>
              </template>
            </el-table-column>
            <el-table-column
              label="最小单买价格"
              width="120">
              <template slot-scope="scope">
                <div>{{scope.row.min_normal_price / 100}}元</div>
              </template>
            </el-table-column>
            <el-table-column
              prop="mall_name"
              label="店铺名称"
              width="120">
            </el-table-column>
            <el-table-column
              prop="category_name"
              label="商品类目"
              width="120">
            </el-table-column>
            <el-table-column
              prop="opt_name"
              label="商品标签"
              width="120">
            </el-table-column>
            <el-table-column
              prop="has_coupon"
              label="商品是否有优惠券"
              width="120">
            </el-table-column>
            <el-table-column
              label="优惠券门槛价格"
              width="120">
              <template slot-scope="scope">
                <div>{{scope.row.coupon_min_order_amount / 100}}元</div>
              </template>
            </el-table-column>
            <el-table-column
              prop="coupon_discount"
              label="优惠券面额"
              width="120">
              <template slot-scope="scope">
                <div>{{scope.row.coupon_discount / 100}}元</div>
              </template>
            </el-table-column>
            <el-table-column
              prop="coupon_total_quantity"
              label="优惠券总数量"
              width="120">
            </el-table-column>
            <el-table-column
              prop="coupon_remain_quantity"
              label="优惠券剩余数量"
              width="120">
            </el-table-column>
            <el-table-column
              prop="coupon_start_time"
              label="优惠券生效时间"
              width="100">
            </el-table-column>
            <el-table-column
              prop="coupon_end_time"
              label="优惠券失效时间"
              width="100">
            </el-table-column>
            <el-table-column
              prop="promotion_rate"
              label="佣金比例，千分比"
              width="120">
            </el-table-column>
            <el-table-column
              prop="goods_eval_score"
              label="商品评价分"
              width="120">
            </el-table-column>
            <el-table-column
              prop="goods_eval_count"
              label="商品评价数量"
              width="120">
            </el-table-column>
          </el-table>     
      </el-col>
      <!-- 表格 end -->
      <!-- 分页 start -->
      <el-col :span="24">
        <div class="pagination" style="margin-top:20px;">
          <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="formInline.page" :page-sizes="[10, 20, 30, 40]" :page-size="formInline.page_size" layout="total, sizes, prev, pager, next" :total="totalcount">
          </el-pagination>
        </div>
      </el-col>
      <!-- 分页 end -->
    </el-row>
  </div>
</template>

<script>
import { getGoodsList, getOptList, getCategoryList } from '@/api/pdd';
import { timestampToTime } from 'utils/chanageTime';
import { resolve } from 'url';

export default {
  data() {
    return {
      totalcount: 0,
      loading: false,
      formInline: {
        sort_type: '',
        page: 1,
        page_size: 10,
        keyword: '',
      },
      opts_sels: [],
      opts: [{ opt_name: '所有标签', opt_id: 0, opts: [] }],
      optProps: {
        label: 'opt_name',
        value: 'opt_id',
        children: 'opts'
      },
      req_opt_ids: [],
      cats_sels: [],
      cats: [{ cat_name: '所有类目', cat_id: 0, cats: [] }],
      catProps: {
        label: 'cat_name',
        value: 'cat_id',
        children: 'cats'
      },
      req_cat_ids: [],
      tableData: []
    };
  },
  created() {
    // 筛选页面初始化
    this.formInline.page = 1;
    this.formInline.page_size = 10;
    this.getOpts();
    this.getCats();
    this.getList();
  },
  methods: {
    onSubmit() {
      // 筛选页面初始化
      this.formInline.page = 1;
      this.formInline.page_size = 10;
      this.getList();
    },
    getCats() {
      const params = { parent_cat_id: 0 };
      if (this.cats_sels.length > 0) {
        params.parent_cat_id = this.cats_sels[this.cats_sels.length - 1];
      }

      if (!this.req_cat_ids.includes(params.parent_cat_id)) {
        getCategoryList(params).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            const obj = {};
            obj.cats = this.cats.concat();
            this.fillCats(obj.cats[0], this.cats_sels.slice(1, this.cats_sels.length), res.data);
            this.cats = obj.cats;
            this.req_cat_ids.push(params.parent_cat_id);
          }
        });
      }
    },
    getOpts() {
      const params = { parent_opt_id: 0 };
      if (this.opts_sels.length > 0) {
        params.parent_opt_id = this.opts_sels[this.opts_sels.length - 1];
      }

      if (!this.req_opt_ids.includes(params.parent_opt_id)) {
        getOptList(params).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            const obj = {};
            obj.opts = this.opts.concat();
            this.fillOpts(obj.opts[0], this.opts_sels.slice(1, this.opts_sels.length), res.data);
            this.opts = obj.opts;
            this.req_opt_ids.push(params.parent_opt_id);
          }
        });
      }
    },
    getList() {
      this.loading = true;
      const params = this.formInline;
      if (this.opts_sels.length > 0) {
        params.opt_id = this.opts_sels[this.opts_sels.length - 1];
      }
      if (this.cats_sels.length > 0) {
        params.cat_id = this.cats_sels[this.cats_sels.length - 1];
      }
      // 请求列表
      getGoodsList(params).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.tableData = res.data;
          this.totalcount = res.totalCount;
        }
        this.loading = false;
      });
    },
    fillCats(parentObj, trees, cats) {
      if (!parentObj.cats) {
        return;
      }

      if (trees.length > 0) {
        const catId = trees.shift();
        for (const i in parentObj.cats) {
          const obj = parentObj.cats[i];
          if (obj.cat_id === catId) {
            this.fillCats(obj, trees, cats);
            return;
          }
        }
      } else {
        parentObj.cats = cats.length > 0 ? cats : null;
        if (parentObj.cats) {
          this.fillEmptyCats(parentObj.cats);
        }
      }
    },
    fillEmptyCats(cats) {
      for (const i in cats) {
        const obj = cats[i];
        obj.cats = [];
      }
    },
    fillOpts(parentObj, trees, opts) {
      if (!parentObj.opts) {
        return;
      }

      if (trees.length > 0) {
        const optId = trees.shift();
        for (const i in parentObj.opts) {
          const obj = parentObj.opts[i];
          if (obj.opt_id === optId) {
            this.fillOpts(obj, trees, opts);
            return;
          }
        }
      } else {
        parentObj.opts = opts.length > 0 ? opts : null;
        if (parentObj.opts) {
          this.fillEmptyOpts(parentObj.opts);
        }
      }
    },
    fillEmptyOpts(opts) {
      for (const i in opts) {
        const obj = opts[i];
        obj.opts = [];
      }
    },
    // 分页
    handleSizeChange(page_size) {
      this.formInline.page_size = page_size;
      this.getList();
    },
    // 页码变化时触发
    handleCurrentChange(page) {
      this.formInline.page = page;
      this.getList();
    },
    handleOptChange(val) {
      console.log('handleOptChange', val);
      this.opts_sels = val;
      this.getOpts();
    },
    handleCatChange(val) {
      console.log('handleCatChange', val);
      this.cats_sels = val;
      this.getCats();
    }
  }
};
</script>

<style scoped>
  
</style>
