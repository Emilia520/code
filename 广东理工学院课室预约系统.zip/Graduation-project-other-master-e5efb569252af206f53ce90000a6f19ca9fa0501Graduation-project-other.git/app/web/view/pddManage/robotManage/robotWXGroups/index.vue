<template>
    <div class='app-container' v-loading="loading">
        <div>
            <el-button class="back-button" icon="el-icon-back" type="text" size="medium" @click="$router.back()"/>
        </div>
        <div class="opt-container">
            <el-button class="opt-button" @click="selectAll" type="primary" size="mini">全选</el-button>
            <el-button class="opt-button" @click="reverseSelect" type="primary" size="mini">反选</el-button>
            <el-button class="opt-button" @click="edit()" type="success" size="mini">批量编辑</el-button>
        </div>
        <div class="list-container">
            <div class='group-card'  v-for="group in groups" >
                <el-card shadow="hover" :body-style="{ padding: '20px 20px 0 20px' }" :key="group.id">
                    <div slot="header" class="group-header" v-on:click="select(group)">
                        <div class="name-container">
                            <div class="group-name">{{group.nickName}}</div>
                            <div class="group-display-name">{{group.displayName}}</div>
                        </div>
                        <svg-icon class="group-check" :icon-class="selectedGroups[group.id] ? 'cb_circle_green' : 'cb_empty_circle_green'"/>
                    </div>
                    <div class="group-body" v-on:click="edit(group)">
                        <div class="body-left">
                            <div class="body-option">
                                <div class="body-option-key">群ID</div>
                                <div class="body-option-value">{{group.wxid}}</div>
                            </div>
                            <div class="body-option">
                                <div class="body-option-key">人数</div>
                                <div class="body-option-value bold">{{group.groupMemberCount}}</div>
                            </div>
                            <div class="body-option">
                                <div class="body-option-key">群主</div>
                                <div class="body-option-value">{{group.groupOwner}}</div>
                            </div>
                            <div class="body-option">
                                <div class="body-option-key">状态</div>
                                <div class="body-option-value" :style="{color: group.status === 1 ? '#70da0e' : '#e3544c'}">
                                    {{group.status === 1 ? '正常' : (group.status  === 0 ? '删除' : '未知')}}
                                </div>
                            </div>
                        </div>
                        <div class="body-right">
                            <img class="body-right-img" :src="group.headHDImg || group.headImg" alt="暂无头像">
                        </div>
                    </div>
                    <div class="group-footer">
                        <div class="footer-option">
                            <div class="footer-option-key">创建时间</div>
                            <div class="footer-option-value">{{group.createTime}}</div>
                        </div>
                        <div class="footer-option">
                            <div class="footer-option-key">更新时间</div>
                            <div class="footer-option-value">{{group.updateTime}}</div>
                        </div>
                    </div>
                </el-card>
            </div>
        </div>
        <el-dialog class="edit-dialog" width="600px" :visible.sync="editDialogVisible" @close="editDialogVisible = false">
            <div class="edit-header" slot="title" >
                <div class="edit-title">添加群信息</div>
                <div class="edit-count-container">
                    <span>正在编辑</span>
                    <span class="edit-count">{{editGroups.length}}</span>
                    <span>个群</span>
                </div>
            </div>
            <div class="edit-body">
                <div class="edit-option">
                    <span class="edit-option-key">群主手机号:</span>
                    <span class="edit-option-value">
                    <el-input v-model="editForm.phone" class="edit-option-value" placeholder="请输入手机号" size="small" clearable />
                </span>
                </div>
                <div class="edit-option">
                    <span class="edit-option-key">所属APP:</span>
                    <span>
                             <el-select class="edit-option-value" v-model="editForm.type" placeholder="雀享优品" size="small">
                                 <el-option label="雀享优品" value="1"></el-option>
                                 <el-option label="校品团" value="2"></el-option>
                             </el-select>
                </span>
                </div>
                <div class="edit-option">
                    <span class="edit-option-key">群分类:</span>
                    <span>
                        <el-select  class="edit-option-value" v-model="editForm.category" placeholder="群类别" size="small">
                            <el-option v-for="item in groupCategories" :key="item.id" :label="item.name" :value="item.id" />
                        </el-select>
                    </span>
                </div>
            </div>
            <div slot="footer" class="edit-footer">
                <el-button class="edit-footer-confirm" type="text" @click="confirmEdit">确认</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
  import { queryRobotGroups } from '@/api/yjiyun';
  import { getGroupCategoryList, addRobotGroups, loadRobotGroupsForDB } from '@/api/robot';

  export default {
    created() {
      this.getList();
      this.getCategoryList();
      this.getRobotGroupsFromDB();
    },
    data() {
      return {
        formInline: {
          robotKey: this.$route.params.robotKey,
        },
        editForm: {
          type: null,
          robotID: this.$route.params.robotID,
          category: null,
          phone: null,
          groups: null,
        },
        groups: [],
        groupCategories: [],
        editGroups: [],
        excludeGroups: [],
        selectedGroups: {},
        loading: false,
        reachEnd: false,
        editDialogVisible: false,
      };
    },
    methods: {
      getList() {
        if (this.reachEnd) {
          return;
        }

        this.loading = true;
        queryRobotGroups(this.formInline).then(response => {
          const resData = response.data;

          if (resData.code !== 10000) {
            this.$message.error(resData.msg || '获取数据失败');
          } else {
            if (!Array.isArray(resData.data) || resData.data.length < this.formInline.pageSize) {
              this.reachEnd = true;
            }

            this.groups = resData.data;
            this.filterExistedGroups();
            this.$message.success('更新成功');
            this.loading = false;
          }
        });
      },

      getCategoryList() {
        this.loading = true;

        getGroupCategoryList().then(response => {
          this.loading = false;
          const res = response.data;
          if (res.code === 10000) {
            this.groupCategories = res.data;
          }
        });
      },

      getRobotGroupsFromDB() {
        this.loading = true;

        loadRobotGroupsForDB({ robot_id: this.$route.params.robotID }).then(response => {
          this.loading = false;
          const resData = response.data;

          if (resData.code === 10000 && Array.isArray(resData.data)) {
            const existedGroups = resData.data;
            existedGroups.forEach(item => {
              this.excludeGroups.push(item.group_wxid);
            });

            this.filterExistedGroups();
          }
        });
      },

      // 从网络数据中移除已经添加到数据库的群
      filterExistedGroups() {
        if (this.groups.length === 0 || this.excludeGroups.length === 0) {
          return;
        }

        const legalGroups = this.groups.filter(item => {
          return this.excludeGroups.indexOf(item.wxid) === -1;
        });

        console.log(`Get ${this.groups.length} groups from network, filtered left ${legalGroups.length} groups`);
        console.log('Filter result', legalGroups);
        this.groups = legalGroups;
      },

      edit(group) {
        this.editForm.type = '';
        this.editForm.category = null;
        this.editForm.phone = null;
        this.editForm.groups = null;

        if (typeof group !== 'undefined') {
          this.editGroups = [group];
        } else {
          this.editGroups = Object.values(this.selectedGroups);
        }

        if (this.editGroups.length === 0) {
          this.$message.info('未选择微信群');
          return;
        }

        this.editDialogVisible = true;
      },

      confirmEdit() {
        console.log(this.editForm);
        this.editForm.groups = this.editGroups;

        this.loading = true;
        addRobotGroups(this.editForm).then(response => {
          this.loading = false;

          const resData = response.data;
          if (resData.code !== 10000) {
            this.$message.error(resData.msg || '添加失败');
          } else {
            this.$message.success('添加成功');
            this.editDialogVisible = false;
            this.editGroups.forEach(item => {
              this.excludeGroups.push(item.wxid);
            });

            this.editGroups = [];
            this.selectedGroups = [];
            this.filterExistedGroups();
          }
        });
      },

      select(group) {
        const selection = {};
        Object.assign(selection, this.selectedGroups);

        if (selection.hasOwnProperty(group.id)) {
          delete selection[group.id];
        } else {
          selection[group.id] = group;
        }

        this.selectedGroups = selection;
        console.log(this.selectedGroups);
      },

      selectAll() {
        const selections = {};
        this.groups.forEach(item => {
          selections[item.id] = item;
        });

        this.selectedGroups = selections;
        console.log(this.selectedGroups);
      },

      reverseSelect() {
        const targets = this.groups.filter(item => {
          return !this.selectedGroups.hasOwnProperty(item.id);
        });

        this.selectedGroups = {};
        targets.forEach(item => {
          this.selectedGroups[item.id] = item;
        });

        console.log(this.selectedGroups);
      },
    },
  };
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .app-container {
        font-family: "Microsoft YaHei", "微软雅黑", STXihei, "华文细黑", Georgia, "Times New Roman", Arial, sans-serif;

        .back-button {
            font-size: 25px;
        }

        .opt-container {
            margin-bottom: 5px;

            .opt-button {
                margin: 10px 10px 10px 0;
                min-width: 120px;
            }
        }

        .list-container {
            display: flex;
            flex-direction: row;
            justify-content: flex-start;
            flex-wrap: wrap;

            .group-card {
                width: 380px;
                margin: 5px;
                background-color: #FEFEFE;

                .group-header {
                    display: flex;
                    flex-direction: row;
                    justify-content: space-between;
                    align-items: center;

                    .group-name {
                        font-size: 14px;
                        font-weight: bold;
                        margin-bottom: 10px;
                        color: #282828;
                    }

                    .group-display-name {
                        font-size: 12px;
                        color: #666;
                    }

                    .group-check {
                        width: 24px;
                        height: 24px;
                    }
                }

                .group-body {
                    display: flex;
                    flex-direction: row;
                    justify-content: space-between;
                    align-items: center;

                    .body-left {
                        width: calc(100% - 100px);

                        .body-option {
                            margin: 10px 0;
                            display: flex;
                            flex-direction: row;
                            align-items: center;
                            font-size: 13px;

                            .body-option-key {
                                color: #AAA;
                                min-width: 75px;
                            }

                            .body-option-value {
                                color: #282828;
                                max-width: 300px;
                                text-overflow: ellipsis;
                            }
                        }
                    }

                    .body-right {
                        .body-right-img {
                            width: 100px;
                        }
                    }
                }

                .group-footer {
                    border-top: 1px dashed #eee;
                    margin-top: 10px;
                    height: 70px;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;

                    .footer-option {
                        display: flex;
                        flex-direction: row;
                        margin: 5px 0;
                        font-size: 13px;

                        .footer-option-key {
                            color: #AAA;
                            min-width: 75px;
                        }

                        .footer-option-value {
                            color: #282828;
                        }
                    }
                }
            }
        }

        .edit-dialog {
            .edit-header {
                .edit-title {
                    font-size: 20px;
                    color: #282828;
                }

                .edit-count-container {
                    margin-top: 10px;
                    font-size: 15px;
                    color: #282828;
                    display: flex;
                    flex-direction: row;
                    align-items: center;

                    .edit-count {
                        font-weight: bolder;
                        font-size: 16px;
                        color: green;
                        margin: 0 5px;
                    }
                }
            }

            .edit-body {
                .edit-option {
                    display: flex;
                    flex-direction: row;
                    justify-content: flex-start;
                    align-items: center;
                    margin: 20px 0;
                    font-size: 14px;

                    .edit-option-key {
                        width: 100px;
                        color: #282828;
                    }

                    .edit-option-value {
                        width: 350px;
                        color: #282828;
                    }
                }
            }

            .edit-footer {
                .edit-footer-confirm {
                    width: 100%;
                    color: lightgreen;

                    &:hover {
                        background-color: lightgreen;
                        color: white;
                    }
                }
            }
        }
    }

</style>