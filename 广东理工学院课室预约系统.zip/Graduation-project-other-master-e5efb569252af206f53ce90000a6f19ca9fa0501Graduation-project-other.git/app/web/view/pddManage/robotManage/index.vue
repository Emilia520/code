<template>
  <div class="app-container">
    <el-row>
      <el-col :span="24">
        <div class="header-title">机器人信息列表</div>
      </el-col>
        <!-- 数据列表 start -->
      <el-col :span="24" v-loading="loading">
        <el-table
          :data="tableData"
          border
          style="width: 100%">
          <el-table-column
            prop="id"
            label="id"
            width="80">
          </el-table-column>
          <el-table-column
            prop="nickname"
            label="机器人昵称"
            width="130">
          </el-table-column>
          <el-table-column
            prop="alias_name"
            label="机器人别名"
            width="130">
          </el-table-column>
          <el-table-column
            label="头像"
            width="150">
            <template slot-scope="scope">
              <img :src="scope.row.head_img" alt="" style="width:80px;height:80px;">
            </template>
          </el-table-column>
          <el-table-column
            label="状态"
            width="120">
            <template slot-scope="scope">
              <span v-if="scope.row.robot_status===0">初始化</span>
              <span v-else-if="scope.row.robot_status===1">在线</span>
              <span v-else-if="scope.row.robot_status===2">离线</span>
              <span v-else-if="scope.row.robot_status===4">被微信踢掉线</span>
              <span v-else>神秘状态</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="group_count"
            label="管理群数量"
            width="130">
          </el-table-column>
          <el-table-column
            prop="wxid"
            label="微信号"
            width="150">
          </el-table-column>
          <el-table-column
            prop="last_login_time"
            label="最近登陆时间"
            width="150">
          </el-table-column>
          <el-table-column
            label="操作"
            width="150">
            <template slot-scope="scope">
              <el-button type="text" @click="wechatGroups(scope.row)">查看微信群</el-button>
            </template>
          </el-table-column>
        </el-table>     
      </el-col>
    </el-row>
    <!-- 筛选列表 end -->
  </div>
</template>

<script>
import { getRobotList } from '@/api/robot';

export default {
  data() {
    return {
      loading: false,
      tableData: []
    };
  },
  created() {
    this.getList();
  },
  methods: {
    getList() {
      this.loading = true;
      getRobotList().then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.tableData = res.data;
        }

        this.loading = false;
      });
    },

    wechatGroups(robot) {
      console.log(robot);
      this.$router.push({
        path: '/robotManage/robotWXGroups',
        name: 'robotWXGroups',
        params: {
          robotKey: robot.robot_key,
          robotID: robot.id
        },
      });
    },
  }
};
</script>
