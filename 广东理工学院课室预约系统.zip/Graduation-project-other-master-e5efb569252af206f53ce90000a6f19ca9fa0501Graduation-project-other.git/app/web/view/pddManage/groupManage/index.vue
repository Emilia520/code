<template>
  <div class="app-container">
    <el-row>
      <el-col :span="24">
        <div class="header-title">机器人群列表</div>
      </el-col>
      <el-col :span="24">
        <el-button style="margin-bottom:20px;" type="primary" size="mini" @click="addNewGroup">添加新群</el-button>
      </el-col>
        <!-- 数据列表 start -->
      <el-col :span="24" v-loading="loading">
        <el-table
          :data="tableData"
          border
          style="width: 100%">
          <el-table-column
            prop="id"
            label="id"
            width="80">
          </el-table-column>
          <el-table-column
            prop="group_name"
            label="微信群名"
            width="130">
          </el-table-column>
          <el-table-column
            prop="group_member_count"
            label="群人数"
            width="130">
          </el-table-column>
          <el-table-column
            prop="community_code_id"
            label="活码id(按活码发消息的群具备)"
            width="130">
          </el-table-column>
          <el-table-column
            prop="nickname"
            label="机器人昵称(按机器人发消息的群具备)"
            width="130">
          </el-table-column>
          <el-table-column
            prop="create_time"
            label="创建时间"
            width="130">
          </el-table-column>
          <el-table-column
            prop="update_time"
            label="更新时间"
            width="130">
          </el-table-column>
          <el-table-column
            prop="name"
            label="群所属用户昵称"
            width="130">
          </el-table-column>
          <el-table-column
            prop="cat_name"
            label="群分类"
            width="120">
          </el-table-column>
          <el-table-column
            label="操作"
            width="120">
            <template slot-scope="scope">
              <el-button type="primary" size="small" @click="edit(scope.row)" style="margin-top:10px">
                编辑
              </el-button>
            </template>
          </el-table-column>
        </el-table>     
      </el-col>
    </el-row>
    <!-- 筛选列表 end -->
    <!-- 弹层 start -->
      <el-col :span="24">
        <el-dialog title="添加新群" :visible.sync="dialogFormVisible" width="300" @close="cancelForm">
          <el-form :model="addForm" :rules="rules" ref="addForm">
            <el-form-item label="群名" label-width="120px" prop="groupName">
              <el-input v-model="addForm.groupName" placeholder="请务必不要写错群名，否则无法添加成功" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="群主手机号" label-width="120px" prop="phone">
              <el-input v-model="addForm.phone" placeholder="请填写手机号" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="群主所属app" label-width="120px" prop="type">
              <el-select v-model="addForm.type" placeholder="app" size="mini">
                <el-option label="雀享优品" value="1"></el-option>
                <el-option label="校品团" value="2"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="机器人" label-width="120px" prop="robot">
              <el-select 
                v-model="addForm.robot" 
                value-key="nickname"
                collapse-tags 
                filterable
                placeholder="选择管理的机器人" size="mini"
                style="width:280px;margin-top:20px;">
                <el-option 
                  v-for="item in robotList" 
                  :key="item.id" 
                  :label="item.nickname"
                  :value="item">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="群类别" label-width="120px" prop="category">
              <el-select v-model="addForm.category" placeholder="群类别" size="mini">
                <el-option v-for="item in categoryList" :key="item.id" :label="item.name" :value="item.id">
                </el-option>
              </el-select>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="cancelForm('addForm')">取 消</el-button>
            <el-button type="primary" @click="confirmForm('addForm')">确 定</el-button>
          </div>
        </el-dialog>
      </el-col>
      <el-col :span="24">
        <el-dialog title="更新群信息" :visible.sync="updateDialogFormVisible" width="300" @close="cancelUpdateForm">
          <el-form :model="updateForm" :rules="updateRules" ref="updateForm">
            <el-form-item label="群名" label-width="120px" prop="groupName">
              <el-input v-model="updateForm.groupName" placeholder="请务必不要写错群名，否则无法添加成功" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="群类别" label-width="120px" prop="category">
              <el-select v-model="updateForm.category" placeholder="群类别" size="mini">
                <el-option v-for="item in categoryList" :key="item.id" :label="item.name" :value="item.id">
                </el-option>
              </el-select>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="cancelUpdateForm('updateForm')">取 消</el-button>
            <el-button type="primary" @click="confirmUpdateForm('updateForm')">更 新</el-button>
          </div>
        </el-dialog>
      </el-col>
      <!-- 弹层 end -->
  </div>
</template>

<script>
import { getRobotList, addGroup, updateGroup, getGroupCategoryList } from '@/api/robot';
import { getWXGroupList } from '@/api/yjiyun';

export default {
  data() {
    return {
      loading: false,
      dialogFormVisible: false,
      updateDialogFormVisible: false,
      addForm: {
        groupName: '',
        phone: '',
        type: '',
        robot: null,
        category: ''
      },
      updateForm: {
        groupInfo: {},
        groupName: '',
        phone: '',
        category: ''
      },
      rules: {
        groupName: [{ required: true, message: '请输入群名称', trigger: 'blur' }],
        phone: [{ required: true, message: '请输入手机号', trigger: 'blur' }],
        type: [{ required: true, message: '请选择app类型', trigger: 'blur' }],
        robot: [{ required: true, message: '请选择机器人', trigger: 'blur' }],
        category: [{ required: true, message: '请选择群分类', trigger: 'blur' }],
      },
      updateRules: {
        groupName: [{ required: true, message: '请输入群名称', trigger: 'blur' }],
        category: [{ required: true, message: '请选择群分类', trigger: 'blur' }],
      },
      tableData: [],
      robotList: [],
      categoryList: [],
      categoryMap: {}
    };
  },
  created() {
    this.getList();
    this.getRobots();
    this.getCategoryList();
  },
  methods: {
    getList() {
      this.loading = true;
      getWXGroupList().then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.tableData = res.data;
        }

        this.loading = false;
      });
    },
    getRobots() {
      getRobotList().then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.robotList = res.data;
        }
      });
    },
    getCategoryList() {
      getGroupCategoryList().then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.categoryList = res.data;

          for (const i in this.categoryList) {
            const info = this.categoryList[i];
            this.categoryMap[info.id] = info.name;
          }
        }
      });
    },
    addNewGroup() {
      this.addForm.groupName = '';
      this.addForm.phone = '';
      this.addForm.robot = null;
      this.addForm.category = '';
      this.addForm.type = '';
      this.dialogFormVisible = true;
    },
    edit(data) {
      this.updateForm.groupInfo = data;
      this.updateForm.id = data.id;
      this.updateForm.groupName = data.group_name;
      this.updateForm.category = data.category;
      this.updateDialogFormVisible = true;
    },
    cancelForm(formName) {
      this.dialogFormVisible = false;
    },
    cancelUpdateForm(formName) {
      this.updateDialogFormVisible = false;
    },
    confirmForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.loading = true;
          const params = {
            groupName: this.addForm.groupName,
            phone: this.addForm.phone,
            type: Number(this.addForm.type),
            category: Number(this.addForm.category),
            robotKey: this.addForm.robot.robot_key,
            robotId: this.addForm.robot.id
          };
          addGroup(params).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.$message({
                message: '添加成功',
                type: 'success'
              });
              this.dialogFormVisible = false;
              this.getList();
            } else {
              this.$message({
                message: res.msg ? res.msg : '添加失败',
                type: 'error'
              });
            }

            this.loading = false;
          });
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    confirmUpdateForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.loading = true;
          const params = {
            id: this.updateForm.id,
            groupName: this.updateForm.groupName,
            category: Number(this.updateForm.category),
          };
          updateGroup(params).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.$message({
                message: '更新成功',
                type: 'success'
              });
              this.updateForm.groupInfo.group_name = this.updateForm.groupName;
              this.updateForm.groupInfo.category = this.updateForm.category;
              this.updateForm.groupInfo.cat_name = this.categoryMap[this.updateForm.category];
              this.updateDialogFormVisible = false;
            } else {
              this.$message({
                message: res.msg ? res.msg : '更新失败',
                type: 'error'
              });
            }

            this.loading = false;
          });
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    getRobot(id) {
      for (const i in this.robotList) {
        const robot = this.robotList[i];
        if (robot.id === id) {
          return robot;
        }
      }
    }
  }
};
</script>
