<template>
  <div class="app-container">
    <el-row>
      <el-col :span="24">
        <div class="header-title">推广信息生成</div>
      </el-col>
    </el-row>
      <!-- 筛选列表 end -->
      <!-- 筛选条件 start -->
    <el-row>
      <el-tabs type="border-card" @tab-click="onTabClick">
        <el-tab-pane label="拼多多单品推广">
          <pdd-sku-list ref="pddSkuList" @onSelect="addGoods">
          </pdd-sku-list>
        </el-tab-pane>
        <el-tab-pane label="拼多多频道推广">
          <pdd-channel-list ref="pddChannelList" @onSelect="addChannel">
          </pdd-channel-list>
        </el-tab-pane>
        <el-tab-pane label="拼多多主题推广">
          <pdd-theme-list ref="pddThemeList" @onSelect="addTheme">
          </pdd-theme-list>
        </el-tab-pane>
        <el-tab-pane label="淘宝单品推广">
          <tb-sku-list ref="tbSkuList" @onSelect="addTbGoods">
          </tb-sku-list>
        </el-tab-pane>
      </el-tabs>
    </el-row>
    <el-row>
      <!-- 弹层 start -->
      <el-col :span="24">
        <el-dialog title="生成推广信息" :visible.sync="dialogFormVisible" width="300" v-loading="loadingGenPromotion">
          <el-form :model="addForm" :rules="rules" ref="addForm">
            <el-form-item label="平台" :label-width="formLabelWidth" prop="type">
              <el-input v-model="addForm.type" placeholder="平台" size="mini" clearable disabled></el-input>
            </el-form-item>
            <el-form-item label="推广描述" :label-width="formLabelWidth" prop="desc">
              <el-input v-model="addForm.desc" placeholder="推广描述" size="mini" clearable disabled></el-input>
            </el-form-item>
            <el-form-item label="请选择推广的群" :label-width="formLabelWidth" prop="wx_group_id" :hidden="groupSelHidden">
              <el-select 
                v-model="addForm.wx_group_id" 
                collapse-tags 
                filterable
                placeholder="选择群" 
                size="mini"
                style="width:280px;">
                <el-option
                  v-for="item in group_list"
                  :key="item.group_wxid"
                  :label="item.group_name"
                  :value="item.group_wxid">
                </el-option>
              </el-select>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible=false">取 消</el-button>
            <el-button type="primary" @click="convert('addForm')">确 定</el-button>
          </div>
        </el-dialog>
      </el-col>
      <!-- 弹层 end -->
    </el-row>
    <el-row>
      <!-- 弹层 start -->
      <el-col :span="24">
        <el-dialog title="推广信息" :visible.sync="convertResultVisible" width="300">
          <el-tabs type="card">
            <el-tab-pane label="短链接">
              <span>{{promotionData.short_url}}</span>
              <span style="float:right;"><el-button type="primary" size="mini" v-clipboard:copyhttplist="promotionData.short_url" v-clipboard:success="onCopy">复 制</el-button></span>
            </el-tab-pane>
            <el-tab-pane v-if="addForm.type === 1" label="淘口令">
              <span>{{promotionData.tbk_pwd}}</span>
              <span style="float:right;"><el-button type="primary" size="mini" v-clipboard:copyhttplist="promotionData.tbk_pwd" v-clipboard:success="onCopy">复 制</el-button></span>
            </el-tab-pane>
          </el-tabs>
          <div slot="footer" class="dialog-footer">
            <el-button @click="convertResultVisible=false">确 定</el-button>
          </div>
        </el-dialog>
      </el-col>
      <!-- 弹层 end -->
    </el-row>
  </div>
</template>

<script>
import { sendGroupMsgImmediately } from '@/api/pdd';
import { uploadCalendarMsg, genPromotionInfo } from '@/api/robot';
import { getWXGroupList } from '@/api/yjiyun';
import { timestampToTime } from 'utils/chanageTime';
import { resolve } from 'url';
import { Loading } from 'element-ui';
import { uploadImg } from '@/api/uploadImg';
import RangeSelector from '@/component/RangeSelector';
import PddSkuList from '@/component/Pdd/SkuList';
import PddChannelList from '@/component/Pdd/ChannelList';
import PddThemeList from '@/component/Pdd/ThemeList';
import TbSkuList from '@/component/Taobao/SkuList';

export default {
  components: { RangeSelector, PddSkuList, PddChannelList, PddThemeList, TbSkuList },
  data() {
    return {
      groupSelHidden: false,
      dialogFormVisible: false,
      convertResultVisible: false,
      addForm: {
        type: '',
        desc: '',
        promote_type: '',
        channel_type: '',
        wx_group_id: ''
      },
      formLabelWidth: '120px',
      rules: {
        wx_group_id: [{ required: true, message: '请选择需要推广的群', trigger: 'blur' }]
      },
      promotionData: {},
      group_list: [],
    };
  },
  created() {
    if (this.$store.getters.role === 5) {
      this.groupSelHidden = true;
      this.rules = {};
    }

    // 筛选页面初始化
    this.getGroupList();
  },
  mounted() {
    this.$refs.pddSkuList.didPresent();
  },
  methods: {
    getGroupList() {
      getWXGroupList().then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.group_list = res.data;
        }
      });
    },
    addGoods(goodsInfo) {
      this.addForm = {};
      this.addForm.type = 3;
      this.addForm.goods_id = goodsInfo.goods_id;
      this.addForm.desc = goodsInfo.goods_name;
      this.addForm.promote_type = 1;
      this.addForm.channel_type = 1111;
      this.dialogFormVisible = true;
    },
    addChannel(info) {
      this.addForm = {};
      this.addForm.type = 3;
      this.addForm.desc = info.name;
      this.addForm.promote_type = info.promote_type;
      this.addForm.channel_type = info.channel_type;
      this.dialogFormVisible = true;
    },
    addTheme(info) {
      this.addForm = {};
      this.addForm.type = 3;
      this.addForm.desc = info.name;
      this.addForm.goods_id = info.id;
      this.addForm.promote_type = 4;
      this.addForm.channel_type = 8888;
      this.dialogFormVisible = true;
    },
    addTbGoods(info) {
      this.addForm = {};
      this.addForm.type = 1;
      this.addForm.desc = info.title;
      this.addForm.goods_id = info.num_iid;
      this.dialogFormVisible = true;
    },
    onTabClick(val) {
      if (val.index === '2') {
        this.$refs.pddThemeList.didPresent();
      } else if (val.index === '0') {
        this.$refs.pddSkuList.didPresent();
      } else if (val.index === '3') {
        this.$refs.tbSkuList.didPresent();
      }
    },
    getGroupListByType(type) {
      const list = [];
      for (const i in this.group_list) {
        const group = this.group_list[i];
        if (group.category === type) {
          list.push(group.groupWxid);
        }
      }

      return list;
    },
    convert(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.loadingGenPromotion = true;
          this.addForm.adminUser = this.$store.getters.name;
          genPromotionInfo(this.addForm).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.promotionData = res.data;
              this.dialogFormVisible = false;
              this.convertResultVisible = true;
            } else {
              this.$message({
                message: '生成推广信息接口返回异常',
                type: 'error'
              });
            }

            this.loadingGenPromotion = false;
          });
        }
      });
    },
    onCopy() {
      this.$message({
        message: '复制成功！',
        type: 'success'
      });
    }
  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .tab_pane {
    display: -webkit-flex;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
  }

  .el-col {
    border-radius: 10px;
    margin-bottom: 30px;
  }
</style>
