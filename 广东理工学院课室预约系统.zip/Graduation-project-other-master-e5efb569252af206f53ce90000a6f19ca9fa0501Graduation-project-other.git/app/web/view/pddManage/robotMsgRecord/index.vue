<template>
  <div class="app-container">
    <el-row>
      <el-col :span="24">
        <div class="header-title">机器人发送消息记录</div>
      </el-col>
      <!-- 筛选条件 start -->
      <el-col :span="24">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
          <el-form-item label="商品id">
            <el-input v-model="formInline.goods_id" placeholder="商品id" size="mini" clearable></el-input>
          </el-form-item>
          <el-form-item label="发送状态">
            <el-select v-model="formInline.status" placeholder="请选择" size="mini">
              <el-option label="所有" value=""></el-option>
              <el-option label="未处理" value="0"></el-option>
              <el-option label="发送队列中" value="1"></el-option>
              <el-option label="已撤回" value="2"></el-option>
              <el-option label="全部成功" value="3"></el-option>
              <el-option label="部分成功" value="4"></el-option>
              <el-option label="全部失败" value="5"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="操作人">
            <el-input v-model="formInline.operator" placeholder="操作人" size="mini" clearable></el-input>
          </el-form-item>
          <el-form-item label="生效时间" class="time-width">
            <el-date-picker
              v-model="send_times"
              type="datetimerange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              size="mini"
              align="right">
            </el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onSubmit">筛选</el-button>
          </el-form-item>
        </el-form>
      </el-col>
      <!-- 筛选条件 end -->
      <!-- 发送记录列表 start -->
      <el-col :span="24">
        <el-table
          :data="tableData"
          border
          style="width: 100%"
          v-loading="loading">
          <el-table-column
            label="消息类型"
            width="80">
            <template slot-scope="scope">
              <div v-if="scope.row.type==0">自定义消息</div>
              <div v-else-if="scope.row.type==1">淘宝</div>
              <div v-else-if="scope.row.type==2">京东</div>
              <div v-else-if="scope.row.type==3">拼多多</div>
              <div v-else-if="scope.row.type === 4">卡片消息</div>
              <div v-else-if="scope.row.type === 5">品牌团购</div>
              <div v-else-if="scope.row.type === 6">领面膜</div>
              <div v-else-if="scope.row.type === 7">小程序卡片</div>
              <div v-else>神秘消息</div>
            </template>
          </el-table-column>
          <el-table-column
            prop="goods_id"
            label="商品编号"
            width="120">
          </el-table-column>
          <el-table-column
            prop="desc"
            label="消息描述"
            width="120">
          </el-table-column>
          <el-table-column
            height="50"
            label="商品缩略图"
            width="80">
            <template slot-scope="scope">
              <img :src="scope.row.send_img" alt="" style="width:50px;height:50px;">
            </template>
          </el-table-column>
          <el-table-column
            label="发送时间"
            width="100">
            <template slot-scope="scope">
              <div>{{scope.row.send_datetime}}</div>
            </template>
          </el-table-column>
          <el-table-column
            label="发送文案"
            width="300"
            height="300">
            <template slot-scope="scope">
              <div>{{scope.row.send_text}}</div>
            </template>
          </el-table-column>
          <el-table-column
            prop="send_group"
            label="发送群"
            width="200">
          </el-table-column>
          <el-table-column
            label="发送状态"
            width="80">
            <template slot-scope="scope">
              <div v-if="scope.row.status==0">未处理</div>
              <div v-else-if="scope.row.status==1">发送队列中，无法撤回</div>
              <div v-else-if="scope.row.status==2">已撤回</div>
              <div v-else-if="scope.row.status==3">全部成功</div>
              <div v-else-if="scope.row.status==4">部分成功</div>
              <div v-else-if="scope.row.status==5">全部失败</div>
              <div v-else>未知状态</div>
            </template>
          </el-table-column>
          <el-table-column
            prop="reason"
            label="状态原因"
            width="160">
          </el-table-column>
          <el-table-column
            prop="operator"
            label="操作人"
            width="80">
          </el-table-column>
          <el-table-column
            label="操作"
            width="100">
            <template slot-scope="scope">
              <el-button :disabled="scope.row.status !== 0" type="danger" size="small" @click="revokeMsg(scope.row)" style="margin-top:10px">撤回</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
      <!-- 发送记录列表 end -->
      <!-- 分页 start -->
      <el-col :span="24">
        <div class="pagination" style="margin-top:20px;">
          <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="formInline.page" :page-sizes="[100, 200, 300, 400]" :page-size="formInline.page_size" layout="total, sizes, prev, pager, next" :total="totalcount">
          </el-pagination>
        </div>
      </el-col>
      <!-- 分页 end -->
    </el-row>
  </div>
</template>

<script>
import { getGroupMsgList } from '@/api/robot';
import { timestampToTime } from 'utils/chanageTime';
import { revokeMsg, getGroupCategoryList } from '@/api/robot';

export default {
  data() {
    return {
      totalcount: 0,
      groupInfo: {},
      loading: false,
      formInline: {
        goods_id: '',
        start_time: '',
        end_time: '',
        page: 1,
        page_size: 100,
        community_codes: [],
        operator: ''
      },
      send_times: [],
      categoryList: [],
      categoryMap: {},
      tableData: []
    };
  },
  created() {
    // 筛选页面初始化
    this.formInline.page = 1;
    this.formInline.page_size = 100;
    this.getCategoryList();
  },
  methods: {
    onSubmit() {
      // 筛选页面初始化
      this.formInline.page = 1;
      this.formInline.page_size = 100;
      this.getList();
    },
    getCategoryList() {
      getGroupCategoryList().then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.categoryList = res.data;

          for (const i in this.categoryList) {
            const info = this.categoryList[i];
            this.categoryMap[info.id] = info.name;
          }
        }

        this.getList();
      });
    },
    getList() {
      this.loading = true;
      if (this.send_times.length > 0) {
        this.formInline.start_time = this.send_times[0].getTime() / 1000;
        this.formInline.end_time = this.send_times[1].getTime() / 1000;
      } else {
        this.formInline.start_time = null;
        this.formInline.end_time = null;
      }

      const params = this.formInline;
      // 请求列表
      getGroupMsgList(params).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.tableData = res.data;
          this.totalcount = res.totalCount;
          this.groupInfo = res.group;

          for (const i in this.tableData) {
            const row = this.tableData[i];
            row.send_datetime = timestampToTime(row.send_time);
            row.wx_group_cats = JSON.parse(row.wx_group_cats);
            row.wx_group_ids = JSON.parse(row.wx_group_ids);
            if (row.wx_group_cats.length > 0) {
              row.send_group = row.wx_group_cats.map(id => {
                return this.categoryMap[id];
              }).join(',');
            } else if (row.wx_group_ids.length > 0) {
              row.send_group = row.wx_group_ids.map(item => {
                return this.groupInfo[item];
              }).join(',');
            } else {
              row.send_group = '无';
            }
          }
        }
        this.loading = false;
      });
    },
    // 分页
    handleSizeChange(page_size) {
      this.formInline.page_size = page_size;
      this.getList();
    },
    // 页码变化时触发
    handleCurrentChange(page) {
      this.formInline.page = page;
      this.getList();
    },
    revokeMsg(row) {
      revokeMsg(row).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          row.status = 2;
          this.$message({
            type: 'success',
            message: '撤回成功'
          });
        } else {
          this.$message({
            type: 'error',
            message: '撤回失败'
          });
        }
      });
    }
  }
};
</script>

<style scoped>
  .el-col {
    border-radius: 10px;
    margin-bottom: 30px;
  }
</style>
