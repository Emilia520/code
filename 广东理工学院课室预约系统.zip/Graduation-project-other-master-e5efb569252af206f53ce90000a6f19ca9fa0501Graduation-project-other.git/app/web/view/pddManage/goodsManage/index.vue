<template>
    <div class="app-container">
        <el-row>
            <el-col :span="24">
                <div class="header-title">机器人商品运营</div>
            </el-col>
            <el-col :span="24">
                <el-table :data="selectedData" border style="width: 100%">
                    <el-table-column label="消息类型" width="80">
                        <template slot-scope="scope">
                            <p v-if="scope.row.type === 0">通用消息</p>
                            <p v-else-if="scope.row.type === 1">淘宝</p>
                            <p v-else-if="scope.row.type === 2">京东</p>
                            <p v-else-if="scope.row.type === 3">拼多多</p>
                            <p v-else-if="scope.row.type === 4">卡片消息</p>
                            <p v-else-if="scope.row.type === 5">品牌团购</p>
                            <p v-else-if="scope.row.type === 6">领面膜</p>
                            <p v-else-if="scope.row.type === 7">小程序卡片</p>
                            <p v-else>神秘消息</p>
                        </template>
                    </el-table-column>
                    <el-table-column prop="goods_id" label="商品编号" width="120">
                    </el-table-column>
                    <el-table-column prop="desc" label="标题文案(小程序卡片时为title)" width="300">
                        <template slot-scope="scope" >
                            <emoji-text-input v-model="scope.row.desc" placeholder="卡片标题" v-if="scope.row.type === 4"></emoji-text-input>
                            <el-input v-else-if="scope.row.type === 7"
                                      v-model="scope.row.desc" type="textarea"
                                      :autosize="{ minRows: 1, maxRows: 2}" placeholder="小程序title" size="mini"
                                      clearable></el-input>
                            <div v-else>{{scope.row.desc}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column height="150" width="200" align="center" label="消息图(拼多多非单品商品暂时不做默认发送)">
                        <template slot-scope="scope">
                            <el-upload v-if="scope.row.type !== 7"
                                       class="avatar-uploader" :action="uploadImg" :show-file-list="false"
                                       :on-success="handleAvatarSuccess('send_img')" :before-upload="beforeAvatarUpload(scope.row)"
                                       :list-type="scope.row.send_img ? '' : 'picture-card'">
                                <img v-if="scope.row.send_img" :src="scope.row.send_img" class="avatar" alt=""
                                     style="width:100px;height:100px;">
                                <i v-else class="el-icon-plus"></i>
                            </el-upload>
                            <div v-else>无需编辑</div>
                        </template>
                    </el-table-column>
                    <el-table-column height="150" width="200" align="center" label="发送文件(.jpg、.png、.mp4等文件)">
                        <template slot-scope="scope">
                            <el-upload v-if="scope.row.type !== 7"
                                       class="avatar-uploader" :action="uploadImg" :show-file-list="false"
                                       :on-success="handleAvatarSuccess('send_file')" :before-upload="beforeAvatarUpload(scope.row)"
                                       :list-type="scope.row.send_file ? '' : 'picture-card'">
                                <img v-if="(scope.row.send_file.indexOf('.jpg') !== -1 || scope.row.send_file.indexOf('.jpeg') !== -1 || scope.row.send_file.indexOf('.png') !== -1 || scope.row.send_file.indexOf('.webp') !== -1)" :src="scope.row.send_file" class="avatar" alt=""
                                     style="width:100px;height:100px;">
                                <span v-else-if="scope.row.send_file">{{scope.row.fileName}}</span>
                                <i v-else class="el-icon-plus"></i>
                            </el-upload>
                            <div v-else>无需编辑</div>
                        </template>
                    </el-table-column>
                    <el-table-column label="发送时间" width="250">
                        <template slot-scope="scope">
                            <el-date-picker v-model="scope.row.send_datetime" type="datetime" placeholder="选择日期时间">
                            </el-date-picker>
                        </template>
                    </el-table-column>
                    <el-table-column label="详情文案(推广商品内容预览，推广地址在发送前生成)" width="350" height="300" header-align="center" align="center">
                        <template slot-scope="scope">
                            <emoji-text-input v-model="scope.row.send_text"
                                              :placeholder="sendTextPlaceholderForMsgType(scope.row.type)"
                                              :inputWidth="300">
                            </emoji-text-input>
                        </template>
                    </el-table-column>
                    <el-table-column property="send_link" label="发送链接" width="200">
                        <template slot-scope="scope" v-if="scope.row.type === 4">
                            <el-input v-model="scope.row.send_link" type="textarea"
                                      :autosize="{ minRows: 1, maxRows: 2}" placeholder="卡片链接" size="mini"
                                      clearable></el-input>
                        </template>
                    </el-table-column>
                    <el-table-column prop="from_friend" label="好友微信号（小程序卡片专用）" width="300">
                        <template slot-scope="scope" >
                            <el-input v-model="scope.row.from_friend" type="textarea"
                                      :autosize="{ minRows: 1, maxRows: 2}" placeholder="好友微信号" size="mini"
                                      clearable></el-input>
                        </template>
                    </el-table-column>
                    <el-table-column label="发送群" width="350">
                        <template slot-scope="scope">
                            <el-select v-model="scope.row.wx_group_cats" multiple collapse-tags filterable
                                       placeholder="请选择群类型（可多选）" size="mini"
                                       style="width:280px;margin-top:20px;">
                                <el-option v-for="item in category_list" :key="item.id" :label="item.name"
                                           :value="item.id">
                                </el-option>
                            </el-select>
                            <el-select v-model="scope.row.wx_group_ids" multiple collapse-tags filterable
                                       placeholder="如选择了群类型，则无法单独选择群" size="mini"
                                       :disabled="scope.row.wx_group_cats.length > 0"
                                       style="width:280px;margin-top:20px;">
                                <el-option v-for="item in group_list" :key="item.group_wxid" :label="item.group_name"
                                           :value="item.group_wxid">
                                </el-option>
                            </el-select>
                        </template>
                    </el-table-column>
                    <el-table-column label="操作" width="100">
                        <template slot-scope="scope">
                            <el-button type="danger" size="small" @click="deleteMsg(scope.row)" style="margin-top:10px">
                                删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
            <el-col :span="24">
                <el-form :inline="true" class="demo-form-inline">
                    <el-form-item>
                        <el-button type="primary" size="mini" @click="onBatchSend">批量发送</el-button>
                    </el-form-item>
                    <el-form-item>
                        <el-dropdown @command="handleAddMsgCommand">
                            <el-button type="primary" size="mini">添加消息<i class="el-icon-arrow-down el-icon--right"></i>
                            </el-button>
                            <el-dropdown-menu slot="dropdown">
                                <el-dropdown-item command="0">通用消息</el-dropdown-item>
                                <el-dropdown-item command="4">卡片消息</el-dropdown-item>
                                <el-dropdown-item command="7">转发小程序卡片</el-dropdown-item>
                            </el-dropdown-menu>
                        </el-dropdown>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" size="mini" @click="onCheckSendRecord">消息记录</el-button>
                    </el-form-item>
                </el-form>
            </el-col>
        </el-row>
        <el-row>
            <el-tabs type="border-card" @tab-click="onTabClick">
                <el-tab-pane label="拼多多单品推广">
                    <pdd-sku-list ref="pddSkuList" @onSelect="addGoods">
                    </pdd-sku-list>
                </el-tab-pane>
                <el-tab-pane label="拼多多频道推广">
                    <pdd-channel-list ref="pddChannelList" @onSelect="addChannel">
                    </pdd-channel-list>
                </el-tab-pane>
                <el-tab-pane label="拼多多主题推广">
                    <pdd-theme-list ref="pddThemeList" @onSelect="addTheme">
                    </pdd-theme-list>
                </el-tab-pane>
                <el-tab-pane label="淘宝单品推广">
                    <tb-sku-list ref="tbSkuList" @onSelect="addTbGoods">
                    </tb-sku-list>
                </el-tab-pane>
                <el-tab-pane label="淘宝热销高佣推广">
                    <tb-hot-list ref="tbHotList" @onSelect="addTbGoods">
                    </tb-hot-list>
                </el-tab-pane>
                <el-tab-pane label="品牌团购推广">
                    <akc-sku-list ref="akcSkuList" @onSelectAct="addAkcActivity" @onSelectGoods="addAkcGoods">
                    </akc-sku-list>
                </el-tab-pane>
                <el-tab-pane label="淘宝1688商品列表">
                    <tb-1688-goods-list ref="tb1688GoodsList" @onSelect="addTb1688Goods" >
                    </tb-1688-goods-list>
                </el-tab-pane>
            </el-tabs>
        </el-row>
        <!-- <div style="position:fixed;width:375px;height:600px;background-color:red;z-index:2019;left:50%;margin-left:-188px;top:50%;margin-top:-300px;" :hidden="!dialogFormVisible">
          <div class="poster-container">
            <div class="poster" v-for="item in selectedData" :key="item.tmp_id" :ref="`poster${item.tmp_id}`">
            <div class="poster" ref="poster_preview" :hidden="!dialogFormVisible">
              <div class="main-image">
                <img style="width:100%;height:100%;" :src="`${getImage}?img=${urlencode(preview_pics[0])}`" />
              </div>
              <div class="content">
                <div class="goods-desc">
                  <div class="icon">
                    <img style="width:100%;height:100%;" :src="`${getImage}?img=${urlencode(item.goods_info.brand_logo_url)}`" />
                  </div>
                  <div class="title">
                    {{item.goods_info.name}}
                  </div> 
                </div>
                <div class="price">
                  <span style="font-size:18px;">¥</span>
                  <span style="font-size:30px;">{{item.goods_info.settlement_price}}.<span style="font-size:18px;">5</span></span>
                </div>
                <div class="ori-price">
                  <span>¥</span>
                  <span>2345.5</span>
                </div>
                <div class="guide-text">
                  扫一扫或长按识别二维码抢购
                </div>
              </div>
              <div class="bottom-bar">
                <img :src="`${getImage}?img=${urlencode('https://img.quexb.com/xtt/e888074be6fd4a73ab2c20adaefdc9b4.png')}`" />
              </div>
              <div class="sub-image">
                <img style="width:125px;height:125px;" :src="`${getImage}?img=${urlencode(preview_pics[1])}`" />
                <img style="width:125px;height:125px;" :src="`${getImage}?img=${urlencode(preview_pics[2])}`" />
                <img style="width:125px;height:125px;" :src="`${getImage}?img=${urlencode(preview_pics[3])}`" />
              </div>
            </div>
          </div>
        </div> -->
    </div> 
</template>

<script>
  import { sendGroupMsgImmediately } from '@/api/pdd';
  import { uploadCalendarMsg, getGroupCategoryList } from '@/api/robot';
  import { getWXGroupList } from '@/api/yjiyun';
  import { timestampToTime } from 'utils/chanageTime';
  import { convertBase64UrlToBlob } from 'utils/utils';
  import { Loading } from 'element-ui';
  import { genGroupbuyPoster } from '@/api/image';
  import { uploadImgNew } from '@/api/uploadImg';
  import html2canvas from 'html2canvas';
  // import urlencode from 'urlencode';
  import RangeSelector from '@/component/RangeSelector';
  import PddSkuList from '@/component/Pdd/SkuList';
  import PddChannelList from '@/component/Pdd/ChannelList';
  import PddThemeList from '@/component/Pdd/ThemeList';
  import TbSkuList from '@/component/Taobao/SkuList';
  import TbHotList from '@/component/Taobao/HotSaleList';
  import Tb1688GoodsList from '@/component/Taobao/1688GoodsList';
  import EmojiTextInput from '@/component/EmojiTextArea/';
  import AkcSkuList from '@/component/AiKuCun/skuList';
  import axios from 'axios';

  export default {
    components: { EmojiTextInput, RangeSelector, PddSkuList, PddChannelList, PddThemeList, TbSkuList, TbHotList, AkcSkuList, Tb1688GoodsList },
    data() {
      return {
        tmpId: 0,
        uploadImg: uploadImgNew,
        uploadingRow: {},
        selectedData: [],
        group_list: [],
        category_list: [],
      };
    },
    created() {
      // 筛选页面初始化
      this.getGroupList();
      this.getCategoryList();
    },
    mounted() {
      this.$refs.pddSkuList.didPresent();
    },
    methods: {
      getGroupList() {
        getWXGroupList().then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.group_list = res.data;
          }
        });
      },
      getCategoryList() {
        getGroupCategoryList().then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.category_list = res.data;
          }
        });
      },
      beforeAvatarUpload(row) {
        this.uploadingRow = row;
      },
      handleAvatarSuccess(key) {
        return (res, file, fileList) => {
          this.uploadingRow[key] = res.data;
          this.uploadingRow.fileName = file.name;
          console.log(file);
        };
      },
      addTbGoods(goodsInfo) {
        if (this.isDuplicate(goodsInfo.num_iid)) {
          return;
        }

        const text_tml = `${goodsInfo.title}\n{zk_final_price}{reserve_price}【下单地址】{{promote_url}} \n----★抢购方法★----\n1.点开“下单地址”\n2.点击“一键复制”\n3.打开掏宝APP\n[怄火] 领券！下单！`;
        let reserve_price = '';
        let zk_final_price = '';
        if (goodsInfo.reserve_price) {
          reserve_price = `【原价】 ${goodsInfo.reserve_price}元 \n`;
        }
        if (goodsInfo.coupon_price >= 0) {
          zk_final_price = `【券后价】 ${goodsInfo.coupon_price}元 \n`;
        } else if (goodsInfo.zk_final_price) {
          zk_final_price = `【折后价】 ${goodsInfo.zk_final_price}元 \n`;
        }
        goodsInfo.num_iid = goodsInfo.num_iid || goodsInfo.item_id;

        const data = {
          tmp_id: ++this.tmpId,
          goods_info: goodsInfo,
          desc: goodsInfo.title,
          goods_id: goodsInfo.num_iid,
          send_img: goodsInfo.pict_url,
          send_file: '',
          wx_group_ids: [],
          send_text: text_tml.replace('{zk_final_price}', zk_final_price).replace('{reserve_price}', reserve_price),
          send_datetime: this.genMsgSendDateTime(),
          operator: this.$store.getters.name,
          wx_group_cats: [],
          wx_group_options: [],
          type: 1
        };

        this.selectedData.push(data);
      },
      addTb1688Goods(goodsInfo) {
        this.$message({ type: 'info', message: '功能未开放' });
      },
      addAkcActivity(activity) {
        if (this.isDuplicate(activity.id)) {
          return;
        }
  
        const data = {
          tmp_id: ++this.tmpId,
          desc: activity.name,
          goods_id: activity.id,
          send_img: activity.brand_logo_url,
          send_file: '',
          wx_group_ids: [],
          send_text: `💯雀享优品福利时间到，好货不常有，优惠抢先知！今天给大家精选了以下商品 ✌️\n【${activity.name}】\n❗群里限时团购低至【${(activity.min_discount / 10).toFixed(1)}折】\n 冰点价限时狂欢，数量不多了，快来看看吧\n【{{promote_url}}】`,
          send_datetime: this.genMsgSendDateTime(),
          operator: this.$store.getters.name,
          wx_group_cats: [],
          wx_group_options: [],
          promote_type: 7,
          type: 5
        };

        this.selectedData.push(data);
      },
      addAkcGoods(goods) {
        if (this.isDuplicate(goods.id)) {
          return;
        }

        this.preview_pics = goods.pictures;
        const code = goods.description.split('、')[0];
        const id = ++this.tmpId;
  
        const data = {
          tmp_id: id,
          goods_info: goods,
          desc: goods.name,
          goods_id: goods.real_goods_id,
          send_img: goods.pictures[0],
          send_file: '',
          wx_group_ids: [],
          send_text: `️❤️雀享优品:为您打造精致生活\n\n⭕【${goods.ownBrandName}】开团啦⭕\n${code || ''} ${goods.name}\n👉【原价】${goods.akc_tag_price}\n👉【秒杀价】${goods.settlement_price}\n\n爱生活，爱自己😝[色]\n喜欢就要买买买👇\n{{promote_url}}`,
          send_datetime: this.genMsgSendDateTime(),
          operator: this.$store.getters.name,
          wx_group_cats: [],
          wx_group_options: [],
          promote_type: 1,
          type: 5
        };

        const loadingInstance = Loading.service({
          lock: true,
          text: '生成海报中，请耐心等待',
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)'
        });
        genGroupbuyPoster({ pics: goods.pictures }).then(response => {
          const res = response.data;
          if (res.code === 10000 && res.data && res.data.length > 0) {
            data.send_img = res.data;
          }

          this.selectedData.push(data);
          loadingInstance.close();
        }).catch(err => {
          loadingInstance.close();
        });
      },

      addGoods(goodsInfo) {
        if (this.isDuplicate(goodsInfo.goods_id)) {
          return;
        }
  
        console.log(goodsInfo);

        const data = {
          tmp_id: ++this.tmpId,
          goods_info: goodsInfo,
          desc: goodsInfo.goods_name,
          goods_id: goodsInfo.goods_id,
          send_img: goodsInfo.goods_thumbnail_url,
          send_file: '',
          wx_group_ids: [],
          send_text: goodsInfo.goods_name + '\n【券后价】' + (goodsInfo.min_group_price / 100 - goodsInfo.coupon_discount / 100).toFixed(2) + '元[玫瑰][玫瑰][玫瑰] \n【原价】' + (goodsInfo.min_group_price / 100).toFixed(2) + '元 \n【下单地址】{{promote_url}} \n领券省钱，真的超划算！',
          send_datetime: this.genMsgSendDateTime(),
          operator: this.$store.getters.name,
          wx_group_cats: [],
          wx_group_options: [],
          promote_type: 1,
          channel_type: 1111,
          type: 3
        };

        this.selectedData.push(data);
      },
      addChannel(info) {
        const data = {
          tmp_id: ++this.tmpId,
          send_img: info.image,
          send_file: '',
          wx_group_ids: [],
          send_text: info.send_text,
          send_datetime: this.genMsgSendDateTime(),
          operator: this.$store.getters.name,
          wx_group_cats: [],
          wx_group_options: [],
          promote_type: info.promote_type,
          channel_type: info.channel_type,
          type: 3
        };

        this.selectedData.push(data);
      },
      addTheme(info) {
        const data = {
          tmp_id: ++this.tmpId,
          goods_id: info.id,
          send_img: info.image_url,
          send_file: '',
          wx_group_ids: [],
          send_text: info.name + ' \n主题链接:{{promote_url}} \n快来抢限时优惠券！！！',
          send_datetime: this.genMsgSendDateTime(),
          operator: this.$store.getters.name,
          wx_group_cats: [],
          wx_group_options: [],
          promote_type: 4,
          channel_type: 8888,
          type: 3
        };

        this.selectedData.push(data);
      },

      deleteMsg(goodsInfo) {
        for (const i in this.selectedData) {
          const obj = this.selectedData[i];
          if (obj.tmp_id === goodsInfo.tmp_id) {
            this.selectedData.splice(i, 1);
            return;
          }
        }
      },
      sendImmediately(goodsInfo) {
        const loadingInstance = Loading.service({
          lock: true,
          text: '发送群消息中',
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)'
        });
        const params = Object.assign({}, goodsInfo);
        params.send_time = new Date(params.send_time).getTime() / 1000;
        sendGroupMsgImmediately(params).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.$message({
              type: 'success',
              message: '发送完成，请到发送记录查看结果'
            });
          } else {
            this.$message({
              type: 'error',
              message: '发送失败'
            });
          }
          loadingInstance.close();
        }).catch(err => {
          loadingInstance.close();
        });
      },
      onCheckSendRecord() {
        this.$router.push({
          path: '/pdd/robotMsgRecord',
          name: 'robotMsgRecord',
        });
      },
      onBatchSend() {
        // console.log(`开始:${new Date()}`);
        if (this.selectedData.length > 0) {
          const msgList = Object.assign([], this.selectedData);

          // 是否有未选择发送群的消息
          let noGroupInfo = false;

          for (const i in msgList) {
            const msg = msgList[i];

            if (msg.wx_group_cats.length === 0 && msg.wx_group_ids.length === 0) {
              noGroupInfo = true;
              break;
            }

            msg.send_time = new Date(msg.send_datetime).getTime() / 1000;
            // const tick = new Date();
            // html2canvas(this.$refs[`poster${msg.tmp_id}`][0]).then(canvas => {
            //   const dataUrl = canvas.toDataURL('image/jpeg', 0.5);
            //   this.uploadBase64Image(dataUrl, `poster${msg.tmp_id}.jpeg`).then(response => {
            //     const res = response.data;
            //     if (res.code === 10000 && res.data) {
            //       msg.send_img = res.data;
            //     }
            //     console.log(msg.send_img, new Date());
            //   });
            // });
          }

          if (noGroupInfo) {
            // 有一条信息缺少群信息则不允许上传
            this.$message({ type: 'error', message: '所有消息都需要指定发送群信息' });
            return;
          }

          const loadingInstance = Loading.service({
            lock: true,
            text: '上传群消息中',
            spinner: 'el-icon-loading',
            background: 'rgba(0, 0, 0, 0.7)'
          });

          // console.log('upload', msgList);
          uploadCalendarMsg(msgList).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.$message({
                type: 'success',
                message: '上传完成，将会删除列表数据，避免重复上传，可到消息记录中查看'
              });
              this.selectedData = [];
            } else {
              this.$message({
                type: 'error',
                message: '上传失败'
              });
            }
            loadingInstance.close();
          }).catch(err => {
            loadingInstance.close();
          });
        } else {
          this.$message({
            type: 'info',
            message: '请不要发送空数据，你这样是不对滴'
          });
        }
      },
      onTabClick(val) {
        if (val.index === '2') {
          this.$refs.pddThemeList.didPresent();
        } else if (val.index === '0') {
          this.$refs.pddSkuList.didPresent();
        } else if (val.index === '3') {
          this.$refs.tbSkuList.didPresent();
        } else if (val.index === '4') {
          this.$refs.tbHotList.didPresent();
        } else if (val.index === '5') {
          this.$refs.akcSkuList.didPresent();
        } else if (val.index === '6') {
          this.$refs.tb1688GoodsList.didPresent();
        }
      },
      getGroupListByType(type) {
        const list = [];
        for (const i in this.group_list) {
          const group = this.group_list[i];
          if (group.category === type) {
            list.push(group.groupWxid);
          }
        }

        return list;
      },
      onChangeGroupOption(msgInfo) {
        if (!msgInfo) {
          return;
        }

        msgInfo.wx_group_cats = [];
        msgInfo.wx_group_ids = [];
        for (const i in msgInfo.wx_group_options) {
          const option = msgInfo.wx_group_options[i];
          const type = this.group_options.indexOf(option);
          if (type !== -1) {
            msgInfo.wx_group_cats.push(type);
          }
        }
      },

      /*
      添加消息处理
       */
      handleAddMsgCommand(msgType) {
        switch (msgType) {
          case '0':
          {
            this.addCommonMsg();
            break;
          }
          case '4':
          {
            this.addShareLinkMsg();
            break;
          }
          case '7':
          {
            this.addMiniProgramMsg();
            break;
          }
          default:
            this.$message({
              type: 'error',
              message: '不支持该消息的发送'
            });
            break;
        }
        // msgType === '0' ? this.addCommonMsg() : this.addShareLinkMsg();
      },

      // 通用消息
      addCommonMsg() {
        const data = {
          tmp_id: ++this.tmpId,
          send_img: '',
          send_file: '',
          wx_group_ids: [],
          send_text: '',
          send_datetime: this.genMsgSendDateTime(),
          operator: this.$store.getters.name,
          wx_group_cats: [],
          wx_group_options: [],
          promote_type: 4,
          channel_type: 8888,
          type: 0
        };

        this.selectedData.push(data);
      },

      // 卡片消息
      addShareLinkMsg() {
        const shareData = {
          type: 4,
          tmp_id: ++this.tmpId,
          wx_group_ids: [],
          send_datetime: this.genMsgSendDateTime(),
          operator: this.$store.getters.name,
          wx_group_cats: [],
          wx_group_options: [],
          send_text: '',
          send_img: '',
          send_file: '',
          send_link: '',
          desc: '',
        };

        this.selectedData.push(shareData);
      },

      // 转发小程序卡片消息
      addMiniProgramMsg() {
        const data = {
          tmp_id: ++this.tmpId,
          wx_group_ids: [],
          desc: '',
          send_text: '',
          send_datetime: this.genMsgSendDateTime(),
          from_friend: '',
          operator: this.$store.getters.name,
          wx_group_cats: [],
          wx_group_options: [],
          type: 7
        };

        this.selectedData.push(data);
      },

      sendTextPlaceholderForMsgType(type) {
        return type === 0 ? '消息内容' : (type === 4 ? '卡片描述' : '');
      },

      handleEmojiInput(event, index) {
        this.selectedData[index].desc = event;
      },

      genMsgSendDateTime() {
        const len = this.selectedData.length;
        return len > 0 ? new Date(this.selectedData[len - 1].send_datetime).getTime() + 900000 : new Date().getTime();
      },

      isDuplicate(goodsId) {
        let duplicate = false;
        for (const i in this.selectedData) {
          const obj = this.selectedData[i];
          if (obj.goods_id === goodsId) {
            this.$message({
              type: 'error',
              message: '重复的商品添加'
            });
            duplicate = true;
            break;
          }
        }

        return duplicate;
      },

      uploadBase64Image(base64Str, fileName) {
        const formData = new FormData();
        const blob = convertBase64UrlToBlob(base64Str);
        formData.append('file', blob, fileName);
  
        const service = axios.create({
          baseURL: 'https://xttapi.lexj.com', // api的base_url
          timeout: 30000, // 请求超时时间
          headers: { 'Content-Type': 'multipart/form-data' }
        });

        return service.post('/helper/uploadCdn', formData);
      }
    },
  };
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .tab_pane {
      display: -webkit-flex;
      display: flex;
      flex-direction: row;
      flex-wrap: wrap;
      justify-content: space-around;
    }

    .el-col {
      border-radius: 10px;
      margin-bottom: 30px;
    }

    .poster-container {
      display: -webkit-flex;
      display: flex;
      flex-direction: row;
      flex-wrap: wrap;

      .poster {
        position:fixed;
        height:600px;
        width: 375px;
        z-index:2019;
        left:50%;
        margin-left:-188px;
        top:50%;
        margin-top:-300px;
        background-color: #ffffff;

        .main-image {
          width: 375px;
          height: 375px;
        }

        .sub-image {
          width: 100%;
          display: flex;
          display: -webkit-flex; /* Safari */
          justify-content: space-between;
          flex-direction: row;
        }

        .content {
          width: 100%;
          height: 224px;
          padding: 25px 19px;

          .goods-desc {
            display: -webkit-flex;
            display: flex;
            flex-direction: row;
            flex-wrap: wrap;

            .icon {
              width: 52px;
              height: 52px;
            }

            .title {
              padding: 2px 0 8px 13px;
              width: 275px;
              font-family: 'pingFangSC-Medium';
              font-size: 15px;
              line-height: 22px;
              color: #282828;
            }
          }

          .price {
            font-family: 'pingFangSC-Heavy';
            color: #ff1815;
            margin-top: 20px;
          }

          .ori-price {
            font-family: 'pingFangSC-Medium';
            color: #aaaaaa;
            margin-top: 5px;
            span {
              text-decoration:line-through;
              font-size:16px;
            }
          }

          .guide-text {
            font-family: 'pingFangSC-Medium';
            width: 184px;
            height: 28px;
            line-height: 28px;
            margin-top: 16px;
            background-color: #ffcecd;
            color: #ff1815;
            border-radius: 14px;
            font-size: 12px;
            text-align: center;
          }
        }

        .bottom-bar {
          width: 100%;
          height: 42px;

          img {
            width: 100%;
            height: 100%;
          }
        }
      }
    }
    
</style>
