<template>
  <div class="app-container">
    <el-row>
      <el-col :span="24">
        <div class="header-title">五大入口筛选</div>
      </el-col>
      <!-- 筛选条件 start -->
      <el-col :span="24">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
          <el-form-item label="入口名称">
            <el-input v-model="formInline.title" placeholder="入口名称" size="mini" clearable></el-input>
          </el-form-item>
          <el-form-item label="链接">
            <el-input v-model="formInline.url" placeholder="链接" size="mini" clearable></el-input>
          </el-form-item>
          <el-form-item label="投放条件">
            <!-- <el-input v-model="formInline.platform" placeholder="投放条件" size="mini" clearable></el-input> -->
            <el-select v-model="formInline.platform" placeholder="请选择" size="mini">
              <el-option
                v-for="item in selectOptions"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="操作人">
            <el-input v-model="formInline.operateBy" placeholder="操作人" size="mini" clearable></el-input>
          </el-form-item>
          <el-form-item label="生效时间" class="time-width">
            <el-date-picker
              v-model="selectTimes"
              type="datetimerange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              size="mini"
              align="right">
            </el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onSubmit">筛选</el-button>
          </el-form-item>
          <el-form-item>
            <el-button size="mini" type="primary" @click="addBannerButton">添加</el-button>
          </el-form-item>
        </el-form>
      </el-col>
      <!-- 筛选条件 end -->
      <!-- 表格 start -->
      <el-col :span="24">
          <el-table
            :data="tableData"
            border
            style="width: 100%"
            v-loading="loading">
            <el-table-column
              fixed
              prop="sequence"
              label="序列"
              width="50">
            </el-table-column>
            <el-table-column
              prop="title"
              label="入口名称"
              width="120">
            </el-table-column>
            <el-table-column
              label="链接">
              <template slot-scope="scope">
                <a :href="scope.row.url" target="_blank">{{scope.row.url}}</a>
              </template>
            </el-table-column>
            <el-table-column
              height="80"
              label="入口照片预览"
              width="100">
              <template slot-scope="scope">
                <img :src="scope.row.img" alt="" style="width:80px;height:80px;">
              </template>
            </el-table-column>
            <el-table-column
              prop="platform"
              label="投放条件"
              width="120">
            </el-table-column>
            <el-table-column
              label="投放时间"
              width="310">
              <template slot-scope="scope">
                <div>{{scope.row.startTime}} 至 {{scope.row.endTime}}</div>
              </template>
            </el-table-column>
            <el-table-column
              prop="operateBy"
              label="操作人"
              width="70">
            </el-table-column>
            <el-table-column
              label="操作"
              fixed="right"
              width="150">
              <template slot-scope="scope">
                <el-button type="danger" @click="deleteBanner(scope.row.id, scope.$index)" size="small">删除</el-button>
                <el-button type="primary" size="small" @click="editBannerButton(scope.row.id)">编辑</el-button>
              </template>
            </el-table-column>
          </el-table>     
      </el-col>
      <!-- 表格 end -->
      <!-- 弹层 start -->
      <el-col :span="24">
        <el-dialog :title="dialogFormTitle" :visible.sync="dialogFormVisible" width="300" @close="cancelAddBanner">
          <el-form :model="addForm" :rules="rules" ref="addForm">
            <el-form-item label="序号" :label-width="formLabelWidth" prop="sequence">
              <el-input v-model="addForm.sequence" placeholder="序号" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="活动名称" :label-width="formLabelWidth" prop="title">
              <el-input v-model="addForm.title" placeholder="活动名称" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="链接" :label-width="formLabelWidth" prop="url">
              <el-input v-model="addForm.url" placeholder="链接" size="mini" clearable></el-input>
            </el-form-item>
            <!-- <el-form-item label="生效版本" :label-width="formLabelWidth" prop="startVersion">
              <el-input v-model="addForm.startVersion" placeholder="生效版本" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="失效版本" :label-width="formLabelWidth" prop="endVersion">
              <el-input v-model="addForm.endVersion" placeholder="失效版本" size="mini" clearable></el-input>
            </el-form-item> -->
            <el-form-item label="投放平台" :label-width="formLabelWidth" size="mini" prop="platform">
              <el-select v-model="addForm.platform" placeholder="请投放平台">
                <el-option label="all" value="0"></el-option>
                <el-option label="android" value="1"></el-option>
                <el-option label="ios" value="2"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="生效时间" class="time-width"  :label-width="formLabelWidth" prop="startTime">
            <el-date-picker
              v-model="selectTimes2"
              type="datetimerange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              align="right"
              size="mini"
              @change="selectTimeAfter">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="上传图片" class="time-width"  :label-width="formLabelWidth" prop="img">
            <el-upload
              class="avatar-uploader"
              :action="uploadImg"
              :show-file-list="false"
              :on-success="handleAvatarSuccess"
              :before-upload="beforeAvatarUpload"
              :list-type="addForm.img ? '' : 'picture-card'">
              <img v-if="addForm.img" :src="addForm.img" class="avatar" width="150" height="150">
              <i v-else class="el-icon-plus"></i>
            </el-upload>
          </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="cancelAddBanner('addForm')">取 消</el-button>
            <el-button type="primary" @click="addBanner('addForm')">确 定</el-button>
          </div>
        </el-dialog>
      </el-col>
      <!-- 弹层 end -->
      <!-- 分页 start -->
      <el-col :span="24">
        <div class="pagination" style="margin-top:20px;">
          <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="formInline.page" :page-sizes="[10, 20, 30, 40]" :page-size="formInline.pageSize" layout="sizes, prev, pager, next" :total="totalcount">
          </el-pagination>
        </div>
      </el-col>
      <!-- 分页 end -->
    </el-row>
  </div>
</template>

<script>
import {
  editInfomation,
  addInfomation,
  deleteInfomation
} from '@/api/infomation';
import { uploadImg } from '@/api/uploadImg';
import { timestampToTime } from 'utils/chanageTime';

export default {
  data() {
    return {
      totalcount: 0,
      loading: false,
      uploadImg: '',
      selectOptions: [
        {
          value: 0,
          label: 'all'
        },
        {
          value: 1,
          label: 'android'
        },
        {
          value: 2,
          label: 'ios'
        }
      ],
      formInline: {
        pageNum: 1,
        pageSize: 10,
        title: null,
        url: null,
        startTime: null,
        endTime: null,
        operateBy: null,
        platform: null
      },
      pickerOptions2: {
        shortcuts: [
          {
            text: '未来一周',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 7);
              picker.$emit('pick', [start, end]);
            }
          },
          {
            text: '未来一个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 30);
              picker.$emit('pick', [start, end]);
            }
          },
          {
            text: '未来三个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 90);
              picker.$emit('pick', [start, end]);
            }
          }
        ]
      },
      value4: [new Date(2000, 10, 10, 10, 10), new Date(2000, 10, 11, 10, 10)],
      selectTimes: '',
      selectTimes2: '',
      tableData: [],
      dialogFormVisible: false, // 弹层显示与否
      dialogFormTitle: '', // 弹层标题
      addForm: {
        sequence: '',
        title: '',
        url: '',
        img: '',
        startTime: '',
        endTime: '',
        platform: ''
        // startVersion: '',
        // endVersion: ''
      },
      formLabelWidth: '120px',
      rules: {
        sequence: [{ required: true, message: '请输入权重', trigger: 'blur' }],
        title: [{ required: true, message: '请填写活动名称', trigger: 'blur' }],
        url: [{ required: true, message: '请输入链接', trigger: 'blur' }],
        startVersion: [
          { required: true, message: '请填写生效版本', trigger: 'blur' }
        ],
        endVersion: [
          { required: true, message: '请失效版本', trigger: 'blur' }
        ],
        platform: [
          { required: true, message: '请选择投放平台', trigger: 'change' }
        ],
        startTime: [
          { required: true, message: '请选择生效时间段', trigger: 'change' }
        ],
        img: [{ required: true, message: '请上传banner图片' }]
      }
    };
  },
  created() {
    this.getList();
    this.uploadImg = uploadImg;
  },
  methods: {
    onSubmit() {
      // 筛选页面初始化
      this.formInline.pageNum = 1;
      this.formInline.pageSize = 10;
      this.getList();
    },
    addBannerButton() {
      this.dialogFormVisible = true;
      this.dialogFormTitle = '添加五大入口';
    },
    getList() {
      this.loading = true;
      if (this.selectTimes) {
        const selectTime = this.selectTimes;
        const startDate = selectTime[0].getTime() / 1000;
        const endDate = selectTime[1].getTime() / 1000;
        this.formInline.startTime = startDate;
        this.formInline.endTime = endDate;
      } else if (this.selectTimes == null) {
        this.formInline.startTime = null;
        this.formInline.endTime = null;
      }
      // 请求列表
      // selectFiveEnter(this.formInline).then(response => {
      //   const res = response.data;
      //   if (res.code == '10000') {
      //     this.tableData = res.data.data;
      //     this.loading = false;
      //     this.totalcount = res.data.totalNum;
      //     // 整理数据
      //     this.tableData.map((item, index) => {
      //       item.startTime = timestampToTime(item.startTime);
      //       item.endTime = timestampToTime(item.endTime);
      //       const platform = item.platform;
      //       if (platform == 0) {
      //         item.platform = 'android & ios';
      //       } else if (platform == 1) {
      //         item.platform = 'android';
      //       } else if (platform == 2) {
      //         item.platform = 'ios';
      //       }
      //     });
      //   }
      // });
    },
    deleteBanner(id, index) {
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          deleteInfomation({ id }).then(response => {
            const res = response.data;
            if (res.code == '10000') {
              this.$message({
                message: '删除成功！',
                type: 'success'
              });
              this.tableData.splice(index, 1);
            } else {
              this.$message.error(res.msg);
            }
          });
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });
        });
    },
    handleAvatarSuccess(res, file) {
      // console.log(res,'成功')
      // this.addForm.img = URL.createObjectURL(file.raw);
      this.addForm.img = res.data;
    },
    beforeAvatarUpload(file) {
      // const isJPG = file.type === 'image/jpeg';
      // const isLt2M = file.size / 1024 / 1024 < 2;
      // if (!isJPG) {
      //   this.$message.error('上传头像图片只能是 JPG 格式!');
      // }
      // if (!isLt2M) {
      //   this.$message.error('上传头像图片大小不能超过 2MB!');
      // }
      // return isJPG && isLt2M;
    },
    addBanner(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          const formLoading = this.$loading({
            lock: true,
            text: '提交中，请稍后！',
            background: 'rgba(0, 0, 0, 0.7)'
          });
          if (this.addForm.id) {
            editInfomation(this.addForm).then(response => {
              formLoading.close();
              const res = response.data;
              if (res.code == '10000') {
                this.$message({
                  message: '修改成功',
                  type: 'success'
                });
                setTimeout(() => {
                  this.dialogFormVisible = false;
                  this.$refs[formName].resetFields();
                }, 2000);

                // 重新请求列表
                this.getList();
              } else {
                this.$message.error(res.msg);
              }
            });
          } else {
            addInfomation(this.addForm).then(response => {
              formLoading.close();
              const res = response.data;
              if (res.code == '10000') {
                this.$message({
                  message: '增加成功！',
                  type: 'success'
                });
                setTimeout(() => {
                  this.addForm.id = null;
                  this.dialogFormVisible = false;
                  this.$refs[formName].resetFields();
                }, 2000);

                // 重新请求列表
                this.getList();
              } else {
                this.$message.error(res.msg);
              }
            });
          }
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    editBannerButton(id) {
      // 请求当前id的form内容
      getOneInfomation({ id }).then(response => {
        const res = response.data;
        if (res.code == '10000') {
          this.dialogFormTitle = '修改五大入口';
          this.addForm = res.data;
          this.addForm.platform = res.data.platform.toString();
          const startTime = timestampToTime(this.addForm.startTime);
          const endTime = timestampToTime(this.addForm.endTime);
          this.selectTimes2 = [startTime, endTime];
          this.dialogFormVisible = true;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    cancelAddBanner(formName) {
      this.addForm = {
        sequence: '',
        title: '',
        url: '',
        img: '',
        startTime: '',
        endTime: '',
        platform: ''
        // startVersion: '',
        // endVersion: ''
      };
      this.selectTimes2 = '';
      this.dialogFormVisible = false;
    },
    selectTimeAfter() {
      const selectTime = this.selectTimes2;
      const startDate = selectTime[0].getTime() / 1000;
      const endDate = selectTime[1].getTime() / 1000;
      this.addForm.startTime = startDate;
      this.addForm.endTime = endDate;
    },
    // 分页
    handleSizeChange(pageSize) {
      this.formInline.pageSize = pageSize;
      this.getList();
    },
    // 页码变化时触发
    handleCurrentChange(page) {
      this.formInline.pageNum = page;
      this.getList();
    }
  }
};
</script>

<style scoped>

</style>
