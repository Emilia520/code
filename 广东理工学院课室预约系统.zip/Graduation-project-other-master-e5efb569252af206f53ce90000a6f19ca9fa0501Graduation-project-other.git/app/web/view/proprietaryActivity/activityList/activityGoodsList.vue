<template>
    <div class="app-container">
        <el-row>
            <el-col :span="24">
                <div class="header-title">活动商品列表</div>
            </el-col>
            <el-row style="padding-bottom: 30px">
                <el-col>
                    <el-button v-show="!editingGoods" type="primary" @click="add()">添加活动商品</el-button>
                    <el-row v-show="editingGoods">
                        <el-form :model="addForm" ref="addForm">
                            <el-form-item label="商品id" :label-width="formLabelWidth" prop="name">
                                <el-input style="width:300px;" v-model="addForm.goodsId"
                                          placeholder="商品id(通过品牌特卖查到商品的id)"
                                          size="mini"
                                          clearable @change="checkGoods"></el-input>
                                <span v-if="!goodsIdVisible" style="color: #c9302c">商品已存在砍价活动当中</span>
                            </el-form-item>
                            <el-form-item label="最小的可购买价格" :label-width="formLabelWidth" prop="title">
                                <el-input style="width:300px;" v-model="addForm.min_purchasable_price"
                                          placeholder="最小的可购买价格" size="mini"
                                          clearable></el-input>
                            </el-form-item>
                            <el-form-item label="运费" :label-width="formLabelWidth" prop="title">
                                <el-input style="width:300px;" v-model="addForm.postage" placeholder="运费" size="mini"
                                          clearable></el-input>
                            </el-form-item>
                            <el-form-item label="可购买助力次数" :label-width="formLabelWidth" prop="title">
                                <el-input style="width:300px;" v-model="addForm.buyTime" placeholder="可购买助力次数"
                                          size="mini"
                                          clearable></el-input>
                            </el-form-item>
                            <el-form-item label="底价助力次数" :label-width="formLabelWidth" prop="title">
                                <el-input style="width:300px;" v-model="addForm.stopTime" placeholder="底价助力次数"
                                          size="mini"
                                          clearable></el-input>
                            </el-form-item>
                            <el-form-item label="砍价商品的库存" :label-width="formLabelWidth" prop="title">
                                <el-input style="width:300px;" v-model="addForm.inventory" placeholder="(当库存减为0时,所有该商品砍价都不可用)"
                                          size="mini"
                                          clearable></el-input>
                            </el-form-item>
                            <el-form-item label="权重" :label-width="formLabelWidth" prop="title">
                                <el-input style="width:300px;" v-model="addForm.sort" placeholder="底价助力次数"
                                          size="mini"
                                          clearable></el-input>
                            </el-form-item>
                            <el-form-item label="状态" :label-width="formLabelWidth" size="mini" prop="status">
                                <el-select v-model="addForm.status" placeholder="请设置状态">
                                    <el-option label="禁用" value="0"></el-option>
                                    <el-option label="启用" value="1"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-form>
                        <el-button type="primary" @click="confirmForm(addForm)" size="mini">创建</el-button>
                        <el-button type="info" @click="cancelAdd" size="mini">取消</el-button>
                    </el-row>
                </el-col>
            </el-row>
            <!-- 表格 start -->
            <el-col :span="24">
                <el-table
                        :data="tableData"
                        border
                        style="width: 100%"
                        v-loading="loading">
                    <el-table-column
                            height="200"
                            label="图片"
                            width="200">
                        <template slot-scope="scope">
                            <div class="container">
                                <img :src="scope.row.picture">
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="商品名"
                            width="300">
                        <template slot-scope="scope">
                            <div>{{scope.row.name}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="最小的可购买价格"
                            width="100">
                        <template slot-scope="scope">
                            <div>{{scope.row.min_purchasable_price}} 元</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="吊牌价"
                            width="100">
                        <template slot-scope="scope">
                            <div>{{scope.row.original_price}} 元</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="运费"
                            width="100">
                        <template slot-scope="scope">
                            <div>{{scope.row.postage}} 元</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="剩余库存"
                            width="100">
                        <template slot-scope="scope">
                            <div>{{scope.row.inventory}} 件</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="库存耗尽状态"
                            width="100">
                        <template slot-scope="scope">
                            <div  :style="{background: scope.row.inventory_exhaust_sign === 1 ? 'red' : 'white'}">{{scope.row.inventoryStatus}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="可购买助力次数"
                            width="100">
                        <template slot-scope="scope">
                            <div>{{scope.row.buyTime}} 次</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="底价助力次数"
                            width="100">
                        <template slot-scope="scope">
                            <div>{{scope.row.stopTime}} 次</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="权重"
                            width="100">
                        <template slot-scope="scope">
                            <div>{{scope.row.sort}} </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="状态"
                            width="80">
                        <template slot-scope="scope">
                            <div v-if="scope.row.status===0">下架</div>
                            <div v-if="scope.row.status===1">上架</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="操作"
                            width="200">
                        <template slot-scope="scope">
                            <el-button type="danger" icon="el-icon-delete" circle
                                       @click="deleteGoods(scope.row.id)"></el-button>
                            <el-button type="primary" icon="el-icon-edit" circle
                                       @click="editGoods(scope.row)"></el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
            <!-- 表格 end -->
            <!-- 弹层 start -->
            <el-col :span="24">
                <el-dialog :title="dialogFormTitle" :visible.sync="dialogFormVisible" width="300"
                           @close="cancel">
                    <el-form :model="addForm" ref="addForm">
                        <el-form-item label="ID" :label-width="formLabelWidth" prop="id">
                            <el-input :disabled="true" v-model="addForm.id" placeholder="ID" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="商品名" :label-width="formLabelWidth" prop="name">
                            <el-input v-model="addForm.name" placeholder="商品名" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="最小购买价格(元)" :label-width="formLabelWidth" prop="name">
                            <el-input v-model="addForm.min_purchasable_price" placeholder="最小可购买价格" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="吊牌价(元)" :label-width="formLabelWidth" prop="name">
                            <el-input v-model="addForm.original_price" placeholder="吊牌价" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="运费(元)" :label-width="formLabelWidth" prop="name">
                            <el-input v-model="addForm.postage" placeholder="运费" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="可购买助力次数" :label-width="formLabelWidth" prop="name">
                            <el-input v-model="addForm.buyTime" placeholder="可购买助力次数" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="底价助力次数" :label-width="formLabelWidth" prop="name">
                            <el-input v-model="addForm.stopTime" placeholder="底价助力次数" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="库存" :label-width="formLabelWidth" prop="inventory">
                            <el-input v-model="addForm.inventory" placeholder="库存" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="状态" :label-width="formLabelWidth" size="mini" prop="status">
                            <el-select v-model="addForm.status" placeholder="请设置状态">
                                <el-option label="下架" value="0"></el-option>
                                <el-option label="上架" value="1"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="图片" :label-width="formLabelWidth" prop="title">
                            <el-upload class="avatar-uploader" :action="uploadImg" :show-file-list="false"
                                       :on-success="handleAvatarSuccess"
                                       :list-type="addForm.picture? '' : 'picture-card'">
                                <div class="container">
                                    <img v-if="addForm.picture" :src="addForm.picture" class="avatar" alt="">
                                    <i v-else class="el-icon-plus"></i>
                                </div>
                            </el-upload>
                        </el-form-item>
                    </el-form>
                    <div slot="footer" class="dialog-footer">
                        <el-button @click="cancel('addForm')">取 消</el-button>
                        <el-button type="primary" @click="editItem(addForm)">确 定</el-button>
                    </div>
                </el-dialog>
            </el-col>
            <!-- 弹层 end -->
            <!-- 分页 start -->
            <el-col :span="24">
                <div class="pagination" style="margin-top:20px;">
                    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                                   :current-page="formInline.pageNum" :page-sizes="[10, 20, 30, 40]"
                                   :page-size="formInline.pageSize" layout="total, sizes, prev, pager, next"
                                   :total="totalcount">
                    </el-pagination>
                </div>
            </el-col>
            <!-- 分页 end -->
        </el-row>
    </div>
</template>

<script>
  import {
    getGoodsList,
    getGoodsById,
    updateGoods,
    deleteGoods,
    createGoods,
    checkGoods
  } from '@/api/proprietaryActivity';
  import {uploadImg} from '@/api/uploadImg';
  import {timestampToTime} from 'utils/chanageTime';

  export default {
    data() {
      return {
        totalcount: 0,
        id: 0,
        loading: false,
        editingGoods: false,
        goodsIdVisible: true,
        uploadImg: '',
        formInline: {
          type: null,
        },
        selectTimes: '',
        selectTimes2: '',
        tableData: [],
        goodsData: {},
        dialogFormVisible: false, // 弹层显示与否
        dialogFormTitle: '', // 弹层标题
        addForm: {
          id: '',
          showCondition: '',
          picture: ''
        },
        help_rule: {
          range_num: '',
        },
        formLabelWidth: '150px',
      };
    },
    created() {
      this.getList();
      this.uploadImg = uploadImg;
    },
    methods: {
      updateAddForm(addForm) {
        this.addForm = addForm;
      },
      onSubmit() {
        // 筛选页面初始化
        this.formInline.pageNum = 1;
        this.formInline.pageSize = 10;
        this.getList();
      },
      getList() {
        this.loading = true;
        this.id = this.$route.params.id;
        getGoodsList({ id: this.id }).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.tableData = res.data;
            // 查询商品
            for (const i in this.tableData) {
              getGoodsById({ id: this.tableData[i].product_over_id }).then(response => {
                const res = response.data;
                if (res.code === 10000) {
                  this.goodsData = res.data[0];
                  const pics = JSON.parse(this.goodsData.picture);
                  if (! this.tableData[i].picture) {
                    this.tableData[i].picture = pics[0];
                  }
                  if (! this.tableData[i].name) {
                    this.tableData[i].name = this.goodsData.name;
                  }
                  if (! this.tableData[i].original_price) {
                    this.tableData[i].original_price = this.goodsData.akc_tag_price;
                  }
                }
              });
              this.tableData[i].inventoryStatus = Number(this.tableData[i].inventory_exhaust_sign) === 0 ? '未添加库存/库存充足' : '库存/供应商库存耗尽';
              const helpRule = JSON.parse(this.tableData[i].help_rule);
              const times = helpRule.range_num;
              this.tableData[i].buyTime = times[1];
              this.tableData[i].stopTime = times[2];
            }
          }
          this.loading = false;
        });
      },
      selectTimeAfter() {
        const startDate = this.selectTimes2[0].getTime() / 1000;
        const endDate = this.selectTimes2[1].getTime() / 1000;
        this.addForm.start_time = startDate;
        this.addForm.end_time = endDate;
      },
      // 上传图片
      handleAvatarSuccess(res, b) {
        this.addForm.picture = res.data;
      },
      // 分页
      handleSizeChange(pageSize) {
        this.formInline.pageSize = pageSize;
        this.getList();
      },
      // 页码变化时触发
      handleCurrentChange(page) {
        this.formInline.pageNum = page;
        this.getList();
      },
      // 编辑商品
      editGoods(data) {
        this.dialogFormVisible = true;
        this.addForm = data;
        this.addForm.status = data.status.toString();
      },
      // 编辑商品
      editItem(data) {
        const helpNum = [0];
        helpNum.push(parseInt(data.buyTime));
        helpNum.push(parseInt(data.stopTime));
        this.help_rule.range_num = helpNum;
        data.help_rule = JSON.stringify(this.help_rule);
        console.log('data', data);
        updateGoods(data).then(response => {
          this.getList();
        });
        this.dialogFormVisible = false;
      },
      cancel() {
        this.dialogFormVisible = false;
        this.getList();
      },
      deleteGoods(id) {
        console.log(id);
        this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            deleteGoods({ goodsId: id }).then(response => {
              const res = response.data;
              if (res.code === '10000') {
                this.$message({
                  message: '删除成功！',
                  type: 'success'
                });
              }
              this.getList();
            });
          })
          .catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除'
            });
          });
      },

      add() {
        this.addForm = {};
        this.editingGoods = true;
      },
      cancelAdd() {
        this.addForm = {};
        this.editingGoods = false;
      },
      confirmForm(addForm) {
        this.id = this.$route.params.id;
        console.log(this.id);
        const helpNum = [0];
        helpNum.push(parseInt(addForm.buyTime));
        helpNum.push(parseInt(addForm.stopTime));
        this.help_rule.range_num = helpNum;
        addForm.help_rule = JSON.stringify(this.help_rule);
        createGoods({ activityId: this.id, addForm }).then(response => {
          const res = response.data;
          if (res.code === '10000') {
            this.$message({
              message: '成功！',
              type: 'success'
            });
          }
          this.getList();
        });
        this.editingGoods = false;
      },

      // 检查商品是否加入过活动
      checkGoods() {
        checkGoods({ goodsId: this.addForm.goodsId }).then(response => {
          const res = response.data;
          console.log(res.data);
          if (res.data.length > 0) {
            this.goodsIdVisible = false;
          } else {
            this.goodsIdVisible = true;
          }
        });
      },
    }
  };
</script>

<style scoped>
    .container {
        width: 200px;
        height: 100px;
        margin: 20px auto;
        text-align: center;
        padding: 5px;
    }

    .container > img {
        max-width: 100%;
        max-height: 100%;
    }
</style>
