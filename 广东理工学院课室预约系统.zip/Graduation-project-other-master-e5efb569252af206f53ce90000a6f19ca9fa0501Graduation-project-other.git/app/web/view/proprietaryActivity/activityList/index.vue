<template>
    <div class="app-container">
        <el-row>
            <el-col :span="24">
                <div class="header-title">砍价活动列表</div>
            </el-col>
            <el-row>
                <el-col style="padding-bottom: 20px">
                    <el-button v-show="!editingChoiceList" type="primary" @click="add()">
                        新增砍价会场
                    </el-button>

                    <el-row v-show="editingChoiceList">
                        <el-form :model="addForm" ref="addForm">
                            <el-form-item label="活动标题" :label-width="formLabelWidth" prop="title">
                                <el-input style="width:300px;" v-model="addForm.title" placeholder="活动标题" size="mini"
                                          clearable></el-input>
                            </el-form-item><!--
                            <el-form-item label=
                            <el-form-item label="免单规则" :label-width="formLabelWidth" prop="title">
                                <el-input style="width:300px;" v-model="addForm.free_sheet_rule_content" placeholder="免单规则" size="mini"
                                          clearable></el-input>
                            </el-form-item>
                            <el-form-item label="活动规则" :label-width="formLabelWidth" prop="title">
                                <el-input
                                        style="width:300px;"
                                        type="textarea"
                                        :rows="2"
                                        placeholder="活动规则(问前端拿html)"
                                        v-model="addForm.rule_content">
                                </el-input>
                            </el-form-item>-->
                            <el-form-item label="参与条件" :label-width="formLabelWidth" size="mini" prop="client_id">
                                <el-select v-model="addForm.join_condition" placeholder="参与条件">
                                    <el-option label="新注册用户" value="1"></el-option>
                                    <el-option label="新激活用户" value="2"></el-option>
                                    <el-option label="老用户" value="3"></el-option>
                                    <el-option label="全部注册用户" value="4"></el-option>
                                </el-select>
                            </el-form-item>
                            <el-form-item label="状态" :label-width="formLabelWidth" size="mini" prop="status">
                                <el-select v-model="addForm.status" placeholder="请设置状态">
                                    <el-option label="禁用" value="0"></el-option>
                                    <el-option label="启用" value="1"></el-option>
                                </el-select>
                            </el-form-item>
                            <el-form-item label="助力条件" :label-width="formLabelWidth" size="mini" prop="status">
                                <el-select v-model="addForm.help_condition" placeholder="助力条件">
                                    <el-option label="新注册用户" value="1"></el-option>
                                    <el-option label="新激活用户" value="2"></el-option>
                                    <el-option label="老用户" value="3"></el-option>
                                    <el-option label="全部注册用户" value="4"></el-option>
                                </el-select>
                            </el-form-item>
                            <el-form-item label="生效时间" class="time-width" :label-width="formLabelWidth"
                                          prop="start_time">
                                <el-date-picker
                                        v-model="selectTimes2"
                                        type="datetimerange"
                                        range-separator="至"
                                        start-placeholder="开始日期"
                                        end-placeholder="结束日期"
                                        align="right"
                                        size="mini"
                                        @change="selectTimeAfter">
                                </el-date-picker>
                            </el-form-item>
                        </el-form>
                        <el-button type="primary" @click="confirmForm(addForm)" size="mini">创建</el-button>
                        <el-button type="info" @click="cancelAdd" size="mini">取消</el-button>
                    </el-row>
                </el-col>
            </el-row>
            <!-- 表格 start -->
            <el-col :span="24">
                <el-table
                        :data="tableData"
                        border
                        style="width: 100%"
                        v-loading="loading">
                    <el-table-column
                            fixed
                            label="会场ID"
                            width="80">
                        <template slot-scope="scope">
                            <div>{{scope.row.id}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="活动标题"
                            width="150">
                        <template slot-scope="scope">
                            <div>{{scope.row.title}}</div>
                        </template>
                    </el-table-column><!--
                    <el-table-column
                            label="免单规则"
                            width="150">
                        <template slot-scope="scope">
                            <div>{{scope.row.free_sheet_rule_content}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="活动文案"
                            width="700">
                        <template slot-scope="scope">
                            <el-col :span="24">
                                <el-table
                                        :data="scope.row.activity_content"
                                        border
                                        style="width: 100%"
                                        v-loading="loading">
                                    <el-table-column
                                            label="标题"
                                            width="80">
                                        <template slot-scope="scope">
                                            <div>{{scope.row.title}}</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                            label="跳转地址"
                                            width="250">
                                        <template slot-scope="scope">
                                            <div>{{scope.row.url}}</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                            label="文本内容"
                                            width="150">
                                        <template slot-scope="scope">
                                            <div>{{scope.row.content}}</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                            label="图片"
                                            width="80">
                                        <template slot-scope="scope">
                                            <div><img :src="scope.row.imageUrl" alt="" height="50" width="50"></div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                            fixed="right"
                                            height="150"
                                            label="操作"
                                            width="80">
                                        <template slot-scope="scope">
                                            <el-button type="primary" icon="el-icon-edit" circle
                                                       @click="editActivityContent(scope.row)"></el-button>
                                        </template>
                                    </el-table-column>
                                </el-table>
                            </el-col>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="浮窗"
                            width="520">
                        <template slot-scope="scope">
                            <el-col :span="24">
                                <el-table
                                        :data="scope.row.floating_window"
                                        border
                                        style="width: 100%"
                                        v-loading="loading">
                                    <el-table-column
                                            label="标题"
                                            width="80">
                                        <template slot-scope="scope">
                                            <div>{{scope.row.title}}</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                            label="跳转地址"
                                            width="250">
                                        <template slot-scope="scope">
                                            <div>{{scope.row.url}}</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                            label="图片"
                                            width="80">
                                        <template slot-scope="scope">
                                            <div><img :src="scope.row.imageUrl" alt="" height="50" width="50"></div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                            fixed="right"
                                            height="150"
                                            label="操作"
                                            width="80">
                                        <template slot-scope="scope">
                                            <el-button type="primary" icon="el-icon-edit" circle
                                                       @click="editFloatingWindow(scope.row)"></el-button>
                                        </template>
                                    </el-table-column>
                                </el-table>
                            </el-col>
                        </template>
                    </el-table-column>-->
                    <el-table-column
                            label="参与条件"
                            width="180">
                        <template slot-scope="scope">
                            <div v-if="scope.row.join_condition === 1">新注册用户</div>
                            <div v-if="scope.row.join_condition === 2">新激活用户</div>
                            <div v-if="scope.row.join_condition === 3">老用户</div>
                            <div v-if="scope.row.join_condition === 4">全部注册用户</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="助力条件"
                            width="100">
                        <template slot-scope="scope">
                            <div v-if="scope.row.help_condition === 1">新注册用户</div>
                            <div v-if="scope.row.help_condition === 2">新激活用户</div>
                            <div v-if="scope.row.help_condition === 3">老用户</div>
                            <div v-if="scope.row.help_condition === 4">全部注册用户</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="活动时间"
                            width="350">
                        <template slot-scope="scope">
                            <div>{{scope.row.start_time}} 至 {{scope.row.end_time}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="状态"
                            width="50">
                        <template slot-scope="scope">
                            <div v-if="scope.row.status===0">不展示</div>
                            <div v-if="scope.row.status===1">展示</div>
                        </template>
                    </el-table-column>

                    <el-table-column
                            label="配置信息"
                            width="100">
                        <template slot-scope="scope">
                            <el-button type="primary"
                                       @click="editRule(scope.row)"
                                       size="small">查看
                            </el-button>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="操作"
                            width="280">
                        <template slot-scope="scope">
                            <el-button type="danger"
                                       @click="$router.push({name: 'activityGoodsList',params: {id: scope.row.id}})"
                                       size="small">查看砍价商品
                            </el-button>
                            <el-button type="primary" size="small" @click="editActivity(scope.row)"
                            >编辑会场
                            </el-button>
                            <!--<el-row>
                                <el-button type="primary" size="small" @click="createActContent(scope.row)"
                                           style="margin-top:20px" v-show="!scope.row.activity_content">创建活动内容
                                </el-button>
                                <el-button type="primary" size="small" @click="createFloat(scope.row)"
                                           style="margin-top:20px" v-show="!scope.row.floating_window">创建浮窗
                                </el-button>
                            </el-row>-->
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
            <!-- 表格 end -->
            <!-- 弹层 start -->
            <el-col :span="24">
                <el-dialog :title="dialogFormTitle" :visible.sync="dialogFormVisible" width="300"
                           @close="cancel">
                    <el-form :model="addForm" :rules="rules" ref="addForm">
                        <el-form-item label="ID" :label-width="formLabelWidth" prop="id">
                            <el-input :disabled="true" v-model="addForm.id" placeholder="ID" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <!--<el-form-item label="活动名" :label-width="formLabelWidth" prop="name" v-show="visibleType === 0">
                            <el-input v-model="addForm.name" placeholder="活动名" size="mini"
                                      clearable></el-input>
                        </el-form-item>-->
                        <el-form-item label="活动标题" :label-width="formLabelWidth" prop="title"
                                      v-show="visibleType !== 5">
                            <el-input v-model="addForm.title" placeholder="活动标题" size="mini"
                                      clearable></el-input>
                        </el-form-item><!--
                        <el-form-item label="活动规则" :label-width="formLabelWidth" prop="title"
                                      v-show="visibleType === 0">
                            <el-input
                                    type="textarea"
                                    :rows="2"
                                    placeholder="活动规则"
                                    v-model="addForm.rule_content">
                            </el-input>
                        </el-form-item>
                        <el-form-item label="文案" :label-width="formLabelWidth" prop="title"
                                      v-show="visibleType === 1 || visibleType === 3 ">
                            <el-input v-model="addForm.content" placeholder="文案" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="跳转地址" :label-width="formLabelWidth" prop="title"
                                      v-show="visibleType === 1 || visibleType === 2 || visibleType === 3  || visibleType === 4">
                            <el-input v-model="addForm.url" placeholder="跳转地址" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="图片" :label-width="formLabelWidth" prop="title"
                                      v-show="visibleType === 1 || visibleType === 2 || visibleType === 3  || visibleType === 4">
                            <el-upload class="avatar-uploader" :action="uploadImg" :show-file-list="false"
                                       :on-success="handleAvatarSuccess"
                                       :list-type="addForm.imageUrl? '' : 'picture-card'">
                                <div class="container">
                                    <img v-if="addForm.imageUrl" :src="addForm.imageUrl" class="avatar" alt="">
                                    <i v-else class="el-icon-plus"></i>
                                </div>
                            </el-upload>
                        </el-form-item>-->
                        <!-- 砍价规则 -->
                        <el-form-item label="会场砍价规则" :label-width="formLabelWidth" size="mini" prop="rule_content"
                                      v-show="visibleType === 5">
                            <el-input v-model="addForm.rule_content" placeholder="会场砍价规则" size="mini" type="textarea"
                            ></el-input>
                        </el-form-item>
                        <el-form-item label="雀享优品地址" :label-width="formLabelWidth" prop="url"
                                      v-show="visibleType === 5">
                            <el-input :disabled="true" v-model="addForm.actQxbUrl" placeholder="雀享优品跳转地址"
                                      size="mini"
                            ></el-input>
                        </el-form-item>
                        <el-form-item label="校品团地址" :label-width="formLabelWidth" prop="url" v-show="visibleType === 5">
                            <el-input :disabled="true" v-model="addForm.actCampusUrl" placeholder="校品团跳转地址"
                                      size="mini"
                            ></el-input>
                        </el-form-item>
                        <el-form-item label="图片" :label-width="formLabelWidth"
                                      v-show="visibleType === 5">
                            <el-upload class="avatar-uploader" :action="uploadImg" :show-file-list="false"
                                       :on-success="handleAvatarSuccess"
                                       :list-type="addForm.actImageUrl? '' : 'picture-card'">
                                <div class="container">
                                    <img v-if="addForm.actImageUrl" :src="addForm.actImageUrl" class="avatar" alt="" >
                                    <i v-else class="el-icon-plus"></i>
                                </div>
                            </el-upload>
                        </el-form-item>
                        <!--  -->
                        <el-form-item label="参与条件" :label-width="formLabelWidth" size="mini" prop="client_id"
                                      v-show="visibleType === 0  && !isStart">
                            <el-select v-model="addForm.join_condition" placeholder="">
                                <el-option label="新注册用户" value="1"></el-option>
                                <el-option label="新激活用户" value="2"></el-option>
                                <el-option label="老用户" value="3"></el-option>
                                <el-option label="全部注册用户" value="4"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="状态" :label-width="formLabelWidth" size="mini" prop="status"
                                      v-show="visibleType === 0">
                            <el-select v-model="addForm.status" placeholder="请设置状态">
                                <el-option label="禁用" value="0"></el-option>
                                <el-option label="启用" value="1"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="助力条件" :label-width="formLabelWidth" size="mini" prop="status"
                                      v-show="visibleType === 0 && !isStart">
                            <el-select v-model="addForm.help_condition" placeholder="">
                                <el-option label="新注册用户" value="1"></el-option>
                                <el-option label="新激活用户" value="2"></el-option>
                                <el-option label="老用户" value="3"></el-option>
                                <el-option label="全部注册用户" value="4"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="生效时间" class="time-width" :label-width="formLabelWidth" prop="start_time"
                                      v-show="visibleType === 0">
                            <el-date-picker
                                    v-model="selectTimes2"
                                    type="datetimerange"
                                    range-separator="至"
                                    start-placeholder="开始日期"
                                    end-placeholder="结束日期"
                                    align="right"
                                    size="mini"
                                    @change="selectTimeAfter">
                            </el-date-picker>
                        </el-form-item>
                    </el-form>
                    <div slot="footer" class="dialog-footer">
                        <el-button @click="cancel('addForm')">取 消</el-button>
                        <el-button type="primary" @click="update(addForm)">确 定</el-button>
                    </div>
                </el-dialog>
            </el-col>
            <!-- 弹层 end -->
            <!-- 分页 start -->
            <el-col :span="24">
                <div class="pagination" style="margin-top:20px;">
                    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                                   :current-page="formInline.pageNum" :page-sizes="[10, 20, 30, 40]"
                                   :page-size="formInline.pageSize" layout="total, sizes, prev, pager, next"
                                   :total="totalcount">
                    </el-pagination>
                </div>
            </el-col>
            <!-- 分页 end -->
        </el-row>
    </div>
</template>

<script>
  import {
    getActivityList,
    getActivityListById,
    updateActivityListById,
    createActivity,
    updateActivityListRoleById
  } from '@/api/proprietaryActivity';
  import {uploadImg} from '@/api/uploadImg';
  import {timestampToTime} from 'utils/chanageTime';

  export default {
    data() {
      return {
        selectTimes: '',
        selectTimes2: '',
        totalcount: 0,
        loading: false,
        uploadImg: '',
        formInline: {
          pageNum: 1,
          pageSize: 10,
        },
        tableData: [],
        dialogFormVisible: false, // 弹层显示与否
        editingChoiceList: false, // 展示添加按钮
        isStart: false, // 展示添加按钮
        visibleType: 1, // 弹层类型
        dialogFormTitle: '', // 弹层标题
        addForm: {
          id: '',
          title: '',
          content: '',
          rule_content: '',
          activity_content: [
            {
              title: '',
              url: '',
              imgUrl: '',
              content: ''
            }
          ],
          floatingWindow: [
            {
              title: '',
              url: '',
              imgUrl: '',
              content: ''
            }
          ],
          start_time: '',
          end_time: '',
          free_sheet_rule_content: '',
          status: 0,
          join_condition: 1,
          help_condition: 1,
          activityContent:
            {
              title: '',
              url: '',
              imgUrl: '',
              content: ''
            }
        },
        formLabelWidth: '120px',
        rules: {
          sort: [{ required: true, message: '请输入权重', trigger: 'blur' }],
        }
      };
    },
    created() {
      this.getList();
      this.uploadImg = uploadImg;
    },
    methods: {
      onSubmit() {
        // 筛选页面初始化
        this.formInline.pageNum = 1;
        this.formInline.pageSize = 10;
        this.getList();
      },

      getList() {
        this.loading = true;
        // 请求列表
        getActivityList(this.formInline).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.tableData = res.data;
            this.totalcount = res.totalCount;
            // 整理数据
            for (const i in this.tableData) {
              const item = this.tableData[i];
              item.start_time = timestampToTime(item.start_time);
              item.end_time = timestampToTime(item.end_time);
              item.activity_content = JSON.parse(item.activity_content);
              if (item.activity_content) {
                item.actQxbUrl = item.activity_content[0].actQxbUrl;
                item.actCampusUrl = item.activity_content[0].actCampusUrl;
                item.actImageUrl = item.activity_content[0].imageUrl;
              }
              item.floating_window = JSON.parse(item.floating_window);
              for (const i in item.activity_content) {
                item.activity_content[i].id = item.id;
              }
              for (const i in item.floating_window) {
                item.floating_window[i].id = item.id;
              }
            }
          }

          this.loading = false;
        });
      },
      selectTimeAfter() {
        const startDate = this.selectTimes2[0].getTime() / 1000;
        const endDate = this.selectTimes2[1].getTime() / 1000;
        this.addForm.start_time = startDate;
        this.addForm.end_time = endDate;
      },
      // 分页
      handleSizeChange(pageSize) {
        this.formInline.pageSize = pageSize;
        this.getList();
      },
      // 页码变化时触发
      handleCurrentChange(page) {
        this.formInline.pageNum = page;
        this.getList();
      },
      // 编辑活动
      editActivity(data) {
        this.visibleType = 0;
        this.dialogFormTitle = '修改';
        this.addForm = data;
        this.addForm.status = data.status.toString();
        this.addForm.join_condition = data.join_condition.toString();
        this.addForm.help_condition = data.help_condition.toString();
        this.selectTimes2 = [this.addForm.start_time, this.addForm.end_time];
        this.addForm.start_time = new Date(this.selectTimes2[0]).getTime() / 1000;
        this.addForm.end_time = new Date(this.selectTimes2[1]).getTime() / 1000;
        if (new Date().getTime() / 1000 > this.addForm.start_time) {
          this.isStart = true;
        } else {
          this.isStart = false;
        }
        this.dialogFormVisible = true;
      },
      // 关闭弹层
      cancel() {
        this.dialogFormVisible = false;
        this.getList();
      },
      // 修改活动文案
      editActivityContent(data) {
        this.visibleType = 1;
        this.dialogFormTitle = '修改活动文案';
        this.addForm = data;
        this.dialogFormVisible = true;
      }, // 修改浮窗
      editFloatingWindow(data) {
        this.visibleType = 2;
        this.dialogFormTitle = '修改浮窗内容';
        this.addForm = data;
        this.dialogFormVisible = true;
      },
      // 上传图片
      handleAvatarSuccess(res, b) {
        this.addForm.actImageUrl = res.data;
      },
      // 更新数据
      update(addForm) {

        if (this.visibleType === 1) {
          const activity_content = [];
          activity_content.push(addForm);
          // 更新活动文案
          const activityContent = JSON.stringify(activity_content);
          updateActivityListById({ id: addForm.id, activityContent }).then(response => {
            this.$message({
              message: '成功！',
              type: 'success'
            });
            this.getList();
          });
        }
        if (this.visibleType === 2) {
          const floating_window = [];
          floating_window.push(addForm);
          // 更新浮窗
          const floatingWindow = JSON.stringify(floating_window);
          console.log(floatingWindow);
          updateActivityListById({ id: addForm.id, floatingWindow }).then(response => {
            this.$message({
              message: '成功！',
              type: 'success'
            });
            this.getList();
          });
        }
        if (this.visibleType === 0) {
          updateActivityListById({ id: addForm.id, addForm }).then(response => {
            this.$message({
              message: '成功！',
              type: 'success'
            });
            this.getList();
          });
        }
        // 增加活动文案
        if (this.visibleType === 3) {
          const act = [];
          const actContent = {};
          actContent.url = addForm.url;
          actContent.imageUrl = addForm.imageUrl;
          console.log(addForm.imageUrl);
          actContent.content = addForm.content;
          actContent.title = addForm.title;
          act.push(actContent);
          const activityContent = JSON.stringify(act);
          updateActivityListById({ id: addForm.id, activityContent }).then(response => {
            this.$message({
              message: '成功！',
              type: 'success'
            });
            this.getList();
          });
        }
        // 增加浮窗
        if (this.visibleType === 4) {
          const act = [];
          const actFloat = {};
          actFloat.url = addForm.url;
          actFloat.imageUrl = addForm.imageUrl;
          actFloat.title = addForm.title;
          act.push(actFloat);
          const floatingWindow = JSON.stringify(act);
          updateActivityListById({ id: addForm.id, floatingWindow }).then(response => {
            this.$message({
              message: '成功！',
              type: 'success'
            });
            this.getList();
          });
        }
        // 更新活动规则,文案
        if (this.visibleType === 5) {
          const act = [];
          const actContent = {};
          actContent.actQxbUrl = addForm.actQxbUrl;
          actContent.actCampusUrl = addForm.actCampusUrl;
          actContent.imageUrl = addForm.actImageUrl;
          act.push(actContent);
          const activityContent = JSON.stringify(act);
          // 更新文案
          updateActivityListById({ id: addForm.id, activityContent }).then(response => {
            this.$message({
              message: '成功！',
              type: 'success'
            });
            this.getList();
          });
          updateActivityListRoleById({ id: addForm.id, rule_content: addForm.rule_content }).then(response => {
            this.$message({
              message: '成功！',
              type: 'success'
            });
            this.getList();
          });
        }
        this.dialogFormVisible = false;
      },
      // 添加新的活动按钮
      add() {
        this.editingChoiceList = true;
        console.log(this.addForm);
        this.addForm.status = this.addForm.status.toString();
        this.addForm.join_condition = this.addForm.join_condition.toString();
        this.addForm.help_condition = this.addForm.help_condition.toString();
      },
      cancelAdd() {
        this.editingChoiceList = false;
      },
      // 创建一个活动
      confirmForm(addForm) {
        createActivity(addForm).then(response => {
          this.$message({
            message: '成功！',
            type: 'success'
          });
          this.getList();
          this.editingChoiceList = false;
        });
      },
      // 创建一个活动内容
      createActContent(addForm) {
        this.visibleType = 3;
        this.dialogFormTitle = '新增活动内容';
        this.addForm = addForm;
        this.addForm.title = '';
        this.dialogFormVisible = true;
      },
      // 创建一个活动内容
      createFloat(addForm) {
        this.visibleType = 4;
        this.dialogFormTitle = '新增浮窗';
        this.addForm = addForm;
        this.addForm.title = '';
        this.dialogFormVisible = true;
      },
      // 查看配置信息
      editRule(addForm) {
        this.visibleType = 5;
        this.dialogFormTitle = '查看配置信息';
        if (!addForm.activity_content) {
          const act = [];
          const actContent = {};
          addForm.actQxbUrl = 'http://web.quexiangbao.com/freebuy/index.html#/cutPrice/cutPriceSquare?activityId=' + addForm.id;
          addForm.actCampusUrl = 'http://groupbuy.quexc.com/freebuy/index.html#/cutPrice/cutPriceSquare?activityId=' + addForm.id;
          addForm.actImageUrl = '';
          act.push(actContent);
          addForm.activity_content = act;
        }
        this.addForm = addForm;
        console.log(addForm);
        this.dialogFormVisible = true;
      }
    }
  };
</script>

<style scoped>
    .container {
        width: 200px;
        height: 100px;
        margin: 20px auto;
        text-align: center;
        padding: 5px;
    }

    .container > img {
        max-width: 100%;
        max-height: 100%;
    }
</style>
