<template>
    <div class="app-container">
        <el-row>
            <el-col :span="24">
                <div class="header-title">版本选择</div>
            </el-col>
            <el-row>
                <el-col style="padding-bottom: 20px">
                    <el-button v-show="!editingChoiceList" type="primary" @click="add()" >添加新的版本</el-button>
                        <el-button type="primary" @click="confirmForm(addForm)" size="mini">创建</el-button>
                        <el-button type="info" @click="cancel" size="mini">取消</el-button>
                </el-col>
            </el-row>
            <!-- 表格 start -->
            <el-col :span="24">
                <el-table
                        :data="tableData"
                        border
                        style="width: 100%"
                        v-loading="loading">
                    <el-table-column
                            fixed
                            label="ID"
                            width="50">
                        <template slot-scope="scope">
                            <div>{{scope.row.id}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="投放平台"
                            width="180">
                        <template slot-scope="scope">
                            <div v-if="scope.row.client_id==0">雀享全平台</div>
                            <div v-else-if="scope.row.client_id==1">雀享Android</div>
                            <div v-else-if="scope.row.client_id==2">雀享iOS</div>
                            <div v-else-if="scope.row.client_id==3">雀享Web</div>
                            <div v-else-if="scope.row.client_id==4">校品全平台</div>
                            <div v-else-if="scope.row.client_id==5">校品Android</div>
                            <div v-else-if="scope.row.client_id==6">校品iOS</div>
                            <div v-else-if="scope.row.client_id==7">校品Web</div>
                            <div v-else-if="scope.row.client_id==11">雀享优品小程序</div>
                            <div v-else-if="scope.row.client_id==12">雀享优品web</div>
                            <div v-else>All</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="生效版本"
                            width="180">
                        <template slot-scope="scope">
                            <div>{{scope.row.start_version}} ~ {{scope.row.end_version}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="生效时间"
                            width="350">
                        <template slot-scope="scope">
                            <div>{{scope.row.start_time}} 至 {{scope.row.end_time}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="状态"
                            width="150">
                        <template slot-scope="scope">
                            <div v-if="scope.row.status===0">禁用</div>
                            <div v-if="scope.row.status===1">启用</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="权重"
                            width="150">
                        <template slot-scope="scope">
                            <div>{{scope.row.sort}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="操作"
                            width="300">
                        <template slot-scope="scope">
                            <el-button type="danger"
                                       @click="$router.push({name: 'bannerList',params: {client_id: scope.row.id}})"
                                       size="small">查看版本配置资源
                            </el-button>
                            <el-button type="primary" size="small" @click="editBannerButton(scope.row)">编辑</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
            <!-- 表格 end -->
            <!-- 弹层 start -->
            <el-col :span="24">
                <el-dialog :title="dialogFormTitle" :visible.sync="dialogFormVisible" width="300"
                           @close="cancelAddBanner">
                    <el-form :model="addForm" :rules="rules" ref="addForm">
                        <el-form-item label="ID" :label-width="formLabelWidth" prop="id">
                            <el-input :disabled="true" v-model="addForm.id" placeholder="ID" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="权重" :label-width="formLabelWidth" prop="sort">
                            <el-input v-model="addForm.sort" placeholder="权重" size="mini" clearable></el-input>
                        </el-form-item>
                        <el-form-item label="生效起始版本" :label-width="formLabelWidth" prop="start_version">
                            <el-input v-model="addForm.start_version" placeholder="生效起始版本" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="生效结束版本" :label-width="formLabelWidth" prop="end_version">
                            <el-input v-model="addForm.end_version" placeholder="生效结束版本" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="投放平台" :label-width="formLabelWidth" size="mini" prop="client_id">
                            <el-select v-model="addForm.client_id" placeholder="请投放平台">
                                <el-option label="雀享all" value="0"></el-option>
                                <el-option label="雀享android" value="1"></el-option>
                                <el-option label="雀享ios" value="2"></el-option>
                                <el-option label="校品all" value="4"></el-option>
                                <el-option label="校品android" value="5"></el-option>
                                <el-option label="校品ios" value="6"></el-option>
                                <el-option label="雀享优品小程序" value="11"></el-option>
                                <el-option label="雀享优品web" value="12"></el-option>
                                <el-option label="无" value=""></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="状态" :label-width="formLabelWidth" size="mini" prop="status">
                            <el-select v-model="addForm.status" placeholder="请设置状态">
                                <el-option label="禁用" value="0"></el-option>
                                <el-option label="启用" value="1"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="生效时间" class="time-width" :label-width="formLabelWidth" prop="start_time">
                            <el-date-picker
                                    v-model="selectTimes2"
                                    type="datetimerange"
                                    range-separator="至"
                                    start-placeholder="开始日期"
                                    end-placeholder="结束日期"
                                    align="right"
                                    size="mini"
                                    @change="selectTimeAfter">
                            </el-date-picker>
                        </el-form-item>
                    </el-form>
                    <div slot="footer" class="dialog-footer">
                        <el-button @click="cancelAddBanner('addForm')">取 消</el-button>
                        <el-button type="primary" @click="updateClient('addForm')">确 定</el-button>
                    </div>
                </el-dialog>
            </el-col>
            <!-- 弹层 end -->
            <!-- 分页 start -->
            <el-col :span="24">
                <div class="pagination" style="margin-top:20px;">
                    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                                   :current-page="formInline.pageNum" :page-sizes="[10, 20, 30, 40]"
                                   :page-size="formInline.pageSize" layout="total, sizes, prev, pager, next"
                                   :total="totalcount">
                    </el-pagination>
                </div>
            </el-col>
            <!-- 分页 end -->
        </el-row>
    </div>
</template>

<script>
  import {
    getActivityList,
  } from '@/api/proprietaryActivity';
  import {uploadImg} from '@/api/uploadImg';
  import {timestampToTime} from 'utils/chanageTime';

  export default {
    data() {
      return {
        totalcount: 0,
        loading: false,
        uploadImg: '',
        formInline: {
          pageNum: 1,
          pageSize: 10,
        },
        tableData: [],
        dialogFormVisible: false, // 弹层显示与否
        dialogFormTitle: '', // 弹层标题
        addForm: {
          id: '',
        },
        formLabelWidth: '120px',
        rules: {
          sort: [{ required: true, message: '请输入权重', trigger: 'blur' }],
        }
      };
    },
    created() {
      this.getList();
      this.uploadImg = uploadImg;
    },
    methods: {
      onSubmit() {
        // 筛选页面初始化
        this.formInline.pageNum = 1;
        this.formInline.pageSize = 10;
        this.getList();
      },
      addBannerButton() {
        this.dialogFormVisible = true;
        this.dialogFormTitle = '添加banner';
      },

      getList() {
        this.loading = true;
        // 请求列表
        getActivityList(this.formInline).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.tableData = res.data;
            this.totalcount = res.totalCount;
            // 整理数据
            for (const i in this.tableData) {
              const item = this.tableData[i];
              item.start_time = timestampToTime(item.start_time);
              item.end_time = timestampToTime(item.end_time);
            }
          }

          this.loading = false;
        });
      },
      selectTimeAfter() {
        const startDate = this.selectTimes2[0].getTime() / 1000;
        const endDate = this.selectTimes2[1].getTime() / 1000;
        this.addForm.start_time = startDate;
        this.addForm.end_time = endDate;
      },
      // 分页
      handleSizeChange(pageSize) {
        this.formInline.pageSize = pageSize;
        this.getList();
      },
      // 页码变化时触发
      handleCurrentChange(page) {
        this.formInline.pageNum = page;
        this.getList();
      }
    }
  };
</script>

<style scoped>

</style>
