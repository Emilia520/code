<template>
  <div class="app-container">
    <div class="header-title">活动列表</div>
    <akc-act-list ref="akcActList" :appType="appType">
    </akc-act-list>
  </div>
</template>

<script>
import AkcActList from '@/component/AiKuCun/activityList';

export default {
  components: { AkcActList },
  data() {
    return {
      appType: 2
    };
  },
  created() {
    // 筛选页面初始化
    // this.$refs.akcActList.getList();
  },
  methods: {

  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  
</style>
