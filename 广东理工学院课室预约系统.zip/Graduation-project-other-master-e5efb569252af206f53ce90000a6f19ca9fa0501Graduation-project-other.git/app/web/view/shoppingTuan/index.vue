<template>
    <div class="app-container">
        <el-tabs type="border-card" @tab-click="onTabClick">
            <el-tab-pane label="拼多多单品推广">
                <pdd-sku-list ref="pddSkuList" selBtnTitle="选 取" @onSelect="addPDDGoods">
                </pdd-sku-list>
            </el-tab-pane>
            <el-tab-pane label="淘宝单品推广">
                <tb-sku-list ref="tbSkuList" @onSelect="addTbGoods">
                </tb-sku-list>
            </el-tab-pane>
            <el-tab-pane label="淘宝热销高佣推广">
                <tb-hot-list ref="tbHotList" @onSelect="addTbGoods">
                </tb-hot-list>
            </el-tab-pane>
        </el-tabs>
        <div class="selection-bar">
            <span class="selected-count" v-on:click="showSelectionList()">已选取
            <strong class="selected-count-strong"> {{selectedData.length}}</strong>
                个商品
            </span>
            <span class="show-choice-list" v-on:click="choiceListPage">我的选品库</span>
            <span class="add-to-choice" v-on:click="choiceListPopBox">加入选品库</span>
            <div class="selection-list">
                <span :class="selectionVisible ? 'mask' : ''" @click="selectionVisible=false"></span>
                <div :class="selectionVisible ? 'show' : 'close'">
                    <div style="height: 60px; margin-bottom: 10px">
                        <el-button type="info" @click="deleteAllProducts" plain
                                   style="min-height: 60px; width: 100%; border: none;">
                            清空已选
                        </el-button>
                    </div>
                    <img src="../../icons/svg/userlist.svg" v-show="selectedData.length === 0"
                         style="margin-top:200px"/>
                    <el-row v-show="selectedData.length !== 0">
                        <el-col class="item-pic-container" v-for="item in selectedData">
                            <img class="item-pic" :src="item.pic_url"/>
                            <el-button class="item-delete" type="primary" icon="el-icon-close"
                                       @click="deleteProduct(item)" circle></el-button>
                        </el-col>
                    </el-row>
                </div>
            </div>
        </div>
        <el-dialog class='choice-list-popup' title="选择选品队列" :visible.sync="choiceListPopBoxVisible"
                   v-loading="loadingState" :show-close="false">
            <el-row>
                <el-col>
                    <el-button v-show="!editingChoiceList" size="mini" icon="el-icon-plus"
                               @click="prepareAddChoiceList">新建选品队列
                    </el-button>
                    <el-row v-show="editingChoiceList">
                        <el-input ref='listInput' :placeholder="defaultListName()" autofocus="true"
                                  style="max-width:250px; margin-right:10px"
                                  v-model="editingChoiceListName" size="mini" clearable></el-input>
                        <el-button type="primary" @click="onAddChoiceList" size="mini">创建</el-button>
                        <el-button type="info" @click="onCancelAddChoiceList" size="mini">取消</el-button>
                    </el-row>
                </el-col>
            </el-row>
            <div class="choice-list-container">
                <el-row v-for="choiceList in choiceListData">
                    <el-col :span="12"
                            :class="choiceListClass(choiceList)"
                            v-on:click.native="selectChoiceList(choiceList)">
                        <span> {{choiceList.list_name}}</span>
                        <span> 商品数量: {{Array.isArray(choiceList.item_list) ?choiceList.item_list.length : 0}}</span>
                    </el-col>
                </el-row>
            </div>
            <el-form class="btn-container" :inline="true" align="center">
                <el-form-item>
                    <el-button type="primary" size="mini" style="min-width: 120px; min-height:32px"
                               :disabled="!selectedChoice" @click="addToChoiceList">加入
                    </el-button>
                </el-form-item>
                <el-form-item>
                    <el-button type="info" size="mini" style="min-width: 120px; margin-left: 20px; min-height: 32px;"
                               @click="hideChoiceListPopBox">取消
                    </el-button>
                </el-form-item>
            </el-form>
        </el-dialog>
        <el-dialog class="add-success-popup" :visible.sync="addSuccessPopBoxVisible" width="30%" :show-close="false">
            <div class="success-popup-icon"><i class="el-icon-success"></i></div>
            <div class="success-popup-text">添加成功</div>
            <el-form :inline="true" align="center" style="margin-top: 20px">
                <el-form-item>
                    <el-button type="primary" size="medium" style="min-width: 150px; min-height: 36px" @click="choiceListPage()">查看选品库</el-button>
                </el-form-item>
                <el-form-item style="margin-left: 20px">
                    <el-button type="info" size="medium" @click="addSuccessPopBoxVisible = false"
                               style="min-width: 150px; min-height: 36px; background-color: rgba(32,32,64,.08); color: #333; border: none">
                        继续选品
                    </el-button>
                </el-form-item>
            </el-form>
        </el-dialog>
    </div>
</template>

<script>
  import RangeSelector from '@/component/RangeSelector';
  import PddSkuList from '@/component/Pdd/SkuList';
  import TbSkuList from '@/component/Taobao/SkuList';
  import TbHotList from '@/component/Taobao/HotSaleList';
  import { dateFtt } from '../../framework/utils/utils';
  import { addChoiceList } from '../../api/choiceList';
  import { choiceList } from '../../api/choiceList';
  import { addToChoiceList } from '../../api/choiceList';

  const Constant = require('../../../utils/constant.js');

  export default {
    components: { RangeSelector, PddSkuList, TbSkuList, TbHotList },
    name: 'index',
    data() {
      return {
        choiceListPopBoxVisible: false, // 选品队列弹窗是否可见
        addSuccessPopBoxVisible: false, // 是否显示加入选品库成功的弹窗
        selectionVisible: false, // 是否显示当前选择的产品列表
        editingChoiceList: false, // 是否正在编辑新选品队列信息
        editingChoiceListName: null, // 正在编辑新选品队列名称
        loadingState: false, // 是否正从数据库读取选品列表

        selectedData: [], // 当前选择商品
        choiceListData: [], // 选品列表
        selectedChoice: null, // 当前选中的选品列表
      };
    },
    mounted() {
      this.$refs.pddSkuList.didPresent();
    },
    methods: {
      onTabClick(val) {
        if (val.index === '0') {
          this.$refs.pddSkuList.didPresent();
        } else if (val.index === '1') {
          this.$refs.tbSkuList.didPresent(1);
        } else if (val.index === '2') {
          this.$refs.tbHotList.didPresent();
        }
      },

      /**
       * 选取一个淘宝商品，将其转换为选品列表实际能识别的数据
       */
      addTbGoods(tbProduct) {
        let repeated = false;
        this.selectedData.some(function(item) {
          return (repeated = (item.item_id === tbProduct.num_iid && item.item_platform === Constant.platform.TB));
        });

        if (repeated) {
          this.$message({ type: 'error', message: '该商品已经选取' });
          return;
        }

        const choiceItem = {};
        choiceItem.item_id = tbProduct.num_iid;
        choiceItem.pic_url = tbProduct.pict_url;
        choiceItem.item_platform = Constant.platform.TB;
        choiceItem.item_sort = this.selectedData.length;
        choiceItem.item_detail = tbProduct;

        this.selectedData.push(choiceItem);
      },

      /**
       * 选取一个拼多多商品
       */
      addPDDGoods(pddProduct) {
        let repeated = false;
        this.selectedData.some(function(item) {
          return (repeated = (item.item_id === pddProduct.goods_id && item.item_platform === Constant.platform.PDD));
        });

        if (repeated) {
          this.$message({ type: 'error', message: '该商品已经选取' });
          return;
        }

        const choiceItem = {};
        choiceItem.item_id = pddProduct.goods_id;
        choiceItem.pic_url = pddProduct.goods_thumbnail_url;
        choiceItem.item_platform = Constant.platform.PDD;
        choiceItem.item_sort = this.selectedData.length;
        choiceItem.item_detail = pddProduct;

        this.selectedData.push(choiceItem);
      },

      /**
       * 显示用户当前的全部选品列表
       */
      choiceListPage() {
        this.$router.push({
          path: '/choiceListOpt',
          name: 'choiceListOpt',
        });
      },

      /**
       * 在当前页面显示选品列表队列弹窗，供用户选择选品列表或创建选品列表
       */
      choiceListPopBox() {
        if (this.selectedData.length === 0) {
          this.$message({ type: 'info', message: '请选择商品' });
          return;
        }

        if (this.choiceListPopBoxVisible) {
          return;
        }

        this.loadingState = true;
        this.selectionVisible = false;

        choiceList(null).then(res => {
          this.choiceListData = res.data.code === 10000 ? res.data.data : [];
          this.selectedChoice = this.choiceListData.length !== 0 ? this.choiceListData[0] : null;
          this.loadingState = false;
          this.choiceListPopBoxVisible = true;
        });
      },

      hideChoiceListPopBox() {
        this.choiceListPopBoxVisible = false;
      },

      prepareAddChoiceList() {
        this.editingChoiceList = true;
      },

      defaultListName() {
        return `创建于 ${dateFtt('yyyy-MM-dd hh:mm:ss', new Date())}`;
      },

      onAddChoiceList() {
        const listName = this.editingChoiceListName || this.defaultListName();

        addChoiceList(listName).then(res => {
          if (res.data.code === 10000) {
            this.choiceListData.unshift({ choice_list_id: res.data.data.insert_id, list_name: listName });
            this.editingChoiceListName = null;
            this.editingChoiceList = false;
            this.selectedChoice = this.choiceListData[0];
          } else {
            this.$message({ type: 'error', message: res.data.msg || '添加选品列表失败' });
          }
        });
      },

      onCancelAddChoiceList() {
        this.editingChoiceList = false;
        this.editingChoiceListName = null;
      },

      /**
       * 用户在弹窗中选择了某个选品列表
       */
      selectChoiceList(choiceList) {
        this.selectedChoice = choiceList;
      },

      /**
       * 用户在选品列表弹窗中确认添加当前产品到列表中
       */
      addToChoiceList() {
        if (this.selectedChoice === null) {
          throw 'Select nothing to confirm';
        }

        let sort = 0;
        const itemList = this.selectedChoice.item_list;

        if (Array.isArray(itemList) && itemList.length !== 0) {
          sort = itemList[itemList.length - 1].item_sort;
        }

        // 任何时候都需要重排，避免用户多次选择不同的状态的选品队列
        this.selectedData.forEach(function(item) {
          item.item_sort = ++sort;
        });

        addToChoiceList(this.selectedChoice, this.selectedData, Constant.choiceListItemOpt.ADD).then(res => {
          if (res.data.code !== 10000) {
            this.$message({ type: 'error', message: res.data.msg || '加入选品库失败' });
            return;
          }

          // 修改当前选中选品列表的商品队列
          this.selectedChoice.item_list = Array.isArray(this.selectedChoice.item_list) ? this.selectedChoice.item_list.concat(this.selectedData) : this.selectedData;

          // 清空商品队列，显示新的弹窗
          this.selectedData = [];
          this.choiceListPopBoxVisible = false;
          this.addSuccessPopBoxVisible = true;
        });
      },

      /**
       * 返回选品列表弹窗卡片的class，用来决定选中列表的样式高亮
       * @param choiceList 卡片对应的选品列表
       * @returns {string} class 名称
       */
      choiceListClass(choiceList) {
        return this.selectedChoice !== null && this.selectedChoice.choice_list_id === choiceList.choice_list_id ? 'choice-list-selected' : 'choice-list';
      },

      showSelectionList() {
        this.selectionVisible = !this.selectionVisible;
      },

      deleteProduct(item) {
        const index = this.selectedData.findIndex(listItem => {
          return item.item_id === listItem.item_id && item.item_platform === listItem.item_platform;
        });

        if (index >= 0 && index < this.selectedData.length) {
          this.selectedData.splice(index, 1);
        }
      },

      deleteAllProducts() {
        this.selectedData = [];
      }
    }
  };
</script>

<style lang="scss" scoped>
    .app-container {
        margin-bottom: 70px;
    }

    .selection-bar {
        background-color: white;
        z-index: 10002;
        box-shadow: 0 -1px 3px 0 rgba(32, 32, 64, .04);
        border: 1px solid #E2E2E9;
        position: fixed;
        right: 0;
        left: 0;
        bottom: 0;
        height: 60px;
        text-align: center;
    }

    .selected-count, .show-choice-list, .add-to-choice, .choice-list-popup {
        font-family: "Microsoft YaHei", "微软雅黑", STXihei, "华文细黑", Georgia, "Times New Roman", Arial, sans-serif;
        font-size: 16px;
        color: #666666;
    }

    .selected-count {
        vertical-align: center;
        line-height: 60px;
    }

    .selected-count-strong {
        color: #409EFF;
    }

    .add-to-choice, .show-choice-list {
        float: right;
        line-height: 60px;
        padding: 0 40px;
        text-align: center;
    }

    .add-to-choice {
        background-color: #EDEDF0;
    }

    .add-to-choice:hover {
        color: #409EFF;
        background-color: #DADADA;
    }

    .show-choice-list {
        background-color: #409EFF;
        color: white;
    }

    .choice-list-container {
        background-color: #FAFAFA;
        overflow: scroll;
        max-height: 203px;
        margin-top: 20px;
        padding: 10px;
    }

    .choice-list, .choice-list-selected {
        padding: 10px;
        font-size: 12px;
        line-height: 61px;
        max-height: 81px;
        min-width: 50%;
    }

    .choice-list:hover {
        color: #409EFF;
        background-color: #EBEBEB;
    }

    .choice-list-selected {
        background-color: #409EFF;
        color: white;
    }

    .btn-container {
        padding: 10px 0;
        max-height: 30px;
    }

    .success-popup-icon {
        text-align: center;
        font-size: 48px;
        color: #409EFF;
        display: block;
    }

    .success-popup-text {
        text-align: center;
        font-size: 14px;
        color: #409EFF;
        margin-top: 10px;
    }

    .selection-list {
        width: 100%;
        z-index: 10001;
        .mask {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 60px;
            width: 100%;
            background-color: black;
            opacity: .3;
            display: block;
        }
        .show {
            position: absolute;
            bottom: 59px;
            height: 400px;
            width: 100%;
            overflow: hidden;
            transition: height .3s ease-out;
            background-color: #EEEEEE;
        }
        .close {
            position: absolute;
            width: 100%;
            height: 0;
            bottom: 59px;
            overflow: hidden;
            transition: height .3s ease-out;
            background-color: #EEEEEE;
        }
    }

    .item-pic-container {
        width: 140px;
        height: 140px;
        padding: 10px;
        align-items: center;

        .item-pic {
            width: 90%;
            height: 90%;
            object-fit: contain;
        }

        .item-delete {
            position: relative;
            width: 24px;
            height: 24px;
            bottom: 116px;
            left: 56px;
            background-color: rgba(0, 0, 0, .4);
            border: none;
            padding: 0;
            visibility: hidden;
        }
    }

    .item-pic-container:hover {
        .item-pic {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        }

        .item-delete {
            visibility: visible;
        }
    }

</style>