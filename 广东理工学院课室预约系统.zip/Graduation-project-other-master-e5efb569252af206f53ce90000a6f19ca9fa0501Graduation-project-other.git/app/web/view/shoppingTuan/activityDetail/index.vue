<template>
  <div class="app-container">
    <el-row>
      <el-col :span="24">
        <div class="header-title">
          <div style="display:inline-block;width:15px;height:15px;margin-right:10px;cursor:pointer" @click="$router.back()">
            <svg-icon icon-class="back" />
          </div>
          <span>商品列表</span>
        </div>
      </el-col>
      <!-- 表格 start -->
      <el-col :span="24">
          <akc-goods-list ref="goodsList" :appType="$route.params.appType">
          </akc-goods-list>
      </el-col>
      <!-- 表格 end -->

      <!-- 弹层 start -->
      <!-- <el-col :span="24">
        <el-dialog :title="dialogFormTitle" :visible.sync="dialogFormVisible" width="300" @close="cancelForm">
          <el-form :model="addForm" :rules="rules" ref="addForm">
            <el-form-item label="ID" :label-width="formLabelWidth" prop="id">
              <el-input :disabled="true" v-model="addForm.id" placeholder="ID" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="活动名称" :label-width="formLabelWidth" prop="name">
              <el-input :disabled="true" v-model="addForm.name" placeholder="活动名称" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="权重" :label-width="formLabelWidth" prop="sort">
              <el-input v-model.number="addForm.sort" placeholder="权重" size="mini" clearable></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="cancelForm('addForm')">取 消</el-button>
            <el-button type="primary" @click="confirmForm('addForm')">确 定</el-button>
          </div>
        </el-dialog>
      </el-col> -->
      <!-- 弹层 end -->
    </el-row>
  </div>
</template>

<script>
import AkcGoodsList from '@/component/AiKuCun/goodsList';

export default {
  components: { AkcGoodsList },
  data() {
    return {

    };
  },
  mounted() {
    this.$refs.goodsList.didPresent(this.$route.params.id);
  },
  methods: {

  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  
</style>
