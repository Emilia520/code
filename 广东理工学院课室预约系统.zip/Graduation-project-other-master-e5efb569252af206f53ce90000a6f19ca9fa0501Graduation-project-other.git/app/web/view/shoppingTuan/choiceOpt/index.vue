<template xmlns:v-on="http://www.w3.org/1999/xhtml">
    <akc-choice-opt ref="choiceOpt" :appType="appType">
    </akc-choice-opt>
</template>

<script>
    import AkcChoiceOpt from '@/component/AiKuCun/choiceOpt';

    export default {
      components: { AkcChoiceOpt },
      data() {
        return {
          appType: 2
        };
      },
      created() {

      },
      methods: {
    
      }
    };
</script>

<style lang="scss" scoped>

</style>