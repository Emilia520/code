<template>
    <div class="app-container">   
        <!-- 新增298商品 -->
        <el-row class="main_button">
            <el-button type="primary" class="button_on" @click="dialogFormVisible = true" >新增298团长礼包商品</el-button>
        </el-row>
        <el-dialog title="新增298商品" :visible.sync="dialogFormVisible">
            <el-form :model="captainPackage" :rules="rules"  label-width="180px" label-position="left" size="mini">
                <el-form-item label="活动名称" prop="act_name" >
                    <el-input :disabled="true" v-model="captainPackage.act_name" placeholder="【开团大礼包】精选全球超值好货，助你躺赚更欢乐" maxlength="50" clearable  />
                </el-form-item>
                <el-form-item label="活动描述" prop="act_description" >
                    <el-input :disabled="true" type="textarea"  placeholder="精选全球超值好货，更有团长超值权益，万元机器人加超高佣金，让你在享受好货的同时实现躺赚收益" v-model="captainPackage.act_description" maxlength="255" clearable :show-word-limit="true" />
                </el-form-item>
                <el-form-item label="商品名" prop="goods_name" >
                    <el-input  placeholder="商品名" v-model="captainPackage.goods_name" maxlength="50" clearable />
                </el-form-item>
                <el-form-item label="商品描述" prop="goods_description" >
                    <el-input type="textarea" placeholder="商品描述" v-model="captainPackage.goods_description" maxlength="255" clearable :show-word-limit="true" />
                </el-form-item>
                <el-form-item label="供应商名" prop="supplier_name" >
                    <el-autocomplete v-model="captainPackage.supplier_name" :fetch-suggestions="querySearch" placeholder="请输入内容" @select="handleSelect">
                        <template slot-scope="{ item }">
                            <div class="name">{{ item.value }}</div>
                        </template>
                    </el-autocomplete>
                </el-form-item>
                <el-form-item label="供应商商品ID" prop="supplier_goods_id" >
                    <el-input  placeholder="供应商商品ID" v-model="captainPackage.supplier_goods_id" maxlength="100" clearable />
                </el-form-item>
                <el-form-item label="供应商商品名" prop="supplier_goods_name" >
                    <el-input  placeholder="供应商商品名" v-model="captainPackage.supplier_goods_name" maxlength="100" clearable />
                </el-form-item>
                <el-form-item label="产品颜色描述" prop="color" >
                    <el-input  placeholder="产品颜色描述" v-model="captainPackage.color" maxlength="100" clearable />
                </el-form-item>
                <el-form-item label="产品规格描述" prop="size" >
                    <el-input  placeholder="产品规格描述" v-model="captainPackage.size" maxlength="100" clearable />
                </el-form-item>
                <el-form-item label="自动下单" prop="auto_buy" >
                    <el-select v-model="captainPackage.auto_buy" @change="checkPackageAuto" placeholder="仅限爱库存商品">
                        <el-option label="自动" value="1" />
                        <el-option label="手动" value="0" />
                    </el-select>
                </el-form-item>
                <el-form-item label="【自动下单】商品ID" prop="akc_group_buy_goods_id" >
                    <el-input :disabled="hideAutoByCaptain" placeholder="商品ID" v-model="captainPackage.akc_group_buy_goods_id" maxlength="20" clearable />
                </el-form-item>
                <el-form-item label="【自动下单】商品数量" prop="product_num" >
                    <el-input :disabled="hideAutoByCaptain" placeholder="一个礼包中的该商品数量" v-model="captainPackage.product_num" maxlength="2" clearable />
                </el-form-item>
                <el-form-item label="298库存" prop="stock" >
                    <el-input  placeholder="298库存" v-model="captainPackage.stock" maxlength="5" clearable />
                </el-form-item>
                <el-form-item label="上传详情页横划图片">
                    <el-upload class="avatar-uploader" action="https://xttapi.lexj.com/helper/uploadCdn" list-type="picture-card" :on-success="handleUpCaptain_1ImgSuccess" >
                        <i slot="default" class="el-icon-plus" />                    
                        <div slot="file" slot-scope="{file}">
                            <img class="el-upload-list__item-thumbnail" :src="file.url" alt="">
                            <span class="el-upload-list__item-actions">
                                <span class="el-upload-list__item-delete" @click="handleRemoveCaptain_1Img(file)">
                                    <i class="el-icon-delete"></i>
                                </span>
                            </span>
                        </div>
                    </el-upload> 
                </el-form-item>
                <el-form-item label="上传详情页竖划图片">
                    <el-upload class="avatar-uploader" action="https://xttapi.lexj.com/helper/uploadCdn" list-type="picture-card" :on-success="handleUpCaptain_2ImgSuccess"  >
                        <i slot="default" class="el-icon-plus" />                    
                        <div slot="file" slot-scope="{file}">  
                            <img class="el-upload-list__item-thumbnail" :src="file.url" alt="">              
                            <span @click="handleRemoveCaptain_2Img(file)">
                                <i class="el-icon-delete"></i>
                            </span>
                        </div>
                    </el-upload> 
                </el-form-item>
                <el-form-item label="上传298卡片图">
                    <el-upload class="avatar-uploader" action="https://xttapi.lexj.com/helper/uploadCdn" list-type="picture-card" :on-success="handleUpCaptain_3ImgSuccess" :limit="1" :on-exceed="exceedLimitFileNum" >
                        <i slot="default" class="el-icon-plus" />                    
                        <div slot="file" slot-scope="{file}"> 
                            <img class="el-upload-list__item-thumbnail" :src="file.url" alt="">               
                            <span @click="handleRemoveCaptain_3Img(file)">
                                <i class="el-icon-delete"></i>
                            </span>
                        </div>
                    </el-upload> 
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="createCaptainPackageConfirm">立即创建</el-button>
                </el-form-item>
            </el-form>
        </el-dialog>
        
        <!-- 上下架商品查询，下架商品不能重新上架，涉及到商品的自动下单 -->
        <template>
            <div class="radioGroup">
                <el-radio-group v-model="radio_status" @change="radioStatusChange">
                    <el-radio-button label=1>上架</el-radio-button>
                    <el-radio-button label=0>下架</el-radio-button>
                </el-radio-group>
            </div>
        </template>
        
        <el-table class="table_list" :data="tableData" stripe border >
            <el-table-column prop="id" fixed label="产品ID" width="100px"/>
            <el-table-column prop="name" label="名字" width="300px"/>
            <el-table-column prop="type" label="商品类型" width="80px"/>
            <el-table-column prop="original_price" label="原价" width="50px"/>
            <el-table-column prop="price" label="售价" width="50px"/>
            <el-table-column label="自动下单" width="100px">
                <el-table-column prop="detail.goods_id" label="商品ID" width="80px"/>
                <el-table-column prop="detail.goods_num" label="商品数量" width="50px"/>
                <el-table-column prop="detail.order_type" label="订单类型" width="80px"/>
                <el-table-column prop="detail.sku_info" label="规格类型" width="200px"/>                
            </el-table-column>
            <el-table-column  label="卡片图" width="100px">
                <template slot-scope="scope">
                    <div><img :src="scope.row.image_url" height="50" width="50" lazy=true ></div>
                </template>
            </el-table-column>
            <el-table-column prop="postage" label="邮费" width="50px"/>
            <el-table-column prop="stock" label="建议库存" width="80px"/>
            <el-table-column prop="status" label="下架" width="80px">
                <template slot-scope="scope">
                     <el-button type="danger" @click="upStatus(scope.row.id)" icon="el-icon-delete" circle :disabled="!up_status_show" />
                </template>
            </el-table-column>
            <el-table-column label="编辑" width="80px">
                <template slot-scope="scope">
                    <el-button type="primary" @click="editProduct(scope.row)" icon="el-icon-edit" circle :disabled="!up_status_show" />
                </template>
            </el-table-column>
        </el-table>

        <el-dialog title="编辑298商品" :visible.sync="hideEditProduct">
            <el-form :model="editProductParam">
                <!-- <div>{{editProductParam}}</div> -->
                <el-form-item label="产品ID" prop="id" >
                    <el-input :disabled="true" v-model="editProductParam.id" maxlength="50" clearable  />
                </el-form-item>
                <el-form-item label="产品名字" prop="name" >
                    <el-input v-model="editProductParam.name" maxlength="100" clearable  />
                </el-form-item>
                <el-form-item label="排序[越小越靠前]" prop="sort" >
                    <el-input v-model="editProductParam.sort" maxlength="100" clearable  />
                </el-form-item>
                <el-form-item label="产品图片" prop="image_url" size="mini">
                    <el-upload action="https://xttapi.lexj.com/helper/uploadCdn" :show-file-list="false" :on-success="handleUpCaptain_4ImgSuccess" :list-type="editProductParam.image_url ? '' : 'picture-card'">
                        <div class="container">
                            <img v-if="editProductParam.image_url" :src="editProductParam.image_url" class="avatar" alt="">
                            <i v-else class="el-icon-plus"></i>
                        </div>
                    </el-upload>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="updateCaptainPackage(editProductParam)">立即修改</el-button>
                </el-form-item>
            </el-form>
        </el-dialog>

        <div class="page-on">
        <el-pagination :hide-on-single-page="false" @current-change="currentChange" background :total="pageTotal" :page-size="pageNum" layout="prev, pager, next" />
        </div>

    </div>
</template>

<script>
import { uploadImg } from '@/api/uploadImg';
import { createCaptainGoods, listCaptainGoods, updateCaptainGoods } from '@/api/groupbuy';

export default {
  data() {
    return {
      editProductParam: {},
      hideEditProduct: false,
      hideCreateCaptainPackageConfirm: true,
      hideAutoByCaptain: true,
      state: '',
      timeout: null,
      restaurants: [],
      dialogFormVisible: false,
      up_status_show: true,
      radio_status: 1,
      page: 1,
      pageSize: 10,
      pageNum: 0,
      pageTotal: 0,
      status: 1,
      uploadImg,
      actTimeRange: '',
      captainPackage: {
        act_name: '',
        act_description: '',
        act_start_time: 0,
        act_end_time: 0,
        goods_name: '',
        goods_description: '',
        picture: [],
        detail_pic: [],
        supplier_name: '',
        supplier_goods_id: '',
        supplier_goods_name: '',
        color: '',
        size: '',
        auto_buy: null,
        akc_group_buy_goods_id: null,
        product_num: 0,
        stock: 0,
        card_pic: []
      },

      tableData: [],
      rules: {
        act_name: [
          { required: true, message: '请输入活动名称', trigger: 'blur' },
          { min: 1, max: 50, message: '长度在 1 到 50 个字符', trigger: 'blur' }
        ],
        act_description: [
          { required: true, message: '请输入活动描述', trigger: 'blur' },
          { min: 1, max: 255, message: '长度在 1 到 255 个字符', trigger: 'blur' }
        ],
        goods_name: [
          { required: true, message: '请输入商品名称', trigger: 'blur' },
          { min: 1, max: 50, message: '长度在 1 到 50 个字符', trigger: 'blur' }
        ],
        goods_description: [
          { required: true, message: '请输入商品描述', trigger: 'blur' },
          { min: 1, max: 255, message: '长度在 1 到 255 个字符', trigger: 'blur' }
        ],

        supplier_name: [
          { required: true, message: '请输入供应商名', trigger: 'blur' },
          { min: 1, max: 100, message: '长度在 1 到 100 个字符', trigger: 'blur' }
        ],
        supplier_goods_id: [
          { required: true, message: '请输入供应商商品ID', trigger: 'blur' },
          { min: 1, max: 100, message: '长度在 1 到 100 个字符', trigger: 'blur' }
        ],
        supplier_goods_name: [
          { required: true, message: '请输入供应商商品名', trigger: 'blur' },
          { min: 1, max: 100, message: '长度在 1 到 100 个字符', trigger: 'blur' }
        ],
        color: [
          { required: true, message: '请输入颜色', trigger: 'blur' },
          { min: 1, max: 100, message: '长度在 1 到 100 个字符', trigger: 'blur' }
        ],
        size: [
          { required: true, message: '请输入规格', trigger: 'blur' },
          { min: 1, max: 100, message: '长度在 1 到 100 个字符', trigger: 'blur' }
        ],
        auto_buy: [
          { required: true, message: '请选择是否自动下单', trigger: 'blur' },
        ],
        akc_group_buy_goods_id: [],
        product_num: [],
        stock: [
          { required: true, message: '请输入库存', trigger: 'blur' },
          { min: 1, max: 5, message: '库存有误', trigger: 'blur' }
        ],
        card_pic: []
      }
    };
  },
  created() {
    this.initPage();
  },
  methods: {
    initPage() {
      this.pageNum = this.pageSize;
      this.listGoods({ status: this.status, pageNum: this.page, pageSize: this.pageSize });
      this.restaurants = this.loadAll();
    },
    editProduct(params) {
      this.hideEditProduct = true;
      this.editProductParam = params;
    },
    checkPackageAuto(value) {
      const temp = Number(value);
      this.hideAutoByCaptain = !(temp === 1);
      this.captainPackage.akc_group_buy_goods_id = null;
      this.captainPackage.product_num = null;
    },
    querySearch(queryString, cb) {
      const restaurants = this.restaurants;
      const results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants;
      // 调用 callback 返回建议列表的数据
      cb(results);
    },
    createFilter(queryString) {
      return (restaurant) => {
        return (restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
      };
    },
    handleSelect(item) {
    },
    handleIconClick(ev) {
    },
    loadAll() {
      return [
        { value: '爱库存' },
        { value: '好衣库' }
      ];
    },
    upStatus(param) {
      const paramUpdate = {
        id: Number(param),
        type: 5,
        status: 0
      };
      updateCaptainGoods(paramUpdate).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.$message({
            message: '操作成功',
            type: 'success'
          });
          this.listGoods({ status: this.status, pageNum: this.page, pageSize: this.pageSize });
        } else {
          this.$message({
            message: res.msg,
            type: 'fail'
          });
        }

      });

    },
    radioStatusChange(label) {
      this.status = label;
      this.up_status_show = Number(this.status) === 1;
      this.page = 1;
      this.pageSize = 10;
      this.listGoods({ status: this.status, pageNum: this.page, pageSize: this.pageSize });
    },
    currentChange(val) {
      this.page = val < 1 ? 1 : val > this.pageTotal ? this.pageTotal : val;
      this.listGoods({ status: this.status, pageNum: this.page, pageSize: this.pageSize });
    },
    listGoods(params) {
      listCaptainGoods(params).then(response => {
        const tableData = response.data.data;
        const arr = [];
        this.pageTotal = tableData.rowNum;
        for (const iterator of tableData.resultList) {
          let detail_info = null;
          if (iterator.detail) {
            const detail = JSON.parse(iterator.detail);
            detail_info = {
              goods_id: detail.productId,
              goods_num: detail.productNum,
              order_type: detail.orderType,
              sku_info: detail.skuId
            };
          } else {
            detail_info = {
              sku_info: '非自动下单'
            };
          }
          iterator.detail = detail_info;
          arr.push(iterator);
        }
        this.tableData = arr;
      })
      ;
    },
    updateCaptainPackage(params) {
      console.log(JSON.stringify(params));
      updateCaptainGoods(params).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.$message({
            message: '操作成功',
            type: 'success'
          });
          this.listGoods({ status: this.status, pageNum: this.page, pageSize: this.pageSize });
        } else {
          this.$message({
            message: res.msg,
            type: 'fail'
          });
        }

      });
    },

    createCaptainPackageConfirm() {
      this.$prompt('请输入“yes,i do”', '警告：确认后，商品立即上架', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        inputRule: 'yes,i do',
        inputErrorMessage: '验证字符输入不正确' }).then(({ value }) => {
        this.createCaptainPackage(this.captainPackage);
        this.$message({
          type: 'success',
          message: '298的商品创建成功: '
        });
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '取消'
        });
      });
      this.initPage();
    },
    createCaptainPackage(msg) {
      msg.act_start_time = 0;
      msg.act_end_time = 0;
      msg.status = 1;
      msg.act_name = '【开团大礼包】精选全球超值好货，助你躺赚更欢乐';
      msg.act_description = '精选全球超值好货，更有团长超值权益，万元机器人加超高佣金，让你在享受好货的同时实现躺赚收益';
      if (msg.goods_name && msg.goods_description && msg.picture && msg.supplier_name && msg.supplier_goods_id && msg.supplier_goods_name &&
            msg.color && msg.size && (typeof undefined === msg.auto_buy) && msg.stock && msg.card_pic) {
        alert('参数设置不全，请检查');
      } else {
        createCaptainGoods(msg).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.$message({
              message: '操作成功',
              type: 'success'
            });
          } else {
            this.$message({
              message: res.msg,
              type: 'fail'
            });
          }
        });
      }
    },
    handleUpCaptain_1ImgSuccess(res, file, fileList) {
      this.captainPackage.picture.push(res.data);
    },
    handleRemoveCaptain_1Img(file, fileList) {
      const removePic = file.response.data;
      const index = this.captainPackage.picture.indexOf(removePic);
      if (index !== -1) {
        this.captainPackage.picture.splice(index);
      }
    },

    handleUpCaptain_2ImgSuccess(res, file, fileList) {
      if (typeof undefined === this.captainPackage.detail_pic || this.captainPackage.detail_pic === null) {
        this.captainPackage.detail_pic = [];
      }
      this.captainPackage.detail_pic.push(res.data);
    },
    handleRemoveCaptain_2Img(file, fileList) {
      const removePic = file.response.data;
      const index = this.captainPackage.detail_pic.indexOf(removePic);
      if (index !== -1) {
        this.captainPackage.detail_pic.splice(index);
      }
    },

    handleUpCaptain_3ImgSuccess(res, file, fileList) {
      this.captainPackage.card_pic = res.data;
    },
    handleUpCaptain_4ImgSuccess(res, file, fileList) {
      this.editProductParam.image_url = res.data;
    },
    handleRemoveCaptain_3Img(file, fileList) {
      const removePic = file.response.data;
      const index = this.captainPackage.card_pic.indexOf(removePic);
      if (index !== -1) {
        this.captainPackage.card_pic.splice(index);
      }
    },
    exceedLimitFileNum() {
      alert('超出上传文件数量');
    }
  }
};
</script>
    
<style lang="scss" scoped >
    .app-container {
        font-family: "Microsoft YaHei", "微软雅黑", STXihei, "华文细黑", Georgia, "Times New Roman", Arial, sans-serif;
       
        .main_button {
            margin:10px 5px 20px 5px;
            .button_on {
                box-shadow: 0 4px 4px rgba(0, 0, 0, .12), 0 0 11px rgba(0, 0, 0, .04)
            }
        }

        .radioGroup{
            margin-left:5px;
            margin-bottom: 10px;
        }

        .el-table .warning-row {
            background: oldlace;
        }

        .el-table .success-row {
            background: #f0f9eb;
        }

        .table_list{
            margin-left:5px;
        }
        
    }
</style>
