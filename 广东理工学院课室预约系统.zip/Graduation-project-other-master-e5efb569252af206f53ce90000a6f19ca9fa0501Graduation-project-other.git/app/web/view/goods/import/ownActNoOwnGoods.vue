<template>
    <div class="app-container">        
        <!-- 新增自营活动 -->
        <el-row class="main_button">
            <el-button type="primary" class="button_on" @click="dialogFormVisible = true" >新增自营活动</el-button>
        </el-row>
        <!-- 已有的自营活动列表 -->
        <el-table style="margin-top:20px; width: 100%" class="table_list" :data="tableData" stripe border fit >
            <el-table-column prop="id" fixed label="ID" width="100px"/>
            <el-table-column prop="name" fixed label="名称" width="100px"/>            
            <el-table-column prop="description" label="描述" width="300px"/>
            <el-table-column prop="start_time_str" label="开始时间" width="180px"/>
            <el-table-column prop="end_time_str" label="结束时间" width="180px"/>
            <el-table-column prop="min_discount" label="最低折扣" width="100px"/>
            <el-table-column prop="goods_num"  label="商品的数量" width="100px"/>      
            <el-table-column prop="qxb_status_str" label="上下架" width="100px"/> 
            <el-table-column label="上下架" width="80px">
                <template slot-scope="scope">
                    <el-button type="warning" @click="upStatus(scope.row)" icon="el-icon-refresh" circle   />
                </template>
            </el-table-column>
            <el-table-column prop="selected_nice_img" label="精选图片" width="100px" >  
                <template slot-scope="scope">
                    <div><img :src="scope.row.selected_nice_img" height="50" width="50" lazy=true ></div>
                </template>
            </el-table-column>
            <el-table-column prop="wx_mini_program_show_str" label="微信展示" width="100px"/>   
            <el-table-column label="编辑活动" width="80px">
                <template slot-scope="scope">
                    <el-button type="primary" @click="editProduct(scope.row)" icon="el-icon-edit" circle />
                </template>
            </el-table-column>
            <el-table-column label="添加商品" width="80px">
                <template slot-scope="scope">
                    <el-button type="success" @click="addGoods(scope.row)" icon="el-icon-plus" circle />
                </template>
            </el-table-column>
            <el-table-column label="活动商品列表" width="80px">
                <template slot-scope="scope">
                    <el-button type="success" @click="listGoodsInfo(scope.row)" icon="el-icon-s-unfold" circle />
                </template>
            </el-table-column>
        </el-table>
        <!-- 页码设置 -->
        <div class="page-on">
            <el-pagination :hide-on-single-page="false" @current-change="currentChange" background :total="pageTotal" :page-size="pageNum" layout="prev, pager, next" />
        </div>
        <!-- 活动商品列表 -->
        <el-dialog title="活动商品列表" :visible.sync="showActGoodsList">
            <el-table border :data="ownActGoods">
                <el-table-column label="排序" type="index" :index="1" width="80px" />
                <el-table-column prop="id" fixed label="商品ID" width="100px"/>
                <el-table-column prop="name" fixed label="商品名" width="500px"/>  
                <el-table-column label="排序" width="70px"> 
                    <template slot-scope="scope">
                        <el-button type="success" @click="updateSort(scope.row,  scope.$index + 1)" icon="el-icon-sort" circle />
                    </template> 
                </el-table-column>
                 <el-table-column label="删除" width="70px"> 
                    <template slot-scope="scope">
                        <el-button type="danger" @click="deleteGood(scope.row,  scope.$index + 1)" icon="el-icon-delete" circle />
                    </template> 
                </el-table-column>
            </el-table>
        </el-dialog>
         <!-- 排序修改 -->
        <el-dialog title="排序修改" :visible.sync="goodsSort">
            
            <el-form :model="updateSortObj" >
                <el-form-item label="品牌ID">
                    <el-input :disabled="true" v-model="updateSortObj.id" />
                </el-form-item>
                <el-form-item label="品牌名">
                    <el-input :disabled="true" v-model="updateSortObj.name" />
                </el-form-item>
                <el-form-item label="目标排序">
                    <el-input v-model="updateSortObj.sortNew" />
                </el-form-item>
                <el-form-item>
                    <el-button  type="primary"  @click="updateSortConfirm(updateSortObj)" >确认修改 </el-button>
                </el-form-item>
            </el-form>
        </el-dialog>
        <!-- 编辑活动信息 -->
        <el-dialog title="编辑活动信息" :visible.sync="hideEditProduct">
            <el-form :model="editProductParam" size="mini">
                <el-form-item label="ID" prop="id" >
                    <el-input :disabled="true" v-model="editProductParam.id" maxlength="50" clearable  />
                </el-form-item>
                <el-form-item label="名字" prop="name" >
                    <el-input v-model="editProductParam.name" maxlength="50" clearable  />
                </el-form-item>
                <el-form-item label="活动描述" prop="description" >
                    <el-input v-model="editProductParam.description" maxlength="255" clearable  />
                </el-form-item>
                <el-form-item label="活动时间" required>
                    <span class="demonstration"></span>
                    <el-form-item prop="actTimeRange">
                        <el-date-picker type="datetimerange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" placeholder="活动时间" value-format="timestamp" v-model="actTimeRange" style="width: 100%;" />
                    </el-form-item>
                </el-form-item>
                <el-form-item label="最小折扣（1折 = 10）" prop="min_discount" >
                    <el-input type="number" v-model="editProductParam.min_discount" maxlength="50" clearable  />
                </el-form-item>
                <el-form-item label="商品数量" prop="goods_num" >
                    <el-input type="number" v-model="editProductParam.goods_num" maxlength="50" clearable  />
                </el-form-item>
                <el-form-item label="活动是否对微信可见" >
                    <el-select  v-model="editProductParam.wx_mini_program_show" placeholder="是否对微信可见">
                            <el-option label="展示" value="1" />
                            <el-option label="不展示" value="0" />
                    </el-select>
                </el-form-item>
                <el-form-item label="精选图片" prop="selected_nice_img" size="mini">
                    <el-upload action="https://xttapi.lexj.com/helper/uploadCdn" :show-file-list="false" :on-success="handleUpCaptain_4ImgSuccess" :list-type="editProductParam.selected_nice_img ? '' : 'picture-card'">
                        <div class="container">
                            <img v-if="editProductParam.selected_nice_img" :src="editProductParam.selected_nice_img" class="avatar" alt="">
                            <i v-else class="el-icon-plus"></i>
                        </div>
                    </el-upload>
                </el-form-item>        
                <el-form-item>
                    <el-button type="primary" @click="updateProduct(editProductParam)">立即修改</el-button>
                </el-form-item>        
            </el-form>
        </el-dialog>
        <!-- 新增混合商品的弹窗 -->
        <el-dialog title="新增活动商品" :visible.sync="dialogFormVisibleGoods">
            <el-form :model="goodsIdList">
                <el-form-item>
                    <p class="tip">商品ID和商品类型不一致，无法添加商品到活动中</p>
                    <div v-for="(item,index) in goodsIdList">
                        <el-input style="width:300px"  type="number"  placeholder="商品ID" v-model="item.goods_id" maxlength="20" clearable show-word-limit="true" />
                        <el-select style="margin-left:20px" v-model="item.order_type" placeholder="商品类型">
                            <el-option label="爱库存" value="2" />
                            <el-option label="好衣库" value="13" />
                            <el-option label="自营" value="6" />
                        </el-select>
                        <el-button-group style="margin-left:20px">
                            <el-button  type="success" icon="el-icon-plus" @click="addGoodsIdList(index)" />
                            <el-button  type="danger" icon="el-icon-minus" @click="subGoodsIdList(index)" />
                        </el-button-group>
                    </div>
                    <el-tooltip class="item" effect="dark" content="一个活动最多添加100件商品，超过100件，新添加会覆盖旧添加" placement="right-end">
                        <el-button style="margin-top:20px" type="primary" @click="addGoodsIds()" >添加</el-button>                    
                    </el-tooltip>
                </el-form-item>
            </el-form>
        </el-dialog>

        <!-- 新增自营活动的弹窗 -->
        <el-dialog title="新增自营活动" :visible.sync="dialogFormVisible">
            <el-form :model="ownAct" label-width="180px" label-position="left" >    
                <el-form-item label="活动名称" prop="act_name" >
                    <el-input type="text" placeholder="活动名" v-model="ownAct.act_name" maxlength="50" clearable />
                </el-form-item>
                <el-form-item label="活动描述" prop="act_description" >
                    <el-input type="textarea"  placeholder="活动描述" v-model="ownAct.act_description" maxlength="255" clearable show-word-limit="true" />
                </el-form-item>              
                <el-form-item label="品牌选择" prop="brand_id">
                    <el-select v-model="ownAct.brand_id" filterable remote placeholder="请输入关键词" :remote-method="remoteMethod" :loading="loading">
                        <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
                    </el-select>
                    <el-button style="margin-left:20px" type="success" icon="el-icon-edit" circle class="button_on" @click="dialogFormVisibleBrand = true" >新增品牌</el-button>
                </el-form-item>
                <el-dialog title="新增品牌" append-to-body :visible.sync="dialogFormVisibleBrand">
                    <el-form :model="brand" label-width="180px" label-position="left" >
                        <el-form-item label="品牌名" prop="brand_name" >
                            <el-input type="text" placeholder="品牌名" v-model="brand.brand_name" maxlength="50" clearable />
                        </el-form-item>
                        <el-form-item label="品牌描述" prop="brand_description" >
                            <el-input type="textarea" placeholder="品牌描述" v-model="brand.brand_description" maxlength="255" clearable />
                        </el-form-item>
                        <el-form-item label="品牌LOGO" prop="brand_logo_url">
                            <el-upload class="avatar-uploader" action="https://xttapi.lexj.com/helper/uploadCdn" list-type="picture-card" :on-success="handleUpBrandLogoSuccess" :on-remove="handleRemoveBrandLogo" :limit="1" :on-exceed="exceedLimitFileNum" >
                                <i slot="default" class="el-icon-plus" />                    
                            </el-upload> 
                        </el-form-item>
                        <el-form-item>
                            <el-button type="primary" @click="createBrand(brand)">新建品牌</el-button>
                        </el-form-item>
                    </el-form>
                </el-dialog>
                <el-form-item label="分类选择" prop="tag_id" >
                    <el-select v-model="ownAct.cat_id" filterable remote placeholder="请输入关键词" :remote-method="remoteTagMethod" :loading="loading">
                        <el-option v-for="item in optionsTag" :key="item.value" :label="item.label" :value="item.value" />
                    </el-select>
                </el-form-item>
                <el-form-item label="活动时间" required>
                    <span class="demonstration"></span>
                    <el-form-item prop="actTimeRange">
                        <el-date-picker type="datetimerange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" placeholder="活动时间" value-format="timestamp" v-model="actTimeRange" style="width: 100%;" />
                    </el-form-item>
                </el-form-item>
                <el-form-item label="活动是否对微信可见" prop="act_wx_mini_program_show" >
                    <el-select  v-model="ownAct.act_wx_mini_program_show" placeholder="是否对微信可见">
                            <el-option label="是" value="1" />
                            <el-option label="否" value="0" />
                    </el-select>
                </el-form-item>
                <el-form-item label="活动中的商品数量" prop="act_goods_num" >
                    <el-input type="number"  placeholder="商品数量" v-model="ownAct.act_goods_num" maxlength="5" clearable show-word-limit="true" />
                </el-form-item>
                <el-form-item label="活动最低折扣(1折 = 10)" prop="act_min_discount" >
                    <el-input type="number"  placeholder="（1 ~ 99）" v-model="ownAct.act_min_discount" maxlength="5" clearable show-word-limit="true" />
                </el-form-item> 
                <el-form-item label="活动精选图片" prop="act_selected_nice_img">
                    <el-upload class="avatar-uploader" action="https://xttapi.lexj.com/helper/uploadCdn" list-type="picture-card" :on-success="handleUpSelectedSuccess" :on-remove="handleRemoveSelectedImg" :limit="1" :on-exceed="exceedLimitFileNum" >
                        <i slot="default" class="el-icon-plus" />                    
                    </el-upload> 
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="createOwnActAndNoOwnGoods(ownAct)">立即创建</el-button>
                </el-form-item>
            </el-form>
        </el-dialog>
    </div>
</template>

<script>
import { uploadImg }  from '@/api/uploadImg';
import { deleteGoodsSort, updateGoodsSort, listOwnActGoods,createOwnActNoOwnGoodsAct, listTag, listBrand,createBrand, listOwnActNoOwnGoodsAct,updateOwnActNoOwnGoodsAct, createNoOwnGoods } from '@/api/groupbuy';


export default {
    data() {
        return {
            currentAct : {},
            currentIndex : -1,
            updateSortObj : {},
            goodsSort : false,
            ownActGoods : [],
            showActGoodsList : false,
            page: 1,
            pageSize:10,
            pageNum:0,
            pageTotal: 10,
            editProductParam : {},
            hideEditProduct:false,
            up_status_show: true,
            brand: {
                brand_name : null,
                brand_description : null,
                brand_logo_url : null
            },
            tableData:[],
            loading : false,
            value : [],
            options : [],
            optionsTag : [],
            banrdOptions :[],
            tagOptions :[],
            dialogFormVisibleTag : false,
            dialogFormVisibleBrand : false,
            dialogFormVisible : false,
            dialogFormVisibleGoods : false,
            thisActId:null,
            uploadImg,
            actTimeRange : [],
            goodsIdList: [{}],
            ownAct: {
                "brand_id":null,
                "brand_name":null,
                "brand_description":null,
                "brand_logo_url":null,
                "act_id":null,
                "act_name":null,
                "cat_id":null,
                "act_description":null,
                "act_start_time":null,
                "act_end_time":null,
                "act_wx_mini_program_show":null,
                "act_selected_nice_img":null,
                "act_goods_num":null,
                "act_min_discount":null,
                "goodsList": null
            }
        }
    },
    mounted() {
        this.pageNum = this.pageSize;
        this.initHome();
    },
    methods : {
        async deleteGood(params, currentIndex) {
            
            if(this.ownActGoods.length >= currentIndex) {
                await deleteGoodsSort({id: this.currentAct.id ,index:currentIndex}).then(response => {
                    this.$message(response.data.msg);
                });
            }else {
                this.$message("目标排序位置不合理");
            }
            await this.listGoodsInfo(this.currentAct);
        },
        async updateSortConfirm(params) {
            
            if(this.ownActGoods.length >= params.sortNew) {
                await updateGoodsSort({id: this.currentAct.id ,currentSort:this.currentIndex,sortNew: params.sortNew}).then(response => {
                    this.$message(response.data.msg);
                });
            }else {
                this.$message("目标排序位置不合理");
            }
            delete this.updateSortObj.sortNew;
            this.goodsSort = false;
            await this.listGoodsInfo(this.currentAct);
        },
        updateSort(params, currentIndex) {
            this.updateSortObj = params;
            this.currentIndex = currentIndex;
            this.goodsSort = true;
        },
        async listGoodsInfo(params) {
            this.ownActGoods = [];
            this.showActGoodsList = true;
            this.currentAct = params;
            listOwnActGoods(this.currentAct).then(response => {
                const respo = response.data;
                if(respo.code === 10000) {
                    this.ownActGoods = respo.data;
                }else {
                    this.$message(respo.meg);
                }
                
            });
        },
        addGoods(params) {
            this.goodsIdList = [{}];
            this.dialogFormVisibleGoods = true;
            this.thisActId = params.id;
        },
        currentChange(val) {
            this.page = val < 1 ? 1 : val > this.pageTotal ? this.pageTotal : val;
            this.listAct({"pageNum":this.page,"pageSize":this.pageSize});
        },
        updateProduct(params) {
            params.start_time = this.actTimeRange[0] /1000;
            params.end_time = this.actTimeRange[1] /1000;
            updateOwnActNoOwnGoodsAct(params).then(response => {
                const res = response.data;
                if(res.code === 10000) {
                    this.$message({
                        message: '操作成功',
                        type: 'success'
                    });
                    this.currentChange(this.page);
                }else {
                    this.$message({
                        message: res.msg,
                        type: 'fail'
                    });
                }
                
            });
        },
        editProduct(params) {
            this.hideEditProduct = true;
            this.editProductParam = params;
            this.actTimeRange = [params.start_time * 1000, params.end_time  * 1000];
        },
        upStatus(params) {
            params.qxb_status = params.qxb_status === 1 ? 0 : 1;
            this.updateProduct(params);
        },
        handleUpCaptain_4ImgSuccess(res, file, fileList) {
            this.editProductParam.selected_nice_img = res.data;
        },

        initHome() {
            this.pageNum = this.pageSize;
            listBrand().then(response => {
                const res = response.data;
                if(res.code === 10000) {
                    for (const iterator of res.data) {
                        let brandOpt = {};
                        brandOpt.label = iterator.brand_name;
                        brandOpt.value = iterator.id;
                        this.banrdOptions.push(brandOpt);
                    }
                }
            });
            listTag().then(response => {
                const res = response.data;
                if(res.code === 10000) {
                    for (const iterator of res.data) {
                        let tagOpt = {};
                        tagOpt.label = iterator.tag_name;
                        tagOpt.value = iterator.id;
                        this.tagOptions.push(tagOpt);
                    }
                }
            });
            this.currentChange(this.page);
        },
        listAct(params) {
            listOwnActNoOwnGoodsAct(params).then(response => {
                this.tableData  = [];
                const res = response.data;
                if(res.code === 10000) {
                    for (const iterator of res.data.res) {
                        const newDate = new Date();
                        newDate.setTime((iterator.start_time - 12 * 3600) * 1000);
                        iterator.start_time_str = newDate.toLocaleString();
                        newDate.setTime((iterator.end_time - 12 * 3600) * 1000);
                        iterator.end_time_str = newDate.toLocaleString();
                        iterator.qxb_status_str = 1===Number(iterator.qxb_status)?'上架':'下架';
                        iterator.wx_mini_program_show_str = 1===Number(iterator.wx_mini_program_show)?'展示':'不展示';
                        this.tableData.push(iterator);
                    }
                    this.pageTotal = res.data.pageTotal;
                }
            });
        },
        remoteTagMethod(query){
            if (query !== '') {
                this.loading = true; 
                setTimeout(() => {
                    this.loading = false;
                    this.optionsTag = this.tagOptions.filter(item => {
                        return item.label.toLowerCase().indexOf(query.toLowerCase()) > -1;
                    });
                }, 200);
            } else {
                this.optionsTag = [];
            }
        },
        remoteMethod(query){
            if (query !== '') {
                this.loading = true; 
                setTimeout(() => {
                    this.loading = false;
                    this.options = this.banrdOptions.filter(item => {
                        return item.label.toLowerCase().indexOf(query.toLowerCase()) > -1;
                    });
                }, 200);
            } else {
                this.options = [];
            }
        },
        addGoodsIdList(index) {           
            this.goodsIdList.splice(index + 1,0,{});
        },
        subGoodsIdList(index) {           
            this.goodsIdList.splice(index,1);
        },
        addGoodsIds() {
            const msg = {
                act_id:this.thisActId,
                goodsIdList:this.goodsIdList
            };
             createNoOwnGoods(msg).then(response => {
                const res = response.data;
                    if(res.code === 10000) {
                        this.$message({
                            message: '操作成功',
                            type: 'success'
                        });
                        this.currentChange(this.page);
                    }else {
                        this.$message({
                            message: res.msg,
                            type: 'fail'
                        });
                    }
                });

            this.dialogFormVisibleGoods = false;
        },
        createBrand(msg) {
            createBrand(msg).then(response => {
                const res = response.data;
                if(res.code === 10000) {
                    let brandOpt = {};
                    brandOpt.label = res.data.brand_name;
                    brandOpt.value = res.data.insertId;
                    this.banrdOptions.push(brandOpt);         
                    this.$message({
                        message: '操作成功',
                        type: 'success'
                    });
                }else {
                    this.$message({
                        message: res.msg,
                        type: 'fail'
                    });
                }
            });
        },

        createOwnActAndNoOwnGoods(msg) {
            const timeJson = this.actTimeRange;
            msg.act_start_time = parseInt(timeJson[0]/1000);
            msg.act_end_time = parseInt(timeJson[1]/1000);
            createOwnActNoOwnGoodsAct(msg).then(response=>{
                const res=response.data;
                    if(res.code === 10000) {
                        this.$message({
                            message: '操作成功',
                            type: 'success'
                        });
                        this.currentChange(this.page);
                    }else {
                        this.$message({
                            message: res.msg,
                            type: 'fail'
                        });
                    }
                });
            this.goodsIdList = {};
            this.dialogFormVisible = false;
        },
        handleUpSelectedSuccess(res, file, fileList) {
            this.ownAct.act_selected_nice_img = res.data;
        },
        handleRemoveSelectedImg(file, fileList) {
            let removePic = file.response.data;
            let index = this.ownAct.act_selected_nice_img.indexOf(removePic);
            if(-1 !== index) {
                this.ownAct.act_selected_nice_img = null;
            }         
        },
        handleUpBrandLogoSuccess(res, file, fileList) {
            this.brand.brand_logo_url = res.data;
        },
        handleRemoveBrandLogo(file, fileList) {
            let removePic = file.response.data;
            let index = this.ownAct.brand_logo_url.indexOf(removePic);
            if(-1 !== index) {
                this.ownAct.brand_logo_url = null;
            }         
        },
        exceedLimitFileNum() {
            alert("超出上传文件数量");
        }

    }
}
</script>
    
<style scoped>
  .tip{
      text-align: center;
      font-size: 20px;
      color: red;
  }
</style>
