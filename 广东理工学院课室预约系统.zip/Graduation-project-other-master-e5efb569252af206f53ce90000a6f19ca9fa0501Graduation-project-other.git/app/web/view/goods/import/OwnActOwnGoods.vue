<template>
  <div class="app-container">
    <el-row>
      <el-button type="primary" @click="addActMethod" >新增活动</el-button>
    </el-row>  

    <!-- 活动列表 -->
    <el-table border :data="actInfoList" height=1000>
      <el-table-column prop="id" label="ID" width="100px" fixed/>
      <el-table-column prop="name" label="活动名" width="200px" fixed/>
      <el-table-column prop="description" label="描述"  width="400px"/>
      <el-table-column prop="tag_name" label="分类"  />
      <el-table-column prop="start_time" label="开始时间"  width="180px" />
      <el-table-column prop="end_time" label="结束时间"  width="180px" />
      <el-table-column prop="min_discount" label="最小商品折扣"  />
      <el-table-column prop="goods_num" label="商品数量（上架中）"  />
      <el-table-column prop="brand_name" label="供应商品牌名" width="200px" />
      <el-table-column prop="qxb_status" label="上下架状态"  />
      <el-table-column prop="wx_mini_program_show" label="是否对小程序展示" />
      <el-table-column label="编辑" > 
        <template slot-scope="scope">
          <i @click="editActSignMethod(scope.row)" class="el-icon-edit" />
        </template>
      </el-table-column>
      <el-table-column label="查看商品" > 
        <template slot-scope="scope">
          <i @click="getGoodsList(scope.row)" class="el-icon-more" />
        </template>
      </el-table-column>
    </el-table>

    <!-- 活动编辑 -->
    <el-dialog :visible.sync="editActSign" title="编辑活动">
      <el-form v-model="editActObj">
        <el-form-item label="活动名">
          <el-input v-model="editActObj.name" />
        </el-form-item>
        <el-form-item label="活动描述">
          <el-input v-model="editActObj.description" />
        </el-form-item>
        <el-form-item label="活动最低折扣">
          <el-input v-model.number ="editActObj.min_discount" />
        </el-form-item>
        <el-form-item label="活动上架商品数量">
          <el-input v-model.number ="editActObj.goods_num" />
        </el-form-item>
        <el-form-item label="活动时间选择">
          <el-date-picker v-model="editActObj.time" type="datetimerange" value-format="timestamp" @change="actTime" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期"> </el-date-picker>
        </el-form-item> 
        <el-form-item label="是否对小程序可见">
          <el-select v-model="editActObj.wx_mini_program_show_value" placeholder="请选择">
            <el-option v-for="item in optionsWXshow" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button @click="createAct" > 确认修改 </el-button> 
        </el-form-item>
      </el-form>
    </el-dialog>

    <!-- 新增活动弹窗 -->
    <el-dialog :visible.sync="addAct"  title="新增活动">
      <el-form v-model="addActObj">
        <el-form-item label="活动名">
          <el-input v-model="addActObj.name" />
        </el-form-item>
        <el-form-item label="活动描述">
          <el-input v-model="addActObj.description" />
        </el-form-item>
        <el-form-item label="活动最低折扣">
          <el-input v-model.number ="addActObj.min_discount" />
        </el-form-item>
        <el-form-item label="活动上架商品数量">
          <el-input v-model.number ="addActObj.goods_num" />
        </el-form-item>
        <el-form-item label="活动banner图片">
          <el-upload action="https://xttapi.lexj.com/helper/uploadCdn" list-type="picture-card" :on-success="upBannerSuccess" :on-remove="handleBannerRemove" :limit=3>
            <i class="el-icon-plus"></i>
          </el-upload>
        </el-form-item>
        <el-form-item label="活动分类">
          <el-select v-model="addActObj.cat_id" placeholder="请选择活动分类">
            <el-option v-for="item in tags" :key="item.id" :label="item.tag_name" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="活动时间选择">
          <el-date-picker v-model="addActObj.time" type="datetimerange" value-format="timestamp" @change="actTime" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期"> </el-date-picker>
        </el-form-item> 
        <el-form-item label="活动供应商品牌选择">
          <el-select v-model="addActObj.brand_id" filterable remote placeholder="请输入关键词" :remote-method="remoteMethod" :loading="loading">
              <el-option v-for="item in brandSuboptions" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
          <el-button @click="createBrandSign" > 新增品牌 </el-button> 
        </el-form-item>
        <el-form-item label="是否对小程序可见">
          <el-select v-model="addActObj.wx_mini_program_show_value" placeholder="请选择">
            <el-option v-for="item in optionsWXshow" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button @click="createAct" > 立即创建 </el-button> 
        </el-form-item>
      </el-form>
    </el-dialog>

    <!-- 新增品牌 -->
    <el-dialog title="新增品牌" append-to-body :visible.sync="dialogFormVisibleBrand">
      <el-form :model="brand" label-width="180px" label-position="left" >
        <el-form-item label="品牌名" prop="brand_name" >
            <el-input type="text" placeholder="品牌名" v-model="brand.brand_name" maxlength="50" clearable />
        </el-form-item>
        <el-form-item label="品牌描述" prop="brand_description" >
            <el-input type="textarea" placeholder="品牌描述" v-model="brand.brand_description" maxlength="255" clearable />
        </el-form-item>
        <el-form-item label="品牌LOGO" prop="brand_logo_url">
            <el-upload class="avatar-uploader" action="https://xttapi.lexj.com/helper/uploadCdn" list-type="picture-card" :on-success="handleUpBrandLogoSuccess" :on-remove="handleRemoveBrandLogo" :limit="1" :on-exceed="exceedLimitFileNum" >
                <i slot="default" class="el-icon-plus" />                    
            </el-upload> 
        </el-form-item>
        <el-form-item>
            <el-button type="primary" @click="createBrand(brand)">新建品牌</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>

</template>

<script>
import { ownActOwnGoodsActList, getCatList, listBrand, createBrand, ownActAdd } from '@/api/groupbuy';

export default {
  data() {
    return {
      actInfo: {},
      editActObj: {},
      optionsWXshow: [
        { value: 1, label: '可见' },
        { value: 0, label: '不可见' }
      ],
      brandSuboptions: [],
      banrdOptions: [],
      loading: false,
      brand: {},
      dialogFormVisibleBrand: false,
      addActObj: {
        description: '',
        banner: [],
        cat_id: null,
        time: [],
        start_time: 0,
        end_time: 0,
        name: '',
        min_discount: 10,
        goods_num: 0,
        brand_id: null,
        wx_mini_program_show_value: 0
      },
      tags: [],
      addAct: false,
      editActSign: false,
      actInfoList: []
    };
  },
  mounted() {
    this.getList();
    this.getResource();
  },
  methods: {
    getOnlySettlementPrice(tagPrice, settlementPrice) {
      const discount = (settlementPrice / tagPrice).toFixed(2);
      let factor = 6;
      if (discount >= 0.3 && discount < 0.5) {
        factor = 4;
      } else if (discount >= 0.5 && discount < 0.7) {
        factor = 2.5;
      } else if (discount >= 0.7 && discount < 1) {
        factor = 2;
      }

      return Math.min(tagPrice, parseFloat(settlementPrice * (1 + Math.pow(1 - discount, (factor - discount) * 0.75))).toFixed(1));
    },


    createAct() {
      ownActAdd(this.addActObj).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.$message({
            message: '操作成功',
            type: 'success'
          });
          this.addAct = false;
          this.addActObj = {};
        } else {
          this.$message(res.msg);
        }
      });
    },

    getGoodsList(params) {
      this.$router.push({
        name: 'ownGoodsList',
        params,
      });
    },

    createBrandSign() {
      this.dialogFormVisibleBrand = true;
    },

    createBrand(msg) {
      createBrand(msg).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          const brandOpt = {};
          brandOpt.label = res.data.brand_name;
          brandOpt.value = res.data.insertId;
          this.banrdOptions.push(brandOpt);
          this.$message({
            message: '操作成功',
            type: 'success'
          });
        } else {
          this.$message({
            message: res.msg,
            type: 'fail'
          });
        }
      });
    },


    handleUpBrandLogoSuccess(res, file, fileList) {
      this.brand.brand_logo_url = res.data;
    },

    handleRemoveBrandLogo(file, fileList) {
      const removePic = file.response.data;
      const index = this.ownAct.brand_logo_url.indexOf(removePic);
      if (index !== -1) {
        this.ownAct.brand_logo_url = null;
      }
    },

    exceedLimitFileNum() {
      this.$message.error('超出上传文件数量');
    },

    remoteMethod(query) {
      if (query !== '') {
        this.loading = true;
        setTimeout(() => {
          this.loading = false;
          this.brandSuboptions = this.banrdOptions.filter(item => {
            return item.label.toLowerCase().indexOf(query.toLowerCase()) > -1;
          });
        }, 200);
      } else {
        this.brandSuboptions = [];
      }
    },

    getList() {
      ownActOwnGoodsActList({ page: 1, pageSize: 20 }).then(response => {
        this.actInfoList = response.data.data;
      });
    },

    getResource() {
      // tags
      getCatList({ appType: 1 }).then(response => {
        this.tags = response.data.data;
        // 删除最后疯抢分类，新增活动不能指定为最后疯抢
        this.tags.splice(0, 1);
      });
      // brands
      listBrand().then(response => {
        const res = response.data;
        if (res.code === 10000) {
          for (const iterator of res.data) {
            const brandOpt = {};
            brandOpt.label = iterator.brand_name;
            brandOpt.value = iterator.id;
            this.banrdOptions.push(brandOpt);
          }
        }
      });
    },

    addActMethod(params) {
      this.addAct = true;
      this.addActObj = {
        description: '',
        banner: [],
        cat_id: null,
        time: [],
        start_time: 0,
        end_time: 0,
        name: '',
        min_discount: 10,
        goods_num: 0,
        brand_id: null,
        wx_mini_program_show_value: 0
      };
    },

    actTime() {
      this.addActObj.start_time = this.addActObj.time[0] / 1000;
      this.addActObj.end_time = this.addActObj.time[1] / 1000;
    },

    editActSignMethod(params) {
      this.editActObj = params;
      this.editActObj.time = [this.editActObj.start_time_timestamp * 1000, this.editActObj.end_time_timestamp * 1000];
      this.editActSign = true;
    },

    /**
     * response 上传接口返回的内容
     * file element ui组件包装后的文件内容
     * fileList 组件包装后的文件数组
     */
    upBannerSuccess(response, file, fileList) {
      const url = file.response.data;
      this.addActObj.banner.push(url);
    },

    handleBannerRemove(file, fileList) {
      const url = file.response.data;
      const removeIndex = this.addActObj.banner.indexOf(url);
      this.addActObj.banner.splice(removeIndex, 1);
    }
  }
};
</script>

<style lang="scss">
  .box-card {
    margin-top : 50px;
  }
  .clearfix:before,
  .clearfix:after {
    display: table;
    content: "";
  }
  .clearfix:after {
    clear: both
  }
  .el-form-item__content{
      display: flex !important;
  }
  .el-upload {
    display: flex !important;
    text-align: center !important;
    cursor: pointer !important;
    outline: 0 !important;
  }
  .image{
    margin: 0 5px 0 5px;
  }
</style>