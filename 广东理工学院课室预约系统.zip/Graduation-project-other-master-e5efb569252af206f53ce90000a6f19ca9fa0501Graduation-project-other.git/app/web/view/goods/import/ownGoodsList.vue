<template>
    <div class="app-container">
        <el-button @click="$router.back()" circle class="back-button" icon="el-icon-back" type="primary"></el-button>
        <el-button @click="createGoodsShow"> 新增商品 </el-button>
        <el-table :data="goodsList" border fit>
            <el-table-column fixed label="ID" prop="id" width="100"/>
            <el-table-column fixed label="商品名" prop="name" />
            <el-table-column label="商品描述" max-width="400px" prop="description"/>
            <el-table-column label="原价" prop="akc_tag_price" width="100px"/>
            <el-table-column label="佣金" prop="akc_profit" width="100px"/>
            <el-table-column label="团购价" prop="settlement_price" width="100px"/>
            <el-table-column label="单买价" prop="only_settlement_price" width="100px"/>
            <el-table-column label="折扣" prop="discount_rate" width="100px"/>
            <el-table-column label="横向图片" width="300px">
                <template slot-scope="scope">
                    <img :key="index" :src="item" alt="" class="image-preview"
                         v-for="(item, index) in scope.row.pictureArr"/>
                </template>
            </el-table-column>
            <el-table-column label="纵向图片" width="300px">
                <template slot-scope="scope">
                    <img :key="index" :src="item" alt=""
                         class="image-preview" v-for="(item, index) in scope.row.detail_pictureArr"/>
                </template>
            </el-table-column>
            <el-table-column label="供应商" prop="supplier_name" width="100px"/>
            <el-table-column label="供应商ID" prop="supplier_goods_id" width="100px"/>
            <el-table-column label="供应商商品名" prop="supplier_goods_name" width="100px"/>
            <el-table-column label="上下架状态" prop="qxb_status_str" width="100px"/>
            <el-table-column label="查看商品规格">
                <template slot-scope="scope">
                    <el-button @click="showSkuMethod(scope.row)" icon="el-icon-s-grid"></el-button>
                </template>
            </el-table-column>
            <el-table-column label="编辑">
                <template slot-scope="scope">
                    <el-button @click="editGoodsSignMethod(scope)" icon="el-icon-edit"></el-button>
                </template>
            </el-table-column>
            <el-table-column label="排序">
                <el-button icon="el-icon-sort"></el-button>
            </el-table-column>
        </el-table>

        <!-- 编辑商品 -->
        <el-dialog :visible.sync="editGoodsSign" title="商品编辑">
            <el-form :model="_editGoodsObj()" label-width="120px">
                <el-form-item label="ID">
                    <el-input :disabled="true" v-model="_editGoodsObj().id"/>
                </el-form-item>
                <el-form-item label="商品名">
                    <el-input v-model="_editGoodsObj().name"/>
                </el-form-item>
                <el-form-item label="商品描述">
                    <el-input v-model="_editGoodsObj().description"/>
                </el-form-item>
                <el-form-item label="横向图片" prop="pictureArr">
                    <image-preview-card :action="uploadImageAction"
                                        :index='index'
                                        :source="item"
                                        :uploadSuccess="_uploadPictureArrSuccess"
                                        class="image-viewer"
                                        width="100px"
                                        height="100px"
                                        v-for="(item, index) in _editGoodsObj().pictureArr">
                    </image-preview-card>
                </el-form-item>
                <el-form-item label="纵向图片" prop="detail_pictureArr">
                    <image-preview-card :action="uploadImageAction"
                                        :index='index'
                                        :source="item"
                                        :uploadSuccess="_uploadDetailPictureArrSuccess"
                                        class="image-viewer"
                                        width="100px"
                                        height="100px"
                                        v-for="(item, index) in _editGoodsObj().detail_pictureArr">
                    </image-preview-card>
                </el-form-item>
                <el-form-item label="供应商名">
                    <el-input v-model="_editGoodsObj().supplier_name"/>
                </el-form-item>
                <el-form-item label="供应商品ID">
                    <el-input v-model="_editGoodsObj().supplier_goods_id"/>
                </el-form-item>
                <el-form-item label="供应商品名">
                    <el-input v-model="_editGoodsObj().supplier_goods_name"/>
                </el-form-item>
                <el-form-item label="原价">
                    <el-input v-model="_editGoodsObj().akc_tag_price"/>
                </el-form-item>
                <el-form-item label="团购价">
                    <el-input v-model="_editGoodsObj().settlement_price"/>
                </el-form-item>
                <el-form-item label="单买价">
                    <el-input v-model="_editGoodsObj().only_settlement_price"/>
                </el-form-item>
            </el-form>
        </el-dialog>

        <!-- 商品的SKU信息 -->
        <el-dialog :visible.sync="showSkuSign" title="sku信息">
            <el-button @click="createSkuSignMethod()"> 新增规格信息 </el-button>
            <el-table border :data="skuList" height=1000 >
                <el-table-column prop="id" label="规格ID" />
                <el-table-column label="规格信息">
                    <el-table-column label="属性A" >
                        <el-table-column label="属性名" prop="attrAKey" />
                        <el-table-column label="属性值" prop="attrAValue" />
                    </el-table-column>
                    <el-table-column label="属性B" >
                        <el-table-column label="属性名" prop="attrBKey" />
                        <el-table-column label="属性值" prop="attrBValue" />
                    </el-table-column>
                </el-table-column>
                <el-table-column prop="sku_inventory" label="库存"/>
                <el-table-column prop="settlement_price" label="团购价" />
                <el-table-column prop="only_settlement_price" label="单买价" />
                <el-table-column prop="profit_price" label="佣金" />
                <el-table-column label="修改" >
                    <template slot-scope="scope">
                        <el-button icon="el-icon-edit" @click="editSkuSignMethod(scope.row)" />
                    </template>
                </el-table-column>
            </el-table>
        </el-dialog>

        <!-- 新增规格信息 -->
        <el-dialog :visible.sync="createSkuSign" title="新增规格信息">
            <el-form :data="createSku">
                <el-form-item label="颜色">
                    <el-input v-model="createSku.color" />
                </el-form-item>
                <el-form-item label="尺码">
                    <el-input v-model="createSku.size" />
                </el-form-item>
                <el-form-item label="库存">
                    <el-input v-model.number="createSku.sku_inventory" />
                </el-form-item>
                <el-form-item label="团购价">
                    <el-input v-model.number="createSku.settlement_price" />
                </el-form-item>
                <el-form-item label="单买价">
                    <el-input v-model.number="createSku.only_settlement_price" />
                </el-form-item>
                <el-form-item label="佣金">
                    <el-input v-model.number="createSku.profit_price" />
                </el-form-item>
                <el-form-item >
                    <el-button @click="createSkuMethod()" > 确认新增 </el-button>
                </el-form-item>
            </el-form>
        </el-dialog>

        <!-- 新增商品 -->
        <el-dialog :visible.sync="createGoodsShowSign" title="新增商品">
            <el-form v-model="addGoodsObj">
                <el-form-item label="商品名">
                    <el-input v-model="addGoodsObj.name" />
                </el-form-item>
                <el-form-item label="商品描述">
                    <el-input type="textarea" v-model="addGoodsObj.description" />
                </el-form-item>
                <el-form-item label="原价">
                    <el-input v-model.number="addGoodsObj.akc_tag_price" />
                </el-form-item>
                <el-form-item label="佣金">
                    <el-input v-model.number="addGoodsObj.akc_profit" />
                </el-form-item>
                <el-form-item label="团购价">
                    <el-input v-model.number="addGoodsObj.settlement_price"/>
                </el-form-item>
                <el-form-item label="单买价">
                    <el-input v-model.number="addGoodsObj.only_settlement_price" />
                    <el-button @click="culOnlySettlementPrice"> 计算单买价 </el-button>
                </el-form-item>
                <el-form-item label="折扣">
                    <el-input v-model.number="addGoodsObj.discount_rate" />
                    <el-button @click="culDiscount"> 计算折扣 </el-button>
                </el-form-item>
                <el-form-item label="供应商">
                    <el-input v-model="addGoodsObj.supplier_name" />
                </el-form-item>
                <el-form-item label="供应商ID">
                    <el-input v-model="addGoodsObj.supplier_goods_id" />
                </el-form-item>
                <el-form-item label="供应商商品名">
                    <el-input v-model="addGoodsObj.supplier_goods_name" />
                </el-form-item>
                <el-form-item label="上下架状态（配置商品规格后，才可以上架商品）">
                    <el-select v-model="addGoodsObj.qxb_status" placeholder="请选择">
                        <el-option :disabled="true" v-for="item in goodsStatusOptions" :key="item.value" :label="item.label" :value="item.value" />
                    </el-select>
                </el-form-item>
                <el-form-item label="图片（横划）">
                    <el-upload action="https://xttapi.lexj.com/helper/uploadCdn" list-type="picture-card" :on-success="upPicSuccess" :on-remove="handlePicRemove" >
                        <i class="el-icon-plus"></i>
                    </el-upload>
                </el-form-item>
                <el-form-item label="图片（竖划）">
                    <el-upload action="https://xttapi.lexj.com/helper/uploadCdn" list-type="picture-card" :on-success="upDetailPicSuccess" :on-remove="handleDetailPicRemove" >
                        <i class="el-icon-plus"></i>
                    </el-upload>
                </el-form-item>
                <el-form-item>
                    <el-button @click="createGoods"> 确认新增商品 </el-button>
                </el-form-item>
            </el-form>
        </el-dialog>

        <!-- 编辑SKU -->
        <el-dialog :visible.sync="editSkuSign" title="编辑sku">
            <el-form v-model="editSku">
                <el-form-item label="规格ID">
                    <el-input :disabled="true" v-model.number="editSku.id" />
                </el-form-item>
                <el-form-item label="颜色">
                    <el-input v-model="editSku.color" />
                </el-form-item>
                <el-form-item label="尺码">
                    <el-input v-model="editSku.size" />
                </el-form-item>
                <el-form-item label="库存">
                    <el-input v-model.number="editSku.sku_inventory" />
                </el-form-item>
                <el-form-item label="团购价">
                    <el-input v-model.number="editSku.settlement_price" />
                </el-form-item>
                <el-form-item label="单买价">
                    <el-input v-model.number="editSku.only_settlement_price" />
                </el-form-item>
                <el-form-item label="佣金">
                    <el-input v-model.number="editSku.profit_price" />
                </el-form-item>
                <el-form-item>
                    <el-button @click="editSkuMethod">确认修改</el-button>
                </el-form-item>
            </el-form>
        </el-dialog>
    </div>
</template>

<script>
  import ImagePreviewCard from '@/component/ImagePreview';
  import { ownActOwnGoodsList, ownGoodsSkuSee, ownGoodsSkuAdd, ownGoodsAdd, ownGoodsSkuEdit } from '@/api/groupbuy';
  import { uploadImgNew } from '../../../api/uploadImg';

  export default {
    name: 'ownGoodsList',
    components: { ImagePreviewCard },
    data() {
      return {
        uploadImageAction: uploadImgNew,

        actInfo: {},
        goodsList: [],
        editingGoodsIndex: 0,

        sku_product_id: null,
        sku_goods_id: 0,

        editGoodsSign: false,
        showSkuSign: false,
        createSkuSign: false,
        createGoodsShowSign: false,
        editSkuSign: false,

        skuList: [],
        editSku: {},
        createSku: {
          attribute_list: [],
          product_id: null,
          goods_id: 0
        },

        addGoodsObj: {
          discount_rate: 0,
          only_settlement_price: 0,
          qxb_status: 0,
          detail_picture: [],
          picture: []
        },
        goodsStatusOptions: [
          { value: 1, label: '上架' },
          { value: 0, label: '下架' }
        ],
      };
    },
    created() {
      this.getGoodsList(this.$route.params);
    },
    methods: {
      getGoodsList(params) {
        this.actInfo = {};
        ownActOwnGoodsList({ ownActId: params.id }).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.actInfo = {
              own_activity_id: params.id,
              aikucun_activity_id: params.activity_id,
              aikucun_brand_id: params.brand_id
            };
            this.goodsList = res.data;
            for (const goods of this.goodsList) {
              goods.pictureArr = JSON.parse(goods.picture);
              goods.detail_pictureArr = JSON.parse(goods.detail_picture);
              goods.qxb_status_str = Number(goods.qxb_status) === 1 ? '上架' : '下架';
            }
          } else {
            this.$message({
              message: res.msg,
              type: 'fail'
            });
          }
        });
      },

      showSkuMethod(params) {
        this.showSkuSign = true;
        this.sku_goods_id = params.id;
        this.sku_product_id = params.product_id;
        ownGoodsSkuSee({ goods_id: params.id }).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.skuList = res.data;
            for (const sku of this.skuList) {
              const attributeArr = JSON.parse(sku.attribute_list);
              sku.attrAKey = attributeArr[0].attributeName;
              sku.attrAValue = attributeArr[0].attributeValue;
              sku.attrBKey = attributeArr[1].attributeName;
              sku.attrBValue = attributeArr[1].attributeValue;
              if (sku.attrAKey === '颜色') {
                sku.color = sku.attrAValue;
                sku.size = sku.attrBValue;
              } else {
                sku.size = sku.attrAValue;
                sku.color = sku.attrBValue;
              }
            }
          } else {
            this.$message(res.msg);
          }
        });
      },

      editGoodsSignMethod(params) {
        this.editGoodsSign = true;
        this.editingGoodsIndex = params.$index;
      },

      _editGoodsObj() {
        if (!this.editingGoodsIndex && this.editingGoodsIndex !== 0) {
          return {};
        }

        return this.goodsList.hasOwnProperty(this.editingGoodsIndex) ? this.goodsList[this.editingGoodsIndex] : {};
      },

      _uploadPictureArrSuccess(response, index) {
        if (response.code !== 10000) {
          this.$message.error(response.msg || '上传图片失败');
          return;
        }

        const goods = Object.assign({}, this._editGoodsObj());
        goods.pictureArr[index] = response.data;
        this.goodsList.splice(this.editingGoodsIndex, 1, goods);
      },

      _uploadDetailPictureArrSuccess(response, index) {
        if (response.code !== 10000) {
          this.$message.error(response.msg || '上传图片失败');
          return;
        }

        const goods = Object.assign({}, this._editGoodsObj());
        goods.detail_pictureArr[index] = response.data;
        this.goodsList.splice(this.editingGoodsIndex, 1, goods);
      },

      editSkuSignMethod(params) {
        this.editSkuSign = true;
        this.editSku = {
          id: params.id,
          goods_id: this.sku_goods_id,
          sku_inventory: params.sku_inventory,
          settlement_price: params.settlement_price,
          only_settlement_price: params.only_settlement_price,
          profit_price: params.profit_price,
          attribute_list: [],
          color: params.color,
          size: params.size
        };
      },

      createSkuSignMethod() {
        this.createSkuSign = true;
        this.createSku = {
          attribute_list: [],
          goods_id: this.sku_goods_id,
          product_id: this.sku_product_id
        };
      },

      createSkuMethod() {
        const attrColor = {
          attributeName: '颜色', attributeValue: this.createSku.color
        };
        const attrZize = {
          attributeName: '尺寸', attributeValue: this.createSku.size
        };
        this.createSku.attribute_list.push(attrColor);
        this.createSku.attribute_list.push(attrZize);
        ownGoodsSkuAdd(this.createSku).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.$message(res.msg);
            this.createSku = {};
          } else {
            this.$message(res.msg);
          }
        });
      },

      createGoodsShow() {
        this.createGoodsShowSign = true;
        this.addGoodsObj = {
          discount_rate: 0,
          only_settlement_price: 0,
          qxb_status: 0,
          detail_picture: [],
          picture: []
        };
      },

      createGoods() {
        this.addGoodsObj.own_activity_id = this.actInfo.own_activity_id;
        this.addGoodsObj.aikucun_activity_id = this.actInfo.aikucun_activity_id;
        this.addGoodsObj.aikucun_brand_id = this.actInfo.aikucun_brand_id;
        ownGoodsAdd(this.addGoodsObj).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.addGoodsObj = {};
            this.createGoodsShowSign = false;
          }
          this.$message(res.msg);
        });
      },

      upPicSuccess(response, file) {
        const url = file.response.data;
        this.addGoodsObj.picture.push(url);
      },

      upDetailPicSuccess(response, file) {
        const url = file.response.data;
        this.addGoodsObj.detail_picture.push(url);
      },

      upEditPicSuccess(response, file, fileList) {
        const url = file.response.data;
        this.editGoodsObj.pictureArr.push(url);
        console.log('===> ' + JSON.stringify(this.editGoodsObj.pictureArr));
        console.log('===> ' + JSON.stringify(fileList));
      },

      handleEditPicRemove(file) {
        const url = file.response.data;
        const removeIndex = this.editGoodsObj.pictureArr.indexOf(url);
        this.editGoodsObj.pictureArr.splice(removeIndex, 1);
      },

      handlePicRemove(file) {
        const url = file.response.data;
        const removeIndex = this.addGoodsObj.picture.indexOf(url);
        this.addGoodsObj.picture.splice(removeIndex, 1);
      },

      handleDetailPicRemove(file) {
        const url = file.response.data;
        const removeIndex = this.addGoodsObj.detail_picture.indexOf(url);
        this.addGoodsObj.detail_picture.splice(removeIndex, 1);
      },

      culOnlySettlementPrice() {
        if (this.addGoodsObj.akc_tag_price === '' || this.addGoodsObj.akc_tag_price === null || isNaN(this.addGoodsObj.akc_tag_price)) {
          this.$message.error('原价为空');
          return;
        }

        if (this.addGoodsObj.settlement_price === '' || this.addGoodsObj.settlement_price === null || isNaN(this.addGoodsObj.settlement_price)) {
          this.$message.error('团购价为空');
          return;
        }

        this.addGoodsObj.only_settlement_price = this.getOnlySettlementPrice(this.addGoodsObj.akc_tag_price, this.addGoodsObj.settlement_price);
      },

      culDiscount() {
        if (this.addGoodsObj.akc_tag_price === '' || this.addGoodsObj.akc_tag_price === null || isNaN(this.addGoodsObj.akc_tag_price)) {
          this.$message.error('原价为空');
          return;
        }

        if (this.addGoodsObj.settlement_price === '' || this.addGoodsObj.settlement_price === null || isNaN(this.addGoodsObj.settlement_price)) {
          this.$message.error('团购价为空');
          return;
        }

        this.addGoodsObj.discount_rate = (100 * Number(this.addGoodsObj.settlement_price) / Number(this.addGoodsObj.akc_tag_price)).toFixed(0);
      },

      editSkuMethod() {
        const attrColor = {
          attributeName: '颜色', attributeValue: this.editSku.color
        };
        const attrZize = {
          attributeName: '尺寸', attributeValue: this.editSku.size
        };
        this.editSku.attribute_list.push(attrColor);
        this.editSku.attribute_list.push(attrZize);

        ownGoodsSkuEdit(this.editSku).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.$message(res.msg);
            this.editSku = {};
          } else {
            this.$message(res.msg);
          }
        });
      },
    },
  };
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
    .app-container {

        .back-button {
            margin-bottom: 20px;
        }

        .image-viewer {
            margin: 10px;
        }

        .image-preview {
            width: 80px;
            height: 80px;
            margin-left: 20px;
        }
    }

</style>