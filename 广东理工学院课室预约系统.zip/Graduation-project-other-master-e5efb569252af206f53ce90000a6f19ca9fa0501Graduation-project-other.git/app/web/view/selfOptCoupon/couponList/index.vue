<template>
    <div class="app-container" v-loading="loading" :element-loading-text="loadingText">
        <el-button class="add-button" type="primary" @click="_addCoupon" plain>新增优惠券</el-button>
        <div class="filter-container">
            <div class="filter-option">
                <span class="filter-option-key">优惠券ID:</span>
                <el-input class="filter-option-input" v-model="fetchParams.id" size="mini" clearable/>
            </div>
            <div class="filter-option">
                <span class="filter-option-key">优惠券类型</span>
                <el-select class="filter-option-select" v-model="fetchParams.type" placeholder="请选择" size="mini"
                           @change="getList">
                    <el-option
                            v-for="type in couponTypes"
                            :key="type.value"
                            :label="type.name"
                            :value="type.value">
                    </el-option>
                </el-select>
            </div>
            <div class="filter-option">
                <span class="filter-option-key">上/下架</span>
                <el-select class="filter-option-select" v-model="fetchParams.status" placeholder="请选择" size="mini"
                           @change="getList">
                    <el-option
                            v-for="type in couponStatus"
                            :key="type.value"
                            :label="type.name"
                            :value="type.value">
                    </el-option>
                </el-select>
            </div>
            <div class="filter-option">
                <span class="filter-option-key">开始时间: </span>
                <el-date-picker
                        size="mini"
                        v-model="fetchParams.start_time"
                        placeholder="上架时间"
                        style="max-width: 180px;"
                        value-format="timestamp"/>
            </div>
            <div class="filter-option">
                <span class="filter-option-key">结束时间: </span>
                <el-date-picker
                        size="mini"
                        v-model="fetchParams.end_time"
                        placeholder="上架时间"
                        style="max-width: 180px;"
                        value-format="timestamp"/>
            </div>
            <div class="filter-confirm">
                <el-button size="mini" type="primary" @click="getList">查询</el-button>
            </div>
        </div>
        <div class="list-container">
            <el-table :data="couponList" :row-key="_rowKey" border>
                <el-table-column type="index" label="序号" width="80px" fixed/>
                <el-table-column prop="id" label="优惠券ID" width="80px"/>
                <el-table-column prop="title" label="优惠券标题" width="120px"/>
                <el-table-column prop="type" label="优惠券类型" width="100px" :formatter="_formatType"/>
                <el-table-column prop="rule" label="可领取用户" width="230px" :formatter="_formatUser"/>
                <el-table-column prop="condition_price" label="满额限制/元" width="100px"/>
                <el-table-column prop="discount" label="抵扣金额/元" width="100px"/>
                <el-table-column prop="start_time" label="生效时间" width="100px" :formatter="_formatStartTime"/>
                <el-table-column prop="end_time" label="使用时间" min-width="150px">
                    <template slot-scope="scope">
                        <span> {{ _formatEndTime(scope.row )}}</span>
                        <span style="margin-left: 10px; font-size: 5px; color: #D9534F;"> {{ _couponExpired(scope.row) ? '已过期' : '' }}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="stock" label="库存量" width="100px" :formatter="_formatStock"/>
                <el-table-column label="操作" min-width="200px" fixed="right">
                    <template class="opt-button-container" slot-scope="scope">
                        <el-button class="opt-button" type="primary" size="mini" v-if="_showStatusOption(scope.row)" @click="_switchStatus(scope.row)">{{ scope.row.status ? '下架' : '上架' }}</el-button>
                        <el-button class="opt-button" type="primary" size="mini" v-if="_showCopyOption(scope.row)" @click="_copyCoupon(scope.row)">复制</el-button>
                        <el-button class="opt-button" type="primary" size="mini" @click="_showDetail(scope.row)">查看</el-button>
                        <el-button class="opt-button" type="primary" size="mini" v-if="_showStockOption(scope.row)" @click="_editStock(scope.row)">增加库存量</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div class="pagination" style="margin-top:20px;">
            <el-pagination @size-change="_handlePageSizeChange" @current-change="_handlePageChange"
                           :total="totalCount"
                           :current-page="fetchParams.page" :page-sizes="[20, 40, 80]"
                           :page-size="fetchParams.pageSize"
                           layout="total, sizes, prev, pager, next"/>
        </div>
        <!-- 修改库存量弹窗 -->
        <el-dialog :visible.sync="stockDialogVisible" title="增加库存量" width="450px" :show-close="false">
            <div class="stock-tips">
                增加:
                <el-input class="stock-input" v-model="stock" placeholder="输入库存" clearable/>
                张
            </div>
            <div slot="footer">
                <el-button type="primary" style="min-width: 85px;" @click="_confirmStock">确认</el-button>
                <el-button type="info" style="min-width: 85px;" @click="stockDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <!-- 优惠券详情 -->
        <el-dialog width="60%" top="30px" :visible.sync="detailDialogVisible">
            <div class="detail-dialog" >
                <div class="data-title">数据情况</div>
                <div class="data-container">
                    <div class="data-item">
                        <div class="data-item-value">{{ editingCoupon.receive_num || 0 }}</div>
                        <div class="data-item-title">领取数</div>
                    </div>
                    <div class="data-item">
                        <div class="data-item-value">{{ editingCoupon.coupon_use_num || 0 }}</div>
                        <div class="data-item-title">使用数</div>
                    </div>
                </div>
                <div class="detail-title">券详情</div>
                <div class="detail-container">
                    <div class="option">
                        <div class="option-key">优惠券类型:</div>
                        <div class="option-value">{{ _formatType(editingCoupon) }}优惠券</div>
                    </div>
                    <div class="option">
                        <div class="option-key">优惠券标题:</div>
                        <div class="option-value">{{ editingCoupon.title }}</div>
                    </div>
                    <div class="option-top">
                        <div class="option-key">使用限制说明:</div>
                        <pre class="option-value" style="margin: 0">{{ editingCoupon.detail }}</pre>
                    </div>
                    <div class="option-center">
                        <div class="option-key">有效期:</div>
                        <div class="option-value">{{ _formatEndTime(editingCoupon) }}</div>
                        <div v-if="_couponExpired(editingCoupon)" style="margin-left: 15px; font-size: 11px; color: #D9534F;">已过期</div>
                    </div>
                    <div class="option">
                        <div class="option-key">库存量:</div>
                        <div class="option-value">{{ _formatStock(editingCoupon) }}</div>
                    </div>
                    <div class="option">
                        <div class="option-key">余量预警邮箱:</div>
                        <div class="option-value">yinmeiwei@quexb.com</div>
                    </div>
                    <div class="option">
                        <div class="option-key">满:</div>
                        <pre class="option-value" style="margin: 0">{{ editingCoupon.condition_price }}元       减:      {{ editingCoupon.discount }}元</pre>
                    </div>
                    <div class="option">
                        <div class="option-key">可领取用户:</div>
                        <div class="option-value">{{ _formatUser(editingCoupon) }}</div>
                    </div>
                    <div class="option">
                        <div class="option-key">是否公开:</div>
                        <div class="option-value">{{ editingCoupon.overt ? '公开券' : '隐藏券' }}</div>
                    </div>
                    <div class="option">
                        <div class="option-key">投放渠道:</div>
                        <div class="option-value">{{ _formatPlatform(editingCoupon) }}</div>
                    </div>
                    <div class="option" v-if="editingCoupon.type">
                        <div class="option-key">优惠券使用{{ _attachName(editingCoupon) }}管理:</div>
                        <div class="selection-list" v-if="editingCoupon.attachments">
                            <div class="select-product-list">
                                <div class="select-product" v-for="attachment in editingCoupon.attachments">
                                    <div class="product-box">{{ _attachName(editingCoupon) }}：{{ `${attachment.id}" ${attachment.name || attachment.tag_name}` }} </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="option" v-if="editingCoupon.keyword">
                        <div class="option-key">搜索关键字:</div>
                        <div class="option-value">{{ _formatKeyword(editingCoupon) }}</div>
                    </div>
                </div>
            </div>
        </el-dialog>
    </div>
</template>

<script>
  import { couponList, updateCoupon, couponAttachments, couponSearchKeywords } from '../../../api/selfOptCoupon';
  import { dateFtt } from '../../../framework/utils/utils';

  export default {
    created() {
      this.getList();
    },
    data() {
      return {
        loading: false,
        loadingText: null,
        couponTypes: [
          { name: '', value: null },
          { name: '全场通用', value: 0 },
          { name: '指定商品', value: 1 },
          { name: '指定活动', value: 2 },
          { name: '指定品类', value: 3 },
        ],
        couponStatus: [
          { name: '', value: null },
          { name: '上架', value: 1 },
          { name: '下架', value: 0 }
        ],
        fetchParams: {
          page: 1,
          pageSize: 20,
        },
        totalCount: 0,
        couponList: [],

        editingCoupon: {},
        stock: null,
        stockDialogVisible: false,

        detailDialogVisible: false,
        couponSearchKeywords: {},
      };
    },
    methods: {
      getList() {
        this._getCouponList(this.fetchParams);
        this._fetchCouponSearchKeywords();
      },

      // 获取优惠券列表
      _getCouponList(params) {
        this.loading = true;
        couponList(params).then(res => {
          this.loading = false;
          const resData = res.data;
          console.log(resData);
          if (resData.code !== 10000) {
            this.$message.error(resData.msg || '获取优惠券列表失败');
          } else {
            this.$message.success('获取列表成功');
            this.totalCount = resData.totalCount;
            this.couponList = resData.data;
          }
        });
      },

      _fetchCouponSearchKeywords() {
        couponSearchKeywords().then(response => {
          this.couponSearchKeywords = response.data.data;
          console.log(this.couponSearchKeywords);
        });
      },

      // 获取优惠券关联的商品、活动或分类数据
      _getCouponAttachments(coupon) {
        this.loading = true;
        this.loadingText = '正在收集数据';

        return new Promise((resolve, reject) => {
          couponAttachments(coupon).then(response => {
            this.loading = false;
            this.loadingText = null;

            if (response.data.code !== 10000) {
              reject(response.data.msg || '加载数据出错');
            } else {
              resolve(response.data.data, response.data.totalCount);
            }
          });
        });
      },

      _handlePageSizeChange(pageSize) {
        this.fetchParams.pageSize = pageSize;
      },

      _handlePageChange(page) {
        this.fetchParams.page = page;
      },

      // 跳转到添加优惠券页面，param是需要复制的优惠券
      _addCoupon(params) {
        console.log(params);
        this.$router.push({
          path: '/addCoupon',
          name: 'selfOptCouponAdd',
          params,
        });
      },

      _rowKey(row) {
        return row.id;
      },

      // 类型名称
      _formatType(coupon) {
        const target = this.couponTypes.find(item => item.value === coupon.type);
        return target ? target.name : '';
      },

      // 可领取用户
      _formatUser(coupon) {
        if (!coupon.hasOwnProperty('rule') || typeof coupon.rule.role !== 'string') {
          return '';
        }

        const roleAlias = coupon.rule.role.split(';');
        const roleNames = roleAlias.map(item => this._roleName(item));
        return roleNames.join(' / ');
      },

      // 开始日期
      _formatStartTime(coupon) {
        if (coupon.start_time === -1) {
          return '';
        }

        return dateFtt('yyyy.MM.dd', new Date(coupon.start_time * 1000));
      },

      // 结束日期
      _formatEndTime(coupon) {
        if (coupon.start_time === -1) {
          return `用户领取后${coupon.end_time}天有效`;
        }

        const startDate = dateFtt('yyyy.MM.dd', new Date(coupon.start_time * 1000));
        const endDate = dateFtt('yyyy.MM.dd', new Date(coupon.end_time * 1000));
        return `${startDate} - ${endDate}`;
      },

      // 库存量
      _formatStock(coupon) {
        return coupon.stock === -1 ? '无限制' : coupon.stock - coupon.receive_num;
      },

      _formatPlatform(coupon) {
        if (!coupon.hasOwnProperty('rule') || typeof coupon.rule.channel !== 'string') {
          return '';
        }

        const roleAlias = coupon.rule.channel.split(';');
        const roleNames = roleAlias.map(item => this._channelName(item));
        return roleNames.join(' / ');
      },
  
      _formatKeyword(coupon) {
        if (!coupon.hasOwnProperty('keyword') || typeof coupon.keyword !== 'string') {
          return '';
        }

        const values = coupon.keyword.split(',');
        return values.map((value) =>
          Object.keys(this.couponSearchKeywords).find((key) => this.couponSearchKeywords[key] === value)
        ).filter((key) => typeof key !== 'undefined').join('、');
      },

      // 上/下架优惠券
      _switchStatus(coupon) {
        console.log(coupon);
        const status = coupon.status ? 0 : 1;
        this.loading = true;
        updateCoupon({ id: coupon.id, status }).then(response => {
          this.loading = false;
          if (response.data.code !== 10000) {
            this.$message.error(response.data.msg || '更新失败');
          } else {
            this.$message.success('更新成功');
            this.getList();
          }
        });
      },

      // 复制优惠券
      _copyCoupon(coupon) {
        this._getCouponAttachments(coupon).then((attachments) => {
          // 已选分类列表只包含了一个id 键
          if (coupon.type === 3) {
            attachments = attachments.map(item => item.id);
          }

          this._addCoupon({ coupon, attachments });
        }).catch((error) => {
          this.$message.error(error);
        });
      },

      _editStock(coupon) {
        this.editingCoupon = coupon;
        this.stockDialogVisible = true;
      },

      _confirmStock() {
        const id = this.editingCoupon.id;
        const addStock = parseInt(this.stock);

        if (isNaN(addStock)) {
          this.$message.error('请输入正确的库存');
          return;
        }

        if (!addStock) {
          this.$message.info('增加0张？');
          return;
        }

        const stock = this.editingCoupon.stock + addStock;
        this.loading = true;

        updateCoupon({ id, stock }).then(response => {
          this.loading = false;
          if (response.data.code !== 10000) {
            this.$message.error(response.data.msg || '更新失败');
          } else {
            this.$message.success('更新成功');
            this.stockDialogVisible = false;
            this.getList();
          }
        });
      },

      _showDetail(coupon) {
        this.editingCoupon = coupon;
        this._getCouponAttachments(coupon).then((attachments) => {
          this.$message.success('加载成功');
          this.editingCoupon.attachments = attachments;
          this.detailDialogVisible = true;
        }).catch((error) => {
          this.$message.error(error);
        });
      },

      // 操作按钮显示逻辑
      _showStatusOption(coupon) {
        return !this._couponExpired(coupon);
      },

      _showCopyOption(coupon) {
        return this._couponExpired(coupon) || !coupon.status;
      },

      _showStockOption(coupon) {
        return !this._couponExpired(coupon) && coupon.stock !== -1;
      },

      _couponExpired(coupon) {
        if (coupon.start_time === -1) {
          return false;
        }

        return (Date.now() / 1000) > coupon.end_time;
      },

      _roleName(role) {
        switch (role) {
          case 'N':
          case 'n':
            return '新用户';
          case '1':
          case 1:
            return '普通用户';
          case '2':
          case 2:
            return '团长';
          case '3':
          case 3:
            return '合伙人';
          default:
            return '';
        }
      },

      _channelName(chanel) {
        switch (chanel) {
          case 'A':
          case 'a':
            return '全平台';
          case '1':
          case 1:
            return 'APP';
          case '2':
          case 2:
            return '小程序';
          case '3':
          case 3:
            return 'H5';
          default:
            return '';
        }
      },

      _attachName(coupon) {
        if (coupon.type === 0) {
          return '';
        }

        return coupon.type === 1 ? '商品' : (coupon.type === 2 ? '活动' : '品类');
      },
    }
  };
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .app-container {
        font-family: "华文宋体", Helvetica, serif;

        .add-button {
            min-width: 150px;
        }

        .filter-container {
            display: flex;
            flex-direction: row;
            justify-content: flex-start;
            align-items: center;
            margin-top: 30px;

            .filter-option {
                margin-right: 30px;
                display: flex;
                flex-direction: row;
                align-items: center;

                .filter-option-key {
                    font-size: 14px;
                    color: #999;
                    min-width: 80px;
                }
            }
        }

        .list-container {
            margin-top: 30px;
        }

        .stock-tips {
            display: flex;
            flex-direction: row;
            align-items: center;

            .stock-input {
                margin: 0 10px 0 30px;
                max-width: 100px;
            }
        }
        
        .detail-dialog {
            padding-left: 30px;

            .data-title, .detail-title {
                font-size: 18px;
                font-weight: bolder;
                color: #282828;
                margin-bottom: 30px;
            }

            .data-container {
                display: flex;
                flex-direction: row;
                margin-bottom: 50px;

                .data-item {
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                    border: 1px solid #999;
                    min-width: 240px;
                    min-height: 80px;
                    color: #282828;
                    margin-left: 100px;

                    .data-item-value {
                        font: 40px bold;
                    }
                 }
            }

            .detail-container {
                color: #282828;

                .option, .option-top, .option-center {
                    margin-bottom: 30px;
                    display: flex;
                    flex-direction: row;

                    .option-key {
                        width: 130px;
                        margin-right: 50px;
                        text-align: right;
                        white-space: nowrap;
                    }

                    .selection-list {
                        .select-product-list {
                            display: flex;
                            justify-content: flex-start;
                            align-items: center;
                            flex-wrap: wrap;

                            .select-product {
                                width: 300px;
                                margin-right: 30px;
                                margin-bottom: 10px;
                                display: flex;
                                justify-content: flex-start;
                                align-items: center;

                                .product-box {
                                    font-size: 14px;
                                    color: #555;
                                    white-space: nowrap;
                                    overflow: hidden;
                                    text-overflow: ellipsis;
                                }

                            }
                        }
                    }
                }

                .option-center {
                    align-items: center;
                }
            }
        }
    }
</style>