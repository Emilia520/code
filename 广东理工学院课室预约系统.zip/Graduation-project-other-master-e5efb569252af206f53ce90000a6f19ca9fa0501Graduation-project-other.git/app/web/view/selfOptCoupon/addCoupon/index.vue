<template>
    <div class="app-container" v-loading="loading">
        <el-button class="back-button" icon="el-icon-back" type="primary" @click="$router.back()" circle></el-button>
        <div class="app-title">新增优惠券</div>
        <div class="options">
            <span class="option-key"><b style="color: red">* </b>优惠券类型:</span>
            <el-select class="option-select" v-model="coupon.type" placeholder="请选择" size="mini">
                <el-option
                        v-for="type in couponTypes"
                        :key="type.value"
                        :label="type.name"
                        :value="type.value">
                </el-option>
            </el-select>
        </div>
        <div class="options">
            <span class="option-key"><b style="color: red">* </b>优惠券标题:</span>
            <el-input class="option-value" v-model="coupon.title" maxlength="12" size="mini" clearable></el-input>
        </div>
        <div class="options">
            <span class="option-key"><b style="color: red">* </b>使用限制说明:</span>
            <el-input class="option-value" v-model="coupon.detail" maxlength="80" size="mini" type="textarea"
                      clearable></el-input>
            <el-popover
                    width="400"
                    placement="right"
                    trigger="hover">
                <div style="margin: 10px 0 0 10px">
                    <b>使用限制是对优惠券的进一步说明，有以下参考：</b>
                    <p>A.全场通用：除0元购、免费领、团长礼包等商品均可使用</p>
                    <p>B.单品优惠：仅限指定商品使用</p>
                    <p>C.品类优惠：仅限XX（品类名）品类的商品使用</p>
                    <p>D.活动优惠：仅限xx（品牌名）品牌的商品使用</p>
                </div>
                <el-button icon="el-icon-question"
                           slot="reference"
                           style="font-size: 24px; border: none; background: none"
                           circle />
            </el-popover>
        </div>
        <div class="options">
            <span class="option-key"><b style="color: red">* </b>有效期:</span>
            <div class="option-value-container">
                <el-radio-group style="display: flex; flex-direction: column;" v-model="timespan.startTimeFormat">
                    <el-radio :label="0">
                        <el-date-picker
                                class="option-select"
                                size="mini"
                                v-model="coupon.start_time"
                                placeholder="开始时间"
                                value-format="timestamp"
                                style="margin-right: 10px;"
                                :picker-options="datePickerOption"
                                :disabled="timespan.startTimeFormat === -1">
                        </el-date-picker>
                        至
                        <el-date-picker
                                class="option-select"
                                size="mini"
                                v-model="coupon.end_time"
                                placeholder="结束时间"
                                value-format="timestamp"
                                style="margin-left: 10px;"
                                :picker-options="datePickerOption"
                                :disabled="timespan.startTimeFormat === -1">
                        </el-date-picker>
                    </el-radio>
                    <el-radio :label="-1" style="color: #282828; margin: 10px 0 0 0;">
                        领取后，当天生效。有效天数:
                        <el-input v-model="timespan.validDays"
                                  size="mini"
                                  style="max-width: 70px;"
                                  :disabled="timespan.startTimeFormat === 0"/>
                        天
                    </el-radio>
                </el-radio-group>
            </div>
        </div>
        <div class="options">
            <span class="option-key"><b style="color: red">* </b>设置库存量:</span>
            <div class="option-value-container">
                <el-radio-group v-model="stockType">
                    <el-radio :label="-1" @select="stocks = -1">无限制</el-radio>
                    <el-radio :label="0">
                        其它:
                        <el-input v-model="stocks" size="mini" style="max-width: 80px;"
                                  :disabled="stockType === -1"/>
                        张
                    </el-radio>
                </el-radio-group>
            </div>
        </div>
        <div class="options">
            <span class="option-key">余量预警邮箱:</span>
            <el-input class="option-value" v-model="notifier" placeholder="yinmeiwei@quexb.com" size="mini"></el-input>
        </div>
        <div class="options">
            <span class="option-key"><b style="color: red">* </b>满:</span>
            <span class="option-value" style="color: #282828; font-size: 14px;">
                <el-input v-model="coupon.condition_price" size="mini" style="max-width: 70px;"></el-input>
                <b style="color: red; margin-left: 20px;">* </b>减:
                <el-input v-model="coupon.discount" size="mini" style="max-width: 70px;"></el-input>
            </span>
        </div>
        <div class="options">
            <span class="option-key"><b style="color: red">* </b>可领取用户:</span>
            <el-checkbox-group v-model="legalLevels">
                <el-checkbox class="option-checkbox" label="N">新用户</el-checkbox>
                <el-checkbox class="option-checkbox" label="1">普通用户</el-checkbox>
                <el-checkbox class="option-checkbox" label="2">团长</el-checkbox>
                <el-checkbox class="option-checkbox" label="3">合伙人</el-checkbox>
            </el-checkbox-group>
        </div>
        <div class="options">
            <span class="option-key"><b style="color: red">* </b>投放渠道:</span>
            <el-checkbox-group v-model="legalPlatforms">
                <el-checkbox class="option-checkbox" label="A">全平台</el-checkbox>
                <el-checkbox class="option-checkbox" label="1">APP</el-checkbox>
                <el-checkbox class="option-checkbox" label="2">小程序</el-checkbox>
                <el-checkbox class="option-checkbox" label="3">H5</el-checkbox>
            </el-checkbox-group>
        </div>
        <div class="options">
            <span class="option-key"><b style="color: red">* </b>是否公开:</span>
            <el-radio-group v-model="coupon.overt">
                <el-radio class="option-checkbox" :label="1">公开券</el-radio>
                <el-radio class="option-checkbox" :label="0">隐藏券</el-radio>
            </el-radio-group>
        </div>
        <div class="options" v-if="couponSearchKeywords">
            <span class="option-key">搜索关键字:</span>
            <el-checkbox-group v-model="selectedKeywords">
                <el-checkbox
                        class="option-checkbox"
                        v-for="keyword in Object.keys(couponSearchKeywords)"
                        :label="couponSearchKeywords[keyword]">
                    {{ keyword }}
                </el-checkbox>
            </el-checkbox-group>

        </div>
        <div class="select-container" v-if="coupon.type">
            <div class="select-container-title"><b style="color: red">* </b>{{ _selectAttachmentTitle() }}</div>
            <div class="select-container-content">
                <el-button type="text" icon='el-icon-circle-plus-outline' @click="_addAttachment">新增一列</el-button>
                <div class="selection-list">
                    <div class="select-product-list" v-if="coupon.type === 1">
                        <div class="select-product" v-for="product in selectedProductList">
                            <div class="product-box">商品：{{ `${product.id}" ${product.name}` }} </div>
                            <el-icon class="el-icon-close product-delete" @click.native="_deselectProduct(product)" />
                        </div>
                    </div>
                    <div class="select-product-list" v-if="coupon.type === 2">
                        <div class="select-product" v-for="activity in selectedActivities">
                            <div class="product-box">活动：{{ `${activity.id}" ${activity.name}` }} </div>
                            <el-icon class="el-icon-close product-delete" @click.native="_deselectActivity(activity)" />
                        </div>
                    </div>
                    <div class="select-product-list" v-if="coupon.type === 3">
                        <div class="select-product" v-for="categoryID in selectedCategories">
                            <div class="product-box">品类：{{ `${categoryID}\t${_categoryName(categoryID)}` }} </div>
                            <el-icon class="el-icon-close product-delete" @click.native="_deselectCategory(categoryID)" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="opt-button">
            <el-button class="create-button" type="success" @click="_createCoupon">创建优惠券</el-button>
        </div>
        <!-- 选择商品或活动等关联项目的弹窗 -->
        <el-dialog custom-class="attach-dialog"
                   width="85%"
                   top="50px"
                   :title="_attachmentDialogTile()"
                   :visible.sync="selectAttachmentDialogVisible"
                   v-loading="selectAttachmentDialogLoading"
                   @opened="_onAttachmentDialogShow"
                   >
            <div class="products-container" v-if="coupon.type === 1">
                <el-button type="text" @click="productFilterVisible=!productFilterVisible">
                    {{productFilterVisible ? '收起筛选器' : '展开筛选器'}}
                </el-button>
                <product-filter v-if="productFilterVisible" @getList="getProductList"/>
                <div class="product-list-container">
                    <div class="product-list" v-for="product in productList" :key="product.id">
                        <seckill-product-card :selected="_hasSelectProduct(product)"
                                              :productInfo="product"
                                              @onEdit="_onEditProduct"
                                              @onSelect="_onSelectProduct"/>
                    </div>
                </div>
                <div class="pagination" style="margin-top:20px;">
                    <el-pagination @size-change="_handlePageSizeChange" @current-change="_handlePageChange"
                                   :total="attachmentTotalCount"
                                   :current-page="attachmentPage" :page-sizes="[40, 80, 160]"
                                   :page-size="attachmentPageSize"
                                   layout="total, sizes, prev, pager, next" />
                </div>
            </div>
            <div class="activities-container" v-else-if="coupon.type === 2">
                <akc-act-list
                        ref="akcActList"
                        :appType="1"
                        :onSelectActivity="_onSelectActivity"
                        :hasSelectActivity="_hasSelectActivity" />
            </div>
            <div class="category-container" v-else-if="coupon.type === 3">
                <el-checkbox-group v-model="selectedCategories">
                    <el-checkbox class="category-checkbox"
                                 v-for="category in categoryList"
                                 :label="category.id"
                                 :disabled="_shouldDisableCategoryCheckBox(category)">
                        {{ category.tag_name }}
                        <el-popover
                                v-if="!_onlySupportWxPlatform() && !_categoryAvailableForWx(category)"
                                width="20"
                                placement="right"
                                trigger="hover">
                            <span style="font-size: 12px">小程序不可用</span>
                            <el-button icon="el-icon-warning-outline"
                                       slot="reference"
                                       style="font-size: 10px; border: none; background: none; color: red; padding: 0"
                                       circle />
                        </el-popover>
                    </el-checkbox>
                </el-checkbox-group>
            </div>
        </el-dialog>
        <!-- 编辑商品弹窗 -->
        <div class='edit-dialog-container'>
            <el-dialog :visible.sync="editProductDialogVisible" class="edit-dialog">
                <el-form :model="editProductForm" ref="editProductForm">
                    <el-form-item label="商品描述" label-width="400" prop="name">
                        <el-input v-model="editProductForm.name" placeholder="商品描述" size="mini" clearable></el-input>
                    </el-form-item>
                    <el-form-item label="排序" label-width="400" prop="sort">
                        <el-input v-model.number="editProductForm.sort" placeholder="排序" size="mini"
                                  clearable></el-input>
                    </el-form-item>
                    <el-form-item
                            v-if="$store.getters.role < 3 && editProductForm.goods && editProductForm.goods.type === 0"
                            label="加价" abel-width="400" prop="addPrice">
                        <el-input v-model.number="editProductForm.addPrice" placeholder="加价" size="mini"
                                  clearable></el-input>
                    </el-form-item>
                    <el-form-item v-if="$store.getters.role < 3" label="佣金" label-width="400" prop="akcProfit">
                        <el-input v-model.number="editProductForm.akcProfit" placeholder="佣金" size="mini"
                                  clearable></el-input>
                    </el-form-item>
                    <el-form-item label="商品首图" class="time-width" label-width="120px">
                        <el-upload
                                class="avatar-uploader"
                                :action="uploadImgNew"
                                :show-file-list="false"
                                :on-success="_handleAvatarSuccess"
                                :list-type="editProductForm.image ? '' : 'picture-card'">
                            <img v-if="editProductForm.image" :src="editProductForm.image" class="avatar" width="120"
                                 height="120"
                                 alt="">
                            <i v-else class="el-icon-plus"></i>
                        </el-upload>
                    </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                    <el-button @click="editProductDialogVisible = false">取 消</el-button>
                    <el-button type="primary" @click="_confirmEditProduct">确 定</el-button>
                </div>
            </el-dialog>
        </div>
    </div>
</template>

<script>
  import SeckillProductCard from '@/component/Seckill/seckillProductCard';
  import ProductFilter from '@/component/AiKuCun/productFilter';
  import AkcActList from '@/component/AiKuCun/activityList';

  import { allOnSaleGoods, updateGoodsInfo, listTag, listTagForWXMiniProgram } from '../../../api/groupbuy';
  import { uploadImgNew } from '../../../api/uploadImg';
  import { productsOverallIDs, addCoupon, couponSearchKeywords } from '../../../api/selfOptCoupon';

  export default {
    components: { SeckillProductCard, ProductFilter, AkcActList },
    data() {
      return {
        loading: false,
        uploadImgNew,
        couponTypes: [
          { name: '全场通用', value: 0 },
          { name: '指定商品', value: 1 },
          { name: '指定活动', value: 2 },
          { name: '指定品类', value: 3 },
        ],
        coupon: {
          type: null,
          overt: 1,
          stock: -1,
        },
        timespan: {
          startTimeFormat: 0, // 存储优惠券的生效开始时间类型 0: 日期， -1: 无效
          validDays: null, // 有效时长，单位：天
        },
        stocks: null,
        stockType: -1, // 库存类型，-1无限制，其它具体数字
        notifier: null,
        legalLevels: [],
        legalPlatforms: [],
        selectAttachmentDialogVisible: false,
        selectAttachmentDialogLoading: false,
        editProductDialogVisible: false,
        assignIDs: [],

        // 关联数据分页
        attachmentTotalCount: 0,
        attachmentPage: 1,
        attachmentPageSize: 40,

        // 商品列表相关
        productFetchParams: {},
        productList: [],
        selectedProductList: [],
        editProductForm: {},
        productFilterVisible: false,

        // 活动列表相关
        selectedActivities: [],

        // 分类相关
        selectedCategories: [],
        categoryList: null,
        categoryListForWx: null, // 微信小程序可用的分类列表

        // 优惠券的搜索关键字
        couponSearchKeywords: {},
        selectedKeywords: [],

        // 时间选择
        datePickerOption: {
          shortcuts: [
            {
              text: '今天',
              onClick(picker) {
                picker.$emit('pick', new Date());
              }
            },
            {
              text: '3天后',
              onClick(picker) {
                const date = new Date();
                date.setTime(Date.now() + 3600 * 1000 * 24 * 3);
                picker.$emit('pick', date);
              }
            },
            {
              text: '一周后',
              onClick(picker) {
                const date = new Date();
                date.setTime(Date.now() + 3600 * 1000 * 24 * 7);
                picker.$emit('pick', date);
              }
            },
          ]
        },
      };
    },
    created() {
      this._parseRouterParams();
      this._fetchCouponSearchKeywords();
    },
    methods: {
      getProductList(params) {
        this.selectAttachmentDialogLoading = true;

        if (params) {
          this.productFetchParams = params;
          this.attachmentPage = params.page;
          this.attachmentPageSize = params.pageSize;
        }

        allOnSaleGoods(this.productFetchParams).then(response => {
          const resData = response.data;
          this.selectAttachmentDialogLoading = false;
          if (resData.code === 10000) {
            this.attachmentTotalCount = resData.count;
            this.productList = resData.data;
          } else {
            this.$message.error(resData.msg || '获取商品列表失败');
          }
        });
      },

      _fetchCouponSearchKeywords() {
        couponSearchKeywords().then(response => {
          this.couponSearchKeywords = response.data.data;
          console.log(this.couponSearchKeywords);
        });
      },

      _fetchCategoryList() {
        this.selectAttachmentDialogLoading = true;
        listTag().then(response => {
          this.categoryList = response.data.data;
          listTagForWXMiniProgram().then(response => {
            this.categoryListForWx = response.data.data;
            this.selectAttachmentDialogLoading = false;
            this.$message.success('获取分类列表成功');
          });
        });
      },

      _categoryAvailableForWx(category) {
        if (isNaN(category.id)) {
          return false;
        }

        return this.categoryListForWx.findIndex(item => item.id === category.id) !== -1;
      },

      _onlySupportWxPlatform() {
        return Array.isArray(this.legalPlatforms) &&
        this.legalPlatforms.length === 1 &&
        this.legalPlatforms.indexOf('2') !== -1;
      },

      _shouldDisableCategoryCheckBox(category) {
        return this._onlySupportWxPlatform() && this._categoryAvailableForWx(category);
      },

      // 确认创建优惠券
      _createCoupon() {
        const error = this._testUserInput();
        if (error) {
          this.$message.error(error);
          return;
        }

        this.loading = true;
        // 整理数据并转换必要的ID后开始写数据库
        this._beforeCreation().then((attachIDs) => {
          this.coupon.attach_ids = attachIDs;

          // 开始写数据库
          addCoupon(this.coupon).then(response => {
            this.loading = false;
            if (response.data.code !== 10000) {
              this.$message.error(response.data.msg || '新增优惠券失败');
            } else {
              this.$message.success('添加优惠券成功');
              this.$router.back();
            }
          });
        }).catch((error) => {
          this.loading = false;
          this.$message.error(error);
        });
      },

      // 将部分字段重新整理
      _beforeCreation() {
        if (this.timespan.startTimeFormat === -1) {
          this.coupon.start_time = -1;
          this.coupon.end_time = this.timespan.validDays;
        } else {
          // 将结束时间安排在当天的23点59分59秒
          const endDate = new Date(this.coupon.end_time);
          endDate.setHours(23);
          endDate.setMinutes(59);
          endDate.setSeconds(59);

          this.coupon.start_time /= 1000;
          this.coupon.end_time = Math.floor(endDate.getTime() / 1000);
        }

        if (typeof this.coupon.up_time !== 'undefined') {
          this.coupon.up_time /= 1000;
        }

        // 转换用户规则和平台规则
        const roleRule = `${this.legalLevels.join(';')}`;
        const platformRule = `${this.legalPlatforms.join(';')}`;

        this.coupon.rule = JSON.stringify({ role: roleRule, channel: platformRule });
        this.coupon.status = 0; // 需要手工上架
        this.coupon.stock = this.stockType === -1 ? -1 : this.stocks;
        this.coupon.keyword = this.selectedKeywords.join(',');

        return new Promise((resolve, reject) => {
          if (this.coupon.type !== 1) {
            if (this.coupon.type === 2) {
              this.assignIDs = this.selectedActivities.map(item => item.id);
            } else if (this.coupon.type === 3) {
              this.assignIDs = this.selectedCategories;
            }
            resolve(this.assignIDs);
          } else {
            // 将商品ID转换为product_overall表的主键ID
            const productIDs = this.selectedProductList.map(item => item.id);
            productsOverallIDs({ product_ids: productIDs }).then(response => {
              const resData = response.data;
              if (resData.code !== 10000) {
                reject(resData.msg || '获取商品对应overall表ID列表出错');
              } else {
                this.assignIDs = resData.data;
                resolve(this.assignIDs);
              }
            });
          }
        });
      },

      _parseRouterParams() {
        const coupon = this.$route.params.coupon;
        const attachment = this.$route.params.attachments;

        if (coupon) {
          this.coupon = coupon;

          if (this.coupon.start_time && this.coupon.start_time !== -1) {
            this.coupon.start_time *= 1000;
            this.coupon.end_time *= 1000;
          } else {
            this.timespan.startTimeFormat = -1;
            this.timespan.validDays = this.coupon.end_time;
          }

          if (this.coupon.up_time) {
            this.coupon.up_time *= 1000;
          }

          if (this.coupon.stock === -1) {
            this.stocks = null;
            this.stockType = -1;
          } else {
            this.stockType = 0;
            this.stocks = this.coupon.stock;
          }

          if (this.coupon.rule) {
            if (this.coupon.rule.role) {
              this.legalLevels = this.coupon.rule.role.split(';');
            }
            if (this.coupon.rule.channel) {
              this.legalPlatforms = this.coupon.rule.channel.split(';');
            }
          }

          if (this.coupon.keyword) {
            this.selectedKeywords = this.coupon.keyword.split(',');
          }

          delete this.coupon.id;

          if (attachment) {
            if (coupon.type === 1) {
              this.selectedProductList = attachment;
            } else if (coupon.type === 2) {
              this.selectedActivities = attachment;
            } else if (coupon.type === 3) {
              this.selectedCategories = attachment;
              this._fetchCategoryList();
            }
          }
        }
      },

      _addAttachment() {
        this.selectAttachmentDialogVisible = true;
      },

      _onAttachmentDialogShow() {
        if (this.coupon.type === 3 && (!this.categoryList || this.categoryList.length === 0)) {
          this._fetchCategoryList();
        }
      },

      _attachmentDialogTile() {
        return this.coupon.type === 1 ? '选择商品' : (this.coupon.type === 2 ? '选择活动' : '选择分类');
      },

      // 选择关联项目的标题
      _selectAttachmentTitle() {
        if (this.coupon.type === 0) {
          return null;
        }

        const attachment = this.coupon.type === 1 ? '商品' : (this.coupon.type === 2 ? '活动' : '品类');
        return `优惠券使用${attachment}管理`;
      },

      // 是否选择某个商品
      _hasSelectProduct(product) {
        return this.selectedProductList.findIndex(item => item.id === product.id) !== -1;
      },

      _onSelectProduct(product) {
        const index = this.selectedProductList.findIndex(item => item.id === product.id);
        if (index === -1) {
          this.selectedProductList.push(product);
        } else {
          this.selectedProductList.splice(index, 1);
        }
      },

      _deselectProduct(product) {
        const index = this.selectedProductList.findIndex(item => item.id === product.id);
        if (index !== -1) {
          this.selectedProductList.splice(index, 1);
        }
      },

      _onEditProduct(product) {
        this.editProductForm.goods = product;
        this.editProductForm.id = product.id;
        this.editProductForm.name = product.name;
        this.editProductForm.akcPrice = product.akc_price;
        this.editProductForm.akcSettlementPrice = product.akc_settlement_price;
        this.editProductForm.addPrice = product.add_price;
        this.editProductForm.akc_price = product.akc_price;
        this.editProductForm.akcProfit = product.akc_profit;
        this.editProductForm.sort = product.qxb_sort;
        this.editProductForm.image = product.picture[0];
        this.editProductDialogVisible = true;
      },

      _handleAvatarSuccess(res) {
        this.editProductForm.image = res.data;
      },

      _confirmEditProduct() {
        this.loading = true;
        const addPrice = this.editProductForm.addPrice;
        const settlementPrice = this.editProductForm.akc_price + addPrice;
        const goods = this.editProductForm.goods;
        const name = this.editProductForm.name;
        const image = this.editProductForm.image;
        const sort = this.editProductForm.sort;
        const akcProfit = this.editProductForm.akcProfit;
        const pictures = goods.picture.slice();
        const akcTagPrice = goods.akc_tag_price;
        pictures[0] = image;
        updateGoodsInfo({
          appType: 1,
          id: this.editProductForm.id,
          name,
          addPrice,
          akcProfit,
          sort,
          settlementPrice,
          akcTagPrice,
          picture: JSON.stringify(pictures)
        }).then(response => {
          this.loading = false;
          const res = response.data;
          if (res.code === 10000) {
            this.$message.success('更新成功');
            goods.add_price = parseFloat(parseFloat(addPrice).toFixed(2));
            goods.settlement_price = parseFloat(parseFloat(settlementPrice).toFixed(2));
            goods.name = name;
            goods.picture = pictures;
            goods.qxb_sort = sort;
            this.editProductDialogVisible = false;
          } else {
            this.$message.error('更新失败');
          }
        });
      },

      _handlePageSizeChange(pageSize) {
        this.attachmentPageSize = pageSize;

        if (this.coupon.type === 1) {
          // 筛选商品
          this.productFetchParams.pageSize = pageSize;
          this.getProductList(this.productFetchParams);
        }
      },

      _handlePageChange(page) {
        this.attachmentPage = page;

        if (this.coupon.type === 1) {
          // 筛选商品
          this.productFetchParams.page = page;
          this.getProductList(this.productFetchParams);
        }
      },

      _onSelectActivity(activity) {
        const index = this.selectedActivities.findIndex(item => item.id === activity.id);
        if (index === -1) {
          this.selectedActivities.push(activity);
        } else {
          this.selectedActivities.splice(index, 1);
        }
      },

      _hasSelectActivity(activity) {
        return this.selectedActivities.findIndex(item => item.id === activity.id) !== -1;
      },

      _deselectActivity(activity) {
        const index = this.selectedActivities.findIndex(item => item.id === activity.id);
        if (index !== -1) {
          this.selectedActivities.splice(index, 1);
        }
      },

      _categoryName(categoryID) {
        if (!this.categoryList) {
          return '';
        }

        return this.categoryList.find(item => item.id === categoryID).tag_name;
      },

      _deselectCategory(categoryID) {
        const index = this.selectedCategories.indexOf(categoryID);
        if (index !== -1) {
          this.selectedCategories.splice(index, 1);
        }
      },

      // 校验用户输入
      _testUserInput() {
        let errorMsg;
        do {
          if (this.coupon.type === null) {
            errorMsg = '请选择优惠券类型';
            break;
          }
          if (!this._testUserTextInput(this.coupon.title)) {
            errorMsg = '优惠券标题为空或带有非法字符';
            break;
          }
          if (!this.coupon.detail) {
            errorMsg = '请填写优惠券使用限制说明';
            break;
          }
          if (!this._testStock()) {
            errorMsg = '请填写正确的库存量';
            break;
          }
          if (this.timespan.startTimeFormat === 0 && (!this.coupon.start_time || !this.coupon.end_time)) {
            errorMsg = '请选择正确的生效时间段';
            break;
          }
          if (this.timespan.startTimeFormat === -1 && this.timespan.validDays <= 0) {
            errorMsg = '请填写正确的有效天数';
            break;
          }
          if (!this._testDiscountCondition()) {
            errorMsg = '请填写正确的满减规则';
            break;
          }
          if (this.legalLevels.length === 0) {
            errorMsg = '请选择投放的用户群';
            break;
          }
          if (this.legalPlatforms.length === 0) {
            errorMsg = '请选择投放渠道';
            break;
          }
          // eslint-disable-next-line no-constant-condition
        } while (false);
        return errorMsg;
      },

      // 至能包含汉字、数字、字母、下划线
      _testUserTextInput(inputText) {
        if (!inputText) {
          return false;
        }

        const regex = new RegExp('^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$');
        return regex.test(inputText);
      },

      // 满减条件不能为空并且条件金额不能小于等于优惠金额
      _testDiscountCondition() {
        if (!this.coupon.condition_price || !this.coupon.discount) {
          return false;
        }

        if (isNaN(this.coupon.condition_price) || isNaN(this.coupon.discount)) {
          return false;
        }

        const price = parseFloat(this.coupon.condition_price);
        const discount = parseFloat(this.coupon.discount);
        return price > discount;
      },
  
      _testStock() {
        if (this.stockType === -1) {
          return true;
        }

        return this.stocks && !isNaN(this.stocks) && this.stocks > 0;
      },
    },
  };
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .app-container {
        font-family: "华文宋体", Helvetica, serif;

        .app-title {
            margin-top: 20px;
        }

        .options {
            margin: 20px 0 10px 0;
            display: flex;
            flex-direction: row;
            justify-content: flex-start;
            align-items: center;

            .option-key {
                font-size: 14px;
                min-width: 100px;
                color: #282828;
                text-align: right;
                margin-right: 50px;
            }

            .option-select {
                max-width: 150px;
            }

            .option-value {
                max-width: 400px;
            }

            .option-checkbox {
                min-width: 80px;
            }
        }

        .options-center {
            padding-left: 120px;
            font-size: 14px;
            color: #282828;
        }

        .select-container {
            margin-top: 30px;

            .select-container-title {
                font-size: 14px;
                color: #282828;
                margin-bottom: 10px;
            }

            .select-container-content {
                border: 1px #eee solid;
                padding: 10px 20px;

                .selection-list {
                    .select-product-list {
                        display: flex;
                        justify-content: flex-start;
                        align-items: center;
                        flex-wrap: wrap;

                        .select-product {
                            width: 300px;
                            margin-right: 30px;
                            margin-top: 10px;
                            display: flex;
                            justify-content: flex-start;
                            align-items: center;

                            .product-box {
                                font-size: 14px;
                                color: #555;
                                white-space: nowrap;
                                overflow: hidden;
                                text-overflow: ellipsis;
                            }

                            .product-delete {
                                color: red;
                                margin-left: 5px;
                                display: none;
                            }
                        }

                        .select-product:hover {
                            .product-delete {
                                display: inline;
                            }
                        }
                    }
                }
            }
        }

        .opt-button {
            margin-top: 30px;

            .create-button {
                min-width: 150px;
            }
        }

        .attach-dialog {
            .product-list-container {
                display: flex;
                flex-direction: row;
                justify-content: flex-start;
                flex-wrap: wrap;
                max-height: 700px;
                overflow: scroll;
            }

            .activities-container {
                max-height: 800px;
                overflow: scroll;
            }

            .category-container {
                display: flex;
                justify-content: flex-start;
                align-items: center;
                flex-wrap: wrap;

                .category-checkbox {
                    margin-left: 30px;
                    min-width: 100px;
                }
            }
        }

        .add-dialog-container {
            .add-dialog-title {
                font-size: 18px;
                font-weight: bold;
                margin-bottom: 40px;
            }

            .option {
                display: flex;
                flex-direction: row;
                align-items: center;
                color: #999;
                margin-bottom: 10px;

                .option-key {
                    width: 100px;
                }

                .option-input {
                    max-width: 250px;
                }
            }
        }
    }
</style>