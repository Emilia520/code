<template>
    <div class="app-container">
        <el-row>
            <el-col :span="24">
                <div class="header-title">会员信息展示</div>
            </el-col>
            <div style="padding-bottom: 30px">
                <el-button type="primary" @click="addUserButton" v-show="!addUserVisible && $store.getters.role < 3">
                    创建一个用户
                </el-button>
            </div>
            <el-row v-show="addUserVisible" style="padding-bottom: 50px">
                <el-form :model="addForm" ref="addForm">
                    <el-form-item label="用户名" :label-width="formLabelWidth" prop="name">
                        <el-input v-model="addForm.name" placeholder="用户名" size="mini" clearable
                                  style="width: 200px"></el-input>
                    </el-form-item>
                    <el-form-item label="电话" :label-width="formLabelWidth" prop="phone">
                        <el-input v-model="addForm.phone" placeholder="电话号码" size="mini" clearable
                                  style="width: 200px" @change="checkPhone"></el-input>
                        <span v-if="!phoneVisible" style="color: #c9302c">电话号码为空或已被使用</span>
                    </el-form-item>
                    <!--<el-form-item label="上级id" :label-width="formLabelWidth" prop="up_id">
                        <el-input v-model="addForm.up_id" placeholder="上级id(无上级填-1)" size="mini" clearable
                                  style="width: 200px"></el-input>
                    </el-form-item>-->
                    <el-form-item label="邀请码" :label-width="formLabelWidth" prop="invitationCode">
                        <el-input v-model="addForm.invitationCode" placeholder="邀请码" size="mini" clearable
                                  style="width: 200px" @change="checkCode"></el-input>
                        <span v-if="!invitationCodeVisible" style="color: #c9302c">邀请码为空或已被使用</span>
                    </el-form-item>
                    <el-form-item label="用户角色" :label-width="formLabelWidth"
                                  prop="role_id">
                        <el-select v-model="addForm.role_id" placeholder="请选择用户角色" size="mini">
                            <el-option label="普通会员" value="1"></el-option>
                            <el-option label="团长" value="2"></el-option>
                            <el-option label="合伙人" value="3"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="设置地区" :label-width="formLabelWidth"
                                  prop="addr">
                        <template>
                            <el-select v-model="addForm.province_id" placeholder="请选择省" size="mini" @change="getCity">
                                <el-option
                                        v-for="item in addForm.provinceData"
                                        :key="item.id"
                                        :label="item.province"
                                        :value="item.index">
                                </el-option>
                            </el-select>
                        </template>
                        <template>
                            <el-select v-model="addForm.city_id" placeholder="请选择市" size="mini"
                                       style="margin-left: 20px;" @change="getArea">
                                <el-option
                                        v-for="item in addForm.cityData"
                                        :key="item.id"
                                        :label="item.city"
                                        :value="item.index">
                                </el-option>
                            </el-select>
                        </template>
                        <template>
                            <el-select v-model="addForm.area_id" placeholder="请选择区" size="mini"
                                       style="margin-left: 20px;">
                                <el-option
                                        v-for="item in addForm.areaData"
                                        :key="item.id"
                                        :label="item.area"
                                        :value="item.id">
                                </el-option>
                            </el-select>
                        </template>
                    </el-form-item>
                    <el-form-item label="头像" :label-width="formLabelWidth" prop="avatar_url">
                        <el-upload class="avatar-uploader" :action="uploadImg" :show-file-list="false"
                                   :on-success="handleAvatarSuccess"
                                   :list-type="addForm.avatar_url? '' : 'picture-card'">
                            <div class="container">
                                <img v-if="addForm.avatar_url" :src="addForm.avatar_url" class="avatar" alt="">
                                <i v-else class="el-icon-plus"></i>
                            </div>
                        </el-upload>
                    </el-form-item>
                </el-form>
                <el-button type="primary" @click="confirmForm(addForm)" size="mini">创建</el-button>
                <el-button type="info" @click="cancelAdd" size="mini">取消</el-button>
            </el-row>
            <!-- 筛选条件 start -->
            <el-col :span="24">
                <el-form :inline="true" :model="formInline" class="demo-form-inline">
                    <el-form-item label="会员id">
                        <el-input v-model="formInline.id" placeholder="会员id" size="mini" clearable
                                  @change="onSubmit"></el-input>
                    </el-form-item>
                    <el-form-item label="手机号码">
                        <el-input v-model="formInline.phone" placeholder="手机号码" size="mini" clearable
                                  @change="onSubmit"></el-input>
                    </el-form-item>
                    <el-form-item label="会员昵称">
                        <el-input v-model="formInline.name" placeholder="会员昵称" size="mini" clearable
                                  @change="onSubmit"></el-input>
                    </el-form-item>
                    <el-form-item label="会员等级">
                        <!-- <el-input v-model="formInline.platform" placeholder="投放条件" size="mini" clearable></el-input> -->
                        <el-select v-model="formInline.role_id" placeholder="请选择" size="mini">
                            <el-option label="无" value="0" @change="onSubmit"></el-option>
                            <el-option label="普通会员" value="1" @change="onSubmit"></el-option>
                            <el-option label="团长" value="2" @change="onSubmit"></el-option>
                            <el-option label="合伙人" value="3" @change="onSubmit"></el-option>
                            <el-option label="校品团合伙人" value="4" @change="onSubmit"></el-option>
                            <el-option label="校品团普通会员" value="5" @change="onSubmit"></el-option>
                            <el-option label="校品团团长" value="6" @change="onSubmit"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" size="mini" @click="onSubmit">筛选</el-button>
                    </el-form-item>
                </el-form>
            </el-col>
            <!-- 筛选条件 end -->
            <!-- 表格 start -->
            <el-col :span="24">
                <el-table
                        :data="tableData"
                        border
                        style="width: 100%"
                        v-loading="loading">
                    <el-table-column
                            fixed
                            prop="id"
                            label="会员id"
                            width="120">
                    </el-table-column>
                    <el-table-column
                            prop="phone"
                            label="手机号码"
                            width="120">
                    </el-table-column>
                    <el-table-column
                            prop="name"
                            label="会员昵称"
                            width="120">
                    </el-table-column>
                    <el-table-column
                            label="会员头像"
                            width="120">
                        <template slot-scope="scope">
                            <img :src="scope.row.avatar_url" alt="" style="width:80px;height:80px;">
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="会员等级"
                            width="120">
                        <template slot-scope="scope">
                            <span v-if="scope.row.role_id==1">普通会员</span>
                            <span v-else-if="scope.row.role_id==2">团长</span>
                            <span v-else-if="scope.row.role_id==3">合伙人</span>
                            <span v-else-if="scope.row.role_id==4">校园合伙人</span>
                            <span v-else-if="scope.row.role_id==5">校品团普通会员</span>
                            <span v-else-if="scope.row.role_id==7">校品团团长</span>
                            <span v-else>神秘身份</span>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="注册时间"
                            width="200">
                        <template slot-scope="scope">
                            <div>{{scope.row.create_time}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="激活时间"
                            width="200">
                        <template slot-scope="scope">
                            <div>{{scope.row.activate_time}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="团长id"
                            width="80">
                        <template slot-scope="scope">
                            <div>{{scope.row.captain_id}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="合伙人id"
                            width="80">
                        <template slot-scope="scope">
                            <div>{{scope.row.partner_id}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="上级id"
                            width="80">
                        <template slot-scope="scope">
                            <div>{{scope.row.up_id}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="操作"
                            width="280">
                        <template slot-scope="scope">
                            <el-button type="primary" size="small" @click="editUserButton(scope.row)">编辑</el-button>
                            <el-button type="danger" size="small" @click="upQxbCaptainButton(scope.row)"
                                       v-show="$store.getters.role < 3 && scope.row.role_id === 1">升级团长
                            </el-button>
                            <el-button type="danger" size="small" @click="upQxbPartnerButton(scope.row)"
                                       v-show="$store.getters.role < 3 && scope.row.role_id === 1 || scope.row.role_id === 2">升级合伙人
                            </el-button>
                        </template>
                    </el-table-column>
                    <!-- <el-table-column
                      prop="pushPhone"
                      label="	推荐人手机"
                      width="120">
                    </el-table-column>
                    <el-table-column
                      label="锁粉url">
                      <template slot-scope="scope">
                        <a :href="scope.row.lockFansCode" target="_blank">{{scope.row.lockFansCode}}</a>
                      </template>
                    </el-table-column> -->
                    <!-- <el-table-column
                      height="80"
                      label="入口照片预览"
                      width="150">
                      <template slot-scope="scope">
                        <img :src="scope.row.img" alt="" style="width:80px;height:80px;">
                      </template>
                    </el-table-column> -->
                    <!-- <el-table-column
                      label="操作"
                      width="180">
                      <template slot-scope="scope">
                        <el-button type="danger" @click="deleteBanner(scope.row.id, scope.$index)" size="small">删除</el-button>
                        <el-button type="primary" size="small" @click="editBannerButton(scope.row.id)">编辑</el-button>
                      </template>
                    </el-table-column> -->
                </el-table>
            </el-col>
            <!-- 表格 end -->
            <!-- 弹层 start -->
            <el-col :span="24">
                <el-dialog title="输入秘钥" :visible.sync="dialogFormVisible" width="300"
                           @close="cancel" style="width: 30%; margin:0 auto">
                    <el-form :model="addForm" ref="addForm">
                        <el-form-item label="需要升级用户" :label-width="formLabelWidth">
                            <el-input :disabled="true" v-model="addForm.name" placeholder="用户名" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                    </el-form>
                    <el-form :model="addForm" ref="addForm">
                        <el-form-item label="秘钥" :label-width="formLabelWidth">
                            <el-input v-model="addForm.key" placeholder="秘钥" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                    </el-form>
                    <div slot="footer" class="dialog-footer">
                        <el-button @click="cancel('addForm')">取 消</el-button>
                        <el-button type="primary" @click="upQxbCaptain(addForm)">确 定</el-button>
                    </div>
                </el-dialog>
            </el-col>
            <!-- 弹层 end -->
            <!-- 分页 start -->
            <el-col :span="24">
                <div class="pagination" style="margin-top:20px;">
                    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                                   :current-page="formInline.page" :page-sizes="[10, 20, 30, 40]"
                                   :page-size="formInline.pageSize" layout="total, sizes, prev, pager, next"
                                   :total="totalcount">
                    </el-pagination>
                </div>
            </el-col>
            <!-- 分页 end -->
        </el-row>
    </div>
</template>

<script>
  import {getUserMessage, upQxbCaptain, findRegion, checkCode, checkPhone, createUser,upQxbPartner} from '@/api/userManage';
  import {timestampToTime} from 'utils/chanageTime';
  import {uploadImg} from '@/api/uploadImg';

  export default {
    data() {
      return {
        dialogFormVisible: false, // 弹层显示与否
        addUserVisible: false, // 弹层显示与否
        invitationCodeVisible: true, // 邀请码是否正确
        phoneVisible: true, // 电话是否被使用
        upGrade: 0, // 2升级团长,3升级合伙人
        totalcount: 0,
        loading: false,
        formInline: {
          id: '',
          pageNum: 1,
          pageSize: 10,
          phone: '',
          name: '',
          shop: '',
          role_id: ''
        },
        uploadImg: '',
        tableData: [],
        formLabelWidth: '120px',
        addForm: {
          name: '',
          key: '',
          phone: '',
          avatar_url: '',
          provinceData: [{
            id: null,
            province: null,
            index: 0,
            citys: null
          }],
          cityData: [{
            id: null,
            city: null,
            index: 0,
            areas: null
          }],
          areaData: [{
            id: null,
            area: null
          }],
          up_id: null,
          role_id: null,
          province_id: null,
          city_id: null,
          area_id: null,
          invitationCode: null
        },
      };
    },
    created() {
      // 筛选页面初始化
      this.formInline.pageNum = 1;
      this.formInline.pageSize = 10;
      this.getList();
      this.uploadImg = uploadImg;
    },
    methods: {
      onSubmit() {
        this.getList();
      },
      getList() {
        console.log('formInline', this.formInline);
        this.loading = true;
        // 请求列表
        getUserMessage(this.formInline).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.tableData = res.data.data;
            this.loading = false;
            this.totalcount = res.data.totalNum;
            this.tableData.map((item, index) => {
              if (item != null) {
                item.create_time = (item == null) ? '' : timestampToTime(item.create_time);
                item.activate_time = (item == null) ? '' : timestampToTime(item.activate_time);
              }
            });
          }
        });
      },
      // 分页
      handleSizeChange(pageSize) {
        this.formInline.pageSize = pageSize;
        this.getList();
      },
      // 页码变化时触发
      handleCurrentChange(page) {
        this.formInline.pageNum = page;
        this.getList();
      },
      editUserButton(data) {
        alert('该功能暂未开放');
      },
      addUserButton() {
        this.addForm = {};
        this.findRegion();
        this.addUserVisible = true;
      },
      upQxbCaptainButton(data) {
        this.addForm.name = data.name;
        this.addForm.phone = data.phone;
        this.upGrade = 2;
        this.dialogFormVisible = true;
      },
      upQxbPartnerButton(data) {
        this.addForm.name = data.name;
        this.addForm.phone = data.phone;
        this.upGrade = 3;
        this.dialogFormVisible = true;
      },
      cancel() {
        this.dialogFormVisible = false;
      },
      cancelAdd() {
        this.addUserVisible = false;
      },
      handleAvatarSuccess(res, file) {
        this.addForm.avatar_url = res.data;
      },
      beforeAvatarUpload(file) {
      },
      upQxbCaptain(data) {
        if (this.upGrade === 2) {
          upQxbCaptain(data).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.$message({
                message: '成功！',
                type: 'success'
              });
            } else {
              this.$message({
                message: res.msg,
                type: 'eorr'
              });
            }
            this.dialogFormVisible = false;
            this.getList();
          });
        } else {
          upQxbPartner(data).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.$message({
                message: '成功！',
                type: 'success'
              });
            } else {
              this.$message({
                message: res.msg,
                type: 'eorr'
              });
            }
            this.dialogFormVisible = false;
            this.getList();
          });
        }
      },

      findRegion(data) {
        findRegion(data).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.addForm.provinceData = res.data;
            for (const i in this.addForm.provinceData) {
              this.addForm.provinceData[i].index = i;
              for (const j in this.addForm.provinceData[i].citys) {
                this.addForm.provinceData[i].citys[j].index = j;
              }
            }
          }
        });
      },

      // 获得市
      getCity() {
        this.addForm.cityData = this.addForm.provinceData[this.addForm.province_id].citys;
      },
      // 获得区
      getArea() {
        this.addForm.areaData = this.addForm.cityData[this.addForm.city_id].areas;
      },
      // 检查邀请码
      checkCode() {
        checkCode({ code: this.addForm.invitationCode }).then(response => {
          const res = response.data;
          if (res.code !== 10000) {
            this.invitationCodeVisible = false;
          } else {
            this.invitationCodeVisible = true;
          }
        });
      },
      // 检查邀请码
      checkPhone() {
        checkPhone({ phone: this.addForm.phone }).then(response => {
          const res = response.data;
          if (res.code !== 10000) {
            this.phoneVisible = false;
          } else {
            this.phoneVisible = true;
          }
        });
      },
      confirmForm(addForm) {
        if (! this.invitationCodeVisible || ! this.phoneVisible || ! addForm.phone || ! addForm.area_id || ! addForm.role_id) {
          alert('参数错误');
        } else {
          const data = {};
          data.phone = addForm.phone;
          data.name = addForm.name;
          data.avatar_url = addForm.avatar_url;
          data.area_id = addForm.area_id;
          data.invitationCode = addForm.invitationCode;
          data.up_id = addForm.up_id;
          data.role_id = addForm.role_id;
          createUser(data).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.addForm = {};
              this.$message({
                message: '成功！',
                type: 'success'
              });
            } else {
              this.addForm = {};
              this.$message({
                message: res.msg,
                type: 'eorr'
              });
            }
            this.addUserVisible = false;
            this.getList();
          });
        }
      },
    }
  };
</script>

<style scoped>

</style>
