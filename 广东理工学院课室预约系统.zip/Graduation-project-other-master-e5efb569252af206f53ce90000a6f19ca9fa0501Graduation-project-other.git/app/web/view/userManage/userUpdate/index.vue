<template>
  <div class="app-container">
    <el-row>
      <el-col :span="24">
        <div class="header-title">用户升级订单查询</div>
      </el-col>
      <!-- 筛选条件 start -->
      <el-col :span="24">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
          <el-form-item label="用户id">
            <el-input v-model="formInline.accountId" placeholder="用户id" size="mini" clearable></el-input>
          </el-form-item>
          <el-form-item label="订单号">
            <el-input v-model="formInline.orderCode" placeholder="订单号" size="mini" clearable></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onSubmit">筛选</el-button>
          </el-form-item>
        </el-form>
      </el-col>
      <!-- 筛选条件 end -->
      <!-- 表格 start -->
      <el-col :span="24">
          <el-table
            :data="tableData"
            border
            style="width: 100%"
            v-loading="loading">
            <el-table-column
              fixed
              prop="accountId"
              label="用户id"
              width="120">
            </el-table-column>
            <el-table-column
              prop="lv"
              label="升级身份"
              width="120">
            </el-table-column>
            <el-table-column
              prop="price"
              label="金额"
              width="120">
            </el-table-column>
            <el-table-column
              prop="expressNum"
              label="发货信息"
              width="120">
            </el-table-column>
            <el-table-column
              prop="orderCode"
              label="订单号"
              width="120">
            </el-table-column>
            <el-table-column
              prop="createTime"
              label="下单时间"
              width="180">
            </el-table-column>
            <el-table-column
              label="受益人和金额">
              <template slot-scope="scope">
                <div v-if="scope.row.accountSplit">
                  <div v-for="(item, index) in scope.row.accountSplit" :key="index">
                    <span>{{item.beneficiaryId}} &nbsp;</span>
                    <span>￥{{item.amount}}</span>
                  </div>
                </div>
              </template>
            </el-table-column>
          </el-table>     
      </el-col>
      <!-- 表格 end -->
      <!-- 分页 start -->
      <el-col :span="24">
        <div class="pagination" style="margin-top:20px;">
          <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="formInline.page" :page-sizes="[10, 20, 30, 40]" :page-size="formInline.pageSize" layout="sizes, prev, pager, next" :total="totalcount">
          </el-pagination>
        </div>
      </el-col>
      <!-- 分页 end -->
    </el-row>
  </div>
</template>

<script>
import { getUserUpdate } from '@/api/userManage';
import { timestampToTime } from 'utils/chanageTime';

export default {
  data() {
    return {
      totalcount: 0,
      loading: false,
      formInline: {
        pageNum: 1,
        pageSize: 10,
        accountId: null,
        orderCode: null
      },
      tableData: [],
    };
  },
  created() {
    this.getList();
  },
  methods: {
    onSubmit() {
      // 筛选页面初始化
      this.formInline.pageNum = 1;
      this.formInline.pageSize = 10;
      this.getList();
    },
    getList() {
      this.loading = true;
      // 请求列表
      getUserUpdate(this.formInline).then(response => {
        const res = response.data;
        if (res.code == '10000') {
          this.tableData = res.data.data;
          this.loading = false;
          this.totalcount = res.data.totalNum;
          // 整理数据
          this.tableData.map((item, index) => {
            item.createTime = timestampToTime(item.createTime);
            const lv = item.lv;
            if (lv == 0) {
              item.lv = '粉丝';
            } else if (lv == 1) {
              item.lv = '皇冠';
            } else if (lv == 2) {
              item.lv = '店主';
            }
          });
        }
      });
    },
    formateDate(row, coiumn) {
      console.log(row.accountSplit);
    },
    // 分页
    handleSizeChange(pageSize) {
      this.formInline.pageSize = pageSize;
      this.getList();
    },
    // 页码变化时触发
    handleCurrentChange(page) {
      this.formInline.pageNum = page;
      this.getList();
    }
  }
};
</script>

<style scoped>
  
</style>
