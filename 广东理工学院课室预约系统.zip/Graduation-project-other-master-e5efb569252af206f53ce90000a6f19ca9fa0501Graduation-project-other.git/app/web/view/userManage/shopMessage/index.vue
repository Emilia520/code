<template>
  <div class="app-container">
    <el-row>
      <el-col :span="24">
        <div class="header-title">小店管理</div>
      </el-col>
      <!-- 筛选条件 start -->
      <el-col :span="24">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
            <el-form-item label="小店名称">
                <el-input v-model="formInline.shop" placeholder="店铺名称" size="mini" clearable></el-input>
             </el-form-item>
            <el-form-item label="所在地">
                <el-select v-model="formInline.sel_provinces" value-key="id" multiple placeholder="请选择省" @visible-change="onProvinceVisibleChange">
                    <el-option
                        v-for="item in regions"
                        :key="item.id"
                        :label="item.province"
                        :value="item">
                    </el-option>
                </el-select>

                <el-select v-model="formInline.sel_cities"
                    value-key="id"
                    @visible-change="onCityVisibleChange"
                    multiple
                    collapse-tags
                    style="margin-left: 20px;"
                    placeholder="请选择市">
                    <el-option
                        v-for="item in cities"
                        :key="item.id"
                        :label="item.city"
                        :value="item">
                    </el-option>
                </el-select>

                <el-select
                    v-model="formInline.sel_areas"
                    value-key="id"
                    @visible-change="onAreaVisibleChange"
                    multiple
                    collapse-tags
                    style="margin-left: 20px;"
                    placeholder="请选择区">
                    <el-option
                        v-for="item in areas"
                        :key="item.id"
                        :label="item.area"
                        :value="item">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="行业信息">
                <el-select v-model="formInline.sel_business1" value-key="id" multiple placeholder="一级行业" @visible-change="onBusiniess1VisibleChange">
                    <el-option
                        v-for="item in businesses"
                        :key="item.id"
                        :label="item.oneLevelBusiness"
                        :value="item">
                    </el-option>
                </el-select>

                <el-select
                    v-model="formInline.sel_business2"
                    value-key="id"
                    @visible-change="onBusiniess2VisibleChange"
                    multiple
                    collapse-tags
                    style="margin-left: 20px;"
                    placeholder="二级行业">
                    <el-option
                        v-for="item in secondBusinesses"
                        :key="item.id"
                        :label="item.business"
                        :value="item">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="手机号码">
                <el-input v-model="formInline.phone" placeholder="手机号码" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="绑定信息">
                <el-input v-model="formInline.bindInfo" placeholder="绑定信息" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" size="mini" @click="onSubmit">筛选</el-button>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" size="mini" @click="onDownload">下载表格</el-button>
            </el-form-item>
        </el-form>
      </el-col>
      <!-- 筛选条件 end -->
      <!-- 表格 start -->
      <el-col :span="24">
        <el-table
          :data="tableData"
          border
          style="width: 100%"
          v-loading="loading">
          <el-table-column
            label="id"
            width="50">
            <template slot-scope="scope">
              <div>{{scope.row.id}}</div>
            </template>
          </el-table-column>
          <el-table-column
            prop="shop"
            label="小店名称"
            width="120">
          </el-table-column>
          <el-table-column
            label="所在地"
            width="120">
            <template slot-scope="scope">
              <div>{{scope.row.province}}-{{scope.row.city}}-{{scope.row.area}}</div>
            </template>
          </el-table-column>
          <el-table-column
            label="行业类型"
            width="120">
            <template slot-scope="scope">
              <div>{{scope.row.business1}}-{{scope.row.business2}}</div>
            </template>
          </el-table-column>
          <el-table-column
            label="会员信息"
            width="120">
            <template slot-scope="scope">
              <div>{{scope.row.name}}</div>
              <div v-if="scope.row.role_id==1">超级会员Lv1</div>
              <div v-else-if="scope.row.role_id==2">超级会员Lv2</div>
              <div v-else-if="scope.row.role_id==3">合伙人</div>
              <div v-else-if="scope.row.role_id==4">校园合伙人</div>
              <div v-else-if="scope.row.role_id==5">校园大使</div>
              <div>{{scope.row.code}}</div>
            </template>
          </el-table-column>
          <el-table-column
            prop="phone"
            label="手机号"
            width="120">
          </el-table-column>
          <el-table-column
            label="绑定信息"
            width="120">
            <template slot-scope="scope">
              <div>{{scope.row.userName}}</div>
              <div>{{scope.row.idCard}}</div>
            </template>
          </el-table-column>
          <el-table-column
            label="小店门头"
            width="100">
            <template slot-scope="scope">
              <img :src="scope.row.facade" alt="" style="width:80px;height:80px">
            </template>
          </el-table-column>
          <el-table-column
            label="营业执照"
            width="100">
            <template slot-scope="scope">
              <img :src="scope.row.licence" alt="" style="width:80px;height:80px">
            </template>
          </el-table-column>
          <el-table-column
            prop="invitation_user_id"
            label="邀请人用户ID"
            width="120">
          </el-table-column>
          <el-table-column
            label="状态"
            width="120">
            <template slot-scope="scope">
              <span v-if="scope.row.active==0">未激活</span>
              <span v-else>已激活</span>
            </template>
          </el-table-column>
          <el-table-column
            fixed="right"
            label="操作"
            width="80">
            <template slot-scope="scope">
              <el-button type="primary" size="small" @click="editButton(scope.row)">编辑</el-button>
            </template>
          </el-table-column>
        </el-table>     
      </el-col>
      <!-- 表格 end -->
      <!-- 分页 start -->
      <el-col :span="24">
        <div class="pagination" style="margin-top:20px;">
          <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="formInline.pageNum" :page-sizes="[10, 20, 30, 40]" :page-size="formInline.pageSize" layout="total, sizes, prev, pager, next" :total="totalcount">
          </el-pagination>
        </div>
      </el-col>
      <!-- 分页 end -->
    </el-row>
  </div>
</template>

<script>
import { getUserMessage } from '@/api/userManage';
import { getRegions } from '@/api/location';
import { timestampToTime } from 'utils/chanageTime';
import { getBusiness, getShopInfos, exportShop } from '@/api/shop';

export default {
  data() {
    return {
      totalcount: 91,
      loading: false,
      formInline: {
        pageNum: 1,
        pageSize: 10,
        phone: '',
        name: '',
        shop: '',
        bindInfo: '',
        sel_provinces: [],
        sel_cities: [],
        sel_areas: [],
        sel_business1: [],
        sel_business2: [],
      },
      tableData: [],
      regions: [],
      cities: [],
      areas: [],
      businesses: [],
      secondBusinesses: [],
      formLabelWidth: '120px',
    };
  },
  created() {
    // 筛选页面初始化
    this.formInline.pageNum = 1;
    this.formInline.pageSize = 10;
    this.getShops({ pageNum: this.formInline.pageNum, pageSize: this.formInline.pageSize });
    this.getList();
  },
  methods: {
    formInlineParams() {
      return {
        provinces: this.generateIdArray(this.formInline.sel_provinces),
        cities: this.generateIdArray(this.formInline.sel_cities),
        areas: this.generateIdArray(this.formInline.sel_areas),
        businesses1: this.generateIdArray(this.formInline.sel_business1),
        businesses2: this.generateIdArray(this.formInline.sel_business2),
        shop: this.formInline.shop,
        phone: this.formInline.phone,
        bindInfo: this.formInline.bindInfo,
        pageNum: this.formInline.pageNum,
        pageSize: this.formInline.pageSize
      };
    },
    onDownload() {
      const formParams = this.formInlineParams();
      formParams.pageNum = 1;
      formParams.pageSize = 100000;
      const params = Object.keys(formParams).map(function(key) {
        // body...
        return encodeURIComponent(key) + '=' + encodeURIComponent(formParams[key]);
      }).join('&');
      location.href = '/api/shop/export?' + params;
    },
    onSubmit() {
      this.getShops();
    },
    getShops() {
      this.loading = true;
      const params = this.formInlineParams();

      getShopInfos(params).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.tableData = res.data;
          this.totalcount = res.totalCount;
        }
        this.loading = false;
      });
    },
    getList() {
      // 请求地区列表
      getRegions().then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.regions = res.data;
        }
      });
      // 获取行业信息
      getBusiness().then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.businesses = res.data;
        }
      });
    },
    // 分页
    handleSizeChange(pageSize) {
      this.formInline.pageSize = pageSize;
      this.getShops();
    },
    // 页码变化时触发
    handleCurrentChange(page) {
      this.formInline.pageNum = page;
      this.getShops();
    },
    editButton(data) {
      alert('该功能暂未开放');
    },

    onProvinceVisibleChange(visible) {
      // 如果收起来的时候选择了省，要把已经选择的市和区的数据删除掉，避免选择的市区不在该省内
    //   if (!visible && this.formInline.sel_provinces.length > 0) {
    //     this.formInline.sel_cities = [];
    //     this.formInline.sel_areas = [];
    //     this.cities = [];
    //     this.areas = [];
    //   }
    },
    onCityVisibleChange(visible) {
      // 展现时计算应该展现的城市，如果已经选择了省，则只展现相关的市
      if (visible) {
        let provinces = this.regions;
        this.cities = [];
        // 展开城市选择时如果已经选择了省，只能显示该省所属的市
        if (this.formInline.sel_provinces.length > 0) {
          provinces = this.formInline.sel_provinces;
        }

        for (const i in provinces) {
          const province = provinces[i];
          this.cities = this.cities.concat(province.cities);
        }
      }
    },
    onAreaVisibleChange(visible) {
      // 展现时计算应该展现的区，如果已经选择了市，则只展现相关的区
      if (visible) {
        let cities = [];
        this.areas = [];
        if (this.formInline.sel_cities.length > 0) {
          // 优先以有已经选择的城市为准
          cities = this.formInline.sel_cities;
        } else if (this.cities.length > 0) {
          // 其次以城市列表为准
          cities = this.cities;
        } else if (this.formInline.sel_provinces.length > 0) {
          // 再有就是如果选择了省，只显示该省所有城市的区
          for (const i in this.formInline.sel_provinces) {
            const province = this.formInline.sel_provinces[i];
            if (province.cities != null) {
              cities = cities.concat(province.cities);
            }
          }
        } else {
          // 如果还是没有就展现所有区
          for (const i in this.regions) {
            const region = this.regions[i];
            if (region.cities != null) {
              cities = cities.concat(region.cities);
            }
          }
        }

        for (const i in cities) {
          const city = cities[i];
          if (city.areas != null) {
            this.areas = this.areas.concat(city.areas);
          }
        }
      }
    },
    onBusiniess1VisibleChange(visible) {

    },
    onBusiniess2VisibleChange(visible) {
      // 展现时计算应该展现的二级行业，如果已经选择了一级行业，则只展现相关的二级行业
      if (visible) {
        let businesses = this.businesses;
        this.secondBusinesses = [];
        // 展开城市选择时如果已经选择了省，只能显示该省所属的市
        if (this.formInline.sel_businesses1.length > 0) {
          businesses = this.formInline.sel_businesses1;
        }

        for (const i in businesses) {
          const business = businesses[i];
          this.secondBusinesses = this.secondBusinesses.concat(business.secondLevelBusiness);
        }
      }
    },
    generateIdArray(oriArr) {
      const targetArr = [];
      for (const i in oriArr) {
        const obj = oriArr[i];
        targetArr.push(obj.id);
      }

      return targetArr;
    }
  }
};
</script>

<style scoped>
  
</style>
