<template>
  <div class="app-container">
    <el-row>
      <el-col :span="24">
        <div class="header-title">订单&收益</div>
      </el-col>
      <!-- 筛选条件 start -->
      <el-col :span="24">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
          <el-form-item label="用户id">
            <el-input v-model="formInline.accountId" placeholder="用户id" size="mini" clearable></el-input>
          </el-form-item>
          <el-form-item label="订单号">
            <el-input v-model="formInline.thirdpartOrderCode" placeholder="订单号" size="mini" clearable></el-input>
          </el-form-item>
          <el-form-item label="商品id">
            <el-input v-model="formInline.productId" placeholder="订单号" size="mini" clearable></el-input>
          </el-form-item>
          <el-form-item label="平台">
            <!-- <el-input v-model="formInline.platform" placeholder="投放条件" size="mini" clearable></el-input> -->
            <el-select v-model="formInline.platform" placeholder="请选择平台" size="mini">
              <!-- <el-option label="粉丝" value="0"></el-option> -->
              <!-- <el-option label="皇冠" value="1"></el-option> -->
              <el-option label="淘宝" value="2"></el-option>
              <el-option label="京东" value="3"></el-option>
              <el-option label="唯品会" value="4"></el-option>
              <el-option label="蘑菇街" value="5"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="onSubmit">筛选</el-button>
          </el-form-item>
        </el-form>
      </el-col>
      <!-- 筛选条件 end -->
      <!-- 表格 start -->
      <el-col :span="24">
          <el-table
            :data="tableData"
            border
            style="width: 100%"
            v-loading="loading">
            <el-table-column
              fixed
              prop="accountId"
              label="用户id"
              width="120">
            </el-table-column>
            <el-table-column
              prop="platform"
              label="平台"
              width="120">
            </el-table-column>
            <el-table-column
              prop="thirdpartOrderCode"
              label="平台订单号"
              width="120">
            </el-table-column>
            <el-table-column
              prop="productId"
              label="商品id"
              width="120">
            </el-table-column>
            <el-table-column
              label="商品名"
              width="120">
              <template slot-scope="scope">
                <a :href="scope.row.productUrl" target="_blank">{{scope.row.productName}}</a>
              </template>
            </el-table-column>
            <el-table-column
              prop="productNum"
              label="购买件数"
              width="120">
            </el-table-column>
            <el-table-column
              prop="payPrice"
              label="实际付款"
              width="120">
            </el-table-column>
            <el-table-column
              prop="totalSplitFlowAmount"
              label="总分佣"
              width="120">
            </el-table-column>
            <el-table-column
              prop="totalProfit"
              label="总利润"
              width="120">
            </el-table-column>
            <el-table-column
              prop="splitFlowStatus"
              label="分佣情况"
              width="120">
            </el-table-column>
            <el-table-column
              prop="orderStatus"
              label="订单状态"
              width="120">
            </el-table-column>
            <el-table-column
              prop="createTime"
              label="下单时间"
              width="180">
            </el-table-column>
            <el-table-column
              label="受益人和金额">
              <template slot-scope="scope">
                <div v-for="(item, index) in scope.row.accountSplit" :key="index">
                  <span>{{item.beneficiaryId}} &nbsp;</span>
                  <span>￥{{item.amount}}</span>
                </div>
              </template>
            </el-table-column>
          </el-table>     
      </el-col>
      <!-- 表格 end -->
      <!-- 分页 start -->
      <el-col :span="24">
        <div class="pagination" style="margin-top:20px;">
          <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="formInline.page" :page-sizes="[10, 20, 30, 40]" :page-size="formInline.pageSize" layout="sizes, prev, pager, next" :total="totalcount">
          </el-pagination>
        </div>
      </el-col>
      <!-- 分页 end -->
    </el-row>
  </div>
</template>

<script>
import { getOrderIncome } from '@/api/userManage';
import { timestampToTime } from 'utils/chanageTime';

export default {
  data() {
    return {
      totalcount: 0,
      loading: false,
      formInline: {
        pageNum: 1,
        pageSize: 10,
        accountId: null,
        thirdpartOrderCode: null,
        productId: null,
        platform: null
      },
      tableData: [],
    };
  },
  created() {
    // 筛选页面初始化
    this.formInline.pageNum = 1;
    this.formInline.pageSize = 10;
    this.getList();
  },
  methods: {
    onSubmit() {
      this.getList();
    },
    getList() {
      this.loading = true;
      // 请求列表
      getOrderIncome(this.formInline).then(response => {
        const res = response.data;
        if (res.code == '10000') {
          this.tableData = res.data.data;
          this.loading = false;
          this.totalcount = res.data.totalNum;
          // 整理数据
          this.tableData.map((item, index) => {
            item.createTime = timestampToTime(item.createTime);
            const lv = item.lv;
            if (lv == 0) {
              item.lv = '粉丝';
            } else if (lv == 1) {
              item.lv = '皇冠';
            } else if (lv == 2) {
              item.lv = '店主';
            }
          });
        }
      });
    },
    formateDate(row, coiumn) {
      console.log(row.accountSplit);
    },
    // 分页
    handleSizeChange(pageSize) {
      this.formInline.pageSize = pageSize;
      this.getList();
    },
    // 页码变化时触发
    handleCurrentChange(page) {
      this.formInline.pageNum = page;
      this.getList();
    }
  }
};
</script>

<style scoped>
  
</style>
