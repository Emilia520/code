<template>
  <div class="dashboard-container">
    <div class="dashboard-text">广东理工学院课室预约系统</div>
    <!-- <div class="dashboard-text">roles:<span v-for='role in roles' :key='role'>{{role}}</span></div> --> 
  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import {searchMs} from '@/api/userInformation';
export default {
  name: 'dashboard',
  computed: {
    ...mapGetters([
      'name',
      'roles'
    ])
  },
  data(){
    return{
 
    }
  },
  created(){

  },
  mounted(){
   
    
  },
  methods:{
   



  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
    text-align: center;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
    margin-top: 10px;
  }
}
</style>
