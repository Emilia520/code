<template>
  <div class="login-container">
    <el-form class="login-form" autoComplete="on" :model="loginForm" :rules="loginRules" ref="loginForm" label-position="left">
      <h3 class="title">广东理工学院课室预约系统</h3>
      <el-form-item prop="username">
        <span class="svg-container svg-container_login">
           <i class="el-icon-user"></i>
        </span>
        <el-input class="loginInput" name="username" type="text" v-model="loginForm.username" autoComplete="on" placeholder="请输入账号" />
      </el-form-item>
      <el-form-item prop="password">
        <span class="svg-container">
          <i class="el-icon-unlock"></i>
        </span>
        <el-input class="loginInput" name="password" :type="pwdType" @keyup.enter.native="handleLogin" v-model="loginForm.password" autoComplete="on"
          placeholder="请输入密码" style=""></el-input>
          <span class="show-pwd" @click="showPwd"><svg-icon icon-class="eye" /></span>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" style="width:100%;" :loading="loading" @click.native.prevent="handleLogin">
          登  陆
        </el-button>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" style="width:100%;" @click="handleDialog('register')">
          注  册
        </el-button>
      </el-form-item>
      <!-- <div class="tips">
        <span style="margin-right:20px;">username: admin</span>
        <span> password: admin</span>
      </div> -->
    </el-form>
    <el-dialog title="账号注册" :visible.sync="dialogFormVisible" :modal-append-to-body='false' width="45%">
        <el-form class="registerForm" :model="register" label-position="right" :rules="rules" ref="register">
            <el-form-item label="账号名称" style="background:white" prop="name">    
                <el-input 
                  placeholder="请输入内容"
                  v-model="register.name"
                  clearable>
               </el-input>
            </el-form-item>
            <el-form-item label="密码" style="background:white" prop="password">
                <el-input
                    placeholder="请输入内容"
                    v-model="register.password"
                    show-password
                    clearable>
                </el-input>
            </el-form-item>
            <el-form-item label="注册类型选择" style="background:white" prop="type">           
                 <el-radio v-model="register.type" label="1">学生</el-radio>
                 <el-radio v-model="register.type" label="2">老师</el-radio>          
            </el-form-item>
            <el-form-item label="学号或教师号" style="background:white" prop="number">             
                  <el-input 
                    placeholder="请输入内容"
                    v-model="register.number"
                    clearable>
                  </el-input>          
            </el-form-item>
            <el-form-item label="真实姓名" style="background:white" prop="truename">         
                  <el-input 
                    placeholder="请输入内容"
                    v-model="register.truename"
                    clearable>
                  </el-input>           
            </el-form-item>
            <el-form-item label="手机号" style="background:white" prop="telephone">          
                  <el-input 
                      placeholder="请输入内容"
                      v-model="register.telephone"
                      clearable>
                  </el-input>          
            </el-form-item>
            <el-form-item label="其他联系方式" style="background:white">
              <el-input  
                    placeholder="请输入内容"
                    v-model="register.contact"
                    clearable>
                </el-input>
            </el-form-item>     
        </el-form>
        <div class="reCheck">
            <span>
              <el-button type="primary" style="width:30%;" @click="reDefine(register)">确 定</el-button>
            </span>
            <span>    
              <el-button style="width:30%;" @click="reCancle()">取 消</el-button>
            </span>
        </div>
    </el-dialog>
  </div>
</template>

<script>
import { isvalidUsername } from 'utils/validate';
import { setTimeout } from 'timers';
import { reAccount } from '@/api/register';
export default {
  name: 'login',
  data() {
    const validateUsername = (rule, value, callback) => {
      if (!isvalidUsername(value)) {
        callback(new Error('请输入正确的用户名'));
      } else {
        callback();
      }
    };
    const validatePass = (rule, value, callback) => {
      if (value.length < 5) {
        callback(new Error('密码不能小于5位'));
      } else {
        callback();
      }
    };
    return {
      loginForm: {
        username: '',
        password: ''
      },
      loginRules: {
        username: [{ required: true, trigger: 'blur', validator: validateUsername }],
        password: [{ required: true, trigger: 'blur', validator: validatePass }]
      },
      loading: false,
      pwdType: 'password',
      dialogFormVisible:false,
      register:{
        name:'',
        password:'',
        type:0,
        truename:'',
        telephone:0,
        contact:'',
        retime:0,
        role:0
      },
      rules:{
        name:[
          { required: true, message: '请输入用户名', trigger: 'blur'},
          { min: 3, max: 10, message: '长度在 3 到 10 个字符', trigger: 'blur' }
        ],
        password:[
          { required: true, message: '请输入需要设置的密码', trigger: 'blur'},
          { min: 5, max: 16, message: '长度在 5 到 16 个字符', trigger: 'blur' }
        ],
        type:[
          { required: true, message: '请选择注册类型', trigger: 'change' }
        ],
        number:[
          { required: true, message: '请输入学生或老师号', trigger: 'blur'},
        ],
        truename:[
          { required: true, message: '请输入真实姓名', trigger: 'blur'},
        ],
        telephone:[
          { required: true, message: '请输入手机号', trigger: 'blur'},
          { min: 10, max: 12, message: '请输入正确的手机号', trigger: 'blur' }
        ],
      }
    };
  },
  methods: {
    showPwd() {
      if (this.pwdType === 'password') {
        this.pwdType = '';
      } else {
        this.pwdType = 'password';
      }
    },
    handleLogin() {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          this.loading = true;
          // login(this.loginForm.username, this.loginForm.password).then(response => {
          //   const data = response.data;
          //   if (data.code === 10000 && data.authorization) {
          //     this.$store.commit('SET_TOKEN', data.authorization);
          //     this.$message({
          //       message: '登陆成功',
          //       type: 'success'
          //     });
          //     this.$router.replace({ path: '/' });
          //   } else {
          //     this.$message({
          //       message: data.msg || '登陆失败',
          //       type: 'error'
          //     });
          //   }
          // });

          this.$store.dispatch('Login', this.loginForm).then((response) => {
            console.log(response);
            this.loading = false;
            const data = response.data;
            if (data.code === 10000 && data.authorization) {
              this.$message({
                message: '登陆成功',
                type: 'success'
              });
              setTimeout(() => {
                location.href = '/';
              }, 1000);
            } else {
              this.$message({
                message: data.msg || '登陆失败',
                type: 'error'
              });
            }

          }).catch((err) => {
            console.log('!@#$%^&*()', err);
            this.$message.err('请输入正确的账号或密码');
            this.loading = false;
          });
        } else {
          console.log('error submit!!');
          this.$message.error('请输入正确的账号或密码');
          // return false;
        }
      });
    },
   
    resetForm(register) {
        if (this.$refs[register]!==undefined) {
         this.$refs[register].resetFields();
        }
    },
 
    handleDialog(register){
      this. dialogFormVisible = true;
      this.register = {};
      this.resetForm(register);
    },
    reDefine(register){
        const time = (Date.parse(new Date()))/1000;
        this.register.retime = time;
        if(this.register.type===1){
            this.register.role = 4;
        }else{
          this.register.role = 3;
        }
        console.log(this.register);
        reAccount(register).then(response=>{
          const resData = response.data;
          if(resData.code===10000){
              this.$message({
                message: '注册成功',
                type: 'success'
              });
              setTimeout(() => {
                this. dialogFormVisible = false;
              }, 2);

          }else{
            this.$message.error('请填写正确的信息');
          }
        });
    },
  
    reCancle(){
      this.register={};
      this. dialogFormVisible = false;
      // this.resetForm(register);
    },
    
  }
};
</script>

<style rel="stylesheet/scss" lang="scss">
$bg:#2d3a4b;
$light_gray:#eee;

/* reset element-ui css */
.login-container {
  .loginInput {
    display: inline-block;
    height: 47px;
    width: 85%;
    input {
      background: transparent;
      border: 0px;
      -webkit-appearance: none;
      border-radius: 0px;
      padding: 12px 5px 12px 15px;
      color: $light_gray;
      height: 47px;
      &:-webkit-autofill {
        -webkit-box-shadow: 0 0 0px 1000px $bg inset !important;
        -webkit-text-fill-color: #fff !important;
      }
    }
  }
  .el-form-item {
    border: 1px solid rgba(255, 255, 255, 0.1);
    background: rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    color: #454545;
  }
}

</style>

<style rel="stylesheet/scss" lang="scss" scoped>
$bg:#2d3a4b;
$dark_gray:#889aa4;
$light_gray:#eee;
.login-container {
  position: fixed;
  height: 100%;
  width: 100%;
  background-color: $bg;
  .login-form {
    position: absolute;
    left: 0;
    right: 0;
    width: 520px;
    padding: 35px 35px 15px 35px;
    margin: 120px auto;
  }
  .tips {
    font-size: 14px;
    color: #fff;
    margin-bottom: 10px;
    span {
      &:first-of-type {
        margin-right: 16px;
      }
    }
  }
  .svg-container {
    padding: 6px 5px 6px 15px;
    color: $dark_gray;
    vertical-align: middle;
    width: 30px;
    display: inline-block;
    &_login {
      font-size: 20px;
    }
  }
  .title {
    font-size: 26px;
    font-weight: 400;
    color: $light_gray;
    margin: 0px auto 40px auto;
    text-align: center;
    font-weight: bold;
  }
  .show-pwd {
    position: absolute;
    right: 10px;
    top: 7px;
    font-size: 16px;
    color: $dark_gray;
    cursor: pointer;
    user-select: none;
  }
}
.reCheck{
    text-align: center;
    padding-top: 40px;
    span{
      margin: 50px;
    }
}
</style>
