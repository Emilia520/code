<template>
  <div>
    <div class="searchClass">
      <el-form :inline="true" ref="formInline" :model="formInline" label-width="100px">
        <el-form-item label="课室号:">
          <el-input
            placeholder="请输入课室号"
            clearable
            style="width:200px;"
            v-model="formInline.roomnumber"
            prefix-icon="el-icon-search"
          ></el-input>
        </el-form-item>
        <el-form-item label="课室名称:">
          <el-input
            placeholder="请输入课室名"
            clearable
            style="width:200px"
            v-model="formInline.roomname"
            prefix-icon="el-icon-search"
          ></el-input>
        </el-form-item>
        <el-form-item label="账号名:">
          <el-input
            placeholder="请输入账号名"
            clearable
            style="width:200px;"
            v-model="formInline.username"
            prefix-icon="el-icon-search"
          ></el-input>
        </el-form-item>
        <el-form-item label="真实姓名:">
          <el-input
            placeholder="请输入真实姓名"
            clearable
            style="width:200px;"
            v-model="formInline.truename"
            prefix-icon="el-icon-search"
          ></el-input>
        </el-form-item>
        <el-form-item label="查询预约日期选择:">
          <el-date-picker
            v-model="formInline.appTime"
            align="right"
            type="date"
            placeholder="选择日期"
            value-format="timestamp"
          ></el-date-picker>
        </el-form-item>
        <el-button style="margin-left:20px;" type="primary" @click="appoinMessage(formInline)">搜 索</el-button>
      </el-form>
    </div>
    <el-table :data="tableData" border stripe style="width: 100%">
      <el-table-column prop="username" label="账号名" width="auto"></el-table-column>
      <el-table-column prop="truename" label="姓名" width="auto"></el-table-column>
      <el-table-column prop="type" label="用户类型" width="auto"></el-table-column>
      <el-table-column prop="roomnumber" label="预约课室号" width="auto"></el-table-column>
      <el-table-column prop="roomname" label="预约课室名" width="auto"></el-table-column>
      <el-table-column prop="time_solt" label="预约时间段" width="auto"></el-table-column>
      <el-table-column prop="roomtime" label="预约日期" width="130"></el-table-column>
      <el-table-column prop="roomresult" label="使用情况说明" width="auto"></el-table-column>
      <el-table-column prop="roomresult" label="使用情况说明" width="auto"></el-table-column>
      <el-table-column prop="appoint_state" label="预约状态" width="auto"></el-table-column>
      <el-table-column prop="appoint_cancle" label="用户是否取消预约" width="100"></el-table-column>
      <el-table-column prop="order_time" label="提交申请日期" width="160"></el-table-column>
    </el-table>
    <div class="pagination" style="margin-top:20px;text-align: center;">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :total="totalCount"
        :current-page="formInline.page"
        :page-sizes="[10, 20, 30]"
        :page-size="formInline.pageSize"
        layout="total, sizes, prev, pager, next"
      />
    </div>
  </div>
</template>

<script>
import { listReord, ownList } from "@/api/appReord";
export default {
  data() {
    return {
      tableData: [],
      formInline: {
        page: 1,
        pageSize: 10,
        appTime:'',
        roomtime:0
      },
      totalCount: 0,
      form: {}
    };
  },
  created() {},
  mounted() {
    this.getList();
  },
  methods: {
    getList() {
      listReord(this.formInline).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.tableData = resData.data;
          this.totalCount = resData.total[0].total;
          for (let i = 0; i < this.tableData.length; i++) {
            let type = this.tableData[i].type;
            let roomtime = this.tableData[i].roomtime;
            let appoint_state = this.tableData[i].appoint_state;
            let appoint_cancle = this.tableData[i].appoint_cancle;
            let order_time = this.tableData[i].order_time;
            this.tableData[i].order_time = this.timestampToTime(order_time);
            this.tableData[i].roomtime = this.changeTime(roomtime);
            switch (appoint_cancle) {
              case 0:
                this.tableData[i].appoint_cancle = "正常预约";
                break;
              case 1:
                this.tableData[i].appoint_cancle = "已取消";
                break;
            }
            switch (appoint_state) {
              case 0:
                this.tableData[i].appoint_state = "等待审核";
                break;
              case 1:
                this.tableData[i].appoint_state = "审核已通过";
                break;
              case 2:
                this.tableData[i].appoint_state = "已过期";
                break;
              case 3:
                this.tableData[i].appoint_state = "预约失败";
                break;
            }
            switch (type) {
              case 1:
                this.tableData[i].type = "学生";
                break;
              case 2:
                this.tableData[i].type = "老师";
                break;
              case 3:
                this.tableData[i].type = "管理员";
                break;
            }
          }
        }
      });
    },
    handleSizeChange(pageSize) {
      this.formInline.pageSize = pageSize;
      this.getList();
    },
    handleCurrentChange(page) {
      this.formInline.page = page;
      this.getList();
    },
    //时间格式化
    timestampToTime(timestamp) {
      const date = new Date(timestamp * 1000); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
      const Y = date.getFullYear() + "-";
      const M = this.padding0(date.getMonth() + 1, 2) + "-";
      const D = this.padding0(date.getDate(), 2) + " ";
      const h = this.padding0(date.getHours(), 2) + ":";
      const m = this.padding0(date.getMinutes(), 2) + ":";
      const s = this.padding0(date.getSeconds(), 2);
      return Y + M + D + h + m + s;
    },
    padding0(num, length) {
      for (var len = (num + "").length; len < length; len = num.length) {
        num = "0" + num;
      }
      return num;
    },
    // 时间格式化2
    changeTime(time) {
      const date = new Date(time * 1000); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
      const Y = date.getFullYear() + "年";
      const M = this.padding0(date.getMonth() + 1, 2) + "月";
      const D = this.padding0(date.getDate(), 2) + "日";
      return Y + M + D;
    },
    appoinMessage(formInline) {
      console.log(this.formInline);
      this.formInline.roomtime =this.formInline.appTime / 1000;
      ownList(formInline).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.tableData = resData.data;
          this.totalCount = resData.stotal[0].stotal;
          for (let i = 0; i < this.tableData.length; i++) {
            let type = this.tableData[i].type;
            let roomtime = this.tableData[i].roomtime;
            let appoint_state = this.tableData[i].appoint_state;
            let appoint_cancle = this.tableData[i].appoint_cancle;
            let order_time = this.tableData[i].order_time;
            this.tableData[i].order_time = this.timestampToTime(order_time);
            this.tableData[i].roomtime = this.changeTime(roomtime);
            switch (appoint_cancle) {
              case 0:
                this.tableData[i].appoint_cancle = "正常预约";
                break;
              case 1:
                this.tableData[i].appoint_cancle = "已取消";
                break;
            }
            switch (appoint_state) {
              case 0:
                this.tableData[i].appoint_state = "等待审核";
                break;
              case 1:
                this.tableData[i].appoint_state = "审核已通过";
                break;
              case 2:
                this.tableData[i].appoint_state = "已过期";
                break;
              case 3:
                this.tableData[i].appoint_state = "预约失败";
                break;
            }
            switch (type) {
              case 1:
                this.tableData[i].type = "学生";
                break;
              case 2:
                this.tableData[i].type = "老师";
                break;
              case 3:
                this.tableData[i].type = "管理员";
                break;
            }
          }
              this.formInline={
                page: 1,
                pageSize: 10,
                appTime:'',
                roomtime:0
            }
        }
      });
    }
  }
};
</script>

<style lang="scss" scoped>
</style>