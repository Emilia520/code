<template>
  <div>
    <div style="width:100%;margin-bottom:30px">
      ID:
      <el-input v-model="formInline.id" placeholder="请输入需要搜索的关键词" clearable style="width:200px"></el-input>账号名:
      <el-input
        v-model="formInline.account_name"
        placeholder="请输入需要搜索的关键词"
        clearable
        style="width:200px"
      ></el-input>使用人真实姓名:
      <el-input
        v-model="formInline.truename"
        placeholder="请输入需要搜索的关键词"
        clearable
        style="width:200px"
      ></el-input>&nbsp;&nbsp;&nbsp;&nbsp;
      身份:
      <el-radio-group v-model="formInline.type">
        <el-radio-button :label="1">学生</el-radio-button>
        <el-radio-button :label="2">老师</el-radio-button>
        <el-radio-button :label="3">管理员</el-radio-button>
      </el-radio-group>&nbsp;&nbsp;&nbsp;&nbsp;
      <br />电话号码:
      <el-input
        v-model="formInline.telephone"
        placeholder="请输入需要搜索的关键词"
        clearable
        style="width:200px"
      ></el-input>
      <el-button type="primary" style="margin-left:30px" @click="searchAppiont(formInline)">搜 索</el-button>
    </div>
    <el-table :data="tableData" border stripe style="width: 100%">
      <el-table-column prop="id" label="用户ID" width="auto"></el-table-column>
      <el-table-column prop="account_name" label="账号名" width="auto"></el-table-column>
      <el-table-column prop="truename" label="姓名" width="auto"></el-table-column>
      <el-table-column prop="number" label="学号/教师号" width="auto"></el-table-column>
      <el-table-column prop="type" label="用户类型" width="auto"></el-table-column>
      <el-table-column prop="telephone" label="电话号码" width="auto"></el-table-column>
      <el-table-column prop="contact" label="其他联系方式" width="auto"></el-table-column>
      <el-table-column prop="redate" label="注册时间" width="auto"></el-table-column>
      <el-table-column label="操作" width="auto">
        <template slot-scope="scope">
          <el-button type="danger" @click="selectRecord(scope.$index, scope.row)">修改信息</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog :visible.sync="dialogVisible" width="50%">
      <el-form ref="form" :model="form" label-width="100px">
        <el-form-item label="用户ID:">
          <el-input v-model="form.id" disabled></el-input>
        </el-form-item>
        <el-form-item label="账号名:">
          <el-input v-model="form.account_name" disabled></el-input>
        </el-form-item>
        <el-form-item label="真实姓名:">
          <el-input v-model="form.truename" clearable></el-input>
        </el-form-item>
        <el-form-item label="学号/教师号:">
          <el-input v-model="form.number" clearable></el-input>
        </el-form-item>
        <el-form-item label="用户类型:">
          <el-select v-model="form.usertype" placeholder="请选择">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div class="dbutton">
        <span class="rowLeft">
          <el-button type="primary" @click="changeInfo(form)">确 定</el-button>
        </span>
        <span class="rowRight">
          <el-button @click="cancleUpdate()">取 消</el-button>
        </span>
      </div>
    </el-dialog>
    <div class="pagination" style="margin-top:20px;text-align: center;">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :total="totalCount"
        :current-page="formInline.page"
        :page-sizes="[10, 20, 30]"
        :page-size="formInline.pageSize"
        layout="total, sizes, prev, pager, next"
      />
    </div>
  </div>
</template>

<script>
import { userInfo, selectInfo, userRecord } from "@/api/userRole";
export default {
  data() {
    return {
      tableData: [],
      formInline: {
        page: 1,
        pageSize: 10
      },
      totalCount: 0,
      dialogVisible: false,
      form: {
        usertype: ""
      },
      options: [
        {
          value: 1,
          label: "学生"
        },
        {
          value: 2,
          label: "老师"
        },
        {
          value: 3,
          label: "管理员"
        }
      ]
    };
  },
  created() {},
  mounted() {
    this.getList();
  },
  methods: {
    getList() {
      userInfo(this.formInline).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.tableData = resData.data;
          this.totalCount = resData.total[0].total;
          for (let i = 0; i < this.tableData.length; i++) {
            let type = this.tableData[i].type;
            let retime = this.tableData[i].registration_date;
            this.tableData[i].redate = this.timestampToTime(retime);
            switch (type) {
              case 1:
                this.tableData[i].type = "学生";
                break;
              case 2:
                this.tableData[i].type = "老师";
                break;
              case 3:
                this.tableData[i].type = "管理员";
                break;
            }
          }
        }
      });
    },
    handleSizeChange(pageSize) {
      this.formInline.pageSize = pageSize;
      this.getList();
    },
    handleCurrentChange(page) {
      this.formInline.page = page;
      this.getList();
    },
    selectRecord(index, row) {
      this.dialogVisible = true;
      this.form = Object.assign({ usertype: "" }, row);
      switch (row.type) {
        case "学生":
          this.form.usertype = 1;
          break;
        case "老师":
          this.form.usertype = 2;
          break;
        case "管理员":
          this.form.usertype = 3;
          break;
      }
    },
    changeInfo(form) {
      userRecord(form).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.$message({
            message: "修改成功",
            type: "success"
          });
          this.dialogVisible = false;
          this.form = {};
          this.getList();
        }
      });
    },
    cancleUpdate() {
      this.dialogVisible = false;
      this.form = {};
    },
    timestampToTime(timestamp) {
      const date = new Date(timestamp * 1000); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
      const Y = date.getFullYear() + "-";
      const M = this.padding0(date.getMonth() + 1, 2) + "-";
      const D = this.padding0(date.getDate(), 2) + " ";
      const h = this.padding0(date.getHours(), 2) + ":";
      const m = this.padding0(date.getMinutes(), 2) + ":";
      const s = this.padding0(date.getSeconds(), 2);
      return Y + M + D + h + m + s;
    },
    padding0(num, length) {
      for (var len = (num + "").length; len < length; len = num.length) {
        num = "0" + num;
      }
      return num;
    },
    searchAppiont(formInline) {
      selectInfo(this.formInline).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.tableData = resData.data;
          this.totalCount = resData.stotal[0].stotal;
          for (let i = 0; i < this.tableData.length; i++) {
            let type = this.tableData[i].type;
            let retime = this.tableData[i].registration_date;
            this.tableData[i].redate = this.timestampToTime(retime);
            switch (type) {
              case 1:
                this.tableData[i].type = "学生";
                break;
              case 2:
                this.tableData[i].type = "老师";
                break;
              case 3:
                this.tableData[i].type = "管理员";
                break;
            }
          }
        }
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.dbutton {
  text-align: center;
  padding: 5px;
  span {
    margin: 30px;
  }
}
</style>>

