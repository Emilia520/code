<template>
  <div>
    <div class="searchHistory">
           课室名称:
         <el-input v-model="formInline.roomname" placeholder="请输入需要搜索的关键词" clearable style="width:200px"></el-input>
            课室号:
         <el-input v-model="formInline.roomnumber" placeholder="请输入需要搜索的关键词" clearable style="width:200px"></el-input>
            预约状态:
            <el-select v-model="formInline.appoint_state" clearable placeholder="请选择">
                <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value">
                </el-option>
            </el-select>
                预约日期:
                <el-date-picker
                    v-model="formInline.appTime"
                    align="right"
                    type="date"
                    placeholder="选择日期"
                    value-format="timestamp"
                >
                </el-date-picker> 
           
        <el-button  @click="searchHistory(formInline)">搜 索</el-button>
    </div>
    <el-table :data="tableData"  style="width: 100%" border stripe>
        <el-table-column 
            prop="truename"
            label="预约人"
            width="100">         
        </el-table-column>
        <el-table-column 
            prop="roomnumber"
            label="课室号"
            width="120">         
        </el-table-column>
        <el-table-column 
            prop="roomname"
            label="课室名"
            width="150">         
        </el-table-column>
        <el-table-column 
            prop="time_solt"
            label="预约时间段"
            width="160">         
        </el-table-column>
        <el-table-column 
            prop="roomtime"
            label="预约日期"
            width="160">         
        </el-table-column>
        <el-table-column 
            prop="roomresult"
            label="预约情况说明"
            width="160">         
        </el-table-column>
        <el-table-column 
            prop="order_time"
            label="预约提交时间"
            width="160">         
        </el-table-column>
        <el-table-column label="操作/当前状态" prop="appoint_state" >
            <template slot-scope="scope">
                <Popconfirm @confirm="handleConfirm(scope.$index, scope.row)" @cancel="handleCancel"  type="danger" okType="danger">
                    <el-button v-if="scope.row.appoint_state===0">取消预约</el-button>
                </Popconfirm>    
                <!-- <el-button v-if="scope.row.appoint_state===0" @click="handleConfirm(scope.$index, scope.row)">取消预约</el-button> -->
                <span class="comitAppiont" v-if="scope.row.appoint_state===0">预约审核中.....</span>
                <span class="failedAppiont" v-if="scope.row.appoint_state===3">预约失败</span>
                <span class="overdue" v-if="scope.row.appoint_state===2">预约已过期</span>
                <span class="successAppiont" v-if="scope.row.appoint_state===1">预约成功</span>
            </template>
        </el-table-column>   
        
    </el-table>
     <div class="pagination" style="margin-top:20px;text-align: center;">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :total="totalCount"
          :current-page="formInline.page"
          :page-sizes="[10, 20, 30]"
          :page-size="formInline.pageSize"
          layout="total, sizes, prev, pager, next"
        />
      </div>
  </div>
</template>
    
<script>
import {historyRecord,updateState,findRecord} from '@/api/record';
import Popconfirm from '../Popconfirm';
export default {
  components:{
      Popconfirm
  },
  data(){
      return{
        tableData:[],
        name:this.$store.getters.name,
        formInline:{
            page:1,
            pageSize:10,
            appTime:'',
            appointTime:''
        },
         totalCount:0,
         options:[
            {
                value: 0,
                label: '预约审核中'
            },
            {
                value: 1,
                label: '审核已通过'
            },
            {
                value: 2,
                label: '预约已过期'
            }
         ],
        //   pickerOptions: {
        //   disabledDate(time) {
        //     return  time.getTime() < Date.now();
        //   },
        // }
      };
  },
  created(){
    
  },
  mounted(){
     this.getList();
  },
  methods:{
      getList(){
        this.formInline.name = this.name;
        historyRecord(this.formInline).then(response => {
            const resData = response.data;
            if (resData.code === 10000) {
                this.tableData = resData.data;
                for(let i=0;i<this.tableData.length;i++){
                    let order_time = this.tableData[i].order_time;
                    let roomtime = this.tableData[i].roomtime;
                    this.tableData[i].order_time = this.timestampToTime(order_time);
                    this.tableData[i].roomtime = this.changeTime(roomtime);
                } 
                this.totalCount = resData.total[0].num;
                // console.log(this.tableData);
                    
            } 
         }); 
      },
      //时间格式化
        timestampToTime(timestamp) {
        const date = new Date(timestamp * 1000);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
        const Y = date.getFullYear() + '-';
        const M = this.padding0(date.getMonth()+1,2)+ '-';
        const D = this.padding0(date.getDate(),2)+ ' ';
        const h = this.padding0(date.getHours(),2) + ':';
        const m = this.padding0(date.getMinutes(),2) + ':';
        const s = this.padding0(date.getSeconds(),2);
        return Y+M+D+h+m+s;
        },
        padding0(num, length) {
            for(var len = (num + "").length; len < length; len = num.length) {
                num = "0" + num;            
            }
            return num;
        },
        // 时间格式化2
        changeTime(time){
            const date = new Date(time * 1000);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
            const Y = date.getFullYear() + '年';
            const M = this.padding0(date.getMonth()+1,2)+ '月';
            const D = this.padding0(date.getDate(),2)+ '日';
            return Y+M+D;
        },
        handleConfirm (index, row){
            updateState(row).then(response => {
                const resData = response.data;
                if (resData.code === 10000) {
                   this.$message({
                     message:'预约取消成功',
                     type:'success',
                     });
                    this.getList();
                } 
            }); 
        },
        handleCancel(){
            this.getList();
        },
         handleSizeChange(pageSize){
            this.formInline.pageSize = pageSize;
            this.getList();
        },
        handleCurrentChange(page){
            this.formInline.page = page;
            this.getList();
        },
        searchHistory(formInline){
            console.log(this.formInline);
            this.formInline.appointTime =this.formInline.appTime/1000;
            findRecord(formInline).then(response => {
                const resData = response.data;
                if (resData.code === 10000) {
                    this.tableData = resData.data;
                    this.totalCount = resData.searchTotal[0].alltotal;
                } 
            });     
        },
        
        // testTime(){
        //     const time =new Date(new Date().toLocaleDateString()).getTime()/1000//获取当日零点时间戳       
        // }
  }
}
</script>

<style lang="scss" scoped>
    .comitAppiont{
        margin-left: 20px;
        color:rgb(166, 182, 26);
    }
    .overdue{
        color: red;
    }
    .successAppiont{
        color: green;
    }
    .failedAppiont{
        color: orange;
    }
    .searchHistory{
        margin: 20px
    }
</style>