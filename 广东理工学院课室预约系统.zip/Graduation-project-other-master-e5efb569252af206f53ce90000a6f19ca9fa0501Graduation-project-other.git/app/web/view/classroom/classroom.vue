<template>
  <div>
    <div class="action">
      课室名称:
      <el-input
        v-model="formInline.roomname"
        placeholder="请输入需要搜索的关键词"
        clearable
        style="width:200px"
      ></el-input>课室号:
      <el-input
        v-model="formInline.roomnumber"
        placeholder="请输入需要搜索的关键词"
        clearable
        style="width:200px"
      ></el-input>课室状态:
      <el-input v-model="formInline.state" placeholder="请输入需要搜索的关键词" clearable style="width:200px"></el-input>使用人:
      <el-input
        v-model="formInline.truenmame"
        placeholder="请输入需要搜索的关键词"
        clearable
        style="width:200px"
      ></el-input>
      <el-button style="margin-left:20px" @click="searchClass(formInline)">搜 索</el-button>
      <el-button
        style="position:relative;"
        type="primary"
        v-if="this.role==1||this.role==2"
        @click="handleAdd()"
      >添加课室</el-button>
    </div>
    <div class="roomstate">
      <el-table :data="tableData" border stripe style="width: 100%;text-align:-webkit-center;">
        <el-table-column prop="roomname" label="课室名称" width="200"></el-table-column>
        <el-table-column prop="roomnumber" label="课室号" width="200"></el-table-column>
        <el-table-column prop="roomstate_describe" label="课室状态" width="200"></el-table-column>
        <el-table-column prop="truename" label="当前使用人" width="200"></el-table-column>
        <el-table-column prop="roomresult" label="当前使用情况" width="200"></el-table-column>
        <el-table-column label="操作" v-if="this.role==1||this.role==2">
          <template slot-scope="scope">
            <Popconfirm
              @confirm="handleConfirm(scope.$index, scope.row)"
              @cancel="handleCancel"
              type="danger"
              okType="danger"
            >
              <el-button type="danger">删 除</el-button>
            </Popconfirm>
            <el-button @click="handUpdate(scope.row)" type="primary">修改课室状态</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <el-dialog :visible.sync="dialogVisible" width="35%">
      <el-form ref="form" :model="form" label-width="100px">
        <el-form-item label="课室名:">
          <el-input v-model="form.name" placeholder="请输入课室名称" clearable></el-input>
        </el-form-item>
        <el-form-item label="课室号:">
          <el-input v-model="form.number" placeholder="请输入课室号" clearable></el-input>
        </el-form-item>
      </el-form>
      <div class="dbutton">
        <span class="rowLeft">
          <el-button type="primary" @click="confimAdd(form)">确 定</el-button>
        </span>
        <span class="rowRight">
          <el-button @click="cancleAdd()">取 消</el-button>
        </span>
      </div>
    </el-dialog>
    <el-dialog :visible.sync="dialogchange" width="35%">
      <el-form ref="handform" :model="handform" label-width="100px">
        <el-form-item label="课室号:">
          <el-input v-model="handform.roomnumber" placeholder="请输入课室名称" disabled></el-input>
        </el-form-item>
        <el-form-item label="课室名:">
          <el-input v-model="handform.roomname" placeholder="请输入课室名称" disabled></el-input>
        </el-form-item>
        <el-form-item label="使用人:">
          <el-input v-model="handform.truename" placeholder="请输入课室名称"></el-input>
        </el-form-item>
        <el-form-item label="使用状态:">
          <el-select v-model="handform.roomstate" placeholder="请选择">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-input
            type="textarea"
            placeholder="请输入内容"
            v-model="handform.roomresult"
            maxlength="30"
            show-word-limit
          ></el-input>
        </el-form-item>
      </el-form>
      <div class="dbutton">
        <span class="rowLeft">
          <el-button type="primary" @click="updateState()">确 定</el-button>
        </span>
        <span class="rowRight">
          <el-button @click="cancleUpdate()">取 消</el-button>
        </span>
      </div>
    </el-dialog>
    <div class="pagination" style="margin-top:20px;text-align: center;">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :total="totalCount"
        :current-page="formInline.page"
        :page-sizes="[10, 20, 30]"
        :page-size="formInline.pageSize"
        layout="total, sizes, prev, pager, next"
      />
    </div>
  </div>
</template>

<script>
import {
  checkClass,
  deletClass,
  addClass,
  selectAll,
  updateState
} from "@/api/classroom";
import Popconfirm from "./Popconfirm";
export default {
  components: {
    Popconfirm
  },
  data() {
    return {
      formInline: {
        page: 1,
        pageSize: 10
      },
      form: {
        name: "",
        number: 0
      },
      handform: {},
      totalCount: 0,
      role: this.$store.getters.role,
      tableData: [],
      dialogVisible: false,
      loading: false,
      dialogchange: false,
      options: [
        {
          value: 0,
          label: "空"
        },
        {
          value: 1,
          label: "使用中"
        }
      ]
      // search:{
      //   page:1,
      //   pageSize:10
      // }
    };
  },
  created() {},
  mounted() {
    this.getList();
  },
  methods: {
    handleSizeChange(pageSize) {
      this.formInline.pageSize = pageSize;
      this.getList();
    },
    handleCurrentChange(page) {
      this.formInline.page = page;
      this.getList();
    },
    getList() {
      checkClass(this.formInline).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.tableData = resData.data;
          this.totalCount = resData.total[0].num;
          for (let i = 0; i < this.tableData.length; i++) {
            let state = this.tableData[i].roomstate;
            let describe = this.tableData[i].roomstate_describe;
            switch (state) {
              case 0:
                this.tableData[i].roomstate_describe = "空";
                break;

              case 1:
                this.tableData[i].roomstate_describe = "使用中";
                break;
            }
          }
        }
      });
    },
    handleConfirm(index, row) {
      deletClass(row).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.$message({
            message: "删除成功",
            type: "warning"
          });
          this.getList();
        }
      });
    },
    handleCancel() {},
    handleAdd() {
      this.dialogVisible = true;
      this.form = {};
    },
    confimAdd(form) {
      if (
        this.form.name !== null &&
        this.form.number !== null &&
        this.form.name !== undefined &&
        this.form.number !== undefined
      ) {
        addClass(form).then(response => {
          const resData = response.data;
          if (resData.code === 10000) {
            this.$message({
              message: "添加成功",
              type: "success"
            });
            this.dialogVisible = false;
            this.getList();
          }
        });
      } else {
        this.$message.error("内容不能为空");
      }
    },
    cancleAdd() {
      this.dialogVisible = false;
    },
    searchClass(formInline) {
      selectAll(formInline).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.tableData = resData.data;
          this.totalCount = resData.stotal[0].sum;
        }
      });
    },
    handUpdate(row) {
      this.dialogchange = true;
      this.handform = row;
    },
    updateState() {
      if (this.handform.roomstate === 1) {
        this.handform.roomstate_describe = "使用中";
      } else {
        this.handform.roomstate_describe = "空";
      }
      updateState(this.handform).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.$message({
            message: "修改成功",
            type: "success"
          });
          this.getList();
          this.dialogchange = false;
        }
      });
    },
    cancleUpdate() {
      this.dialogchange = false;
    }
  }
};
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
.action {
  margin: 15px;
}
.dbutton {
  text-align: center;
  padding: 5px;
  span {
    margin: 30px;
  }
}
</style>