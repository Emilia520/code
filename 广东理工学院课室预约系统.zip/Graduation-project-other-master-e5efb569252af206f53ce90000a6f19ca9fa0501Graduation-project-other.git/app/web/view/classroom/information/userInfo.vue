<template>
   <div>
     <el-table :data="tableData" border style="width: 100%">
        <el-table-column prop="truename" label="真实姓名" width="180">

        </el-table-column>
         <el-table-column prop="number" label="学号/教师号" width="180">

        </el-table-column>
        <el-table-column prop="telephone" label="个人电话号码" width="180">

        </el-table-column>
        <el-table-column prop="status" label="类型" width="180">

        </el-table-column>
        <el-table-column prop="dateTime" label="注册时间" width="180">

        </el-table-column>
        <el-table-column label="操作">
            <template>
              <el-button  
                @click="handleDialog()"
                type="primary" 
               >修改个人信息</el-button>
              <el-button
                @click="updatePassword()"
                type="danger"
                >修改密码</el-button>
            </template>
        </el-table-column>
     </el-table>
      <el-dialog  :visible.sync="dialogVisible" width="35%">
            <el-form  ref="form" :model="form" label-width="100px">
                <el-form-item label="账号名">
                    <el-input v-model="form.name" :disabled="true">
                    </el-input>
                </el-form-item>
                <el-form-item label="真实姓名">
                    <el-input v-model="form.truename" :disabled="true">
                    </el-input>
                </el-form-item>
                <el-form-item label="学号/教师工号">
                    <el-input v-model="form.number" :disabled="true">
                    </el-input>
                </el-form-item>
                <el-form-item label="个人电话号码">
                    <el-input v-model="form.telephone">
                    </el-input>
                </el-form-item>
                <el-form-item label="其他联系方式">
                    <el-input v-model="form.contact">
                    </el-input>
                </el-form-item>
            </el-form>
            <div class="dbutton">
              <span class="rowLeft">
                <el-button @click="handleChange(form)" type="primary">
                  确 定
                </el-button>
              </span>
              <span class="rowRight">
                <el-button @click="closeDialog()">
                  取 消
                </el-button>
              </span>
            </div>
      </el-dialog> 
      <el-dialog :visible.sync="updatePs" width="35%">
          <el-form ref="pwData"  :model="pwData" label-width="130px">
            <el-form-item label="旧密码：">
                    <el-input v-model="pwData.password"
                      show-password
                      placeholder="请输入旧密码"
                      clearable>
                    </el-input>
            </el-form-item>
             <el-form-item label="新密码：">
                    <el-input v-model="pwData.apassword"
                      show-password
                      placeholder="请输入新密码"
                      clearable>
                    </el-input>
            </el-form-item>
             <el-form-item label="重复输入新密码：">
                    <el-input v-model="pwData.compare"
                      show-password
                      placeholder="请输入新密码"
                      clearable>
                    </el-input>
            </el-form-item>
          </el-form>
          <div class="dbutton">
              <span class="rowLeft">
                <el-button type="primary" @click="newPassword(pwData)">
                  确 定
                </el-button>
              </span>
              <span class="rowRight">
                <el-button @click="cancleNewpassword()">
                  取 消
                </el-button>
              </span>
            </div>
      </el-dialog>
        
   </div>
</template>

<script>
import {searchMs,changeMS,updatePs} from '@/api/userInformation';
export default {
  data() {
    return {
      name:this.$store.getters.name,
      tableData:[],
      inforData:[],
      dialogVisible:false,
      updatePs:false,
      form:{
        name:'',
        truename:'',
        number:0,
        telephone:0,
        contact:''
      },
      pwData:{
        name:'',
        password:'',
        apassword:'',
        compare:''
      }
    };
  },
  created(){
    this.getUname();
  },
  mounted(){
    
  },
  methods:{
    getUname(){
      const uname = {name:this.name};
      searchMs(uname).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
            this.inforData = resData.data;
            const type = this.inforData[0].type;
            const dateTime = this.inforData[0].registration_date;
            if(type === 1){
                this.inforData[0].status = "学生";
            }
            if(type === 2){
                this.inforData[0].status = "老师";
            }
            if(type === 3){
                this.inforData[0].status = "管理员";
            }
            this.inforData[0].dateTime=this.timestampToTime(dateTime);
            this.tableData = this.inforData;
            
        } 
      });
    },
    timestampToTime(timestamp) {
        const date = new Date(timestamp * 1000);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
        const Y = date.getFullYear() + '-';
        const M = this.padding0(date.getMonth()+1,2)+ '-';
        const D = this.padding0(date.getDate(),2)+ ' ';
        const h = this.padding0(date.getHours(),2) + ':';
        const m = this.padding0(date.getMinutes(),2) + ':';
        const s = this.padding0(date.getSeconds(),2);
        return Y+M+D+h+m+s;
    },
    padding0(num, length) {
        for(var len = (num + "").length; len < length; len = num.length) {
            num = "0" + num;            
        }
        return num;
    },
    handleDialog(){
      this.dialogVisible=true;
      this.form = Object.assign({name:this.name},this.tableData[0]);
    },
    handleChange(form){
        changeMS(form).then(response=>{
         const resData = response.data;
         if(resData.code===10000){
            this.dialogVisible=false;
            this.$message({
              message:'修改成功',
              type:'success'
            });
         }
        });
      
    },
    closeDialog(){
      this.dialogVisible = false;
    },
    updatePassword(){
      this.updatePs = true;
      this.pwData={};
    },
    newPassword(pwData){
      console.log(pwData);
      this.pwData.name = this.name;
      if(this.pwData.apassword===this.pwData.compare){
        updatePs(pwData).then(response=>{
         const resData = response.data;
         console.log(resData.code);
          if(resData.code===10000){
              this.dialogVisible=false;
              this.$message({
                message:'修改成功',
                type:'success'
              });
             this.$router.replace('/login');
          }
         else{
            this.$message.error('密码不正确');
          }
        });
      }else{
        this.$message.error('两次新密码不一致');
      }
    },
    cancleNewpassword(){
      this.updatePs = false;
      this.pwData={};
    }

  }
}
</script>

<style lang="scss" rel="stylesheet/scss" scoped> 
.dbutton{
  text-align: center;
  padding: 5px;
  span{
    margin: 30px;
  }
}

</style>