<template>
  <div>
    <div style="width:100%;margin-bottom:30px">
      课室名称:
      <el-input
        v-model="formInline.sroomname"
        placeholder="请输入需要搜索的关键词"
        clearable
        style="width:200px"
      ></el-input>课室号:
      <el-input
        v-model="formInline.sroomnumber"
        placeholder="请输入需要搜索的关键词"
        clearable
        style="width:200px"
      ></el-input>使用人真实姓名:
      <el-input
        v-model="formInline.struenmame"
        placeholder="请输入需要搜索的关键词"
        clearable
        style="width:200px"
      ></el-input>&nbsp;&nbsp;&nbsp;&nbsp;
      身份:
      <el-radio-group v-model="formInline.stype">
        <el-radio-button :label="1">学生</el-radio-button>
        <el-radio-button :label="2">老师</el-radio-button>
        <el-radio-button :label="3">管理员</el-radio-button>
      </el-radio-group>&nbsp;&nbsp;&nbsp;&nbsp;
      <br />学号:
      <el-input v-model="formInline.number" placeholder="请输入需要搜索的关键词" clearable style="width:200px"></el-input>日期:
      <el-date-picker
        v-model="formInline.sdateTime"
        align="right"
        type="date"
        placeholder="选择日期"
        value-format="timestamp"
      ></el-date-picker>&nbsp;&nbsp;&nbsp;&nbsp;
      时间段:
      <el-select v-model="formInline.timesolt" placeholder="请选择">
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        ></el-option>
      </el-select>
      <el-button type="primary" style="margin-left:30px" @click="searchAppiont(formInline)">搜 索</el-button>
    </div>
    <el-table :data="tableData" border stripe style="width: 100%">
      <el-table-column prop="roomnumber" label="课室号" width="100"></el-table-column>
      <el-table-column prop="roomname" label="课室名" width="100"></el-table-column>
      <el-table-column prop="username" label="用户名" width="140"></el-table-column>
      <el-table-column prop="truename" label="真实姓名" width="100"></el-table-column>
      <el-table-column prop="number" label="学号" width="140"></el-table-column>
      <el-table-column prop="type" label="用户类型" width="140"></el-table-column>
      <el-table-column prop="roomresult" label="使用情况说明" width="auto"></el-table-column>
      <el-table-column prop="roomtime" label="预约日期" width="auto"></el-table-column>
      <el-table-column prop="time_solt" label="预约时间段" width="100"></el-table-column>
      <el-table-column prop="order_time" label="申请提交时间" width="auto"></el-table-column>
      <el-table-column prop="whether_pass" label="预约是否通过" width="auto"></el-table-column>
      <el-table-column prop="approver" label="审批人" width="100"></el-table-column>
    </el-table>
    <div class="pagination" style="margin-top:20px;text-align: center;">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :total="totalCount"
        :current-page="formInline.page"
        :page-sizes="[10, 20, 30]"
        :page-size="formInline.pageSize"
        layout="total, sizes, prev, pager, next"
      />
    </div>
  </div>
</template>

<script>
import { historyList, selectAppiont } from "@/api/exhistory";
export default {
  data() {
    return {
      tableData: [],
      formInline: {
        page: 1,
        pageSize: 10,
        sdateTime: ""
      },
      totalCount: 0,
      options: [
        {
          value: 1,
          label: "8:25~9:10"
        },
        {
          value: 2,
          label: "9:20~10:05"
        },
        {
          value: 3,
          label: "10:20~11:05"
        },
        {
          value: 4,
          label: "11:15~12:00"
        },
        {
          value: 5,
          label: "14:00~14:45"
        },
        {
          value: 6,
          label: "14:55~15:40"
        },
        {
          value: 7,
          label: "15:50~16:30"
        },
        {
          value: 8,
          label: "16:40~17:25"
        }
      ]
    };
  },
  created() {},
  mounted() {
    this.getList();
  },
  methods: {
    getList() {
      historyList(this.formInline).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.tableData = resData.data;
          this.totalCount = resData.total[0].total;
          for (let i = 0; i < this.tableData.length; i++) {
            let type = this.tableData[i].type;
            let roomtime = this.tableData[i].roomtime;
            let order_time = this.tableData[i].order_time;
            let pass = this.tableData[i].whether_pass;
            this.tableData[i].roomtime = this.changeTime(roomtime);
            this.tableData[i].order_time = this.timestampToTime(order_time);
            switch (type) {
              case 1:
                this.tableData[i].type = "学生";
                break;
              case 2:
                this.tableData[i].type = "老师";
                break;
              case 3:
                this.tableData[i].type = "管理员";
                break;
            }
            switch (pass) {
              case 1:
                this.tableData[i].whether_pass = "通过";
                break;
              case 2:
                this.tableData[i].whether_pass = "未通过";
                break;
            }
          }
        }
      });
    },
    searchAppiont(formInline) {
      this.formInline.sdateTime = this.formInline.sdateTime / 1000;
      selectAppiont(formInline).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.tableData = resData.data;
          this.totalCount = resData.stotal[0].sum;
          this.formInline = {
            page: 1,
            pageSize: 10,
            sdateTime: ""
          };
        }
      });
    },
    handleSizeChange(pageSize) {
      this.formInline.pageSize = pageSize;
      this.getList();
    },
    handleCurrentChange(page) {
      this.formInline.page = page;
      this.getList();
    },
    //时间格式化
    timestampToTime(timestamp) {
      const date = new Date(timestamp * 1000); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
      const Y = date.getFullYear() + "-";
      const M = this.padding0(date.getMonth() + 1, 2) + "-";
      const D = this.padding0(date.getDate(), 2) + " ";
      const h = this.padding0(date.getHours(), 2) + ":";
      const m = this.padding0(date.getMinutes(), 2) + ":";
      const s = this.padding0(date.getSeconds(), 2);
      return Y + M + D + h + m + s;
    },
    padding0(num, length) {
      for (var len = (num + "").length; len < length; len = num.length) {
        num = "0" + num;
      }
      return num;
    },
    // 时间格式化2
    changeTime(time) {
      const date = new Date(time * 1000); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
      const Y = date.getFullYear() + "年";
      const M = this.padding0(date.getMonth() + 1, 2) + "月";
      const D = this.padding0(date.getDate(), 2) + "日";
      return Y + M + D;
    }
  }
};
</script>

<style lang="scss" scoped>
</style>>

