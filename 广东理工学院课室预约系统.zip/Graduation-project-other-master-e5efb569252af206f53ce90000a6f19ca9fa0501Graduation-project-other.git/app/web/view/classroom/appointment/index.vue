<template>
  <div>
    <div class="searchClass">
      <p>请先查询需要预约的课室名或课室号并选择预约日期</p>
      <el-form :inline="true" ref="form" :model="form" label-width="100px">
        <el-form-item label="课室号:">
          <el-input
            placeholder="请输入需要预约的课室号"
            clearable
            style="width:200px;"
            v-model="form.roomnumber"
            prefix-icon="el-icon-search"
          ></el-input>
        </el-form-item>
        <el-form-item label="课室名称:">
          <el-input
            placeholder="请输入需要预约的课室名"
            clearable
            style="width:200px"
            v-model="form.roomname"
            prefix-icon="el-icon-search"
          ></el-input>
        </el-form-item>
        <el-form-item label="日期选择:">
          <el-date-picker
            v-model="form.appTime"
            align="right"
            type="date"
            placeholder="选择日期"
            value-format="timestamp"
            :picker-options="pickerOptions"
          ></el-date-picker>
        </el-form-item>
        <el-button style="margin-left:20px;" type="primary" @click="appoinMessage(form)">搜 索</el-button>
      </el-form>
    </div>

    <el-table :data="tableData" border stripe style="width: 100%;text-align:-webkit-center;">
      <el-table-column prop="roomnumber" label="课室号" width="200"></el-table-column>
      <el-table-column prop="roomname" label="课室名称" width="200"></el-table-column>
      <el-table-column prop="time_solt" label="预约时间段" width="200"></el-table-column>
      <el-table-column prop="time" label="日期" width="200"></el-table-column>
      <el-table-column label="操作" prop="appwhether">
        <template slot-scope="scope">
          <p class="sinceAppiont" v-if="scope.row.appwhether===1">该时间段的该课室已被预约</p>
          <p class="overtime" v-if="scope.row.appwhether===2">已过期</p>
          <el-button
            v-if="scope.row.appwhether===0"
            type="success"
            @click="handleAppiont(scope.$index, scope.row)"
          >预约</el-button>
          <!-- <el-button type="danger">
                  取消预约
          </el-button>-->
        </template>
      </el-table-column>
    </el-table>
    <el-dialog :visible.sync="dialogVisible" width="40%">
      <el-form ref="appform" :model="appform" label-width="150px">
        <el-form-item label="课室号：">
          <el-input v-model="appform.roomnumber" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="课室名：">
          <el-input v-model="appform.roomname" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="账号名:">
          <el-input v-model="appform.name" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="真实姓名：">
          <el-input v-model="appform.truename" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="时间段：">
          <el-input v-model="appform.time_solt" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="预约情况说明：">
          <el-input
            type="textarea"
            placeholder="请输入内容"
            v-model="appform.roomresult"
            maxlength="30"
            show-word-limit
          ></el-input>
        </el-form-item>
      </el-form>
      <div class="appdialog">
        <el-button type="primary" @click="commitAppoint(appform)">确 定</el-button>
        <el-button style="margin-left: 65px;" @click="cancleAppoint()">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { insertTime, recordAppiont, judgeAppiont } from "@/api/appointment";
import { searchMs } from "@/api/userInformation";
export default {
  data() {
    return {
      tableData: [],
      form: {},
      arr: [],
      appform: {
        truename: "",
        type: 0,
        name: ""
      },
      sinceAppiont: {},
      dialogVisible: false,
      name: this.$store.getters.name,
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() < Date.now() - 3600 * 1000 * 24;
        }
        //  shortcuts: [{
        //    text: '今天',
        //    onClick(picker) {
        //      picker.$emit('pick', new Date());
        //    }
        //  }, {
        //    text: '明天',
        //    onClick(picker) {
        //      const date = new Date();
        //      date.setTime(date.getTime() + 3600 * 1000 * 24);
        //      picker.$emit('pick', date);
        //    }
        //  }]
      }
    };
  },
  created() {},
  mounted() {
    this.userMessage();
  },
  methods: {
    appoinMessage(form) {
      const appoinTime = this.form.appTime / 1000;
      this.form.appoinTime = appoinTime;
      const time = this.timestampToTime(this.form.appTime);
      const truename = this.arr[0].truename;
      const type = this.arr[0].type;
      console.log(this.form);
      insertTime(form).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.tableData = resData.data;
          this.tableData.forEach(item => {
            item.time = time;
            item.truename = truename;
            item.type = type;
          });
          //   console.log(this.tableData);
        }
        if (resData.code === 6001) {
          // this.$message.error('没有该课室或输入有误');
        }
      });
    },
    //格式化时间
    timestampToTime(timestamp) {
      const date = new Date(timestamp);
      const Y = date.getFullYear() + "年 ";
      const M = date.getMonth() + 1 + "月 ";
      const D = date.getDate() + "日";
      return Y + M + D;
    },
    //预约操作
    handleAppiont(index, row) {
      this.appform.roomresult = "";
      this.dialogVisible = true;
      this.appform = row;
      this.appform.name = this.name;
      judgeAppiont(row).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.sinceAppiont.record = resData.data[0].record;
        }
      });
    },
    userMessage() {
      searchMs({ name: this.name }).then(response => {
        const resData = response.data;
        if (resData.code === 10000) {
          this.arr = resData.data;
        }
      });
    },
    commitAppoint(appform) {
      if (this.sinceAppiont.record === 0) {
        if (
          this.appform.roomresult !== "" &&
          this.appform.roomresult !== undefined
        ) {
          this.appform.roomtime = this.form.appTime / 1000;
          console.log(this.appform);
          recordAppiont(appform).then(response => {
            const resData = response.data;
            if (resData.code === 10000) {
              this.$message({
                message: "预约申请提交成功",
                type: "success",
                offset: 40
              });
              this.dialogVisible = false;
              this.sinceAppiont = {};
              window.location.href =
                "http://127.0.0.1:7001/classroom/record/index";
            }
          });
        } else {
          this.$message.error("请填写预约理由");
        }
      } else {
        this.$message({
          message: "已提交过该课室预约记录",
          type: "warning"
        });
        this.dialogVisible = false;
        this.sinceAppiont = {};
      }
    },
    cancleAppoint() {
      this.dialogVisible = false;
    }
  }
};
</script>

<style lang="scss" scoped>
.searchClass {
  p {
    text-align: center;
    font-size: 14px;
    color: red;
  }
}
.sinceAppiont {
  text-align: center;
  color: orange;
}
.overtime {
  text-align: center;
  color: red;
}
.appdialog {
  text-align: center;
  padding-top: 20px;
}
</style>