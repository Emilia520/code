<template>
    <div class="app-container">
        <el-upload class="upload-button" :action="uploadAction()" :on-success="onUploadSuccess" :file-list="fileList" drag>
            <i class="el-icon-upload"></i>
            <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
        </el-upload>
    </div>
</template>

<script>
  export default {
    data() {
      return {
        fileList: [],
      };
    },
    methods: {
      uploadAction() {
        const host = process.env.NODE_ENV === 'development' ? 'http://apitest.quexb.com' : 'https://xttapi.lexj.com';
        const action = `${host}/order/importDelivery`;
        console.log(action);
        return action;
      },

      onUploadSuccess(res, file) {
        this.$message({
          type: res.code === 10000 ? 'success' : 'error',
          message: res.msg || (res.code === 10000 ? '处理文件成功' : '处理文件失败')
        });

        const affected = ` 更新了${res.data || 0}条记录`;
        const item = { name: `${file.name}  ${affected}` };
        this.fileList.push(item);
      },
    }
  };
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .app-container {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: calc(100vh - 50px);
    }

</style>