<template>
    <div class="app-container" v-loading="loading">
        <div class="content-container">
            <div class="title">申请售后</div>
            <div class="order-code-container">
                <el-input class="order-code-input" placeholder="请输入订单号" size="large" v-model="formInline.orderCode" clearable />
            </div>
            <div class="info-container">
                <div class="type-select">
                    <span class="select-key">售后类型</span>
                    <el-select class="select-value" v-model="formInline.type" placeholder="请选择">
                        <el-option
                                v-for="item in afterSaleTypes"
                                :key="item.id"
                                :label="item.value"
                                :value="item.id">
                        </el-option>
                    </el-select>
                    <span class="type-select-tips">必填</span>
                </div>
                <div class="type-select">
                    <span class="select-key">售后原因</span>
                    <el-select class="select-value" v-model="formInline.reason" placeholder="请选择">
                        <el-option
                                v-for="item in afterSaleReasons"
                                :key="item.id"
                                :label="item.value"
                                :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="type-select">
                    <span class="select-key">问题描述</span>
                    <el-input class="select-value" v-model="formInline.problem" placeholder="请输入问题描述" type="textarea"
                           :autosize="{minRows: 2}" resize="vertical" />
                </div>
                <div class="images-container">
                    <image-preview-card class="image-previewer"
                                        :index='0'
                                        :action="uploadImageAction"
                                        :beforeUpload="_beforeUploadImage"
                                        :uploadSuccess="_uploadImageSuccess"
                                        :source="formInline.images[0]">
                    </image-preview-card>
                    <image-preview-card class="image-previewer"
                                        :index='1'
                                        :action="uploadImageAction"
                                        :beforeUpload="_beforeUploadImage"
                                        :uploadSuccess="_uploadImageSuccess"
                                        :source="formInline.images[1]">
                    </image-preview-card>
                    <image-preview-card class="image-previewer"
                                        :index='2'
                                        :action="uploadImageAction"
                                        :beforeUpload="_beforeUploadImage"
                                        :uploadSuccess="_uploadImageSuccess"
                                        :source="formInline.images[2]">
                    </image-preview-card>
                    <image-preview-card class="image-previewer"
                                        :index='3'
                                        :action="uploadImageAction"
                                        :beforeUpload="_beforeUploadImage"
                                        :uploadSuccess="_uploadImageSuccess"
                                        :source="formInline.images[3]">
                    </image-preview-card>
                </div>
                <div class="opt-container">
                    <el-button class="opt-button" type="text" @click="confirm">创建售后</el-button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
  import { applyAfterSale, afterSaleReasonList } from '@/api/groupbuy';
  import ImagePreviewCard from '@/component/ImagePreview';
  import { uploadImg } from '@/api/uploadImg';

  export default {
    components: { ImagePreviewCard },

    name: 'applyAfterSale',
    data() {
      return {
        loading: false,
        uploadImageAction: null, // 上传图片接口

        afterSaleTypes: [
          { id: 1, value: '仅退款' },
          { id: 2, value: '退货退款' },
          { id: 3, value: '换货' }
        ],
        afterSaleReasons: [
          { id: 1, value: '与卖家协商一致退款', status: 1, sort: 1 },
          { id: 2, value: '物流公司发货问题', status: 1, sort: 2 },
          { id: 3, value: '卖家虚假发货', status: 1, sort: 3 },
          { id: 4, value: '空包裹/少货', status: 1, sort: 4 },
          { id: 5, value: '多拍/拍错/不想要', status: 1, sort: 5 },
          { id: 6, value: '商家未按时间发货', status: 1, sort: 6 },
          { id: 7, value: '其他', status: 1, sort: 7 },
          { id: 8, value: '下单失败', status: 0, sort: 8 },
          { id: 9, value: '不想要了，手动创建', status: 0, sort: 9 },
          { id: 10, value: '与卖家协商一致', status: 0, sort: 10 },
          { id: 11, value: '优品团人工帮忙创建售后单', status: 0, sort: 11 },
          { id: 12, value: '商家缺货退款', status: 0, sort: 12 },
          { id: 13, value: '质量问题换货', status: 0, sort: 13 },
          { id: 14, value: '质量问题退货退款', status: 0, sort: 14 },
          { id: 15, value: '7天无理由换货', status: 0, sort: 15 },
          { id: 16, value: '7天无理由退货退款', status: 0, sort: 16 },
          { id: 17, value: '截单后仅退款', status: 0, sort: 17 }],

        formInline: {
          type: null,
          reason: null,
          orderCode: null,
          problem: null,
          images: [],
        },
      };
    },

    created() {
      this.uploadImageAction = uploadImg;
      this.getReasonList();
    },

    methods: {
      getReasonList() {
        this.loading = true;
        afterSaleReasonList().then(response => {
          this.loading = false;
          const res = response.data;
          if (res.code !== 10000) {
            this.$message.warning('获取售后原因列表失败，使用缓存数据');
          } else {
            this.afterSaleReasons = res.data;
          }
        });
      },

      _beforeUploadImage(file, index) {
        if (index > 3 || index < 0) {
          this.$message.error('参数错误');
          return false;
        }

        const commonTypes = file.type === 'image/jpeg' || file.type === 'image/png';
        if (!commonTypes) {
          this.$message.error('上传文件格式有误');
          return false;
        }

        const replace = this.formInline.images.length - 1 >= index;
        return this.$alert(`确认${replace ? '替换当前图片' : '新增图片'}？`, '上传图片', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          showCancelButton: true,
          showClose: false,
        });
      },

      _uploadImageSuccess(response, index) {
        const imageUrl = response.data;

        if (index > 3 || index < 0) {
          this.$message.error('更新图片索引超过4，更新失败');
          return;
        }

        if (!Array.isArray(this.formInline.images)) {
          this.formInline.images = [];
        }

        const images = this.formInline.images;
        const replace = images.length - 1 >= index;
        replace ? images.splice(index, 1, imageUrl) : images.push(imageUrl);
      },

      confirm() {
        if (!this.formInline.orderCode) {
          this.$message.error('请填写订单号');
          return;
        }

        // type不会为0
        if (!this.formInline.type) {
          this.$message.error('请选择售后类型');
          return;
        }

        console.log(this.formInline);
        this.loading = true;
        applyAfterSale(this.formInline).then(response => {
          this.loading = false;
          const resData = response.data;
          if (resData.code !== 10000) {
            this.$message.error(resData.msg || '发起售后失败');
          } else {
            this.$message.success('发起售后成功，请使用订单号搜索');
            this.formInline = {
              type: null,
              reason: null,
              orderCode: this.formInline.orderCode, // 留给他复制查询吧
              problem: null,
              images: [],
            };
          }
        });
      },
    },
  };

</script>

<style rel="stylesheet/scss" lang="scss" scoped>
     .app-container {
         font-family: "Microsoft YaHei", "微软雅黑", STXihei, "华文细黑", Georgia, "Times New Roman", Arial, sans-serif;
         display: flex;
         justify-content: center;
         align-items: center;

         .content-container {
             width: 700px;
             padding: 20px;
             box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);

             .title {
                 font-size: 20px;
                 margin: 30px 0;
             }

             .order-code-container {
                 height: 60px;
                 display: flex;
                 margin-bottom: 30px;
                 justify-content: center;
                 border-bottom: 2px dashed #EEEEEE;
             }

             .type-select {
                 display: flex;
                 flex-direction: row;
                 align-items: center;
                 margin-top: 20px;

                 .select-key {
                     display: inline-block;
                     min-width: 100px;
                     font-size: 15px;
                     color: #282828;
                 }

                 .select-value {
                     width: 500px;
                 }

                 .type-select-tips {
                     font-size: 14px;
                     margin-left: 25px;
                     color: #D9534F;
                 }
             }

             .images-container {
                 margin-top: 30px;
                 display: flex;
                 flex-direction: row;
                 justify-content: space-around;
                 align-items: center;
             }

             .opt-container {
                 margin-top: 30px;
                 padding: 20px 0;
                 border-top: 2px dashed #EEE;

                 .opt-button {
                     width: 100%;
                     color: #D9534F;
                     font-size: 15px;
                     font-weight: bolder;

                     &:hover{
                         background-color: #D9534F;
                         color: white;
                     }
                 }
             }
         }
     }

</style>