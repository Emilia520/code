<template>
  <div class="app-container">
    <el-row>
      <el-col :span="24">
        <div class="header-title">售后订单列表</div>
      </el-col>
      <!-- 筛选条件 start -->
      <el-col :span="24" class="status-select">
        <span style="font-size:14px">售后状态：</span>
        <el-select v-model="formInline.statusArr" :placeholder="statusName(0)" multiple>
          <el-option
                  v-for="item in statusArr"
                  :key="item"
                  :label="statusName(item)"
                  :value="item">
          </el-option>
        </el-select>
      </el-col>
      <el-col :span="24" class="status-select">
        <span style="font-size:14px">售后原因：</span>
        <el-select v-model="formInline.reasonArr" multiple>
          <el-option
                  v-for="item in reasonArr"
                  :key="item"
                  :label="reasonName(item)"
                  :value="reasonName(item)">
          </el-option>
        </el-select>
      </el-col>
      <el-col :span="24" class="order-code-select">
        <span style="font-size:14px">订单编号：</span>
        <el-input class="order-code-select-input" v-model="formInline.filterOrderCode" size="small" placeholder="请输入订单编号" clearable />
      </el-col>
      <el-col :span="24" class="confirm-select" style="margin-bottom: 50px">
        <el-button type="primary" size="small" style="min-width: 100px;" @click="getList">查询</el-button>
      </el-col>

      <!-- 筛选条件 end -->
      <el-col :span="24">
        <!-- 表格 start -->
        <el-table
                :data="tableData"
                border
                style="width: 100%"
                @row-click="rowClick"
                v-loading="loading">
          <el-table-column
                  fixed
                  prop="id"
                  label="id"
                  width="60">
          </el-table-column>
          <el-table-column
                  prop="people_name"
                  label="用户姓名"
                  min-width="10%">
          </el-table-column>
          <el-table-column
                  prop="title"
                  label="商品描述"
                  min-width="10%">
          </el-table-column>
          <el-table-column
                  prop="order_code"
                  label="自营订单号"
                  min-width="10%"/>
          <el-table-column
                  prop="reason"
                  label="退款原因"
                  min-width="10%">
          </el-table-column>
          <el-table-column
                  prop="product_info.akcSettlementPrice"
                  label="退款金额"
                  min-width="10%">
          </el-table-column>
          <el-table-column
                  label="售后类型"
                  min-width="10%">
            <template slot-scope="scope">
              <div v-if="scope.row.type === 1">仅退款</div>
              <div v-else-if="scope.row.type === 2">退货退款</div>
              <div v-else-if="scope.row.type === 3">换货</div>
              <div v-else>未知类型</div>
            </template>
          </el-table-column>
          <el-table-column
                  prop="problem"
                  label="问题描述"
                  min-width="10%">
          </el-table-column>
          <el-table-column
                  label="订单状态"
                  min-width="10%">
            <template slot-scope="scope">
              <div v-if="scope.row.order_status === 0">待支付</div>
              <div v-else-if="scope.row.order_status === 1">订单完成</div>
              <div v-else-if="scope.row.order_status === 2">待收货</div>
              <div v-else-if="scope.row.order_status === 3">已结算</div>
              <div v-else-if="scope.row.order_status === 4">删除</div>
              <div v-else-if="scope.row.order_status === 5">退款</div>
              <div v-else-if="scope.row.order_status === 6">待发货</div>
              <div v-else-if="scope.row.order_status === 7">售后</div>
              <div v-else-if="scope.row.order_status === 8">已失效</div>
            </template>
          </el-table-column>
          <el-table-column
                  label="售后状态"
                  min-width="10%">
            <template slot-scope="scope">
              <div v-if="scope.row.status === 0">待审核</div>
              <div v-else-if="scope.row.status === 1">退款成功</div>
              <div v-else-if="scope.row.status === 2">退邮费成功</div>
              <div v-else-if="scope.row.status === 3">待爱库存一审</div>
              <div v-else-if="scope.row.status === 4">爱库存一审通过</div>
              <div v-else-if="scope.row.status === 5">爱库存一审失败</div>
              <div v-else-if="scope.row.status === 6">待用户提交物流信息</div>
              <div v-else-if="scope.row.status === 7">待爱库存二审</div>
              <div v-else-if="scope.row.status === 8">爱库存二审通过</div>
              <div v-else-if="scope.row.status === 9">爱库存二审失败</div>
              <div v-else-if="scope.row.status === 10">失败</div>
            </template>
          </el-table-column>
          <el-table-column
                  label="操作"
                  min-width="10%">
            <template slot-scope="scope" style="display:flex;display:-webkit-flex;flex-direction:row;flex-wrap:wrap;justify-content:space-between;">
              <el-button v-if="scope.row.status === 0" type="success" plain size="small" @click.stop="apply(scope.row)" style="margin:10px">
                通过
              </el-button>
              <el-button v-if="scope.row.status === 0" type="danger" size="small" @click.stop="reject(scope.row)" style="margin:10px">
                拒绝
              </el-button>
              <el-button v-if="scope.row.status === 6" type="primary" size="small" @click.stop="uploadLogistics(scope.row)" style="margin:10px">
                上传快递单
              </el-button>
              <el-button v-if="scope.row.status === 8" type="success" plain size="small" @click.stop="refund(scope.row)" style="margin:10px">
                退款
              </el-button>
              <el-button v-if="scope.row.status > 0" type="primary" size="small" @click.stop="query(scope.row)" style="margin:10px">
                查询
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
      <!-- 表格 end -->
      <!-- 分页 start -->
      <el-col :span="24">
        <div class="pagination" style="margin-top:20px;">
          <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="formInline.page" :page-sizes="[10, 20, 30, 40]" :page-size="formInline.pageSize" layout="total, sizes, prev, pager, next" :total="totalCount">
          </el-pagination>
        </div>
      </el-col>
      <!-- 分页 end -->
      <!-- 弹层 start -->
      <el-col :span="24">
        <el-dialog title="确认售后信息" :visible.sync="applyDialogFormVisible" width="300" @close="cancelApplyForm">
          <el-form :model="applyForm" :rules="applyRules" ref="applyForm">
            <el-form-item label="描述" label-width="120px" prop="description">
              <el-input v-model="applyForm.description" placeholder="描述" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="退货原因" label-width="120px" prop="refundReason">
              <el-select v-model="applyForm.refundReason" placeholder="退货原因" size="mini">
                <el-option label="商品漏发" value="1"></el-option>
                <el-option label="质量问题" value="2"></el-option>
                <el-option label="发错款号" value="3"></el-option>
                <el-option label="发错颜色" value="4"></el-option>
                <el-option label="发错尺码" value="5"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="服务类型" label-width="120px" prop="applicationType">
              <el-select v-model="applyForm.applicationType" placeholder="服务类型" size="mini">
                <el-option label="漏发退款" value="2"></el-option>
                <el-option label="退货退款" value="4"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="是否收货" label-width="120px" prop="isReceived">
              <el-select v-model="applyForm.isReceived" placeholder="是否收货" size="mini">
                <el-option label="未收货" value="0"></el-option>
                <el-option label="已收货" value="1"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="建议原因" label-width="120px" prop="proposedReason">
              <el-select v-model="applyForm.proposedReason" placeholder="建议原因" size="mini">
                <el-option label="非质量问题换货" value="1"></el-option>
                <el-option label="非质量问题退货退款" value="2"></el-option>
                <el-option label="质量问题换货" value="3"></el-option>
                <el-option label="质量问题退货退款" value="4"></el-option>
                <el-option label="截单后仅退款" value="5"></el-option>
                <el-option label="未发货仅退款" value="6"></el-option>
              </el-select>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="cancelApplyForm('applyForm')">取 消</el-button>
            <el-button type="primary" @click="confirmApplyForm('applyForm')">确 定</el-button>
          </div>
        </el-dialog>
      </el-col>
      <el-col :span="24">
        <el-dialog title="拒绝售后" :visible.sync="rejectDialogFormVisible" width="300" @close="cancelRejectForm">
          <el-form :model="rejectForm" :rules="rejectRules" ref="rejectForm">
            <el-form-item label="商品描述" label-width="120px" prop="goodsDesc">
              <el-input :disabled="true" v-model="rejectForm.goodsDesc" placeholder="商品描述" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="拒绝理由" label-width="120px" prop="reason">
              <el-input v-model="rejectForm.reason" placeholder="拒绝理由" size="mini" clearable></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="cancelRejectForm('rejectForm')">取 消</el-button>
            <el-button type="primary" @click="confirmRejectForm('rejectForm')">确 定</el-button>
          </div>
        </el-dialog>
      </el-col>
      <el-col :span="24">
        <el-dialog title="售后单查询" :visible.sync="queryDialogFormVisible" width="300" @close="cancelQueryForm">
          <el-form :model="queryForm" ref="queryForm">
            <el-form-item label="商品描述" label-width="120px">
              <!-- <el-input :disabled="true" v-model="queryForm.goodsDesc" placeholder="商品描述" size="mini" clearable></el-input> -->
              <span>{{queryForm.goodsDesc}}</span>
            </el-form-item>
            <el-form-item label="申请单号" label-width="120px">
              <!-- <el-input :disabled="true" v-model="queryForm.applicationNo" placeholder="申请单号" size="mini" clearable></el-input> -->
              <span>{{queryForm.applicationNo}}</span>
            </el-form-item>
            <el-form-item label="物流信息" label-width="120px">
              <!-- <el-input :disabled="true" v-model="queryForm.applicationNo" placeholder="申请单号" size="mini" clearable></el-input> -->
              <div><b>回寄地址：</b>{{queryForm.returnAddress}}</div>
              <div><b>回寄联系人：</b>{{queryForm.returnName}}</div>
              <div><b>回寄电话：</b>{{queryForm.returnPhone}}</div>
            </el-form-item>
            <el-form-item label="审核信息" label-width="120px">
              <!-- <el-input :disabled="true" v-model="queryForm.applicationNo" placeholder="申请单号" size="mini" clearable></el-input> -->
              <div><b>审核状态：</b>{{queryForm.auditStatus}}</div>
              <div><b>一审审核备注：</b>{{queryForm.fristAuditRemark}}</div>
              <div><b>仓库审核备注：</b>{{queryForm.warehouseAuditRemark}}</div>
              <div><b>仲裁审核备注：</b>{{queryForm.arbitrateAuditRemark}}</div>
              <div><b>一审审核时间：</b>{{queryForm.firstAuditTime}}</div>
              <div><b>仓库审核时间：</b>{{queryForm.warehouseAuditTime}}</div>
              <div><b>仲裁审核时间：</b>{{queryForm.arbitrateAuditTime}}</div>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="cancelQueryForm('queryForm')">返 回</el-button>
          </div>
        </el-dialog>
      </el-col>
      <el-col :span="24">
        <el-dialog title="上传快递单" :visible.sync="logisticsDialogFormVisible" width="300" @close="cancelLogisticsForm">
          <el-form :model="logisticsForm" :rules="logisticsRules" ref="logisticsForm">
            <el-form-item label="商品描述" label-width="120px" prop="goodsDesc">
              <el-input :disabled="true" v-model="logisticsForm.goodsDesc" placeholder="商品描述" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="售后单号" label-width="120px" prop="applicationNo">
              <el-input :disabled="true" v-model="logisticsForm.applicationNo" placeholder="售后单号" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="快递公司" label-width="120px" prop="logisticsCompany">
              <el-input v-model="logisticsForm.logisticsCompany" placeholder="快递公司" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="快递单号" label-width="120px" prop="shipmentNo">
              <el-input v-model="logisticsForm.shipmentNo" placeholder="快递单号" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="寄回地址" label-width="120px" prop="returnAddress">
              <el-input v-model="logisticsForm.returnAddress" placeholder="寄回地址" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="寄回接收人" label-width="120px" prop="returnName">
              <el-input v-model="logisticsForm.returnName" placeholder="寄回接收人" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="寄回接收电话" label-width="120px" prop="returnPhone">
              <el-input v-model="logisticsForm.returnPhone" placeholder="寄回接收电话" size="mini" clearable></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="confirmLogisticsForm('logisticsForm')">上 传</el-button>
            <el-button @click="cancelLogisticsForm('logisticsForm')">返 回</el-button>
          </div>
        </el-dialog>
      </el-col>
      <!-- 弹层 end -->
    </el-row>
  </div>
</template>

<script>
  import { afterSaleList, approveAfterSale, rejectAfterSale, uploadLogistics, refundAfterSale } from '@/api/groupbuy';
  import { queryBill } from '@/api/aikucun';
  import { uploadImg } from '@/api/uploadImg';

  export default {
    data() {
      return {
        applyDialogFormVisible: false,
        rejectDialogFormVisible: false,
        queryDialogFormVisible: false,
        uploadImgDialogFormVisible: false,
        logisticsDialogFormVisible: false,
        uploadImg: '',
        totalCount: 0,
        loading: false,
        statusArr: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        reasonArr: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17],
        formInline: {
          page: 1,
          pageSize: 10,
          statusArr: [0],
          reasonArr: [],
          filterOrderCode: '',
        },
        applyForm: {
          item: null,
          description: '',
          refundReason: '',
          applicationType: '',
          isReceived: '',
          proposedReason: null,
        },
        rejectForm: {
          item: null,
          goodsDesc: '',
          reason: ''
        },
        queryForm: {
          item: null,
          applicationNo: '',
          goodsDesc: '',
          returnAddress: '',
          returnName: '',
          returnPhone: '',
          auditStatus: '',
          fristAuditRemark: '',
          warehouseAuditRemark: '',
          arbitrateAuditRemark: '',
          firstAuditTime: '',
          warehouseAuditTime: '',
          arbitrateAuditTime: ''
        },
        logisticsForm: {
          item: null,
          goodsDesc: '',
          applicationNo: '',
          logisticsCompany: '',
          shipmentNo: '',
          returnAddress: '',
          returnName: '',
          returnPhone: ''
        },
        uploadImgForm: {
          item: null,
          images: ['', '', '', '']
        },
        applyRules: {
          description: [{ required: true, message: '请输入售后描述', trigger: 'blur' }],
          refundReason: [{ required: true, message: '请选择退货原因', trigger: 'blur' }],
          applicationType: [{ required: true, message: '请选择服务类型', trigger: 'blur' }],
          isReceived: [{ required: true, message: '请选择是否已收货', trigger: 'blur' }]
        },
        rejectRules: {
          reason: [{ required: true, message: '请填写拒绝理由', trigger: 'blur' }],
        },
        logisticsRules: {
          logisticsCompany: [{ required: true, message: '请填写物流公司', trigger: 'blur' }],
          shipmentNo: [{ required: true, message: '请填写快递单号', trigger: 'blur' }],
          returnAddress: [{ required: true, message: '请填写寄回地址', trigger: 'blur' }],
          returnName: [{ required: true, message: '请填写寄回接收人', trigger: 'blur' }],
          returnPhone: [{ required: true, message: '请填写寄回接收手机', trigger: 'blur' }]
        },
        tableData: [],
        formLabelWidth: '120px',
      };
    },
    created() {
      // 筛选页面初始化
      this.uploadImg = uploadImg;
      this.formInline.page = 1;
      this.formInline.pageSize = 10;
      this.formInline.statusArr = [0];

      this.getList();
    },
    methods: {
      onSubmit() {
        this.getList();
      },
      getList() {
        this.loading = true;
        // 请求列表
        afterSaleList(this.formInline).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.tableData = res.data;
            this.totalCount = res.totalCount;
            for (const i in this.tableData) {
              const item = this.tableData[i];
              if (item.images) {
                item.images = JSON.parse(item.images);
              } else {
                item.images = [];
              }

              if (item.product_info) {
                item.product_info = JSON.parse(item.product_info);
              } else {
                item.product_info = {};
              }

              if (item.receiving_info) {
                item.receiving_info = JSON.parse(item.receiving_info);
              } else {
                item.receiving_info = {};
              }

              if (item.delivery_info) {
                console.log(item.delivery_info);

                item.delivery_info = JSON.parse(item.delivery_info);
              } else {
                item.delivery_info = {};
              }
            }
          }
          this.loading = false;
        });
      },
      setStatus() {
        this.getList();
      },
      setReasons() {
        this.getList();
      },
      // 分页
      handleSizeChange(pageSize) {
        this.formInline.pageSize = pageSize;
        this.getList();
      },
      // 页码变化时触发
      handleCurrentChange(page) {
        this.formInline.page = page;
        this.getList();
      },
      // 一审通过
      apply(item) {
        if ((item.order_status === 1 || item.order_status === 2 ||
          item.order_status === 3 || item.order_status === 6 || item.order_status === 7) && item.status === 0) {
          // 以上状态满足可通过审核状态，尝试向爱库存创建售后单
          this.applyForm.item = item;
          this.applyForm.description = item.problem ? item.problem : item.reason;
          this.applyDialogFormVisible = true;
        } else {
          this.$message({
            message: '订单状态或者售后状态异常，请联系开发哥哥',
            type: 'error'
          });
        }
      },
      // 拒绝
      reject(item) {
        this.rejectForm.item = item;
        this.rejectForm.goodsDesc = item.title;
        this.rejectDialogFormVisible = true;
      },
      // 退款
      refund(item) {
        this.loading = true;
        refundAfterSale({ id: item.id, orderCode: item.order_code }).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.$message({
              message: res.msg ? res.msg : '退款成功',
              type: 'success'
            });
            item.status = 1;
          } else {
            this.$message({
              message: res.msg ? res.msg : '退款失败',
              type: 'error'
            });
          }

          this.loading = false;
        });
      },
      // 查询
      query(item) {
        if (item.application_no) {
          this.loading = true;
          queryBill({ applicationNo: item.application_no }).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.queryForm.item = item;
              this.queryForm.goodsDesc = item.title;
              this.queryForm.applicationNo = res.data.applicationNo;
              this.queryForm.returnAddress = res.data.returnAddress ? res.data.returnAddress : item.receiving_info.address;
              this.queryForm.returnName = res.data.returnName ? res.data.returnName : item.receiving_info.name;
              this.queryForm.returnPhone = res.data.returnPhone ? res.data.returnPhone : item.receiving_info.phone;
              this.queryForm.auditStatus = res.data.auditStatus + '(-1:审核拒绝;0:待审核;其他找开发确认)';
              this.queryForm.fristAuditRemark = res.data.fristAuditRemark;
              this.queryForm.warehouseAuditRemark = res.data.warehouseAuditRemark;
              this.queryForm.arbitrateAuditRemark = res.data.arbitrateAuditRemark;
              this.queryForm.firstAuditTime = res.data.firstAuditTime;
              this.queryForm.warehouseAuditTime = res.data.warehouseAuditTime;
              this.queryForm.arbitrateAuditTime = res.data.arbitrateAuditTime;
              this.queryDialogFormVisible = true;
            } else {
              this.$message({
                message: res.msg ? res.msg : '查询失败',
                type: 'error'
              });
            }

            this.loading = false;
          });
        } else {
          this.$message({
            message: '售后单为空，无法查询',
            type: 'info'
          });
        }
      },
      // 上传快递单
      uploadLogistics(item) {
        this.logisticsForm.item = item;
        this.logisticsForm.goodsDesc = item.title;
        this.logisticsForm.applicationNo = item.application_no;
        this.logisticsForm.logisticsCompany = '';
        this.logisticsForm.shipmentNo = '';
        this.logisticsForm.returnAddress = item.receiving_info.returnAddress;
        this.logisticsForm.returnName = item.receiving_info.returnName;
        this.logisticsForm.returnPhone = item.receiving_info.returnPhone;
        this.logisticsDialogFormVisible = true;
      },
      cancelApplyForm() {
        this.applyDialogFormVisible = false;
      },
      cancelRejectForm() {
        this.rejectDialogFormVisible = false;
      },
      cancelQueryForm() {
        this.queryDialogFormVisible = false;
      },
      cancelUploadImgForm() {
        this.uploadImgForm.images = [];
        this.uploadImgDialogFormVisible = false;
      },
      cancelLogisticsForm() {
        this.logisticsDialogFormVisible = false;
      },
      confirmApplyForm(formName) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.loading = true;
            let picUrls = this.applyForm.item.images.join(',');
            picUrls = picUrls ? picUrls : '[]';

            console.log(this.applyForm);
            const params = {
              id: this.applyForm.item.id,
              orderCode: this.applyForm.item.order_code,
              orderId: this.applyForm.item.tp_order_code,
              orderDetatilId: this.applyForm.item.akc_order_detatil_id,
              picUrls,
              description: this.applyForm.description,
              refundReason: this.applyForm.refundReason,
              applicationType: this.applyForm.applicationType,
              isReceived: this.applyForm.isReceived,
              amount: String(this.applyForm.item.product_info.akcSettlementPrice),
              proposedReason: this.applyForm.proposedReason,
            };
            approveAfterSale(params).then(response => {
              const res = response.data;
              if (res.code === 10000) {
                this.$message({
                  message: res.msg ? res.msg : '操作成功',
                  type: 'success'
                });
                this.applyForm.item.application_no = res.data.applicationNo;
                // 有售后单说明爱库存已经受理，设置待一审状态。如果没有，则说明退款成功
                this.applyForm.item.status = res.data.applicationNo ? 3 : 1;
              } else {
                this.$message({
                  message: res.msg ? res.msg : '操作失败',
                  type: 'error'
                });
              }

              this.loading = false;
              this.applyDialogFormVisible = false;
            });
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
      confirmRejectForm(formName) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.loading = true;
            const params = {
              id: this.rejectForm.item.id,
              orderId: this.rejectForm.item.order_id,
              reason: this.rejectForm.reason,
            };
            rejectAfterSale(params).then(response => {
              const res = response.data;
              if (res.code === 10000) {
                this.$message({
                  message: '拒绝成功',
                  type: 'success'
                });
                this.rejectForm.item.status = 10;
              } else {
                this.$message({
                  message: '拒绝失败',
                  type: 'error'
                });
              }

              this.loading = false;
              this.rejectDialogFormVisible = false;
            });
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
      confirmLogisticsForm(formName) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.loading = true;
            const params = {
              id: this.logisticsForm.item.id,
              applicationNo: this.logisticsForm.applicationNo,
              logisticsCompany: this.logisticsForm.logisticsCompany,
              shipmentNo: this.logisticsForm.shipmentNo,
              returnAddress: this.logisticsForm.returnAddress,
              returnName: this.logisticsForm.returnName,
              returnPhone: this.logisticsForm.returnPhone
            };
            uploadLogistics(params).then(response => {
              const res = response.data;
              if (res.code === 10000) {
                this.$message({
                  message: res.msg ? res.msg : '上传成功',
                  type: 'success'
                });
                // 有售后单说明爱库存已经受理，设置待一审状态。如果没有，则说明退款成功
                this.logisticsForm.item.status = res.data.applicationNo ? 7 : 6;
              } else {
                this.$message({
                  message: res.msg ? res.msg : '上传失败',
                  type: 'error'
                });
              }

              this.loading = false;
              this.logisticsDialogFormVisible = false;
            });
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
      rowClick(row) {
        this.$router.push({
          path: '/afterSale/afterSaleOrderDetail',
          name: 'afterSaleOrderDetail',
          params: row,
        });
      },
      statusName(status) {
        switch (status) {
          case 0:
            return '待审核';
          case 1:
            return '退款成功';
          case 2:
            return '退邮费成功';
          case 3:
            return '待爱库存一审';
          case 4:
            return '爱库存一审通过';
          case 5:
            return '爱库存一审失败';
          case 6:
            return '待用户提交物流信息';
          case 7:
            return '待爱库存二审';
          case 8:
            return '爱库存二审通过';
          case 9:
            return '爱库存二审失败';
          case 10:
            return '失败';
          default:
            return '未知状态';
        }
      },
      reasonName(reason) {
        switch (reason) {
          case 1:
            return '与卖家协商一致退款';
          case 2:
            return '物流公司发货问题';
          case 3:
            return '卖家虚假发货';
          case 4:
            return '空包裹/少货';
          case 5:
            return '多拍/拍错/不想要';
          case 6:
            return '商家未按时间发货';
          case 7:
            return '其他';
          case 8:
            return '下单失败';
          case 9:
            return '不想要了，手动创建';
          case 10:
            return '与卖家协商一致';
          case 11:
            return '优品团人工帮忙创建售后单';
          case 12:
            return '商家缺货退款';
          case 13:
            return '质量问题换货';
          case 14:
            return '质量问题退货退款';
          case 15:
            return '7天无理由换货';
          case 16:
            return '7天无理由退货退款';
          case 17:
            return '截单后仅退款';
          default:
            return '未知原因';
        }
      },
    }
  };
</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  .status-select {
    margin-bottom: 20px;
  }

  .order-code-select {
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
    align-items: center;
    margin-bottom: 30px;

    .order-code-select-input {
      width: 220px;
    }
  }

</style>
