<template>
    <div class="app-container">
        <el-container>
            <div v-if="afterSaleDetail.order_type === 1" class="self-opt-icon">
                <div class="self-opt-icon-title">自营商品</div>
            </div>
            <div v-else-if="_isHYKProduct()" class="self-opt-icon">
                <div class="self-opt-icon-title">好衣库</div>
            </div>
            <el-aside class="app-aside">
                <div class="back-container" @click="$router.back()">
                    <el-button type="info" class="back-button" icon="el-icon-back" circle></el-button>
                </div>
                <div class="aside-key">ID:</div>
                <div v-if="afterSaleDetail.id != null" class="aside-value">{{afterSaleDetail.id}}</div>
                <div v-else class="aside-value"> 暂无数据</div>
                <div class="aside-key sep">自营订单号:</div>
                <div v-if="afterSaleDetail.order_code != null" class="aside-value">
                    {{afterSaleDetail.order_code}}
                </div>
                <div v-else class="aside-value"> 暂无数据</div>
                <div class="aside-key">售后单号:</div>
                <div v-if="afterSaleDetail.after_sale_no != null" class="aside-value">
                    {{afterSaleDetail.after_sale_no}}
                </div>
                <div v-else class="aside-value"> 暂无数据</div>
                <div class="aside-key sep">爱库存二级订单号:</div>
                <div v-if="afterSaleDetail.tp_order_code != null" class="aside-value">
                    {{afterSaleDetail.tp_order_code}}
                </div>
                <div v-else class="aside-value"> 暂无数据</div>
                <div class="aside-key">爱库存三级订单号:</div>
                <div v-if="afterSaleDetail.akc_order_detatil_id != null" class="aside-value">
                    {{afterSaleDetail.akc_order_detatil_id}}
                </div>
                <div v-else class="aside-value"> 暂无数据</div>
                <div class="aside-key">爱库存售后单号:</div>
                <div v-if="afterSaleDetail.application_no != null" class="aside-value">
                    {{afterSaleDetail.application_no}}
                </div>
                <div v-else class="aside-value"> 暂无数据</div>
            </el-aside>
            <el-container>
                <el-header class="app-header" height="90px">
                    <div class="user-info">
                        <p class="header-user-name">{{afterSaleDetail.people_name}}</p>
                        <div class="header-user-nickname">{{afterSaleDetail.nickname}}</div>
                        <div class="header-user-phone"> TEL: {{afterSaleDetail.user_phone}}</div>
                    </div>
                    <div class="product-info">
                        <div>商品详情<i class="el-icon-d-arrow-right"></i></div>
                    </div>
                </el-header>
                <el-main class="app-center" v-loading="loading">
                    <div class="main-order-title">{{afterSaleDetail.title}}</div>
                    <div class="main-option">
                        <span class="main-option-key">订单状态</span>
                        <el-select :value="afterSaleDetail" value-key="order_status" size="small"
                                   :disabled="_isFinalStatus(afterSaleDetail.status) || afterSaleDetail.status === 1"
                                   :placeholder='_orderStatusName(afterSaleDetail.order_status)'
                                   @change="_onOrderStatusChanged">
                            <el-option
                                    v-for="item in orderStatus"
                                    :key="item"
                                    :label="_orderStatusName(item)"
                                    :value="item"
                                    :disabled="item === afterSaleDetail.order_status || item === 7">
                            </el-option>
                        </el-select>
                    </div>
                    <div class="main-option">
                        <span class="main-option-key">售后类型</span>
                        <el-select :value="afterSaleDetail" value-key="type" size="small"
                                   :disabled="_isFinalStatus(afterSaleDetail.status) || afterSaleDetail.status === 1"
                                   :placeholder='_afterSaleTypeName(afterSaleDetail.type)'
                                   @change="_onAfterSaleTypeChanged">
                            <el-option
                                    v-for="item in afterSaleTypes"
                                    :key="item"
                                    :label="_afterSaleTypeName(item)"
                                    :value="item"
                                    :disabled="item === afterSaleDetail.type">
                            </el-option>
                        </el-select>
                    </div>
                    <div class="main-option">
                        <span class="main-option-key">售后状态</span>
                        <el-select :value="afterSaleDetail" value-key="status" size="small"
                                   :disabled="_isFinalStatus(afterSaleDetail.status) || afterSaleDetail.status === 1"
                                   :placeholder='_afterSaleStatusName(afterSaleDetail.status)'
                                   @change="_onAfterSaleStatusChanged">
                            <el-option
                                    v-for="item in afterSaleStatus"
                                    :key="item"
                                    :label="_afterSaleStatusName(item)"
                                    :value="item"
                                    :disabled="item === afterSaleDetail.status || _disableAfterSaleStatus(item)">
                            </el-option>
                        </el-select>
                        <span v-if="afterSaleDetail.status === 10" class="afterSale-fail-reason">原因: {{afterSaleDetail.fail_reason}}</span>
                    </div>
                    <div class="main-option">
                        <span class="main-option-key">售后原因</span>
                        <el-select :value="afterSaleDetail" value-key="reason" size="small"
                                   :disabled="_isFinalStatus(afterSaleDetail.status) || afterSaleDetail.status === 1"
                                   :placeholder="_isNotEmptyStr(afterSaleDetail.reason) ? afterSaleDetail.reason : '未填写'"
                                   @change="_onAfterSaleReasonChanged">
                            <el-option
                                    v-for="item in afterSaleReasons"
                                    :key="item.id"
                                    :label="item.value"
                                    :value="item"
                                    :disabled="_disableAfterSaleReason(item.value)">
                            </el-option>
                        </el-select>
                    </div>
                    <div class="main-option-withdraw sep">
                        <span class="withdraw-amount-key">退款金额</span>
                        <span class="main-withdraw-amount">{{_price()}}</span>
                    </div>
                    <div class="main-option-withdraw">
                        <span class="withdraw-amount-key">退款邮费</span>
                        <span class="main-withdraw-amount">{{_postage()}}</span>
                    </div>
                    <div class="main-option-problem">
                        <span class="problem-key">问题描述</span>
                        <span class="problem-input">
                            <el-input class="problem-value" type="textarea" v-model="afterSaleProblem"
                                      :placeholder="_problemPlaceholder()" size="small" autosize/>
                            <el-button size="small" type="text" :disabled="_disableSaveProblemButton()"
                                       @click="_saveProblemDescription" circle>
                                更新描述
                            </el-button>
                        </span>
                    </div>
                    <div class="main-product-images">
                        <div class="product-images-title">问题图片</div>
                        <div class="product-images-container">
                            <image-preview-card class="image-previewer"
                                                :index='0'
                                                :action="uploadImageAction"
                                                :beforeUpload="_beforeUploadImage"
                                                :uploadSuccess="_uploadImageSuccess"
                                                :source="afterSaleDetail.images[0]">
                            </image-preview-card>
                            <image-preview-card class="image-previewer"
                                                :index='1'
                                                :action="uploadImageAction"
                                                :beforeUpload="_beforeUploadImage"
                                                :uploadSuccess="_uploadImageSuccess"
                                                :source="afterSaleDetail.images[1]">
                            </image-preview-card>
                            <image-preview-card class="image-previewer"
                                                :index='2'
                                                :action="uploadImageAction"
                                                :beforeUpload="_beforeUploadImage"
                                                :uploadSuccess="_uploadImageSuccess"
                                                :source="afterSaleDetail.images[2]">
                            </image-preview-card>
                            <image-preview-card class="image-previewer"
                                                :index='3'
                                                :action="uploadImageAction"
                                                :beforeUpload="_beforeUploadImage"
                                                :uploadSuccess="_uploadImageSuccess"
                                                :source="afterSaleDetail.images[3]">
                            </image-preview-card>
                        </div>
                    </div>
                    <div class="main-logistics">
                        <div class="main-logistics-container">
                            <div class="main-logistics-header">
                                <span class="main-logistics-title">用户寄回物流信息</span>
                                <span class="main-logistics-save">
                                    <el-button type="text" :disabled="_disableSaveUserDeliveryInfoButton()" size="small"
                                               @click="_updateUserDeliveryInfo">更新信息</el-button>
                                </span>
                            </div>
                            <div class="main-logistics-contents">
                                <div class="main-logistics-contents-left">
                                    <div class="main-logistics-options">
                                        <span class="main-logistics-key">物流号:</span>
                                        <span class="logistics-input">
                                           <el-input class="logistics-value" type="text"
                                                     v-model="userDeliveryInfo.deliveryNo"
                                                     :placeholder="_userDeliveryInfoPlaceholder('deliveryNo')"
                                                     size="small" clearable/>
                                       </span>
                                    </div>
                                    <div class="main-logistics-options">
                                        <span class="main-logistics-key">物流公司:</span>
                                        <span class="logistics-input">
                                           <el-input class="logistics-value" type="text"
                                                     v-model="userDeliveryInfo.deliveryCompany"
                                                     :placeholder="_userDeliveryInfoPlaceholder('deliveryCompany')"
                                                     size="small" clearable/>
                                       </span>
                                    </div>
                                    <div class="main-logistics-options">
                                        <span class="main-logistics-key">发货人手机:</span>
                                        <span class="logistics-input">
                                           <el-input class="logistics-value" type="text"
                                                     v-model="userDeliveryInfo.phone"
                                                     :placeholder="_userDeliveryInfoPlaceholder('phone')" size="small"
                                                     clearable/>
                                       </span>
                                    </div>
                                    <div class="main-logistics-options" style="margin-top: 20px">
                                        <span class="main-logistics-key">用户支付宝昵称:</span>
                                        <span class="logistics-input">{{ _userDeliveryInfoPlaceholder('alipayName')}}</span>
                                    </div>
                                    <div class="main-logistics-options">
                                        <span class="main-logistics-key">用户支付宝账号:</span>
                                        <span class="logistics-input">{{ _userDeliveryInfoPlaceholder('alipayUser')}}</span>
                                    </div>
                                    <div class="main-logistics-options">
                                        <span class="main-logistics-key">邮费:</span>
                                        <span class="logistics-input">{{ _userDeliveryInfoPlaceholder('postage')}}</span>
                                    </div>
                                </div>
                                <div class="main-logistics-contents-right">
                                    <image-preview-card class="image-previewer"
                                                        :action="uploadImageAction"
                                                        :beforeUpload="_beforeUploadReceiptImage"
                                                        :uploadSuccess="_uploadReceiptImageSuccess"
                                                        :source="afterSaleDetail.delivery_info.postageFromImg"/>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="main-send-info">
                        <div class="main-send-info-container">
                            <div class="main-send-info-header">
                                <span class="main-send-info-title">商家寄回信息</span>
                                <span class="main-send-info-save">
                                    <el-button type="text" :disabled="_disableSaveSellerDeliveryInfoButton()"
                                               size="small"
                                               @click="_updateSellerDeliveryInfo">更新信息</el-button>
                                </span>
                            </div>
                            <div class="main-send-info-options">
                                <span class="main-send-info-key">收货人:</span>
                                <span class="send-info-input">
                                           <el-input class="send-info-value" type="text"
                                                     v-model="sellerDeliveryInfo.name"
                                                     :placeholder="_sellerDeliveryInfoPlaceholder('name')"
                                                     size="small" clearable/>
                                       </span>
                            </div>
                            <div class="main-send-info-options">
                                <span class="main-send-info-key">手机号码:</span>
                                <span class="send-info-input">
                                           <el-input class="send-info-value" type="text"
                                                     v-model="sellerDeliveryInfo.phone"
                                                     :placeholder="_sellerDeliveryInfoPlaceholder('phone')"
                                                     size="small" clearable/>
                                       </span>
                            </div>
                            <div class="main-send-info-options">
                                <span class="main-send-info-key">收货地址:</span>
                                <span class="send-info-input">
                                           <el-input class="send-info-value" type="text"
                                                     v-model="sellerDeliveryInfo.address"
                                                     :placeholder="_sellerDeliveryInfoPlaceholder('address')"
                                                     size="small" clearable/>
                                       </span>
                            </div>
                            <div class="send-code-input">
                                <el-input type="text" v-model="storeDeliveryNO" :placeholder="_deliveryPlaceholder()"
                                          size="small">
                                    <el-button icon="el-icon-circle-check-outline" slot="append" size="small"
                                               type="success"
                                               :disabled="_disableSaveDeliveryButton()"
                                               @click="_saveStoreDeliveryNO">
                                    </el-button>
                                </el-input>
                            </div>
                        </div>
                    </div>
                </el-main>
                <el-footer class="app-footer" height="90px">
                    <div class="time-container">
                        <div>订单更新时间: {{_updateTime()}}</div>
                        <div>订单创建时间: {{afterSaleDetail.order_create_date != null
                            ? afterSaleDetail.order_create_date
                            : '暂无数据'}}
                        </div>
                        <div>售后单创建时间: {{afterSaleDetail.create_date != null
                            ? afterSaleDetail.create_date
                            : '暂无数据'}}
                        </div>
                    </div>
                    <div class="btn-container">
                        <el-button class="opt-btn" v-if="afterSaleDetail.status === 0" type="success" plain size="small"
                                   @click="apply(afterSaleDetail)">
                            {{afterSaleDetail.order_type === 2 ? '发起一审' : '通过'}}
                        </el-button>
                        <el-button class="opt-btn" v-if="afterSaleDetail.status === 0" type="danger" size="small"
                                   @click="reject(afterSaleDetail)">
                            拒绝
                        </el-button>
                        <el-button class="opt-btn" v-if="afterSaleDetail.status === 6" type="primary" size="small"
                                   @click="uploadLogistics(afterSaleDetail)">
                            上传快递单
                        </el-button>
                        <el-button class="opt-btn" v-if="_showRefundButton()" type="success" plain size="small"
                                   @click="refund(afterSaleDetail)">
                            退款
                        </el-button>
                        <el-button class="opt-btn" v-if="afterSaleDetail.status > 1" type="primary" size="small"
                                   @click="query(afterSaleDetail)">
                            查询
                        </el-button>
                        <el-button class="opt-btn" v-if="_showRestartAfterSaleButton()" type="primary" size="small"
                                   @click="startAfterSale(afterSaleDetail)">
                            重新售后
                        </el-button>
                        <el-button class="opt-btn" v-if="_showCancelAfterSaleButton()" type="danger" size="small"
                                   @click="cancelAfterSale(afterSaleDetail)">
                            取消售后
                        </el-button>
                        <el-button class="opt-btn" v-if="_showHaveRefundButton()" type="danger" size="small" @click="_alreadyRefund">
                            已手工退款
                        </el-button>
                    </div>
                </el-footer>
            </el-container>
        </el-container>
        <!-- Apply form -->
        <el-dialog title="确认售后信息" :visible.sync="applyDialogFormVisible" width="300"
                   @close="this.applyDialogFormVisible=false">
            <el-form :model="applyForm" :rules="applyRules" ref="applyForm">
                <el-form-item label="描述" label-width="120px" prop="description">
                    <el-input v-model="applyForm.description" placeholder="描述" size="mini" clearable></el-input>
                </el-form-item>
                <el-form-item label="退货原因" label-width="120px" prop="refundReason">
                    <el-select v-model="applyForm.refundReason" placeholder="退货原因" size="mini">
                        <el-option label="商品漏发" value="1"></el-option>
                        <el-option label="质量问题" value="2"></el-option>
                        <el-option label="发错款号" value="3"></el-option>
                        <el-option label="发错颜色" value="4"></el-option>
                        <el-option label="发错尺码" value="5"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="服务类型" label-width="120px" prop="applicationType">
                    <el-select v-model="applyForm.applicationType" placeholder="服务类型" size="mini">
                        <el-option label="漏发退款" value="2"></el-option>
                        <el-option label="退货退款" value="4"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="是否收货" label-width="120px" prop="isReceived">
                    <el-select v-model="applyForm.isReceived" placeholder="是否收货" size="mini">
                        <el-option label="未收货" value="0"></el-option>
                        <el-option label="已收货" value="1"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="建议原因" label-width="120px" prop="proposedReason">
                    <el-select v-model="applyForm.proposedReason" placeholder="建议原因" size="mini">
                        <el-option label="非质量问题换货" value="1"></el-option>
                        <el-option label="非质量问题退货退款" value="2"></el-option>
                        <el-option label="质量问题换货" value="3"></el-option>
                        <el-option label="质量问题退货退款" value="4"></el-option>
                        <el-option label="截单后仅退款" value="5"></el-option>
                        <el-option label="未发货仅退款" value="6"></el-option>
                    </el-select>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="this.applyDialogFormVisible=false">取 消</el-button>
                <el-button type="primary" @click="confirmApplyForm('applyForm')">确 定</el-button>
            </div>
        </el-dialog>
        <!-- Reject form -->
        <el-dialog title="拒绝售后" :visible.sync="rejectDialogFormVisible" width="300"
                   @close="rejectDialogFormVisible = false">
            <el-form :model="rejectForm" :rules="rejectRules" ref="rejectForm">
                <el-form-item label="商品描述" label-width="120px" prop="goodsDesc">
                    <el-input :disabled="true" v-model="rejectForm.goodsDesc" placeholder="商品描述" size="mini"
                              clearable></el-input>
                </el-form-item>
                <el-form-item label="拒绝理由" label-width="120px" prop="reason">
                    <el-input v-model="rejectForm.reason" placeholder="拒绝理由" size="mini" clearable></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="rejectDialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="confirmRejectForm('rejectForm')">确 定</el-button>
            </div>
        </el-dialog>
        <!-- Logistics form -->
        <el-dialog title="上传快递单" :visible.sync="logisticsDialogFormVisible" width="300"
                   @close="logisticsDialogFormVisible = false">
            <el-form :model="logisticsForm" :rules="logisticsRules" ref="logisticsForm">
                <el-form-item label="商品描述" label-width="120px" prop="goodsDesc">
                    <el-input :disabled="true" v-model="logisticsForm.goodsDesc" placeholder="商品描述" size="mini"
                              clearable></el-input>
                </el-form-item>
                <el-form-item label="售后单号" label-width="120px" prop="applicationNo">
                    <el-input :disabled="true" v-model="logisticsForm.applicationNo" placeholder="售后单号" size="mini"
                              clearable></el-input>
                </el-form-item>
                <el-form-item label="快递公司" label-width="120px" prop="logisticsCompany">
                    <el-input v-model="logisticsForm.logisticsCompany" placeholder="快递公司" size="mini"
                              clearable></el-input>
                </el-form-item>
                <el-form-item label="快递单号" label-width="120px" prop="shipmentNo">
                    <el-input v-model="logisticsForm.shipmentNo" placeholder="快递单号" size="mini" clearable></el-input>
                </el-form-item>
                <el-form-item label="寄回地址" label-width="120px" prop="returnAddress">
                    <el-input v-model="logisticsForm.returnAddress" placeholder="寄回地址" size="mini" clearable></el-input>
                </el-form-item>
                <el-form-item label="寄回接收人" label-width="120px" prop="returnName">
                    <el-input v-model="logisticsForm.returnName" placeholder="寄回接收人" size="mini" clearable></el-input>
                </el-form-item>
                <el-form-item label="寄回接收电话" label-width="120px" prop="returnPhone">
                    <el-input v-model="logisticsForm.returnPhone" placeholder="寄回接收电话" size="mini" clearable></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="confirmLogisticsForm('logisticsForm')">上 传</el-button>
                <el-button @click="logisticsDialogFormVisible = false">返 回</el-button>
            </div>
        </el-dialog>
        <!-- Query form -->
        <el-dialog title="售后单查询" :visible.sync="queryDialogFormVisible" width="300"
                   @close="queryDialogFormVisible = false">
            <el-form :model="queryForm" ref="queryForm">
                <el-form-item label="商品描述" label-width="120px">
                    <!-- <el-input :disabled="true" v-model="queryForm.goodsDesc" placeholder="商品描述" size="mini" clearable></el-input> -->
                    <span>{{queryForm.goodsDesc}}</span>
                </el-form-item>
                <el-form-item label="申请单号" label-width="120px">
                    <!-- <el-input :disabled="true" v-model="queryForm.applicationNo" placeholder="申请单号" size="mini" clearable></el-input> -->
                    <span>{{queryForm.applicationNo}}</span>
                </el-form-item>
                <el-form-item label="物流信息" label-width="120px">
                    <!-- <el-input :disabled="true" v-model="queryForm.applicationNo" placeholder="申请单号" size="mini" clearable></el-input> -->
                    <div><b>回寄地址：</b>{{queryForm.returnAddress}}</div>
                    <div><b>回寄联系人：</b>{{queryForm.returnName}}</div>
                    <div><b>回寄电话：</b>{{queryForm.returnPhone}}</div>
                </el-form-item>
                <el-form-item label="审核信息" label-width="120px">
                    <!-- <el-input :disabled="true" v-model="queryForm.applicationNo" placeholder="申请单号" size="mini" clearable></el-input> -->
                    <div><b>审核状态：</b>{{queryForm.auditStatus}}</div>
                    <div><b>一审审核备注：</b>{{queryForm.fristAuditRemark}}</div>
                    <div><b>仓库审核备注：</b>{{queryForm.warehouseAuditRemark}}</div>
                    <div><b>仲裁审核备注：</b>{{queryForm.arbitrateAuditRemark}}</div>
                    <div><b>一审审核时间：</b>{{queryForm.firstAuditTime}}</div>
                    <div><b>仓库审核时间：</b>{{queryForm.warehouseAuditTime}}</div>
                    <div><b>仲裁审核时间：</b>{{queryForm.arbitrateAuditTime}}</div>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="queryDialogFormVisible = false">返 回</el-button>
            </div>
        </el-dialog>
        <!-- 自营订单通过确认弹窗 -->
        <el-dialog title="自营售后" :visible.sync="selfOptApplyDialogVisible">
            <div style="font-size: 15px; margin-bottom: 15px">请确认自营商品售后原因，选择原因后系统会自动更改订单售后状态和售后类型等数据</div>
            <el-radio-group v-model="selfOptApplyType" style="margin-bottom:20px">
                <el-radio :label="1">质量问题换货</el-radio>
                <el-radio :label="2">质量问题退货退款</el-radio>
                <el-radio :label="3">未发货仅退款</el-radio>
            </el-radio-group>
            <div style="text-align: right;">
                <el-button type="primary" size="small" style="min-width: 100px;" @click="_onSelfOptConfirmApply">确定
                </el-button>
                <el-button type="info" size="small" style="min-width: 100px;" @click="selfOptApplyDialogVisible=false">
                    取消
                </el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
  const assert = require('assert');
  const Utils = require('../../../../../utils/utils.js');

  import ImagePreviewCard from '@/component/ImagePreview';
  import { uploadImg } from '@/api/uploadImg';
  import { queryBill } from '@/api/aikucun';
  import { timestampToTime } from 'utils/chanageTime';

  import {
    approveAfterSale,
    rejectAfterSale,
    updateAfterSaleImages,
    uploadLogistics,
    refundAfterSale,
    afterSaleReasonList,
    updateOrderStatus,
    updateStoreDeliveryInfo,
    updateSellerDeliveryInfo,
    updateACKAfterSaleOrder,
    restartAfterSale,
    cancelAfterSale,
    alreadyRefund,
    productForAfterSaleOrder
  } from '@/api/groupbuy';

  export default {
    name: 'afterSaleDetail',
    components: { ImagePreviewCard },
    data() {
      return {
        afterSaleDetail: {},
        afterSaleReasons: [
          { id: 1, value: '与卖家协商一致退款', status: 1, sort: 1 },
          { id: 2, value: '物流公司发货问题', status: 1, sort: 2 },
          { id: 3, value: '卖家虚假发货', status: 1, sort: 3 },
          { id: 4, value: '空包裹/少货', status: 1, sort: 4 },
          { id: 5, value: '多拍/拍错/不想要', status: 1, sort: 5 },
          { id: 6, value: '商家未按时间发货', status: 1, sort: 6 },
          { id: 7, value: '其他', status: 1, sort: 7 },
          { id: 8, value: '下单失败', status: 0, sort: 8 },
          { id: 9, value: '不想要了，手动创建', status: 0, sort: 9 },
          { id: 10, value: '与卖家协商一致', status: 0, sort: 10 },
          { id: 11, value: '优品团人工帮忙创建售后单', status: 0, sort: 11 },
          { id: 12, value: '商家缺货退款', status: 0, sort: 12 },
          { id: 13, value: '质量问题换货', status: 0, sort: 13 },
          { id: 14, value: '质量问题退货退款', status: 0, sort: 14 },
          { id: 15, value: '7天无理由换货', status: 0, sort: 15 },
          { id: 16, value: '7天无理由退货退款', status: 0, sort: 16 },
          { id: 17, value: '截单后仅退款', status: 0, sort: 17 }],

        afterSaleTypes: [1, 2, 3],
        orderStatus: [0, 1, 2, 3, 4, 5, 6, 7, 8],
        afterSaleStatus: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],

        applyForm: {
          item: null,
          description: '',
          refundReason: '',
          applicationType: '',
          isReceived: '',
          proposedRason: null,
        },
        rejectForm: {
          item: null,
          goodsDesc: '',
          reason: ''
        },
        queryForm: {
          item: null,
          applicationNo: '',
          goodsDesc: '',
          returnAddress: '',
          returnName: '',
          returnPhone: '',
          auditStatus: '',
          firstAuditRemark: '',
          warehouseAuditRemark: '',
          arbitrateAuditRemark: '',
          firstAuditTime: '',
          warehouseAuditTime: '',
          arbitrateAuditTime: ''
        },
        logisticsForm: {
          item: null,
          goodsDesc: '',
          applicationNo: '',
          logisticsCompany: '',
          shipmentNo: '',
          returnAddress: '',
          returnName: '',
          returnPhone: ''
        },

        applyRules: {
          description: [{ required: true, message: '请输入售后描述', trigger: 'blur' }],
          refundReason: [{ required: true, message: '请选择退货原因', trigger: 'blur' }],
          applicationType: [{ required: true, message: '请选择服务类型', trigger: 'blur' }],
          isReceived: [{ required: true, message: '请选择是否已收货', trigger: 'blur' }]
        },
        rejectRules: {
          reason: [{ required: true, message: '请填写拒绝理由', trigger: 'blur' }],
        },
        logisticsRules: {
          logisticsCompany: [{ required: true, message: '请填写物流公司', trigger: 'blur' }],
          shipmentNo: [{ required: true, message: '请填写快递单号', trigger: 'blur' }],
          returnAddress: [{ required: true, message: '请填写寄回地址', trigger: 'blur' }],
          returnName: [{ required: true, message: '请填写寄回接收人', trigger: 'blur' }],
          returnPhone: [{ required: true, message: '请填写寄回接收手机', trigger: 'blur' }]
        },

        loading: false,
        selfOptApplyType: 1,
        uploadImageAction: null, // 上传图片接口
        storeDeliveryNO: null, // 商家回执单号
        afterSaleProblem: null, // 商品问题描述
        userDeliveryInfo: {
          deliveryNo: null, // 用户发货物流单号
          deliveryCompany: null, // 用户发货物流公司
          phone: null, // 用户发货人手机号
          alipayName: null, // 用户支付宝昵称
          alipayUser: null, // 用户支付宝账号
          postage: null, // 用户寄货邮费
        },
        sellerDeliveryInfo: {
          address: null,
          name: null,
          phone: null,
        },
        productInfo: {},

        applyDialogFormVisible: false,
        rejectDialogFormVisible: false,
        queryDialogFormVisible: false,
        logisticsDialogFormVisible: false,
        selfOptApplyDialogVisible: false,
      };
    },

    created() {
      console.log('Router params: ', this.$route.params);
      this.afterSaleDetail = this.$route.params;
      this.uploadImageAction = uploadImg;

      this._fetchProductInfo();
      this._fetchAfterSaleReasons();
    },

    methods: {
      apply(item) {
        console.log(item);
        if (item.order_type === 2) {
          // 非自营订单尝试向爱库存发起审核申请
          if ((item.order_status === 1 || item.order_status === 2 ||
            item.order_status === 3 || item.order_status === 6 || item.order_status === 7) && item.status === 0) {
            // 以上状态满足可通过审核状态，尝试向爱库存创建售后单
            this.applyForm.item = item;
            this.applyForm.description = item.problem ? item.problem : item.reason;
            this.applyDialogFormVisible = true;
          } else {
            this.$message({
              message: '订单状态或者售后状态异常，请联系开发哥哥',
              type: 'error'
            });
          }
        } else {
          // 自营订单则直接改变订单状态
          this.selfOptApplyDialogVisible = true;
        }
      },

      reject(item) {
        this.rejectForm.item = item;
        this.rejectForm.goodsDesc = item.title;
        this.rejectDialogFormVisible = true;
      },

      query(item) {
        if (item.application_no) {
          this.loading = true;
          queryBill({ applicationNo: item.application_no }).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.queryForm.item = item;
              this.queryForm.goodsDesc = item.title;
              this.queryForm.applicationNo = res.data.applicationNo;
              this.queryForm.returnAddress = res.data.returnAddress ? res.data.returnAddress : item.receiving_info.address;
              this.queryForm.returnName = res.data.returnName ? res.data.returnName : item.receiving_info.name;
              this.queryForm.returnPhone = res.data.returnPhone ? res.data.returnPhone : item.receiving_info.phone;
              this.queryForm.auditStatus = res.data.auditStatus + '(-1:审核拒绝;0:待审核;其他找开发确认)';
              this.queryForm.fristAuditRemark = res.data.fristAuditRemark;
              this.queryForm.warehouseAuditRemark = res.data.warehouseAuditRemark;
              this.queryForm.arbitrateAuditRemark = res.data.arbitrateAuditRemark;
              this.queryForm.firstAuditTime = res.data.firstAuditTime;
              this.queryForm.warehouseAuditTime = res.data.warehouseAuditTime;
              this.queryForm.arbitrateAuditTime = res.data.arbitrateAuditTime;
              this.queryDialogFormVisible = true;
            } else {
              this.$message({
                message: res.msg ? res.msg : '查询失败',
                type: 'error'
              });
            }

            this.loading = false;
          });
        } else {
          this.$message({
            message: '售后单为空，无法查询',
            type: 'info'
          });
        }
      },

      refund(item) {
        this.$alert('是否确认为该售后单执行退款', '售后退款', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          showCancelButton: true,
          showClose: false,
          type: 'warning',
        }).then(() => {
          this.loading = true;
          refundAfterSale({ id: item.id, orderCode: item.order_code }).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.$message({
                message: res.msg ? res.msg : '退款成功',
                type: 'success'
              });
              item.status = 1;
            } else {
              this.$message({
                message: res.msg ? res.msg : '退款失败',
                type: 'error'
              });
            }

            this.loading = false;
          });
        });
      },

      startAfterSale(item) {
        this.$alert('确认重新发起售后？ \n 重新发起售后流程后，当前售后单状态会被设置为失败，并且不可再修改。\n 如果需要编辑，请使用新的售后单', '重新售后', {
          confirmButtonText: '重新售后',
          cancelButtonText: '取消',
          showCancelButton: true,
          showClose: false,
          type: 'warning',
        }).then(() => {
          this.loading = true;
          restartAfterSale({ afterSale_info: item }).then(response => {
            this.loading = false;

            const resData = response.data;
            if (resData.code !== 10000) {
              this.$message.error(resData.msg || '重新发起售后失败');
            } else {
              this.$message.success('重新发起售后成功，请通过订单号重新搜索新售后单');
            }
          });
        }).catch(() => {});
      },

      cancelAfterSale(item) {
        this.$alert('是否确认取消当前的售后单', '取消售后', {
          confirmButtonText: '取消售后',
          cancelButtonText: '取消',
          showCancelButton: true,
          showClose: false,
          type: 'warning',
        }).then(() => {
          this.loading = true;
          cancelAfterSale({ afterSale_info: item }).then(response => {
            this.loading = false;

            const resData = response.data;
            if (resData.code !== 10000) {
              this.$message.error(resData.msg || '取消售后失败');
            } else {
              this.$message.success('取消售后成功');
              this.afterSaleDetail.status = 10;
              this.afterSaleDetail.fail_reason = '已由后台人员操作取消';
            }
          });
        }).catch(() => {});
      },

      _alreadyRefund() {
        this.$alert('确认已经完成退款，确认后该售后单将结束并且关联订单的售后状态会变为\"成功\"', '已经退款', {
          confirmButtonText: '确认',
          cancelButtonText: '取消',
          showCancelButton: true,
          showClose: false,
          type: 'warning',
        }).then(() => {
          this.loading = true;
          alreadyRefund({ id: this.afterSaleDetail.id, order_id: this.afterSaleDetail.order_id, product: this.productInfo }).then(response => {
            this.loading = false;
            const resData = response.data;
            if (resData.code !== 10000) {
              this.$message.error(resData.msg || '更新失败');
            } else {
              this.$message.success('更新成功');
              this.afterSaleDetail.status = 1;
              this.afterSaleDetail.fail_reason = '已由后台人员确认完成手工退款';
            }
          });
        }).catch(() => {});
      },

      confirmApplyForm(formName) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.loading = true;
            let picUrls = this.applyForm.item.images.join(',');
            picUrls = picUrls ? picUrls : '[]';
            const params = {
              id: this.applyForm.item.id,
              orderCode: this.applyForm.item.order_code,
              orderId: this.applyForm.item.tp_order_code,
              orderDetatilId: this.applyForm.item.akc_order_detatil_id,
              picUrls,
              description: this.applyForm.description,
              refundReason: this.applyForm.refundReason,
              applicationType: this.applyForm.applicationType,
              isReceived: this.applyForm.isReceived,
              amount: String(this.applyForm.item.product_info.akcSettlementPrice),
              proposedReason: this.applyForm.proposedReason,
            };
            approveAfterSale(params).then(response => {
              const res = response.data;
              if (res.code === 10000) {
                this.$message({
                  message: res.msg ? res.msg : '操作成功',
                  type: 'success'
                });
                this.applyForm.item.application_no = res.data.applicationNo;
                // 有售后单说明爱库存已经受理，设置待一审状态。如果没有，则说明退款成功
                this.applyForm.item.status = res.data.applicationNo ? 3 : 1;
              } else {
                this.$message({
                  message: res.msg ? res.msg : '操作失败',
                  type: 'error'
                });
              }

              this.loading = false;
              this.applyDialogFormVisible = false;
            });
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },

      confirmRejectForm(formName) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.loading = true;
            const params = {
              id: this.rejectForm.item.id,
              orderId: this.rejectForm.item.order_id,
              reason: this.rejectForm.reason,
            };
            rejectAfterSale(params).then(response => {
              const res = response.data;
              if (res.code === 10000) {
                this.$message({
                  message: '拒绝成功',
                  type: 'success'
                });
                this.rejectForm.item.status = 10;
              } else {
                this.$message({
                  message: '拒绝失败',
                  type: 'error'
                });
              }

              this.loading = false;
              this.rejectDialogFormVisible = false;
            });
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },

      confirmLogisticsForm(formName) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.loading = true;
            const params = {
              id: this.logisticsForm.item.id,
              applicationNo: this.logisticsForm.applicationNo,
              logisticsCompany: this.logisticsForm.logisticsCompany,
              shipmentNo: this.logisticsForm.shipmentNo,
              returnAddress: this.logisticsForm.returnAddress,
              returnName: this.logisticsForm.returnName,
              returnPhone: this.logisticsForm.returnPhone
            };
            uploadLogistics(params).then(response => {
              const res = response.data;
              if (res.code === 10000) {
                this.$message({
                  message: res.msg ? res.msg : '上传成功',
                  type: 'success'
                });
                // 有售后单说明爱库存已经受理，设置待一审状态。如果没有，则说明退款成功
                this.logisticsForm.item.status = res.data.applicationNo ? 7 : 6;
              } else {
                this.$message({
                  message: res.msg ? res.msg : '上传失败',
                  type: 'error'
                });
              }

              this.loading = false;
              this.logisticsDialogFormVisible = false;
            });
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },

      uploadLogistics(item) {
        this.logisticsForm.item = item;
        this.logisticsForm.goodsDesc = item.title;
        this.logisticsForm.applicationNo = item.application_no;
        this.logisticsForm.logisticsCompany = '';
        this.logisticsForm.shipmentNo = '';
        this.logisticsForm.returnAddress = item.receiving_info.returnAddress;
        this.logisticsForm.returnName = item.receiving_info.returnName;
        this.logisticsForm.returnPhone = item.receiving_info.returnPhone;
        this.logisticsDialogFormVisible = true;
      },

      /**
       * 获取售后原因列表
       */
      _fetchAfterSaleReasons() {
        afterSaleReasonList().then((response) => {
          const res = response.data;
          if (res.code !== 10000) {
            this.$message.warning('获取售后原因列表失败，使用缓存数据');
          } else {
            this.afterSaleReasons = res.data;
          }
        });
      },

      _fetchProductInfo() {
        productForAfterSaleOrder(this.afterSaleDetail).then(response => {
          console.log(response.data);
          if (response.data.code === 10000) {
            this.productInfo = response.data.data;
          }
        });
      },

      /**
       * 商品售价
       */
      _price() {
        if (typeof this.afterSaleDetail.product_info !== 'object' ||
          !this.afterSaleDetail.product_info.hasOwnProperty('akcSettlementPrice')) {
          return 0;
        }

        return this.afterSaleDetail.product_info.akcSettlementPrice;
      },

      /**
       * 邮费
       */
      _postage() {
        return this.afterSaleDetail.refund_postage || '0';
      },

      /**
       * 通过类型转换成售后类型描述
       * @param type 售后类型
       * @returns {string} 售后描述
       */
      _afterSaleTypeName(type) {
        return type === 1 ? '仅退款' : (type === 2 ? '退货退款' : (type === 3 ? '换货' : '未知类型'));
      },

      /**
       * 订单状态描述
       */
      _orderStatusName(status) {
        switch (status) {
          case 0:
            return '待支付';
          case 1:
            return '已收货';
          case 2:
            return '待收货';
          case 3:
            return '已结算';
          case 4:
            return '删除';
          case 5:
            return '退款';
          case 6:
            return '待发货';
          case 7:
            return '售后';
          case 8:
            return '已失效';
          default:
            return '未知状态';
        }
      },

      /**
       * 售后状态描述
       */
      _afterSaleStatusName(status) {
        switch (status) {
          case 0:
            return '待审核';
          case 1:
            return '退款成功';
          case 2:
            return '退邮费成功';
          case 3:
            return '待爱库存一审';
          case 4:
            return '爱库存一审通过';
          case 5:
            return '爱库存一审失败';
          case 6:
            return '待用户提交物流信息';
          case 7:
            return '待爱库存二审';
          case 8:
            return '爱库存二审通过';
          case 9:
            return '爱库存二审失败';
          case 10:
            return '失败';
          case 11:
            return '用户主动取消';
          case 12:
            return '用户收到换货';
          default:
            return '未知状态';
        }
      },

      /**
       * 处理修改售后类型
       */
      _onAfterSaleTypeChanged(type) {
        assert(type !== this.afterSaleDetail.type);

        this.$alert(`确认修改该订单的售后类型为 '${this._afterSaleTypeName(type)}'`, '售后类型', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          showCancelButton: true,
          showClose: false,
        }).then(() => {
          const params = {
            id: this.afterSaleDetail.id,
            type
          };

          this.loading = true;

          updateACKAfterSaleOrder(params).then((response) => {
            const res = response.data;
            this.loading = false;

            if (res.code === 10000) {
              this.afterSaleDetail.type = type;
              this.$message.success('更新成功');
            } else {
              this.$message.error(res.msg || '更新失败');
            }
          });
        });
      },

      /**
       * 处理修改订单状态
       */
      _onOrderStatusChanged(status) {
        assert(status !== this.afterSaleDetail.order_status);

        this.$alert(`确认修改该订单的状态为 '${this._orderStatusName(status)}'`, '订单状态', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          showCancelButton: true,
          showClose: false,
        }).then(() => {
          const params = {
            id: this.afterSaleDetail.order_id,
            status,
          };

          this.loading = true;

          updateOrderStatus(params).then((response) => {
            const res = response.data;
            this.loading = false;

            if (res.code === 10000) {
              this.afterSaleDetail.order_status = status;
              this.$message.success('更新成功');
            } else {
              this.$message.error(res.msg || '更新失败');
            }
          });
        });
      },

      /**
       * 处理售后状态修改
       */
      _onAfterSaleStatusChanged(status) {
        assert(status !== this.afterSaleDetail.status);

        // 3 待爱存库一审
        // 7 待爱存库二审
        // 如果用户选择进入爱库存一、二审，必须保证爱库存的
        // 售后单号已经创建，否则表示爱库存根本没有开始审核
        if ((status === 3 || status === 7) && !this._isNotEmptyStr(this.afterSaleDetail.application_no)) {
          this.$alert(`准备修改为 '${this._afterSaleStatusName(status)}'，但该售后单尚未发起爱库存审核，是否马上发起审核？`, '售后状态', {
            confirmButtonText: '发起审核',
            cancelButtonText: '取消',
            showCancelButton: true,
            showClose: false,
          }).then(() => {
            this.apply(this.afterSaleDetail);
          });

          return;
        }

        const isCritical = this._isFinalStatus(status);
        this.$alert(`确认修改该订单的售后状态为 '${this._afterSaleStatusName(status)}' ${isCritical ? '修改为该状态后，订单状态将不可再修改。如需要你可以选择\'重新发起售后\'' : ''}`, '售后状态', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          showCancelButton: true,
          showClose: false,
          type: isCritical ? 'warning' : 'info',
        }).then(() => {
          const params = {
            id: this.afterSaleDetail.id,
            order_id: this.afterSaleDetail.order_id,
            status,
          };

          this.loading = true;

          updateACKAfterSaleOrder(params).then((response) => {
            const res = response.data;
            this.loading = false;

            if (res.code === 10000) {
              this.afterSaleDetail.status = status;
              this.$message.success('更新成功');
            } else {
              this.$message.error(res.msg || '更新失败');
            }
          });
        });
      },

      /**
       * 处理修改售后原因
       */
      _onAfterSaleReasonChanged(reason) {
        assert(reason.value !== this.afterSaleDetail.reason);

        this.$alert(`确认修改该订单的售后原因 '${reason.value}'`, '售后原因', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          showCancelButton: true,
          showClose: false,
        }).then(() => {
          const params = {
            id: this.afterSaleDetail.id,
            reason: reason.value,
          };

          this.loading = true;

          updateACKAfterSaleOrder(params).then((response) => {
            const res = response.data;
            this.loading = false;

            if (res.code === 10000) {
              this.afterSaleDetail.reason = reason.value;
              this.$message.success('更新成功');
            } else {
              this.$message.error(res.msg || '更新失败');
            }
          });
        });
      },

      /**
       * 上传售后图片校验
       * @param file 图片文件
       * @param index 图片所在索引
       * @private
       * @return boolean true 允许上传，否则不允许上传
       */
      _beforeUploadImage(file, index) {
        assert(index <= 3);

        if (index > 3 || index < 0) {
          this.$message.error('参数错误');
          return false;
        }

        const commonTypes = file.type === 'image/jpeg' || file.type === 'image/png';
        if (!commonTypes) {
          this.$message.error('上传文件格式有误');
          return false;
        }

        const replace = this.afterSaleDetail.images.length - 1 >= index;
        return this.$alert(`确认${replace ? '替换当前图片' : '新增图片'}？`, '售后图片', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          showCancelButton: true,
          showClose: false,
        });
      },

      /**
       * 上传售后图片成功处理
       * @param response 上传图片的网络请求响应
       * @param index 图片所在索引
       * @private
       */
      _uploadImageSuccess(response, index) {
        assert(index <= 3);

        const imageUrl = response.data;

        if (index > 3 || index < 0) {
          this.$message.error('更新图片索引超过4，更新失败');
          return;
        }

        if (!Array.isArray(this.afterSaleDetail.images)) {
          this.afterSaleDetail.images = [];
        }

        const images = this.afterSaleDetail.images.concat();
        const replace = this.afterSaleDetail.images.length - 1 >= index;
        replace ? images.splice(index, 1, imageUrl) : images.push(imageUrl);

        this.loading = true;

        const params = {
          id: this.afterSaleDetail.id,
          images: images.length !== 0 ? JSON.stringify(images) : ''
        };

        // 更新数据库
        updateAfterSaleImages(params).then((response) => {
          const res = response.data;
          if (res.code === 10000) {
            this.$message.success('更新图片成功');
            this.afterSaleDetail.images = images;
          } else {
            this.$message.error('更新图片失败');
          }

          this.loading = false;
        });
      },

      _isNotEmptyStr(str) {
        return Utils.isNotEmptyStr(str);
      },

      /**
       * 禁止用户选择某些售后状态
       * @param status 目标售后状态
       * @return boolean true标示不允许选择，否则允许
       * @private
       */
      _disableAfterSaleStatus(status) {
        if (this.afterSaleDetail.order_type === 2) {
          // 4 爱存库一审通过
          // 5 爱存库一审失败
          // 8 爱存库二审通过
          // 9 爱存库二审失败
          // 这是状态均由外部决定，用户不能擅自决定这些状态
          return status === 4 || status === 5 || status === 8 || status === 9;
        } else {
          // 3 待爱库存一审
          // 7 待爱库存二审
          // 自营商品不支持爱库存审核
          return status === 3 || status === 7;
        }
      },

      /**
       * 禁止用户选择某些售后原因
       * @param status 目标售后原因
       * @return boolean true标示不允许选择，否则允许
       * @private
       */
      _disableAfterSaleReason(reason) {
        if (reason === this.afterSaleDetail.reason) {
          return true;
        }

        if (this.afterSaleDetail.order_type !== 2) {
          // 自营售后单不允许无理由退货
          return reason === '7天无理由换货' || reason === '7天无理由退货退款';
        }

        return false;
      },

      /**
       * 商家寄回单号placeholder
       * @private
       */
      _deliveryPlaceholder() {
        const number = this.afterSaleDetail.delivery_info.storeDeliveryNo;
        return this._isNotEmptyStr(number) ? number : '请输入商家回寄单号';
      },

      /**
       * 保存商家寄回单号按钮可用状态
       * @returns {boolean}
       * @private
       */
      _disableSaveDeliveryButton() {
        if (!this._isNotEmptyStr(this.storeDeliveryNO)) {
          return true;
        }

        if (!this._isNotEmptyStr(this.afterSaleDetail.delivery_info.storeDeliveryNo)) {
          return false;
        }

        return this.storeDeliveryNO === this.afterSaleDetail.delivery_info.storeDeliveryNo;
      },

      /**
       * 保存商家寄回单号处理
       * @private
       */
      _saveStoreDeliveryNO() {
        assert(this.storeDeliveryNO !== this.afterSaleDetail.delivery_info.storeDeliveryNo);

        this.$alert('确认保存商家寄回单号？用户稍后可以通过此单号查看物流', '寄回单号', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          showCancelButton: true,
          showClose: false,
        }).then(() => {
          const info = JSON.parse(JSON.stringify(this.afterSaleDetail.delivery_info));
          info.storeDeliveryNo = this.storeDeliveryNO;

          const params = {
            id: this.afterSaleDetail.id,
            delivery_info: JSON.stringify(info),
          };

          this.loading = true;

          updateStoreDeliveryInfo(params).then((response) => {
            const res = response.data;
            this.loading = false;

            if (res.code === 10000) {
              this.afterSaleDetail.delivery_info = info;
              this.$message.success('更新成功');
            } else {
              this.$message.error(res.msg || '更新失败');
            }
          });
        });
      },

      /**
       * 售后问题描述
       */
      _problemPlaceholder() {
        return this.afterSaleDetail.problem || '用户未填写';
      },

      /**
       * 禁用售后原因保存按钮
       */
      _disableSaveProblemButton() {
        if (!this._isNotEmptyStr(this.afterSaleProblem)) {
          return true;
        }

        if (!this._isNotEmptyStr(this.afterSaleDetail.problem)) {
          return false;
        }

        return this.afterSaleProblem === this.afterSaleDetail.problem;
      },

      /**
       * 保存售后原因
       */
      _saveProblemDescription() {
        assert(this.afterSaleProblem !== this.afterSaleDetail.problem);

        this.$alert('确定更新该售后单的问题描述？', '问题描述', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          showCancelButton: true,
          showClose: false,
        }).then(() => {
          const params = {
            id: this.afterSaleDetail.id,
            problem: this.afterSaleProblem,
          };

          this.loading = true;

          updateACKAfterSaleOrder(params).then((response) => {
            const res = response.data;
            this.loading = false;

            if (res.code === 10000) {
              this.afterSaleDetail.problem = this.afterSaleProblem;
              this.$message.success('更新成功');
            } else {
              this.$message.error(res.msg || '更新失败');
            }
          });
        });
      },

      /**
       * 确认上传用户回执单图片
       * @param file 选取的图片文件
       * @param index
       * @returns {*}
       * @private
       */
      _beforeUploadReceiptImage(file, index) {
        const commonTypes = file.type === 'image/jpeg' || file.type === 'image/png';
        if (!commonTypes) {
          this.$message.error('上传文件格式有误');
          return false;
        }

        const replace = this._isNotEmptyStr(this.afterSaleDetail.delivery_info.payReceiptImg);
        return this.$alert(`确认${replace ? '替换' : '新增'}用户回执单图片？`, '回执图片', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          showCancelButton: true,
          showClose: false,
        });
      },

      /**
       * 更新用户回执单图片成功回调
       * @param response 网络请求回调，data是远端保存的图片地址
       * @param index
       * @private
       */
      _uploadReceiptImageSuccess(response, index) {
        console.log('response', response);
        const imageUrl = response.data;

        this.loading = true;

        const info = JSON.parse(JSON.stringify(this.afterSaleDetail.delivery_info));
        info.payReceiptImg = imageUrl;

        const params = {
          id: this.afterSaleDetail.id,
          delivery_info: JSON.stringify(info),
        };

        updateStoreDeliveryInfo(params).then((response) => {
          const res = response.data;
          this.loading = false;

          if (res.code === 10000) {
            this.afterSaleDetail.delivery_info = info;
            this.$message.success('更新成功');
          } else {
            this.$message.error(res.msg || '更新失败');
          }
        });
      },

      /**
       * 返回用户寄回物流信息字段的placeholder
       * @param key 信息的字段名称
       * @returns {*|string}
       * @private
       */
      _userDeliveryInfoPlaceholder(key) {
        let value = null;

        if (this.afterSaleDetail.delivery_info.hasOwnProperty(key)) {
          value = this.afterSaleDetail.delivery_info[key];
        }

        return value || '等待用户提交';
      },

      /**
       * 返回商家寄回物流信息字段的placeholder
       * @param key 信息的字段名称
       * @returns {*|string}
       * @private
       */
      _sellerDeliveryInfoPlaceholder(key) {
        let value = null;

        if (this.afterSaleDetail.receiving_info.hasOwnProperty(key)) {
          value = this.afterSaleDetail.receiving_info[key];
        }

        return value || '请客服填写';
      },

      /**
       * 更新用户寄回物流信息
       * @private
       */
      _updateUserDeliveryInfo() {
        this.$alert('确认修改用户寄回物流信息', '寄回信息', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          showCancelButton: true,
          showClose: false,
        }).then(() => {
          const info = JSON.parse(JSON.stringify(this.afterSaleDetail.delivery_info));
          if (this._isNotEmptyStr(this.userDeliveryInfo.phone)) {
            info.phone = this.userDeliveryInfo.phone;
          }

          if (this._isNotEmptyStr(this.userDeliveryInfo.deliveryNo)) {
            info.deliveryNo = this.userDeliveryInfo.deliveryNo;
          }

          if (this._isNotEmptyStr(this.userDeliveryInfo.deliveryCompany)) {
            info.deliveryCompany = this.userDeliveryInfo.deliveryCompany;
          }

          const params = {
            id: this.afterSaleDetail.id,
            delivery_info: JSON.stringify(info),
          };

          this.loading = true;

          updateStoreDeliveryInfo(params).then((response) => {
            const res = response.data;
            this.loading = false;

            if (res.code === 10000) {
              this.afterSaleDetail.delivery_info = info;
              this.$message.success('更新成功');
            } else {
              this.$message.error(res.msg || '更新失败');
            }
          });
        });
      },

      /**
       * 更新商家回寄物流信息
       * @private
       */
      _updateSellerDeliveryInfo() {
        this.$alert('确认修改商家回寄物流信息', '寄回信息', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          showCancelButton: true,
          showClose: false,
        }).then(() => {
          const info = JSON.parse(JSON.stringify(this.afterSaleDetail.receiving_info));
          if (this._isNotEmptyStr(this.sellerDeliveryInfo.phone)) {
            info.phone = this.sellerDeliveryInfo.phone;
          }

          if (this._isNotEmptyStr(this.sellerDeliveryInfo.name)) {
            info.name = this.sellerDeliveryInfo.name;
          }

          if (this._isNotEmptyStr(this.sellerDeliveryInfo.address)) {
            info.address = this.sellerDeliveryInfo.address;
          }

          const params = {
            id: this.afterSaleDetail.id,
            receiving_info: JSON.stringify(info),
          };

          this.loading = true;

          updateSellerDeliveryInfo(params).then((response) => {
            const res = response.data;
            this.loading = false;

            if (res.code === 10000) {
              this.afterSaleDetail.receiving_info = info;
              this.$message.success('更新成功');
            } else {
              this.$message.error(res.msg || '更新失败');
            }
          });
        });
      },

      /**
       * 是否禁用保存用户寄回信息按钮
       * @returns {boolean}
       * @private
       */
      _disableSaveUserDeliveryInfoButton() {
        const info = this.afterSaleDetail.delivery_info;
        const change = this.userDeliveryInfo;

        return change.phone === info.phone &&
          change.deliveryNo === info.deliveryNo &&
          change.deliveryCompany === info.deliveryCompany;
      },

      /**
       * 是否禁用保存商家寄回信息按钮
       * @returns {boolean}
       * @private
       */
      _disableSaveSellerDeliveryInfoButton() {
        const info = this.afterSaleDetail.receiving_info;
        const change = this.sellerDeliveryInfo;

        return change.name === info.name &&
          change.phone === info.phone &&
          change.address === info.address;
      },

      _updateTime() {
        if (!this.afterSaleDetail.update_time) {
          return '暂无数据';
        }

        return timestampToTime(this.afterSaleDetail.update_time);
      },

      /**
       * 通过自营商品客服自主审核
       * @private
       */
      _onSelfOptConfirmApply() {
        this.selfOptApplyDialogVisible = false;

        // 6 等待用户提交物流信息
        const type = this.selfOptApplyType === 1 ? 3 : (this.selfOptApplyType === 2 ? 2 : 1);
        const status = (this.selfOptApplyType === 1 || this.selfOptApplyType === 2) ? 6 : this.afterSaleDetail.status;
        const reason = (this.selfOptApplyType === 1 ? '质量问题换货' : (this.selfOptApplyType === 2 ? '质量问题退货退款' : '截单后仅退款'));
        const proposed_final_reason = (this.selfOptApplyType === 1 ? 3 : (this.selfOptApplyType === 2 ? 4 : 6));

        if (type === this.afterSaleDetail.type &&
          status === this.afterSaleDetail.status &&
          reason === this.afterSaleDetail.reason) {
          this.$alert(`当前订单状态已经符合'${reason}' 要求，已经进入到售后流程，无需修改`, '自营售后', {
            type: 'success',
            confirmButtonText: '确定',
            showClose: false,
            showCancelButton: false
          }).then(() => {});

          return;
        }

        const params = {
          id: this.afterSaleDetail.id,
          order_id: this.afterSaleDetail.order_id,
          type,
          status,
          reason,
          proposed_final_reason,
        };

        this.loading = true;

        updateACKAfterSaleOrder(params).then((response) => {
          const res = response.data;
          this.loading = false;

          if (res.code === 10000) {
            this.afterSaleDetail.type = type;
            this.afterSaleDetail.status = status;
            this.afterSaleDetail.reason = reason;

            this.$message.success('更新成功');
          } else {
            this.$message.error(res.msg || '更新失败');
          }
        });
      },

      _isFinalStatus(status) {
        return status === 2 || status === 5 || status === 9 || status === 10;
      },

      _showRefundButton() {
        return this.afterSaleDetail.status != 1 && this.afterSaleDetail.status !== 10 && this.afterSaleDetail.status !== 11 && (this.afterSaleDetail.status === 8 || this.afterSaleDetail.type === 1 || this.afterSaleDetail.type === 2);
      },

      _showRestartAfterSaleButton() {
        const reason = this.afterSaleDetail.fail_reason;
        const status = this.afterSaleDetail.status;
        return this._isFinalStatus(status) && reason !== '对应订单已经重新发起售后'; // 这个字符串判断不是很靠谱，先不管
      },

      _showCancelAfterSaleButton() {
        return !this._isFinalStatus(this.afterSaleDetail.status) && this.afterSaleDetail.status !== 11 && this.afterSaleDetail.order_after_sale_status === 1;
      },

      _showHaveRefundButton() {
        return this.afterSaleDetail.status === 8 || this._isHYKProduct();
      },

      _isHYKProduct() {
        return this.productInfo.supplier_name === '好衣库';
      },
    },
  };
</script>

<style rel="stylesheet/scss" lang="scss" scoped>

    .app-container {
        width: calc(100% - 40px);
        margin: 20px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);

        .app-aside {
            max-width: 30%;
            margin-right: 2px;
            border-right: dashed 2px #EEEEEE;

            .back-container {
                padding-left: 2px;

                .back-button {
                    box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
                }
            }

            .aside-key {
                font-size: 13px;
                color: #AAAAAA;
                margin-top: 40px;
            }

            .aside-key.sep {
                margin-top: 80px;
            }

            .aside-value {
                font: 15px bold;
                color: #282828;
                margin-top: 10px;
            }
        }

        .app-header {
            border-bottom: 1px solid #EEEEEE;
            display: flex;

            .user-info {
                flex: auto;

                .header-user-name {
                    font: 16px bold;
                    color: #282828;
                    margin: 13px 0;
                }

                .header-user-nickname {
                    font-size: 14px;
                    color: #AAAAAA;
                }

                .header-user-phone {
                    font-size: 14px;
                    margin-top: 5px;
                    color: #AAAAAA;
                }
            }

            .product-info {
                display: flex;
                flex-direction: column;
                justify-content: flex-end;
                text-align: right;
                color: #AAAAAA;
                font-size: 14px;
                margin-bottom: 5px;

                &:hover {
                    color: #409EFF;
                }
            }
        }

        .app-center {
            .main-order-title {
                font: 18px bold;
                color: #282828;
                margin-bottom: 40px;
            }

            .main-option {
                margin-bottom: 10px;

                .main-option-key {
                    font-size: 14px;
                    color: #282828;
                    margin-right: 12px;
                }

                .afterSale-fail-reason {
                    margin-left: 10px;
                    font-size: 12px;
                    color: red;
                }
            }

            .main-option-problem {
                display: flex;
                margin-top: 30px;
                flex-direction: row;
                align-items: center;

                .problem-key {
                    margin-right: 12px;
                    font-size: 14px;
                    color: #282828;
                }

                .problem-input {
                    display: flex;
                    flex-direction: row;
                    align-items: center;

                    .problem-value {
                        width: 500px;
                        margin-right: 10px;
                    }
                }
            }

            .main-option-withdraw.sep {
                margin-top: 40px;
            }

            .main-option-withdraw {
                margin-top: 10px;

                .withdraw-amount-key {
                    font-size: 14px;
                    color: #282828;
                    margin-right: 12px;
                }

                .main-withdraw-amount {
                    font-size: 14px;
                    color: #D9534F
                }
            }

            .main-product-images {
                margin-top: 10px;

                .product-images-title {
                    font-size: 14px;
                    color: #282828;
                }

                .product-images-container {
                    display: flex;
                    flex-direction: row;
                    justify-content: flex-start;

                    .image-previewer {
                        margin: 10px 20px;
                    }
                }
            }

            .main-logistics {
                margin-top: 20px;
                padding: 10px;
                border: 1px #EEEEEE solid;

                .main-logistics-container {
                    padding: 10px;
                    background-color: #FAFAFA;

                    .main-logistics-header {
                        display: flex;
                        flex-direction: row;
                        margin-bottom: 10px;
                        padding-bottom: 10px;
                        border-bottom: 2px dashed white;

                        .main-logistics-title {
                            flex: auto;
                            font-weight: bold;
                            font-size: 16px;
                            color: #282828;
                            padding-top: 10px;
                        }
                    }

                    .main-logistics-contents {
                        display: flex;
                        flex-direction: row;
                        justify-content: space-between;

                        .main-logistics-contents-left {
                            display: flex;
                            flex: auto;
                            flex-direction: column;
                            justify-content: space-around;

                            .main-logistics-options {
                                display: flex;
                                flex-direction: row;
                                align-items: center;
                                margin-top: 10px;

                                .main-logistics-key {
                                    font-size: 14px;
                                    color: #282828;
                                    margin-right: 15px;
                                    width: 120px;
                                }

                                .logistics-input {
                                    width: 450px;
                                    font-size: 14px;
                                    color: #aaa;
                                }
                            }
                        }
                    }
                }
            }

            .main-send-info {
                margin-top: 20px;
                padding: 10px;
                border: 1px #EEEEEE solid;

                .main-send-info-container {
                    padding: 10px;
                    background-color: #FAFAFA;

                    .main-send-info-header {
                        display: flex;
                        flex-direction: row;
                        justify-content: space-between;
                        border-bottom: 2px dashed white;

                        .main-send-info-title {
                            font-weight: bold;
                            font-size: 16px;
                            padding-bottom: 10px;
                            margin-top: 10px;
                            color: #282828;
                        }
                    }

                    .main-send-info-options {
                        display: flex;
                        flex-direction: row;
                        align-items: center;
                        margin: 20px 0;

                        .main-send-info-key {
                            font-size: 14px;
                            color: #282828;
                            margin-right: 15px;
                            width: 80px;
                        }

                        .send-info-input {
                            width: 500px;
                        }
                    }

                    .send-code-input {
                        border-top: 2px white solid;
                        margin-top: 30px;
                        padding-top: 10px;
                    }
                }
            }
        }

        .app-footer {
            border-top: 1px solid #EEEEEE;
            display: flex;

            .time-container {
                display: flex;
                flex: auto;
                font-size: 14px;
                color: #AAAAAA;
                flex-direction: column;
                justify-content: space-around;
            }

            .btn-container {
                display: flex;
                flex-direction: row;
                align-items: flex-end;

                .opt-btn {
                    min-width: 100px;
                    min-height: 30px;
                    margin: 10px 10px 0 10px;
                }
            }
        }

        .self-opt-icon {
            box-shadow: 0 2px 4px rgba(0, 0, 0, .5), 0 0 6px rgba(0, 0, 0, .04);
            position: absolute;
            float: right;
            top: 15px;
            right: 15px;
            display: flex;
            flex-direction: row;
            border: 3px red solid;
            border-radius: 50px;
            width: 80px;
            height: 80px;
            align-items: center;
            justify-content: center;
            transform: rotate(20deg);

            .self-opt-icon-title {
                background-color: red;
                color: white;
                width: 80px;
                font-weight: bold;
                text-align: center;
            }
        }
    }

</style>