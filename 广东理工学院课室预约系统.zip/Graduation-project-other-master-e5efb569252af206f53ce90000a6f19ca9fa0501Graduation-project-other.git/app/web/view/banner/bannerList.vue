<template>
    <div class="app-container">
        <el-row>
            <el-col :span="24">
                <div class="header-title">banner操作</div>
            </el-col>
            <el-row style="padding-bottom: 30px">
                <el-col>
                    <div v-show="delRedisVisible" style="padding-bottom: 50px">
                        <template>
                            <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll"
                                         @change="handleCheckAllChange">全选
                            </el-checkbox>
                            <div style="margin: 15px 0;"></div>
                            <el-checkbox-group v-model="checkedKeys" @change="handleCheckedKeysChange"
                                               style="width: 700px;padding-bottom: 20px">
                                <el-checkbox v-for="key in keys" :label="key" :key="key"
                                             style="padding-bottom: 20px;margin-top: 20px" border>
                                    {{key}}
                                </el-checkbox>
                            </el-checkbox-group>
                        </template>
                        <div>
                            <el-button type="primary" @click="delRedisKeys" size="mini">删除</el-button>
                            <el-button type="info" @click="delCancel" size="mini">取消</el-button>
                        </div>
                    </div>
                    <el-row v-show="editingChoiceList" style="padding-bottom: 50px">
                        <el-form :model="addForm" ref="addForm">
                            <el-form-item label="状态" :label-width="formLabelWidth"
                                          prop="status">
                                <el-select v-model="addForm.status" placeholder="请设置状态">
                                    <el-option label="禁用" value="0"></el-option>
                                    <el-option label="启用" value="1"></el-option>
                                </el-select>
                            </el-form-item>
                            <el-form-item label="投放位置" :label-width="formLabelWidth">
                                <el-select v-model="addForm.key_type" placeholder="请选择投放位置"
                                           @change="updateAddForm(addForm)">
                                    <el-option label="banner" value="1"></el-option>
                                    <el-option label="电商折扣页10入口" value="2"></el-option>
                                    <el-option label="小程序banner" value="10"></el-option>
                                    <el-option label="客户端公告" value="11"></el-option>
                                    <el-option label="客户端跑马灯" value="12"></el-option>
                                    <el-option label="首页资源位" value="14"></el-option>
                                    <el-option label="小程序弹窗" value="17"></el-option>
                                    <el-option label="客户端首页5入口" value="18"></el-option>
                                    <el-option label="客户端弹窗" value="19"></el-option>
                                    <el-option label="小程序首页5入口" value="20"></el-option>
                                    <el-option label="客户端个人中心入口" value="21"></el-option>
                                    <el-option label="客户端首页广告位3" value="22"></el-option>
                                    <el-option label="小程序首页广告位3" value="23"></el-option>
                                </el-select>
                            </el-form-item>
                            <el-form-item label="小程序弹窗类型" :label-width="formLabelWidth"
                                          v-show="addForm.key_type === '17'">
                                <el-select v-model="addForm.type" placeholder="请设置弹窗类型">
                                    <el-option label="id双数展示" value="1"></el-option>
                                    <el-option label="id单数展示" value="2"></el-option>
                                    <el-option label="通用" value="0"></el-option>
                                </el-select>
                            </el-form-item>
                            <el-form-item label="生效时间" :label-width="formLabelWidth" prop="text">
                                <el-date-picker
                                        v-model="selectTimes2"
                                        type="datetimerange"
                                        range-separator="至"
                                        start-placeholder="开始日期"
                                        end-placeholder="结束日期"
                                        align="right"
                                        size="mini"
                                        @change="selectTimeAfter">
                                </el-date-picker>
                            </el-form-item>
                        </el-form>
                        <el-button type="primary" @click="confirmForm(addForm)" size="mini">创建</el-button>
                        <el-button type="info" @click="cancel" size="mini">取消</el-button>
                    </el-row>
                    <el-button v-show="!editingChoiceList" type="primary" @click="add()">添加新的资源位</el-button>
                    <el-button v-show="!delRedisVisible" type="primary" @click="delRedis()">清除redis缓存</el-button>
                </el-col>
            </el-row>

            <!-- 筛选条件 start -->
            <el-col :span="24">
                <el-form :inline="true" :model="formInline" class="demo-form-inline">
                    <el-form-item label="投放位置" :label-width="formLabelWidth">
                        <el-select v-model="formInline.key_type" placeholder="请选择投放位置" @change="onSubmit">
                            <el-option label="所有" value="-1"></el-option>
                            <el-option label="banner" value="1"></el-option>
                            <el-option label="电商折扣页10入口" value="2"></el-option>
                            <el-option label="小程序banner" value="10"></el-option>
                            <el-option label="客户端公告" value="11"></el-option>
                            <el-option label="客户端跑马灯" value="12"></el-option>
                            <el-option label="首页资源位" value="14"></el-option>
                            <el-option label="小程序弹窗" value="17"></el-option>
                            <el-option label="客户端首页5入口" value="18"></el-option>
                            <el-option label="客户端弹窗" value="19"></el-option>
                            <el-option label="小程序首页5入口" value="20"></el-option>
                            <el-option label="客户端个人中心" value="21"></el-option>
                            <el-option label="客户端首页广告位3" value="22"></el-option>
                            <el-option label="小程序首页广告位3" value="23"></el-option>
                        </el-select>
                    </el-form-item>
                </el-form>
            </el-col>
            <!-- 筛选条件 end -->
            <!-- 表格 start -->
            <el-col :span="24">
                <el-table
                        :data="tableData"
                        border
                        style="width: 100%"
                        v-loading="loading">
                    <el-table-column
                            fixed
                            label="ID"
                            width="50">
                        <template slot-scope="scope">
                            <div>{{scope.row.id}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="状态"
                            width="50">
                        <template slot-scope="scope">
                            <div v-if="scope.row.status===0">禁用</div>
                            <div v-if="scope.row.status===1">启用</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="展示类型"
                            width="100" v-if="formInline.key_type === '17'">
                        <template slot-scope="scope">
                            <div v-if="scope.row.type===1">id双数展示</div>
                            <div v-if="scope.row.type===2">id单数展示</div>
                            <div v-if="scope.row.type===0">通用</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            height="150"
                            label="内容"
                            width="1120">
                        <template slot-scope="scope">
                            <!-- 表格 start -->
                            <el-col :span="24">
                                <el-table
                                        :data="scope.row.value"
                                        border
                                        style="width: 100%"
                                        v-loading="loading">
                                    <el-table-column
                                            fixed
                                            label="ID"
                                            width="50">
                                        <template slot-scope="scope">
                                            <div>{{scope.row.id}}</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                            label="标题"
                                            width="100">
                                        <template slot-scope="scope">
                                            <div>{{scope.row.title}}</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                            label="跳转地址"
                                            width="250">
                                        <template slot-scope="scope">
                                            <div>{{scope.row.url}}</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                            label="排序"
                                            width="60">
                                        <template slot-scope="scope">
                                            <div>{{scope.row.sort}}</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                            label="展示次数"
                                            width="60"
                                            v-if="formInline.key_type === '17' || formInline.key_type === '19'">
                                        <template slot-scope="scope">
                                            <div>{{scope.row.showTime}}</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                            label="次数降低方法"
                                            width="60"
                                            v-if="formInline.key_type === '17' || formInline.key_type === '19'">
                                        <template slot-scope="scope">
                                            <div v-if="scope.row.reduceTime==='0'">无</div>
                                            <div v-if="scope.row.reduceTime==='1'">点击</div>
                                            <div v-if="scope.row.reduceTime==='2'">重启</div>
                                            <div v-if="scope.row.reduceTime==='3'">刷新</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                            label="强制关闭"
                                            width="60"
                                            v-if="formInline.key_type === '17' || formInline.key_type === '19'">
                                        <template slot-scope="scope">
                                            <div v-if="scope.row.isForceClose==='0'">否</div>
                                            <div v-if="scope.row.isForceClose==='1'">是</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                            label="展示时间点"
                                            width="80"
                                            v-if="formInline.key_type === '17' || formInline.key_type === '19'">
                                        <template slot-scope="scope">
                                            <div v-if="scope.row.showCondition==='0'">无</div>
                                            <div v-if="scope.row.showCondition==='1'">未登录</div>
                                            <div v-if="scope.row.showCondition==='2'">新人</div>
                                            <div v-if="scope.row.showCondition==='3'">无条件</div>
                                        </template>
                                    </el-table-column>

                                    <el-table-column
                                            height="150"
                                            label="入口照片预览"
                                            width="230">
                                        <template slot-scope="scope">
                                            <div class="container">
                                                <img :src="scope.row.imageUrl" alt="">
                                            </div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                            label="展示时间"
                                            width="150"
                                            v-if="formInline.key_type === '17' || formInline.key_type === '19'">
                                        <template slot-scope="scope">
                                            <div>{{scope.row.startTime}} 至 {{scope.row.endTime}}</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                            fixed="right"
                                            height="150"
                                            label="操作"
                                            width="180">
                                        <template slot-scope="scope">
                                            <el-button type="danger" icon="el-icon-delete" circle
                                                       @click="deleteBannerById(scope.row,scope.row.value)"></el-button>
                                            <el-button type="primary" icon="el-icon-edit" circle
                                                       @click="editBanner(scope.row)"></el-button>
                                        </template>
                                    </el-table-column>
                                </el-table>
                            </el-col>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="生效时间"
                            width="150">
                        <template slot-scope="scope">
                            <div>{{scope.row.start_time}} 至 {{scope.row.end_time}}</div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="操作"
                            width="350">
                        <template slot-scope="scope">
                            <el-button type="danger" icon="el-icon-delete" circle
                                       @click="deleteBanner(scope.row.id)"></el-button>
                            <el-button type="primary" icon="el-icon-edit" circle
                                       @click="editBannerButton(scope.row)"></el-button>
                            <el-button type="primary" size="small" @click="addBannerButton(scope.row)">新增</el-button>
                            <el-popover
                                    placement="right"
                                    width="400"
                                    trigger="click">
                                <template>
                                    <el-select v-model="clientId" placeholder="请选择">
                                        <el-option
                                                v-for="item in clientList"
                                                :key="item.id"
                                                :label="item.client_id"
                                                :value="item.id">
                                        </el-option>
                                    </el-select>
                                    <el-button type="primary" size="small" @click="selectClient">确定</el-button>
                                </template>
                                <el-button type="warning" size="small" @click="copyBannerButton(scope.row)"
                                           slot="reference">copy到...
                                </el-button>
                            </el-popover>
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
            <!-- 表格 end -->
            <!-- 弹层 start -->
            <el-col :span="24">
                <el-dialog :title="dialogFormTitle" :visible.sync="dialogFormVisible" width="300"
                           @close="cancelAddBanner">
                    <el-form :model="addForm" ref="addForm">
                        <el-form-item label="ID" :label-width="formLabelWidth" prop="id"
                                      v-if="bannerVisible=== 1 || bannerVisible=== 2">
                            <el-input :disabled="true" v-model="addForm.id" placeholder="ID" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="ID" :label-width="formLabelWidth" prop="id" v-if="bannerVisible=== 3">
                            <el-input :disabled="true" v-model="addForm.bannerId" placeholder="ID" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="资源Id" :label-width="formLabelWidth" prop="id"
                                      v-if="bannerVisible=== 3">
                            <el-input v-model="addForm.id" placeholder="资源Id" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="排序" :label-width="formLabelWidth" prop="id"
                                      v-if="bannerVisible=== 1 || bannerVisible=== 3">
                            <el-input v-model="addForm.sort" placeholder="排序" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="展示次数" :label-width="formLabelWidth" prop="id"
                                      v-if="showTimeVisible">
                            <el-input v-model="addForm.showTime" placeholder="排序" size="mini"
                                      clearable></el-input>
                        </el-form-item>
                        <el-form-item label="生效时间" class="time-width" :label-width="formLabelWidth" prop="start_time"
                                      v-if="bannerVisible=== 2">
                            <el-date-picker
                                    v-model="selectTimes2"
                                    type="datetimerange"
                                    range-separator="至"
                                    start-placeholder="开始日期"
                                    end-placeholder="结束日期"
                                    align="right"
                                    size="mini"
                                    @change="selectTimeAfter">
                            </el-date-picker>
                        </el-form-item>

                        <el-form-item label="展示时间" class="time-width" :label-width="formLabelWidth" prop="start_time"
                                      v-if="bannerVisible=== 1 || bannerVisible=== 3"
                                      v-show="formInline.key_type === '17' || formInline.key_type === '19'">
                            <el-date-picker
                                    v-model="selectTimes2"
                                    type="datetimerange"
                                    range-separator="至"
                                    start-placeholder="开始日期"
                                    end-placeholder="结束日期"
                                    align="right"
                                    size="mini"
                                    @change="selectTimeAfter">
                            </el-date-picker>
                        </el-form-item>
                        <el-form-item label="标题" :label-width="formLabelWidth"
                                      v-if="bannerVisible=== 1 || bannerVisible=== 3">
                            <el-input class="input" placeholder="标题" v-model="addForm.title"></el-input>
                        </el-form-item>
                        <el-form-item label="次数降低方法" :label-width="formLabelWidth"
                                      v-if="bannerVisible=== 1 || bannerVisible=== 3"
                                      v-show="formInline.key_type === '17' || formInline.key_type === '19'">
                            <el-select v-model="addForm.reduceTime" placeholder="请设置状态">
                                <el-option label="无" value="0"></el-option>
                                <el-option label="点击" value="1"></el-option>
                                <el-option label="重启" value="2"></el-option>
                                <el-option label="刷新" value="3"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="强制关闭" :label-width="formLabelWidth"
                                      v-if="bannerVisible=== 1 || bannerVisible=== 3"
                                      v-show="formInline.key_type === '17' || formInline.key_type === '19'">
                            <el-select v-model="addForm.isForceClose" placeholder="请设置状态">
                                <el-option label="否" value="0"></el-option>
                                <el-option label="是" value="1"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="展示时间点" :label-width="formLabelWidth"
                                      v-if="bannerVisible=== 1 || bannerVisible=== 3"
                                      v-show="formInline.key_type === '17' || formInline.key_type === '19'">
                            <el-select v-model="addForm.showCondition" placeholder="请设置状态">
                                <el-option label="无" value="0"></el-option>
                                <el-option label="未登录" value="1"></el-option>
                                <el-option label="新人" value="2"></el-option>
                                <el-option label="无条件" value="3"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="跳转链接" :label-width="formLabelWidth"
                                      v-if="bannerVisible=== 1 || bannerVisible=== 3">
                            <el-input class="input" placeholder="跳转链接" v-model="addForm.url"></el-input>
                        </el-form-item>
                        <el-form-item label="状态" :label-width="formLabelWidth" size="mini" prop="status"
                                      v-if="bannerVisible === 2">
                            <el-select v-model="addForm.status" placeholder="请设置状态">
                                <el-option label="禁用" value="0"></el-option>
                                <el-option label="启用" value="1"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="小程序弹窗类型" :label-width="formLabelWidth"
                                      v-if="addForm.key_type === 17 || addForm.key_type === 19">
                            <el-select v-model="addForm.type"
                                       placeholder="请设置弹窗类型">
                                <el-option label="id双数展示" value="1"></el-option>
                                <el-option label="id单数展示" value="2"></el-option>
                                <el-option label="通用" value="0"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="图片" :label-width="formLabelWidth"
                                      v-if="bannerVisible === 1 || bannerVisible=== 3">
                            <el-upload class="avatar-uploader" :action="uploadImg" :show-file-list="false"
                                       :on-success="handleAvatarSuccess"
                                       :list-type="addForm.imageUrl? '' : 'picture-card'">
                                <div class="container">
                                    <img v-if="addForm.imageUrl" :src="addForm.imageUrl" class="avatar" alt="">
                                    <i v-else class="el-icon-plus"></i>
                                </div>
                            </el-upload>
                        </el-form-item>
                    </el-form>
                    <div slot="footer" class="dialog-footer">
                        <el-button @click="cancelAddBanner('addForm')">取 消</el-button>
                        <el-button type="primary" @click="addBannerList(addForm)">确 定</el-button>
                    </div>
                </el-dialog>
            </el-col>
            <!-- 弹层 end -->
            <!-- 分页 start -->
            <el-col :span="24">
                <div class="pagination" style="margin-top:20px;">
                    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                                   :current-page="formInline.pageNum" :page-sizes="[10, 20, 30, 40]"
                                   :page-size="formInline.pageSize" layout="total, sizes, prev, pager, next"
                                   :total="totalcount">
                    </el-pagination>
                </div>
            </el-col>
            <!-- 分页 end -->
        </el-row>
    </div>
</template>

<script>
  import {
    editBannerImg,
    selectBanner,
    deleteBanner,
    addBanner,
    editBanner,
    editBannerList,
    getBannerList,
    deleteBannerById,
    getBannerById,
    updateBannerList,
    createBannerList,
    getRedisKeys,
    delRedisKeys,
    getClient
  } from '@/api/banner';
  import {uploadImg} from '@/api/uploadImg';
  import {timestampToTime} from 'utils/chanageTime';

  export default {
    data() {
      return {
        checkAll: false,
        isIndeterminate: true,
        checkedKeys: [],
        keys: [],
        client_id: 0,
        clientId: null,
        totalcount: 0,
        clientList: [],
        loading: false,
        uploadImg: '',
        platformOptions: [
          {
            value: 0,
            label: 'all'
          },
          {
            value: 1,
            label: 'android'
          },
          {
            value: 2,
            label: 'ios'
          }
        ],
        listQuery: {
          id: 1
        },
        formInline: {
          type: null,
          key_type: null,
          pageNum: 1,
          pageSize: 10,
          title: null,
          start_time: null,
          end_time: null,
          client_id: null,
          start_version: null,
          end_version: null,
          startTime: '',
          endTime: ''
        },
        selectTimes: '',
        selectTimes2: '',
        tableData: [],
        redisKeys: [],
        value: [
          {
            color: '',
            id: 0,
            imageUrl: '',
            title: '',
            url: '',
            bannerId: 0,
            index: 0,
            startTime: '',
            endTime: '',
            reduceTime: 0,
            isForceClose: 0,
            showCondition: 0
          }
        ],
        content: {
          color: '',
          id: 0,
          imageUrl: '',
          title: '',
          url: '',
          sort: 0,
          showTime: 0,
          startTime: '',
          endTime: '',
          reduceTime: 0,
          isForceClose: 0,
          showCondition: 0
        },
        dialogFormVisible: false, // 弹层显示与否
        editingChoiceList: false, // 弹层显示与否
        delRedisVisible: false, // 删除redis弹窗
        showTimeVisible: false, // 是否展示展示次数
        bannerVisible: 1, // 是否banner
        dialogFormTitle: '', // 弹层标题
        addForm: {
          showTime: 0,
          type: null,
          key_type: null,
          id: '',
          sort: 0,
          start_time: '',
          end_time: '',
          client_id: '',
          bannerId: '',
          imageUrl: '',
          title: '',
          url: '',
          status: '',
          value: [],
          startTime: '',
          endTime: '',
          reduceTime: '',
          isForceClose: '',
          showCondition: ''
        },
        formLabelWidth: '120px',
      };
    },
    created() {
      this.getList();
      this.uploadImg = uploadImg;
    },
    methods: {
      handleCheckAllChange(val) {
        this.checkedKeys = val ? this.redisKeys : [];
        this.isIndeterminate = false;
      },
      getClientList() {
        // 请求列表
        getClient().then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.clientList = res.data;
            // 整理数据
            for (const i in this.clientList) {
              const clientId = this.clientList[i].client_id;
              if (clientId === 0) {
                this.clientList[i].client_id = '雀享全平台' + this.clientList[i].start_version + '-' + this.clientList[i].end_version;
              } else if (clientId === 1) {
                this.clientList[i].client_id = '雀享Android' + this.clientList[i].start_version + '-' + this.clientList[i].end_version;
              } else if (clientId === 2) {
                this.clientList[i].client_id = '雀享ios' + this.clientList[i].start_version + '-' + this.clientList[i].end_version;
              } else if (clientId === 3) {
                this.clientList[i].client_id = 'web' + this.clientList[i].start_version + '-' + this.clientList[i].end_version;
              } else if (clientId === 4) {
                this.clientList[i].client_id = '校品团全平台' + this.clientList[i].start_version + '-' + this.clientList[i].end_version;
              } else if (clientId === 5) {
                this.clientList[i].client_id = '校品团Android' + this.clientList[i].start_version + '-' + this.clientList[i].end_version;
              } else if (clientId === 6) {
                this.clientList[i].client_id = '校品团ios' + this.clientList[i].start_version + '-' + this.clientList[i].end_version;
              } else if (clientId === 11) {
                this.clientList[i].client_id = '雀享优品小程序' + this.clientList[i].start_version + '-' + this.clientList[i].end_version;
              } else if (clientId === 12) {
                this.clientList[i].client_id = '雀享优品web' + this.clientList[i].start_version + '-' + this.clientList[i].end_version;
              } else if (clientId === 13) {
                this.clientList[i].client_id = '校品团web' + this.clientList[i].start_version + '-' + this.clientList[i].end_version;
              }
            }
          }

          this.loading = false;
        });
      },
      handleCheckedKeysChange(value) {
        const checkedCount = value.length;
        this.checkAll = checkedCount === this.keys.length;
        this.isIndeterminate = checkedCount > 0 && checkedCount < this.keys.length;
      },
      updateAddForm(addForm) {
        this.addForm = addForm;
      },
      delRedisKeys() {
        delRedisKeys(this.checkedKeys).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.$message({
              message: '删除成功！',
              type: 'success'
            });
          }
          this.getRedisKeys();
        });
      },
      onSubmit() {
        // 筛选页面初始化
        this.formInline.pageNum = 1;
        this.formInline.pageSize = 10;
        this.getList();
      },
      addBannerButton(data) {
        this.bannerVisible = 3;
        this.addForm.bannerId = data.id;
        this.dialogFormVisible = true;
        this.dialogFormTitle = '添加banner';
      },
      copyBannerButton(data) {
        this.getClientList();
        this.addForm = data;
      },
      selectClient(data) {
        const addForm = this.addForm;
        addForm.values = JSON.stringify(addForm.value);
        addForm.client_id = this.clientId;
        if (addForm.start_time) {
          addForm.start_time = new Date(addForm.start_time).getTime() / 1000;
        }
        if (addForm.end_time) {
          addForm.end_time = new Date(addForm.end_time).getTime() / 1000;

        }
        createBannerList(addForm).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            // 重新请求列表
            this.getList();
            this.$message({
              message: '成功',
              type: 'success'
            });
            this.addForm.type = null;
          } else {
            this.$message.error(res.msg);
          }
          this.addForm = {};
        });
      },
      getList() {
        this.loading = true;
        this.client_id = this.$route.params.client_id;
        this.showTimeVisible = Number(this.formInline.key_type) === 14 ? true : false;
        getBannerList({ client_id: this.client_id, key_type: Number(this.formInline.key_type) }).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.tableData = res.data;
            this.totalcount = res.totalCount;
            // 整理数据
            this.tableData.map((item, index) => {
              item.start_time = timestampToTime(item.start_time);
              item.end_time = timestampToTime(item.end_time);
              item.value = JSON.parse(item.value);
              this.value = item.value;
              for (const i in this.value) {
                this.value[i].bannerId = item.id;
                this.value[i].index = i;
                if (typeof this.value[i].startTime === 'number') {
                  this.value[i].startTime = timestampToTime(this.value[i].startTime);
                }
                if (typeof this.value[i].startTime === 'number') {
                  this.value[i].endTime = timestampToTime(this.value[i].endTime);
                }
              }
            });
          }
          this.loading = false;
        });
      },
      cancel() {
        this.editingChoiceList = false;
      },
      delRedis() {
        this.delRedisVisible = true;
        this.getRedisKeys();
      },
      delCancel() {
        this.delRedisVisible = false;
      },
      getRedisKeys() {
        getRedisKeys({ client_id: this.client_id }).then(response => {
          const res = response.data;
          this.redisKeys = res.data[1];
          this.keys = this.redisKeys;
        });
      },
      add() {
        this.editingChoiceList = true;
      },
      deleteBanner(id, index) {
        this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            deleteBanner({ id }).then(response => {
              const res = response.data;
              if (res.code === '10000') {
                this.$message({
                  message: '删除成功！',
                  type: 'success'
                });
                this.tableData.splice(index, 1);
              } else {
                this.$message.error(res.msg);
              }
              this.getList();
            });
          })
          .catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除'
            });
          });
      },
      deleteBannerById(row) {
        this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          getBannerById({ id: row.bannerId }).then(response => {
            const res = response.data;
            if (res.code === '10000') {
              this.$message({
                message: '成功！',
                type: 'success'
              });
            }
            const banner = JSON.parse(res.data[0].value);
            banner.splice(row.index, 1);
            const text = JSON.stringify(banner);
            updateBannerList({ id: row.bannerId, value: text }).then(response => {
              const res = response.data;
              this.getList();
              if (res.code === '10000') {
                this.$message({
                  message: '删除成功！',
                  type: 'success'
                });
              }
            });
          });
        })
          .catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除'
            });
          });
      },
      handleAvatarSuccess(res, b) {
        this.addForm.imageUrl = res.data;
      },
      beforeAvatarUpload(file) {
        // const isJPG = file.type === 'image/jpeg';
        // const isLt2M = file.size / 1024 / 1024 < 2;
        // if (!isJPG) {
        //   this.$message.error('上传头像图片只能是 JPG 格式!');
        // }
        // if (!isLt2M) {
        //   this.$message.error('上传头像图片大小不能超过 2MB!');
        // }
        // return isJPG && isLt2M;
      },
      confirmForm(addForm) {
        addForm.client_id = this.client_id;
        createBannerList(addForm).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            // 重新请求列表
            this.getList();
            this.$message({
              message: '成功',
              type: 'success'
            });
            this.addForm.type = null;
          } else {
            this.$message.error(res.msg);
          }
          this.editingChoiceList = false;
        });
      },
      addBannerList(addForm) {
        if (this.bannerVisible === 1) {
          getBannerById({ id: addForm.bannerId }).then(response => {
            const res = response.data;
            if (res.code === '10000') {
              this.$message({
                message: '成功！',
                type: 'success'
              });
            }
            let banner = [];
            addForm.startTime = addForm.start_time;
            addForm.endTime = addForm.end_time;
            banner = JSON.parse(res.data[0].value);
            banner.splice(addForm.index, 1);
            banner.push(addForm);
            const value = JSON.stringify(banner);
            // 更新banner
            updateBannerList({ id: addForm.bannerId, value }).then(response => {
              const res = response.data;
              if (res.code === 10000) {
                this.$message({
                  message: '修改成功',
                  type: 'success'
                });
                // 重新请求列表
                this.getList();
              } else {
                this.$message.error(res.msg);
              }
            });
          });
        } else if (this.bannerVisible === 2) {
          editBannerList(addForm).then(response => {
            const res = response.data;
            if (res.code === '10000') {
              this.$message({
                message: '修改成功！',
                type: 'success'
              });
            }
          });
          this.getList();
        } else if (this.bannerVisible === 3) {

          getBannerById({ id: addForm.bannerId }).then(response => {
            const res = response.data;
            if (res.code === '10000') {
              this.$message({
                message: '成功！',
                type: 'success'
              });
            }
            const banner = JSON.parse(res.data[0].value);
            this.content.color = addForm.color;
            this.content.id = addForm.id;
            this.content.imageUrl = addForm.imageUrl;
            this.content.url = addForm.url;
            this.content.title = addForm.title;
            this.content.sort = addForm.sort;
            this.content.showTime = addForm.showTime;
            this.content.startTime = addForm.start_time;
            this.content.endTime = addForm.end_time;
            this.content.reduceTime = addForm.reduceTime;
            this.content.isForceClose = addForm.isForceClose;
            this.content.showCondition = addForm.showCondition;
            banner.push(this.content);
            const text = JSON.stringify(banner);
            updateBannerList({ id: addForm.bannerId, value: text }).then(response => {
              const res = response.data;
              if (res.code === '10000') {
                this.$message({
                  message: '成功！',
                  type: 'success'
                });
              }
              this.getList();
            });
          });
        }
        this.dialogFormVisible = false;
      },
      editBannerButton(data) {
        this.bannerVisible = 2;
        this.dialogFormTitle = '修改banner';
        this.addForm = data;
        this.addForm.status = data.status.toString();
        this.selectTimes2 = [this.addForm.start_time, this.addForm.end_time];
        this.addForm.start_time = new Date(this.selectTimes2[0]).getTime() / 1000;
        this.addForm.end_time = new Date(this.selectTimes2[1]).getTime() / 1000;
        this.dialogFormVisible = true;
      },
      editBanner(data) {
        this.bannerVisible = 1;
        this.dialogFormTitle = '修改banner';
        this.addForm = data;
        if (this.addForm.isForceClose) {
          this.addForm.isForceClose = data.isForceClose.toString();
        }
        if (this.addForm.reduceTime) {
          this.addForm.reduceTime = data.reduceTime.toString();
        }
        if (this.addForm.showCondition) {
          this.addForm.showCondition = data.showCondition.toString();
        }
        this.selectTimes2 = [this.addForm.startTime, this.addForm.endTime];
        this.addForm.start_time = new Date(this.selectTimes2[0]).getTime() / 1000;
        this.addForm.end_time = new Date(this.selectTimes2[1]).getTime() / 1000;
        this.dialogFormVisible = true;
      },
      cancelAddBanner(formName) {
        this.addForm = {
          sort: '',
          title: '',
          url: '',
          image_url: '',
          start_time: '',
          end_time: '',
          client_id: '',
          start_version: '',
          end_version: '',
        };
        this.selectTimes2 = '';
        this.dialogFormVisible = false;
        this.getList();
      },
      selectTimeAfter() {
        const startDate = this.selectTimes2[0].getTime() / 1000;
        const endDate = this.selectTimes2[1].getTime() / 1000;
        this.addForm.start_time = startDate;
        this.addForm.end_time = endDate;
      },
      // 分页
      handleSizeChange(pageSize) {
        this.formInline.pageSize = pageSize;
        this.getList();
      },
      // 页码变化时触发
      handleCurrentChange(page) {
        this.formInline.pageNum = page;
        this.getList();
      }
    }
  };
</script>

<style scoped>
    .container {
        width: 200px;
        height: 100px;
        margin: 20px auto;
        text-align: center;
        padding: 5px;
    }

    .container > img {
        max-width: 100%;
        max-height: 100%;
    }
</style>
