<template xmlns:v-on="http://www.w3.org/1999/xhtml">
    <el-card class="card" shadow="hover" body-style="padding:0">
        <div class="container" v-on:click="onClick">
            <div style="padding-top: 5px;">
                <i class="el-icon-close" style="height: 10px; width: 24px;" @click.stop="onDelete"></i>
            </div>
            <div class="card-title">{{data.text}}</div>
            <div class="count-container">
                <span class="card-count-title">排序(值越大越靠前):  </span>
                <span class="card-count">{{data.sort}} </span>
            </div>
            <div class="count-container">
                <span class="card-count-title">建议分享时间:  </span>
                <span class="card-count">{{data.share_time}} </span>
            </div>
            <div class="count-container">
                <span class="card-count-title">客户端展示时间:  </span>
                <span class="card-count">{{data.on_sale_time}} </span>
            </div>
            <div class="count-container">
                <span class="card-count-title">客户端不展示时间:  </span>
                <span class="card-count">{{data.off_sale_time}} </span>
            </div>
            <div class="pic-container">
                <div class="empty-container" v-show="!Array.isArray(data.pics) || data.pics.length === 0">
                    <p class="empty">空</p>
                </div>
                <div class="item-pic-col" v-if="Array.isArray(data.pics) && data.pics.length !== 0">
                    <img class="item-pic" v-for="(item, index) in (data.pics.slice(0, 5))" :src="item" :key="index"/>
                </div>
            </div>
        </div>
        <div class="edit_area">
            <el-button class="sel_button" @click="updateChoiceList">
                <svg-icon icon-class="sort" />
                <span style="color:#1296db;">修改:({{data.sort}})</span>
            </el-button>
            <el-button class="sel_button" v-if="data.status === 0" @click.stop="putOnSale(data)">
                <svg-icon icon-class="putOn" />
                <span style="color:#1296db;">上 架</span>
            </el-button>
            <el-button class="sel_button" v-else @click.stop="pullOffSale(data)">
                <svg-icon icon-class="pullOff" />
                <span>下 架</span>
            </el-button>
        </div>

        <!-- 弹层 start -->
        <el-col :span="24">
            <el-dialog title="修改权重" :visible.sync="dialogFormVisible" width="300" @close="cancelForm">
                <el-form :model="addForm" :rules="rules" ref="addForm">
                    <el-form-item label="ID" :label-width="formLabelWidth" prop="id">
                        <el-input :disabled="true" v-model="addForm.id" placeholder="ID" size="mini" clearable></el-input>
                    </el-form-item>
                    <el-form-item label="排序 越大越靠前" :label-width="formLabelWidth" prop="sort">
                        <el-input class="input" placeholder="排序" v-model.number="addForm.sort"></el-input>
                    </el-form-item>
                    <el-form-item label="文本介绍" :label-width="formLabelWidth" prop="sort">
                        <el-input class="input" placeholder="文本介绍" v-model="addForm.text"></el-input>
                    </el-form-item>
                    <el-form-item label="建议分享时间" :label-width="formLabelWidth" prop="sort">
                        <el-date-picker v-model="addForm.share_time" type="datetime" placeholder="选择日期时间">
                        </el-date-picker>
                    </el-form-item>
                    <el-form-item label="客户端展示时间" :label-width="formLabelWidth" prop="sort">
                        <el-date-picker v-model="addForm.on_sale_time" type="datetime" placeholder="选择日期时间">
                        </el-date-picker>
                    </el-form-item>
                    <el-form-item label="客户端不展示时间" :label-width="formLabelWidth" prop="sort">
                        <el-date-picker v-model="addForm.off_sale_time" type="datetime" placeholder="选择日期时间">
                        </el-date-picker>
                    </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                    <el-button @click="cancelForm('addForm')">取 消</el-button>
                    <el-button type="primary" @click="confirmForm('addForm')">确 定</el-button>
                </div>
            </el-dialog>
        </el-col>
        <!-- 弹层 end -->
    </el-card>
</template>

<script>
    import { updateSortGoodsHotList, addGoodsHotList, delGoodsHotList } from '@/api/groupbuy';

    export default {
      data() {
        return {
          dialogFormVisible: false,
          dialogFormTitle: '',
          addForm: {
            id: this.data.id,
            sort: this.data.sort,
            share_time: this.data.share_time,
            text: this.data.text,
            on_sale_time: this.data.on_sale_time,
            off_sale_time: this.data.off_sale_time
          },
          formLabelWidth: '120px',
          rules: {
            sort: [{ required: true, message: '请输入权重', trigger: 'blur' },
              { type: 'number', min: 0, max: 9999, message: '权重为数字值，且范围为0～9999' }]
          },
        };
      },
      name: 'choice-list-card',
      props: {
        data: {
          type: Object,
          default: null,
        },
      },

      methods: {
        putOnSale(data) {
          const id = this.data.id;
          addGoodsHotList({ id }).then(res => {
            if (res.data.code === 10000) {
              this.$emit('update', this.data);
            }
            this.$emit('update', this.data);
          });
        },
        pullOffSale(data) {
          const id = this.data.id;
          delGoodsHotList({ id }).then(res => {
            if (res.data.code === 10000) {
              this.$emit('update', this.data);
            }
            this.$emit('update', this.data);
          });
        },
        onDelete() {
          this.$emit('delete', this.data);
        },

        onClick() {
          this.$emit('click', this.data);
        },

        updateChoiceList() {
          this.dialogFormVisible = true;
        },
        confirmForm(formName) {
          this.$refs[formName].validate(valid => {
            if (valid) {
              const id = this.addForm.id;
              const sort = this.addForm.sort;
              const share_time = new Date(this.addForm.share_time).getTime() / 1000;
              const text = this.addForm.text;
              const on_sale_time = new Date(this.addForm.on_sale_time).getTime() / 1000;
              const off_sale_time = new Date(this.addForm.off_sale_time).getTime() / 1000;
              updateSortGoodsHotList({ id, sort, share_time, text, on_sale_time, off_sale_time }).then(res => {
                if (res.data.code === 10000) {
                  this.$message({
                    message: '操作成功',
                    type: 'success'
                  });
                  this.$emit('update', this.data);
                } else {
                  this.$message({ type: 'error', message: res.data.msg || '修改失败' });
                }
              });
              this.dialogFormVisible = false;
            }
          });
        },
        cancelForm(formName) {
          this.dialogFormVisible = false;
        },
      },
    };
</script>

<style lang="scss" scoped>

    .container {
        width: 341px;
        height: 243px;
        font-family: "Microsoft YaHei", "微软雅黑", STXihei, "华文细黑", Georgia, "Times New Roman", Arial, sans-serif;

    .card-title {
        white-space: nowrap;
        text-overflow: ellipsis;
        font-size: 16px;
        color: #666;
        padding: 10px 20px 0;
    }

    .el-icon-close {
        position: relative;
        left: 301px;
        visibility: hidden;
    }

    .count-container {
        padding-left: 20px;
        margin-top: 6px;
        margin-bottom: 10px;

    .card-count-title {
        color: #999;
        font-size: 12px;
    }

    .card-count {
        color: #333;
        font-size: 12px;
    }

    }

    .pic-container {
        padding: 10px;
        background-color: #FAFAFA;
        height: 88px;
        overflow: hidden;
        margin-top: 10px;

    .empty-container {
        width: 58px;
        height: 58px;
        background-color: #F0F0F0;
        margin: 0;
        padding: 12px;

    .empty {
        font-size: 30px;
        color: white;
        margin: 0;
        text-align: center;
    }

    }

    .item-pic-col {
        height: 72px;
        width: 72px;
        display: inline-flex;

    .item-pic {
        width: 100%;
        height: 100%;
        object-fit: contain;
        margin-right: 10px;
    }

    }
    }
    }
    .edit_area {
        width: 100%;
        height: 40px;
        padding: 5px;
        display: flex;
    }
    .container:hover {

    .card-title {
        color: #409EFF;
    }

    .el-icon-close {
        color: #999;
        position: relative;
        left: 301px;
        visibility: visible;
    }

    }

</style>