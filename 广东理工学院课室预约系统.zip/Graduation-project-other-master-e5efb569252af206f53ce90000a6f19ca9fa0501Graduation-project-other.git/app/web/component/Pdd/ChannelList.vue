<template>
    <div class="container">
        <el-card :body-style="{ padding: '0px' }" v-for="channel in channel_list" :key="channel.channel_type" class="channel_card">
            <img :src="channel.image" class="channel_banner">
            <p class="channel_title">{{channel.name}}</p>
            <p class="channel_desc">{{channel.desc}}</p>
            <el-button class="channel_btn" @click="addChannel(channel)">添加推广</el-button>
        </el-card>
    </div>
</template>

<script>
export default {
  name: 'pdd-channel-list',
  data: () => {
    return {
      channel_list: [{
        channel_type: 0,
        name: '1.9包邮',
        image: 'https://t16img.yangkeduo.com/mms_static/468d1e4dbe9d92d9c992d4ae8a5ed692.png',
        desc: '全网最低价，极品肉单',
        send_text: '全场9块9低价包邮，更有超多大额优惠券发放中，一键立抢>>\n {{promote_url}}',
        promote_type: 2
      }, {
        channel_type: 2,
        name: '品牌清仓',
        image: 'https://t16img.yangkeduo.com/mms_static/3a68aa18c4383bf81a73dabdfdf45b25.png',
        desc: '旗舰店好货，百万优惠券',
        send_text: '高性价比品牌清仓，更有超多大额优惠券发放中，一键立抢>>\n {{promote_url}}',
        promote_type: 2
      }, {
        channel_type: 1,
        name: '今日爆款',
        image: 'https://t16img.yangkeduo.com/mms_static/f1f6ae6cae5abbea7e5b3bf2bdab2b05.png',
        desc: '今日爆款推荐，每10分钟计算一次销量',
        send_text: '今日爆款数量有限，更有超多大额优惠券发放中，一键立抢>>\n {{promote_url}}',
        promote_type: 2
      }, {
        channel_type: 9999,
        name: '天天拆红包',
        image: 'https://t16img.yangkeduo.com/mms_static/d577494ae4224fbdd403315ef81177bb.png',
        desc: '红包专场会场，巨额福利优惠',
        send_text: '红包福利专享会场，超多大额优惠券发放中，一键立抢>>\n {{promote_url}}',
        promote_type: 3
      }, {
        channel_type: 5,
        name: '养宝宝兑现金',
        image: 'https://t16img.yangkeduo.com/mms_static/103551a59288bef0e0eb0786f8ee3f1c.png',
        desc: '用户拆红包赚多多币兑现金，所有订单佣金均结算给你',
        send_text: '拼多多发红包啦，点击拆红包得现金，去好友家发现更多红包~快点击链接，跟我一起拿现金吧>>\n {{promote_url}}',
        promote_type: 2
      }, {
        channel_type: 6666,
        name: '转盘抽免单',
        image: 'https://t16img.yangkeduo.com/mms_static/2d19950b0aa5bdffc973aca055135e45.png',
        desc: '抽中免单锁佣一年，抽中红包拿佣金',
        send_text: '转盘抽免单，大批0元商品等你免费拿，更有大额红包发放中，一键抽奖>>\n {{promote_url}}',
        promote_type: 5
      },
      {
        channel_type: 4,
        name: '限时秒杀',
        image: 'https://t16img.yangkeduo.com/mms_static/164ed90b8597500292acc0715a5c42d1.png',
        desc: '超低价好货疯抢，为您带来巨大流量',
        send_text: '限时秒杀，底价狂欢，精选好货即将售罄，一键立抢>>\n {{promote_url}}',
        promote_type: 6
      },
      {
        channel_type: 39997,
        name: '充值中心',
        image: 'https://t16img.yangkeduo.com/mms_static/6df6c0ff30b3172dd75eea3f8bea7298.png',
        desc: '限时优惠，极速到账，保持用户活跃性',
        send_text: '充话费充流量，限时优惠，极速到账，一键立抢>>\n {{promote_url}}',
        promote_type: 6
      },
      {
        channel_type: 39999,
        name: '电器专场',
        image: 'https://t16img.yangkeduo.com/mms_static/b916ce7e0b68fafc8f4bd594d9f2b755.png',
        desc: '正品低价，质量保证，更有佣金等你拿',
        send_text: '数码家电底价狂欢，正品服务有保障，一键立抢>>\n {{promote_url}}',
        promote_type: 6
      }] // 精选频道列表
    };
  },
  methods: {
    addChannel(channel) {
      this.$emit('onSelect', channel);
    }
  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .container {
    display: -webkit-flex;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
  }

  .channel_col {
    line-height: 0px;
  }

  .channel_card {
    text-align: center;
    background-color: #fff;
    width: 355px;
    height: 301px;
    margin-right: 30px;
    margin-bottom: 30px;
  }

  .channel_banner {
    width: 180px;
    height: 160px;
    vertical-align: initial;
  }

  .channel_title {
    margin-bottom: 0px;
    height: 30px;
    font-size: 20px;
    text-align: center;
    color: #333333;
  }

  .channel_desc {
    margin-block-start: 0;
    margin-block-end: 0;
    font-size: 14px;
    color: #666;
  }

  .channel_btn {
    margin-top: 1.5em;
    font-size: 16px;
    height: 40px;
    text-align: center;
    cursor: pointer;
    border-radius: 3px;
    background-image: linear-gradient(-180deg, #ff5454 0%, #f83e3e 100%);
    color: #fff;
  }
</style>

