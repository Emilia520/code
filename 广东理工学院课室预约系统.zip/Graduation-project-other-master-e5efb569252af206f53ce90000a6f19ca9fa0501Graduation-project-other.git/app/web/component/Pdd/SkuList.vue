<template>
    <div v-loading="loadingGoods">
        <el-tabs @tab-click="onOptClick" style="height: 50px;">
            <el-tab-pane v-for="opt in Object.keys(opt_list)" :key="opt" :label="opt"></el-tab-pane>
        </el-tabs>
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
            <el-form-item label="排序方式">
            <el-select v-model="formInline.sort_type" placeholder="请选择" size="mini">
                <el-option label="综合排序" value="0"></el-option>
                <el-option label="按佣金比率升序" value="1"></el-option>
                <el-option label="按佣金比例降序" value="2"></el-option>
                <el-option label="按价格升序" value="3"></el-option>
                <el-option label="按价格降序" value="4"></el-option>
                <el-option label="按销量升序" value="5"></el-option>
                <el-option label="按销量降序" value="6"></el-option>
                <el-option label="优惠券金额排序升序" value="7"></el-option>
                <el-option label="优惠券金额排序降序" value="8"></el-option>
                <el-option label="券后价升序排序" value="9"></el-option>
                <el-option label="券后价降序排序" value="10"></el-option>
                <el-option label="按照加入多多进宝时间升序" value="11"></el-option>
                <el-option label="按照加入多多进宝时间降序" value="12"></el-option>
                <el-option label="按佣金金额升序排序" value="13"></el-option>
                <el-option label="按佣金金额降序排序" value="14"></el-option>
                <el-option label="店铺描述评分升序" value="15"></el-option>
                <el-option label="店铺描述评分降序" value="16"></el-option>
                <el-option label="店铺物流评分升序" value="17"></el-option>
                <el-option label="店铺物流评分降序" value="18"></el-option>
                <el-option label="店铺服务评分升序" value="19"></el-option>
                <el-option label="店铺服务评分降序" value="20"></el-option>
                <el-option label="描述评分击败同类店铺百分比升序" value="27"></el-option>
                <el-option label="描述评分击败同类店铺百分比降序" value="28"></el-option>
                <el-option label="物流评分击败同类店铺百分比升序" value="29"></el-option>
                <el-option label="物流评分击败同类店铺百分比降序" value="30"></el-option>
                <el-option label="服务评分击败同类店铺百分比升序" value="31"></el-option>
                <el-option label="服务评分击败同类店铺百分比降序" value="32"></el-option>
            </el-select>
            </el-form-item>
            <el-form-item label="商品关键词">
            <el-input v-model="formInline.keyword" placeholder="商品编号/商品名称" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item>
            <range-selector label="价格：" unit="元" v-model="formInline.price_range"></range-selector>
            </el-form-item>
            <el-form-item>
            <range-selector label="佣金：" unit="%" v-model="formInline.commission_range"></range-selector>
            </el-form-item>
            <el-form-item>
            <el-checkbox v-model="formInline.with_coupon" @change="setOnlyCoupon">只看优惠券</el-checkbox>
            </el-form-item>
            <el-form-item>
            <el-button type="primary" size="mini" @click="onSubmit">筛选</el-button>
            </el-form-item>
        </el-form>
        <!-- </el-col> -->
        <!-- 筛选条件 end -->
        <div class="goods_wrapper">
            <el-card :body-style="{ padding: '0px' }" v-for="goods in tableData" :key="goods.goods_id" class="goods_card">
                <a :href='"https://mobile.yangkeduo.com/goods2.html?goods_id=".concat(goods.goods_id)' target="_blank" style="cursor=pointer">
                <div class="goods_img_wrapper">
                    <img :src="goods.goods_thumbnail_url" class="goods_thumb">
                </div>
                <div class="goods_info_wrapper">
                    <p class="goods_title">{{goods.goods_name}}</p>
                    <p class="coupon_info">
                    <span><i>券</i>￥{{goods.coupon_discount / 100}}</span>
                    <span>剩余{{goods.coupon_remain_quantity}}张</span>
                    </p>
                    <p class="price_info">
                    <span>券后<b>￥{{(goods.min_group_price / 100 - goods.coupon_discount / 100).toFixed(2)}}</b></span>
                    <span class="orign_price">价格￥{{goods.min_group_price / 100}}</span>
                    </p>
                    <p class="earn_info">
                    <span>赚取<b>￥{{((goods.min_group_price / 100 - goods.coupon_discount / 100) * goods.promotion_rate / 1000).toFixed(2)}}</b></span>
                    <span>比率{{goods.promotion_rate / 10}}%</span>
                    </p>
                    <div class="sale_info">
                    <span>销量{{goods.sold_quantity}}</span>
                    <el-button class="goods_btn" @click.prevent="addGoods(goods)">{{selBtnTitle}}</el-button>
                    </div>
                </div>
                <div class="store_info_wrapper">
                    <div class="store_info">
                    <p class="store_title">
                        <span class="mall_icon"></span>
                        <span class="mall_name">{{goods.mall_name}}</span>
                        <span class="security_icon" v-if="(goods.merchant_type !== 1 && goods.merchant_type !== 6)"></span>
                    </p>
                    </div>
                </div>
                </a>
            </el-card>
        </div>
        <!-- 分页 start -->
        <div class="pagination" style="margin-top:20px;">
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="formInline.page" :page-sizes="[60, 80, 100, 120]" :page-size="formInline.page_size" layout="total, sizes, prev, pager, next" :total="totalCount">
            </el-pagination>
        </div>
        <!-- 分页 end -->
    </div>
</template>

<script>
import { getGoodsList } from '@/api/pdd';
import RangeSelector from '@/component/RangeSelector';

export default {
  components: { RangeSelector },
  name: 'pdd-sku-list',
  props: {
    selBtnTitle: {
      type: String,
      default: '立即推广'
    }
  },
  data: () => {
    return {
      tableData: [],
      totalCount: 0,
      loadingGoods: false,
      formInline: {
        with_coupon: true,
        sort_type: '',
        page: 1,
        page_size: 60,
        keyword: '',
        price_range: ['', ''],
        commission_range: ['', '']
      },
      opt_list: { 精选: 0, 百货: 15, 鞋包: 1281, 美妆: 16, 水果: 13, 女装: 14, 食品: 1, 母婴: 4, 男装: 743, 海淘: 12, 电器: 18, 内衣: 1282, 家纺: 818, 家具: 2974, 运动: 1451, 手机: 1543, 家装: 1917, 汽车: 2048 }
    };
  },
  methods: {
    didPresent() {
      if (this.tableData.length === 0) {
        this.getList();
      }
    },
    getList() {
      this.loadingGoods = true;
      const params = this.formInline;
      // 请求列表
      getGoodsList(params).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.tableData = res.data;
          this.totalCount = res.totalCount;
        }
        this.loadingGoods = false;
      });
    },
    onOptClick(val) {
      this.formInline.page = 1;
      this.formInline.opt_id = this.opt_list[val.label];
      this.getList();
    },
    setOnlyCoupon(val) {
      this.formInline.with_coupon = val;
      this.getList();
    },
    onSubmit() {
      this.getList();
    },
    handleSizeChange(page_size) {
      this.formInline.page_size = page_size;
      this.getList();
    },
    handleCurrentChange(page) {
      this.formInline.page = page;
      this.getList();
    },
    addGoods(goods) {
      this.$emit('onSelect', goods);
    }
  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .goods_wrapper {
    width: 100%;
    display: -webkit-flex;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
  }
  
  .goods_card {
    margin-bottom: 20px;
    margin-right: 20px;
    width: 224px;
    height: 438px;
    background-color: #fff;
    font-size: 0;
    position: relative;
    box-sizing: border-box;
    font-family: PingFang SC, Microsoft YaHei, Segoe UI, Helvetica Neue, Helvetica, Arial, sans-serif, SimSun !important;
  }

  .goods_img_wrapper {
    width: 100%;
    height: 224px;
    position: relative;
    background-color: #ebedf5;
    box-sizing: border-box;
  }

  .goods_thumb {
    width: 224px;
    height: 224px;
    position: absolute;
    left: 0;
    top: 0;
    vertical-align: initial;
    border-style: none;
    box-sizing: border-box;
  }

  .goods_info_wrapper {
    width: 100%;
    height: 186px;
    padding: 10px 10px 0;
    box-sizing: border-box;
    color: #999;
  }

  .goods_info_wrapper b {
    font-size: 18px;
    font-weight: bold;
    color: #e3544c;
  }

  .goods_title {
    color: #333;
    height: 30px;
    font-size: 14px;
    line-height: 30px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    margin-bottom: 0;
    box-sizing: border-box;
  }

  .coupon_info {
    height: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 0;
    box-sizing: border-box;
  }

  .coupon_info span:first-child {
    border: 1px solid #e3544c;
    color: #e3544c;
    font-weight: bold;
    padding-right: 2px;
  }

  .coupon_info span {
    display: flex;
    height: 18px;
    line-height: 17px;
    font-size: 12px;
  }

  .coupon_info span i {
    background-color: #e3544c;
    color: #fff;
    font-weight: normal;
    padding: 0 3px;
    font-style: normal;
  }

  .price_info {
    height: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 0;
    box-sizing: border-box;
    color: #999;
  }

  .price_info span:first-child {
    font-size: 14px;
  }

  .orign_price {
    font-size: 12px;
    text-decoration: line-through;
  }

  .earn_info {
    height: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .earn_info span:first-child {
    font-size: 14px;
  }

  .earn_info span:last-child {
    font-size: 12px;
    color: #e3544c;
  }

  .sale_info {
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .sale_info span {
    font-size: 14px;
  }

  .goods_btn {
    box-sizing: border-box;
    font-size: 16px;
    height: 30px;
    line-height: 28px;
    border: 1px solid #e3544c;
    color: #e3544c;
    text-align: center;
    width: 82px;
    user-select: none;
    border-radius: 4px;
    cursor: pointer;
    padding: 0;
  }

  .store_info_wrapper {
    position: relative;
    box-sizing: border-box;
  }

  .store_info {
    width: 100%;
    background-color: #f8f8f8;
    height: 28px;
  }

  .mall_icon {
    width: 18px;
    height: 16px;
    background: url(https://t16img.yangkeduo.com/mms_static/cc8fb52750564465f46e204ae37dd9b1.png) no-repeat;
    background-size: 100% 100%;
    display: inline-block;
    margin-left: 10px;
    margin-right: 6px;
    position: relative;
    top: 6px;
  }

  .mall_name {
    font-size: 12px;
    color: #999;
    display: inline-block;
    width: 160px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    height: 28px;
    line-height: 28px;
    vertical-align: middle;
  }

  .security_icon {
    width: 14px;
    height: 16px;
    background: url(https://t16img.yangkeduo.com/mms_static/eca51a29c2f8c14b25ec1ac7c103ed2b.png) no-repeat;
    background-size: 100% 100%;
    display: inline-block;
    position: relative;
    top: 7px;
    left: 5px;
  }
</style>
