<template>
    <div class="container" v-loading="loading">
        <el-card :body-style="{ padding: '0px' }" v-for="theme in tableData" :key="theme.id" class="theme_card">
            <img :src="theme.image_url" class="theme_banner">
            <p class="theme_desc_wrapper">
              <span class="theme_title">{{theme.name}}</span>
              <span class="theme_number">商品{{theme.goods_num}}个</span>
            </p>
            <div class="theme_thumbnail_wrapper">
              <img v-for="image in theme.thumbnail_list" :key="image" :src="image" alt>
            </div>
            <el-button class="theme_btn" @click="addTheme(theme)">批量推广</el-button>
        </el-card>
        <div class="pagination" style="margin-top:20px;">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="formInLine.page" :page-sizes="[40, 80, 120, 160]" :page-size="formInLine.page_size" layout="total, sizes, prev, pager, next" :total="totalCount">
            </el-pagination>
        </div>
    </div>
</template>

<script>
import { getThemeList, getThemeGoodsList } from '@/api/pdd';

export default {
  name: 'pdd-theme-list',
  data: () => {
    return {
      loading: false,
      totalCount: 0,
      tableData: [],
      theme_list_cache: {},
      formInLine: {
        page: 1,
        page_size: 40
      }
    };
  },
  methods: {
    didPresent() {
      if (this.tableData.length === 0) {
        this.getList();
      }
    },
    getList() {
      if (this.theme_list_cache[this.formInLine.page]) {
        this.tableData = this.theme_list_cache[this.formInLine.page];
        return;
      }

      this.loading = true;
      getThemeList(this.formInLine).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.tableData = res.data;
          this.totalCount = res.totalCount;
        }
        this.getThemeGoodsThunbnail(res.data, this.formInLine.page);
        this.loading = false;
      });
    },
    getThemeGoodsThunbnail(list, curPage) {
      const newList = [];
      for (const i in list) {
        const theme = list[i];
        newList.push(theme);
        if (!theme.thumbnail_list || theme.thumbnail_list.length === 0) {
          getThemeGoodsList({ theme_id: theme.id }).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              theme.thumbnail_list = [];
              for (const j in res.data) {
                const goods = res.data[j];
                theme.thumbnail_list.push(goods.goods_thumbnail_url || '');
              }
            }

            if (i == list.length - 1) {
              // setTimeout(() => {
              this.tableData = newList;
              this.theme_list_cache[curPage] = newList;
              // }, 2000);
            }
          });
        }
      }
    },
    handlePageChange(page) {
      this.formInLine.page = page;
      this.getList();
    },
    handleSizeChange(page_size) {
      this.formInLine.page_size = page_size;
      this.getList();
    },
    addTheme(theme) {
      this.$emit('onSelect', theme);
    }
  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .container {
    display: -webkit-flex;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
  }

  .theme_card {
    background-color: #fff;
    width: 285px;
    height: 263px;
    margin-right: 5px;
    margin-bottom: 30px;
  }

  .theme_banner {
    width: 100%;
    height: 131px;
    vertical-align: initial;
  }

  .theme_desc_wrapper {
    font-size: 14px;
    height: 33px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-block-start: 0;
    margin-block-end: 0;
    line-height: 33px;
  }

  .theme_title {
    white-space: nowrap;
    overflow: hidden;
    max-width: 180px;
    text-overflow: ellipsis;
    color: #333;
    padding-left: 10px;
    font-size: 14px;
  }

  .theme_number {
    padding-right: 10px;
    color: #9c9c9c;
    font-size: 12px;
  }

  .theme_thumbnail_wrapper {
    margin-bottom: 12px;
    overflow: hidden;
    width: 100%;
    height: 45px;
    justify-content: space-between;
    padding: 0 5px 0 10px;
    box-sizing: border-box;
  }

  .theme_thumbnail_wrapper img {
    margin-left: 1px;
    margin-right: 7px;
    width: 45px;
    height: 45px;
    vertical-align: initial;
  }

  .theme_btn {
    font-size: 14px;
    border: 1px solid #e3544c;
    width: 265px;
    height: 30px;
    text-align: center;
    color: #e3544c;
    border-radius: 5px;
    cursor: pointer;
    line-height: 0px;
  }
</style>
