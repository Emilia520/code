<template>
    <el-form :inline="true" class="demo-form-inline">
        <el-form-item>
            <el-input ref="input" :id="inputID" type="textarea" :width="inputWidth"
                      :autosize="{ minRows: 1, maxRows: 4}" :placeholder="placeholder" style="width: 248px"
                      v-model="content" @change="onChange" @focus="onFocus" clearable>
            </el-input>
        </el-form-item>
        <el-form-item>
            <el-popover>
                <el-button class="emo-btn" slot="reference" size="mini" circle>
                    <emoji emoji=":smile:" :native="true" :size="emojiBtnSize"></emoji>
                </el-button>
                <picker slot-scope="content" :native="true" title="选择表情" emoji="point_up"
                        :i18n="emojiPanelTranslate()" @select="onEmojiSelect"></picker>
            </el-popover>
        </el-form-item>
    </el-form>
</template>

<script>
  import { Picker } from 'emoji-mart-vue';
  import { Emoji } from 'emoji-mart-vue';

  const GraphemeSplitter = require('grapheme-splitter');

  export default {
    components: { Emoji, Picker },
    name: 'emoji-text-input',
    data() {
      return {
        content: this.inputValue,
        cursor: undefined,
        inputID: this._uid,
      };
    },
    model: {
      prop: 'inputValue',
      event: 'inputEmoji'
    },
    props: {
      inputWidth: {
        type: Number,
        default: 300
      },

      inputValue: {
        type: String,
      },

      placeholder: {
        type: String,
        default: '',
      },

      textInputSize: {
        type: String,
        default: 'mini',
      },

      emojiBtnSize: {
        type: Number,
        default: 24,
      },
    },
    watch: {
      inputValue(newVal, oldVal) {
        console.log('++++++++++++++++', newVal);
        this.content = newVal;
      }
    },
    methods: {
      emojiPanelTranslate() {
        return {
          search: '搜索表情',
          notfound: '未发现，请使用英文搜索哦',
          categories: {
            search: '给你',
            recent: '常用',
            people: '人物表情',
            nature: '大自然',
            foods: '餐饮',
            activity: '活动',
            places: '旅游',
            objects: '物件',
            symbols: '符号',
            flags: '旗子',
            custom: '自定义',
          },
        };
      },

      onEmojiSelect(emoji) {
        let startPos;
        let endPos;
        const elInput = document.getElementById(this.inputID);

        if (this.cursor === undefined) {
          startPos = elInput.selectionStart;
          endPos = elInput.selectionEnd;
        } else {
          // 为了保证input在失去聚焦后连续输入emoji的位置正确
          startPos = this.cursor;
          endPos = this.cursor;
        }

        if (startPos === undefined || endPos === undefined) return;

        const splitter = new GraphemeSplitter();
        const chars = splitter.splitGraphemes(this.content);

        if (chars.length !== 0 && this.cursor === undefined) {
          // 用户点击选择的光标位置需要纠偏
          startPos = this.correctSelection(chars, startPos);
          endPos = this.correctSelection(chars, endPos);
        }

        chars.splice(startPos, endPos - startPos, emoji.native);

        this.content = chars.join('');
        this.$emit('inputEmoji', this.content);
        this.cursor = startPos + 1;
      },

      onFocus() {
        console.log('onFocus');
        this.cursor = undefined;
      },

      onChange(val) {
        console.log('onChange', val);
        this.content = val;
        this.$emit('inputEmoji', this.content);
      },

      correctSelection(arr, selection) {
        // input的selectionStart/End不会处理表情符号的长度
        let delta = 0;
        let target = 0;

        for (let index = 0; index <= arr.length; ++index) {
          target = index;

          if (index < arr.length && (delta += arr[index].length) > selection) {
            break;
          }
        }

        return target;
      }
    }
  };

</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .emo-btn {
        margin-top: 6px;
        border: none;
    }
</style>