<template>
    <div v-loading="loadingGoods">
        <el-tabs @tab-click="onCatClick" style="height: 50px;">
            <el-tab-pane v-for="cat in catList" :key="cat.cat_id" :label="cat.cat_name"></el-tab-pane>
        </el-tabs>
        <!-- 筛选条件 start -->
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
            <el-form-item label="搜索（注：当使用此筛选时，分类筛选无效）">
                <el-input v-model="formInline.keywords" placeholder="商品关键词" size="mini" clearable>
                    <i slot="prefix" class="el-input__icon el-icon-search"></i>
                </el-input>
            </el-form-item>
            <el-form-item>
                <range-selector label="价格：" unit="元" v-model="price_range"></range-selector>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" size="mini" @click="onSubmit">筛选</el-button>
            </el-form-item>
        </el-form>
        <!-- 筛选条件 end -->
        <div class="goods_wrapper">
            <el-card :body-style="{ padding: '0px' }" v-for="goods in tableData" :key="goods.num_iid"
                     class="goods_card">
                <a :href="`https://detail.1688.com/offer/${goods.offerId}.html`" target="_blank" style="cursor:pointer">
                    <div class="goods_img_wrapper">
                        <img :src="goods.imgUrl" class="goods_thumb">
                    </div>
                    <div class="goods_info_wrapper">
                        <p class="goods_title">{{goods.title}}</p>
                        <!-- <p class="coupon_info">
                            <span v-if="goods.coupon_info"><i>券</i>{{goods.coupon_info}}</span>
                            <span v-if="goods.coupon_info">剩余{{goods.coupon_remain_count}}张</span>
                        </p> -->
                        <p class="price_info">
                            <span>批发价: <b>￥{{goods.price}}</b></span>
                        </p>
                        <!-- <p class="earn_info">
                            <span>赚取: <b>￥{{(goods.zk_final_price * goods.commission_rate / 100).toFixed(2)}}</b></span>
                            <span>比率: {{goods.commission_rate}}%</span>
                        </p> -->
                        <div class="sale_info">
                            <span>销量: {{goods.saleQuantity}}</span>
                        </div>
                        <div class="store_info">
                            <span class="mall_icon"></span>
                            <span class="mall_name">{{goods.companyName}}</span>
                        </div>
                        <div>
                            <span v-show="!selectable">
                                <el-button class="goods_btn" @click.prevent="addGoods(goods)">立即推广</el-button>
                            </span>'
                            <span v-show="selectable">
                                <el-button class="goods_btn" @click.prevent="addGoods(goods)"
                                           icon="el-icon-download el-icon--left">选取</el-button>
                            </span>
                        </div>
                    </div>
                </a>
            </el-card>
        </div>
        <div class="pagination" style="margin-top:20px;">
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                           :current-page="formInline.page" :page-sizes="[30]" :page-size="formInline.pageSize"
                           layout="total, sizes, prev, pager, next" :total="totalCount">
            </el-pagination>
        </div>
    </div>
</template>

<script>
  import { getGoodsList, getCatList } from '@/api/tb1688';
  import RangeSelector from '@/component/RangeSelector';

  export default {
    components: { RangeSelector },
    name: 'tb-1688-goods-list',
    data: () => {
      return {
        tableData: [],
        totalCount: 0,
        selectable: 1,
        loadingGoods: false,
        formInline: {
          pageNo: 1,
          pageSize: 30,
          categoryIds: '10166',
          keywords: ''
        },
        price_range: ['', ''],
        catList: []
      };
    },
    methods: {
      didPresent(selectable = 0) {
        this.selectable = selectable;
        if (this.tableData.length === 0) {
          this.getList();
        }
      },
      async getCatList() {
        if (this.catList.length > 0) {
          return;
        }
  
        const res = await getCatList();
        if (res.data.code === 10000) {
          this.catList = res.data.data;
        }
      },
      async getList() {
        this.loadingGoods = true;
        await this.getCatList();
        const params = this.formInline;
        if (this.price_range[0]) {
          genRangeParam(params, 'priceStart', this.price_range[0]);
        }
        if (this.price_range[1]) {
          genRangeParam(params, 'priceEnd', this.price_range[1]);
        }
        if (params.keywords) {
          params.categoryIds = '';
        }

        // 请求列表
        const response = await getGoodsList(params);
        const res = response.data;
        if (res.code === 10000) {
          this.tableData = res.data;
          this.totalCount = res.totalCount;
        } else {
          this.tableData = [];
          this.totalCount = 0;
        }
        this.loadingGoods = false;

        function genRangeParam(obj, key, oriData) {
          if (!oriData) {
            return;
          }

          const num = Number(oriData);
          if (!isNaN(num)) {
            obj[key] = num;
          }
        }
      },
      onCatClick(val) {
        let cat;
        for (const i in this.catList) {
          const catInfo = this.catList[i];
          if (catInfo.cat_name === val.label) {
            cat = catInfo;
            break;
          }
        }

        this.formInline.pageNo = 1;
        this.formInline.categoryIds = String(cat.cat_id);
        this.formInline.keywords = '';
        this.getList();
      },
      setCoupon(val) {
        this.formInline.coupon = val ? 1 : 0;
        this.getList();
      },
      setTmall(val) {
        this.formInline.is_tmall = val ? 1 : 0;
        this.getList();
      },
      onSubmit() {
        this.getList();
      },
      handleSizeChange(page_size) {
        this.formInline.pageSize = page_size;
        this.getList();
      },
      handleCurrentChange(page) {
        this.formInline.pageNo = page;
        this.getList();
      },
      addGoods(goods) {
        this.$emit('onSelect', goods);
      },
    }
  };
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .goods_wrapper {
        width: 100%;
        display: -webkit-flex;
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
    }

    .goods_card {
        margin-bottom: 20px;
        margin-right: 20px;
        width: 224px;
        background-color: #fff;
        font-size: 0;
        position: relative;
        box-sizing: border-box;
        font-family: PingFang SC, Microsoft YaHei, Segoe UI, Helvetica Neue, Helvetica, Arial, sans-serif, SimSun !important;
    }

    .goods_img_wrapper {
        width: 100%;
        height: 224px;
        position: relative;
        background-color: #ebedf5;
        box-sizing: border-box;
    }

    .goods_thumb {
        width: 224px;
        height: 224px;
        position: absolute;
        left: 0;
        top: 0;
        vertical-align: initial;
        border-style: none;
        box-sizing: border-box;
    }

    .goods_info_wrapper {
        width: 100%;
        height: 220px;
        padding: 10px 10px 0;
        box-sizing: border-box;
        color: #999;
    }

    .goods_info_wrapper b {
        font-size: 12px;
        font-weight: bold;
        color: #666666;
    }

    .goods_title {
        color: #666666;
        height: 30px;
        font-size: 12px;
        line-height: 30px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        margin-bottom: 0;
        box-sizing: border-box;
    }

    .coupon_info {
        height: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0;
        box-sizing: border-box;
    }

    .coupon_info span:first-child {
        border: 1px solid #e3544c;
        color: #e3544c;
        font-weight: bold;
        padding-right: 2px;
    }

    .coupon_info span {
        display: flex;
        height: 18px;
        line-height: 17px;
        font-size: 12px;
    }

    .coupon_info span i {
        background-color: #e3544c;
        color: #fff;
        font-weight: normal;
        padding: 0 3px;
        font-style: normal;
    }

    .price_info {
        height: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0;
        box-sizing: border-box;
        color: #999;
    }

    .price_info span:first-child {
        font-size: 12px;
    }

    .orign_price {
        font-size: 12px;
        text-decoration: line-through;
    }

    .earn_info {
        height: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .earn_info span:first-child {
        font-size: 12px;
    }

    .earn_info span:last-child {
        font-size: 12px;
        color: #FF5500;
    }

    .sale_info {
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .sale_info span {
        font-size: 12px;
    }

    .goods_btn {
        font-size: 12px;
        height: 40px;
        width: 100%;
        line-height: 40px;
        color: #666;
        text-align: center;
        display: inline-block;
        user-select: none;
        cursor: pointer;
        vertical-align: center;
        padding: 0;
        border-color: transparent;
    }

    .store_info {
        width: 100%;
        height: 30px;
        line-height: 30px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        font-size: 12px;
        vertical-align: center;
        background-color: #FCFCFC;
    }

    .mall_icon {
        width: 12px;
        height: 12px;
        background: url(https://t16img.yangkeduo.com/mms_static/cc8fb52750564465f46e204ae37dd9b1.png) no-repeat;
        background-size: 100% 100%;
        display: inline-block;
        margin-right: 5px;
    }

    .mall_name {
        height: 30px;
        position: absolute;
    }

    .security_icon {
        width: 14px;
        height: 16px;
        background: url(https://t16img.yangkeduo.com/mms_static/eca51a29c2f8c14b25ec1ac7c103ed2b.png) no-repeat;
        background-size: 100% 100%;
        display: inline-block;
        position: relative;
        top: 7px;
        left: 5px;
    }
</style>
