<template>
    <div v-loading="loadingGoods">
        <el-tabs @tab-click="onOptClick" style="height: 50px;">
            <el-tab-pane v-for="opt in Object.keys(opt_list)" :key="opt" :label="opt"></el-tab-pane>
        </el-tabs>
        <!-- 筛选条件 start -->
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
            <el-form-item label="超级搜索（注：当使用此筛选时，分类筛选无效）">
                <el-input v-model="formInline.para" placeholder="商品编号/商品关键词" size="mini" clearable>
                    <i slot="prefix" class="el-input__icon el-icon-search"></i>
                </el-input>
            </el-form-item>
            <el-form-item label="排序方式">
                <el-select v-model="formInline.sort" placeholder="请选择" size="mini">
                    <el-option label="淘客佣金比率降序" value="tk_rate_des"></el-option>
                    <el-option label="淘客佣金比率升序" value="tk_rate_asc"></el-option>
                    <el-option label="销量降序" value="total_sales_des"></el-option>
                    <el-option label="销量升序" value="total_sales_asc"></el-option>
                    <el-option label="累计推广量降序" value="tk_total_sales_des"></el-option>
                    <el-option label="累计推广量升序" value="tk_total_sales_asc"></el-option>
                    <el-option label="总支出佣金降序" value="tk_total_commi_des"></el-option>
                    <el-option label="总支出佣金升序" value="tk_total_commi_asc"></el-option>
                    <el-option label="价格降序" value="price_des"></el-option>
                    <el-option label="价格升序" value="price_asc"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <range-selector label="价格：" unit="元" v-model="price_range"></range-selector>
            </el-form-item>
            <el-form-item>
                <range-selector label="佣金：" unit="%" v-model="commission_range"></range-selector>
            </el-form-item>
            <el-form-item>
                <el-checkbox :checked="formInline.coupon == 1" @change="setCoupon">只看优惠券</el-checkbox>
            </el-form-item>
            <el-form-item>
                <el-checkbox :checked="formInline.is_tmall == 1" @change="setTmall">只看天猫</el-checkbox>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" size="mini" @click="onSubmit">筛选</el-button>
            </el-form-item>
        </el-form>
        <!-- 筛选条件 end -->
        <div class="goods_wrapper">
            <el-card :body-style="{ padding: '0px' }" v-for="goods in tableData" :key="goods.num_iid"
                     class="goods_card">
                <a :href="goods.item_url" target="_blank" style="cursor:pointer">
                    <div class="goods_img_wrapper">
                        <img :src="goods.pict_url" class="goods_thumb">
                    </div>
                    <div class="goods_info_wrapper">
                        <p class="goods_title">{{goods.short_title}}</p>
                        <p class="coupon_info">
                            <span v-if="goods.coupon_info"><i>券</i>{{goods.coupon_info}}</span>
                            <span v-if="goods.coupon_info">剩余{{goods.coupon_remain_count}}张</span>
                        </p>
                        <p class="price_info">
                            <span v-if="goods.coupon_price >= 0">券后价: <b>￥{{goods.coupon_price}}</b></span>
                            <span v-else>折后价: <b>￥{{goods.zk_final_price}}</b></span>
                            <span class="orign_price">价格￥{{goods.reserve_price}}</span>
                        </p>
                        <p class="earn_info">
                            <span>赚取: <b>￥{{(goods.zk_final_price * goods.commission_rate / 100).toFixed(2)}}</b></span>
                            <span>比率: {{goods.commission_rate}}%</span>
                        </p>
                        <div class="sale_info">
                            <span>销量: {{goods.volume}}</span>
                        </div>
                        <div class="store_info">
                            <span class="mall_icon"></span>
                            <span class="mall_name">{{goods.shop_title}}</span>
                        </div>
                        <div>
                            <span v-show="!selectable">
                                <el-button class="goods_btn" @click.prevent="addGoods(goods)">立即推广</el-button>
                            </span>'
                            <span v-show="selectable">
                                <el-button class="goods_btn" @click.prevent="addGoods(goods)"
                                           icon="el-icon-download el-icon--left">选取</el-button>
                            </span>
                        </div>
                    </div>
                </a>
            </el-card>
        </div>
        <div class="pagination" style="margin-top:20px;">
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                           :current-page="formInline.page" :page-sizes="[30]" :page-size="formInline.pagesize"
                           layout="total, sizes, prev, pager, next" :total="totalCount">
            </el-pagination>
        </div>
    </div>
</template>

<script>
  import { getGoodsList } from '@/api/tb';
  import RangeSelector from '@/component/RangeSelector';

  export default {
    components: { RangeSelector },
    name: 'tb-sku-list',
    data: () => {
      return {
        tableData: [],
        totalCount: 0,
        selectable: 1,
        loadingGoods: false,
        formInline: {
          page: 1,
          pagesize: 30,
          sort: 'total_sales_des',
          cat: 1629,
          para: '',
          coupon: 1,
          is_tmall: 0,
          start_price: '',
          end_price: '',
          start_tk_rate: '',
          end_tk_rate: ''
        },
        price_range: ['', ''],
        commission_range: ['', ''],
        opt_list: {
          大码女装: 1629,
          职业女装套裙: 162401,
          '女装/女士精品': 16,
          居家日用: 21,
          '零食/坚果/特产': 50002766,
          '美容护肤/美体/精油': 1801,
          '箱包皮具/热销女包/男包': 50006842,
          '彩妆/香水/美妆工具': 50010788,
          '玩具/童车/益智/积木/模型': 25,
          女鞋: 50006843,
          男装: 30
        }
      };
    },
    methods: {
      didPresent(selectable = 0) {
        this.selectable = selectable;
        if (this.tableData.length === 0) {
          this.getList();
        }
      },
      getList() {
        this.loadingGoods = true;
        const params = this.formInline;
        genRangeParam(params, 'start_price', this.price_range[0]);
        genRangeParam(params, 'end_price', this.price_range[1]);
        genRangeParam(params, 'start_tk_rate', this.commission_range[0] * 100);
        genRangeParam(params, 'end_tk_rate', this.commission_range[1] * 100);

        // 请求列表
        getGoodsList(params).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            for (const i in res.data) {
              const data = res.data[i];
              if (data.coupon_info) {
                const couponArr = data.coupon_info.replace('元', '').replace('满', '').split('减');
                if (couponArr.length > 1) {
                  const coupon_start_fee = parseFloat(couponArr[0]);
                  const coupon_amount = parseFloat(couponArr[1]);
                  if (data.zk_final_price >= coupon_start_fee && data.zk_final_price - coupon_amount >= 0) {
                    data.coupon_price = data.zk_final_price - coupon_amount;
                    data.coupon_price = Number(data.coupon_price).toFixed(2);
                  }
                }
              }
              console.log('conmmision rate ', data.commission_rate);

              // 对维易接口进行适配：搜索参数para传入商品ID唯一确定一件商品时，
              // 接口返回的commission_rate即为佣金比例，其他情况需要除以100
              data.commission_rate /= (res.data.length === 1 && params.para && !isNaN(params.para)) ? 1 : 100;
            }

            this.tableData = res.data;
            this.totalCount = res.totalCount;
          } else {
            this.tableData = [];
            this.totalCount = 0;
          }
          this.loadingGoods = false;
        });

        function genRangeParam(obj, key, oriData) {
          if (!oriData) {
            return;
          }

          const num = Number(oriData);
          if (!isNaN(num)) {
            obj[key] = num;
          }
        }
      },
      onOptClick(val) {
        this.formInline.page = 1;
        this.formInline.cat = this.opt_list[val.label];
        this.getList();
      },
      setCoupon(val) {
        this.formInline.coupon = val ? 1 : 0;
        this.getList();
      },
      setTmall(val) {
        this.formInline.is_tmall = val ? 1 : 0;
        this.getList();
      },
      onSubmit() {
        this.getList();
      },
      handleSizeChange(page_size) {
        this.formInline.pagesize = page_size;
        this.getList();
      },
      handleCurrentChange(page) {
        this.formInline.page = page;
        this.getList();
      },
      addGoods(goods) {
        this.$emit('onSelect', goods);
      },
    }
  };
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .goods_wrapper {
        width: 100%;
        display: -webkit-flex;
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
    }

    .goods_card {
        margin-bottom: 20px;
        margin-right: 20px;
        width: 224px;
        height: 482px;
        background-color: #fff;
        font-size: 0;
        position: relative;
        box-sizing: border-box;
        font-family: PingFang SC, Microsoft YaHei, Segoe UI, Helvetica Neue, Helvetica, Arial, sans-serif, SimSun !important;
    }

    .goods_img_wrapper {
        width: 100%;
        height: 224px;
        position: relative;
        background-color: #ebedf5;
        box-sizing: border-box;
    }

    .goods_thumb {
        width: 224px;
        height: 224px;
        position: absolute;
        left: 0;
        top: 0;
        vertical-align: initial;
        border-style: none;
        box-sizing: border-box;
    }

    .goods_info_wrapper {
        width: 100%;
        height: 220px;
        padding: 10px 10px 0;
        box-sizing: border-box;
        color: #999;
    }

    .goods_info_wrapper b {
        font-size: 12px;
        font-weight: bold;
        color: #666666;
    }

    .goods_title {
        color: #666666;
        height: 30px;
        font-size: 12px;
        line-height: 30px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        margin-bottom: 0;
        box-sizing: border-box;
    }

    .coupon_info {
        height: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0;
        box-sizing: border-box;
    }

    .coupon_info span:first-child {
        border: 1px solid #e3544c;
        color: #e3544c;
        font-weight: bold;
        padding-right: 2px;
    }

    .coupon_info span {
        display: flex;
        height: 18px;
        line-height: 17px;
        font-size: 12px;
    }

    .coupon_info span i {
        background-color: #e3544c;
        color: #fff;
        font-weight: normal;
        padding: 0 3px;
        font-style: normal;
    }

    .price_info {
        height: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0;
        box-sizing: border-box;
        color: #999;
    }

    .price_info span:first-child {
        font-size: 12px;
    }

    .orign_price {
        font-size: 12px;
        text-decoration: line-through;
    }

    .earn_info {
        height: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .earn_info span:first-child {
        font-size: 12px;
    }

    .earn_info span:last-child {
        font-size: 12px;
        color: #FF5500;
    }

    .sale_info {
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .sale_info span {
        font-size: 12px;
    }

    .goods_btn {
        font-size: 12px;
        height: 40px;
        width: 100%;
        line-height: 40px;
        color: #666;
        text-align: center;
        display: inline-block;
        user-select: none;
        cursor: pointer;
        vertical-align: center;
        padding: 0;
        border-color: transparent;
    }

    .store_info {
        width: 100%;
        height: 30px;
        line-height: 30px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        font-size: 12px;
        vertical-align: center;
        background-color: #FCFCFC;
    }

    .mall_icon {
        width: 12px;
        height: 12px;
        background: url(https://t16img.yangkeduo.com/mms_static/cc8fb52750564465f46e204ae37dd9b1.png) no-repeat;
        background-size: 100% 100%;
        display: inline-block;
        margin-right: 5px;
    }

    .mall_name {
        height: 30px;
        position: absolute;
    }

    .security_icon {
        width: 14px;
        height: 16px;
        background: url(https://t16img.yangkeduo.com/mms_static/eca51a29c2f8c14b25ec1ac7c103ed2b.png) no-repeat;
        background-size: 100% 100%;
        display: inline-block;
        position: relative;
        top: 7px;
        left: 5px;
    }
</style>
