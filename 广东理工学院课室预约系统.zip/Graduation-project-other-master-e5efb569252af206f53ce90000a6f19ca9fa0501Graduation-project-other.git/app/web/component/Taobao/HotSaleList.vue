<template>
    <div v-loading="loadingGoods">
        <el-tabs @tab-click="onOptClick" style="height: 50px;">
            <el-tab-pane v-for="opt in opt_list" :key="opt" :label="opt"></el-tab-pane>
        </el-tabs>
        <!-- 筛选条件 start -->
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
            <el-form-item label="排序方式">
            <el-select v-model="formInline.sort" placeholder="请选择" size="mini">
                <el-option label="佣金比率降序" value="tk_rate_des"></el-option>
                <el-option label="佣金比率升序" value="tk_rate_asc"></el-option>
                <el-option label="销量降序" value="total_sales_des"></el-option>
                <el-option label="销量升序" value="total_sales_asc"></el-option>
                <el-option label="优惠券降序" value="coupon_des"></el-option>
                <el-option label="优惠券升序" value="coupon_asc"></el-option>
                <el-option label="价格降序" value="price_des"></el-option>
                <el-option label="价格升序" value="price_asc"></el-option>
            </el-select>
            </el-form-item>
            <el-form-item>
            <el-button type="primary" size="mini" @click="onSubmit">筛选</el-button>
            </el-form-item>
        </el-form>
        <!-- 筛选条件 end -->
        <div class="goods_wrapper">
        <el-card :body-style="{ padding: '0px' }" v-for="goods in tableData" :key="goods.item_id" class="goods_card">
            <a :href="`https://detail.tmall.com/item.htm?id=${goods.item_id}`" target="_blank" style="cursor=pointer">
            <div class="goods_img_wrapper">
                <img :src="goods.pict_url" class="goods_thumb">
            </div>
            <div class="goods_info_wrapper">
                <p class="goods_title">{{goods.title}}</p>
                <p class="coupon_info">
                <span v-if="goods.coupon_amount"><i>券</i>满{{parseInt(goods.coupon_start_fee)}}减{{parseInt(goods.coupon_amount)}}</span>
                <span v-if="goods.coupon_info">剩余{{goods.coupon_remain_count}}张</span>
                </p>
                <p class="price_info">
                <span>券后价<b>￥{{goods.coupon_price}}</b></span>
                <span class="orign_price">价格￥{{goods.zk_final_price}}</span>
                </p>
                <p class="earn_info">
                <span>赚取<b>￥{{(goods.coupon_price * goods.commission_rate / 100).toFixed(2)}}</b></span>
                <span>比率{{goods.commission_rate}}%</span>
                </p>
                <div class="sale_info">
                <span>销量{{goods.volume}}</span>
                <el-button class="goods_btn" @click.prevent="addGoods(goods)">立即推广</el-button>
                </div>
            </div>
            <div class="store_info_wrapper">
                <div class="store_info">
                <p class="store_title">
                    <span class="mall_icon"></span>
                    <span class="mall_name">{{goods.shop_title}}</span>
                </p>
                </div>
            </div>
            </a>
        </el-card>
        </div>
        <div class="pagination" style="margin-top:20px;">
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="formInline.page" :page-sizes="[60]" :page-size="formInline.pagesize" layout="total, sizes, prev, pager, next" :total="totalCount">
            </el-pagination>
        </div>
    </div>
</template>

<script>
import { getHotSaleList } from '@/api/tb';
import RangeSelector from '@/component/RangeSelector';

export default {
  components: { RangeSelector },
  name: 'tb-hot-list',
  data: () => {
    return {
      tableData: [],
      totalCount: 0,
      loadingGoods: false,
      formInline: {
        page: 1,
        pagesize: 60,
        sort: 'total_sales_des',
        topcate: '热销'
      },
      opt_list: ['热销', '优质品', '母婴', '特价']
    };
  },
  methods: {
    didPresent() {
      if (this.tableData.length === 0) {
        this.getList();
      }
    },
    getList() {
      this.loadingGoods = true;
      const params = this.formInline;

      // 请求列表
      getHotSaleList(params).then(response => {
        const res = response.data;
        console.log('getHotSaleList', res);
        if (res.code === 10000) {
          for (const i in res.data) {
            const data = res.data[i];
            if (data.coupon_start_fee && data.coupon_amount && data.zk_final_price) {
              data.coupon_price = Number(data.zk_final_price - data.coupon_amount).toFixed(2);
            }
          }
          this.tableData = res.data;
          this.totalCount = 1000;
        } else {
          this.tableData = [];
          this.totalCount = 0;
        }
        this.loadingGoods = false;
      });
    },
    onOptClick(val) {
      this.formInline.page = 1;
      this.formInline.topcate = val.label;
      this.getList();
    },
    onSubmit() {
      this.getList();
    },
    handleSizeChange(page_size) {
      this.formInline.pagesize = page_size;
      this.getList();
    },
    handleCurrentChange(page) {
      this.formInline.page = page;
      this.getList();
    },
    addGoods(goods) {
      this.$emit('onSelect', goods);
    }
  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .goods_wrapper {
    width: 100%;
    display: -webkit-flex;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
  }
  
  .goods_card {
    margin-bottom: 20px;
    margin-right: 20px;
    width: 224px;
    height: 438px;
    background-color: #fff;
    font-size: 0;
    position: relative;
    box-sizing: border-box;
    font-family: PingFang SC, Microsoft YaHei, Segoe UI, Helvetica Neue, Helvetica, Arial, sans-serif, SimSun !important;
  }

  .goods_img_wrapper {
    width: 100%;
    height: 224px;
    position: relative;
    background-color: #ebedf5;
    box-sizing: border-box;
  }

  .goods_thumb {
    width: 224px;
    height: 224px;
    position: absolute;
    left: 0;
    top: 0;
    vertical-align: initial;
    border-style: none;
    box-sizing: border-box;
  }

  .goods_info_wrapper {
    width: 100%;
    height: 186px;
    padding: 10px 10px 0;
    box-sizing: border-box;
    color: #999;
  }

  .goods_info_wrapper b {
    font-size: 18px;
    font-weight: bold;
    color: #e3544c;
  }

  .goods_title {
    color: #333;
    height: 30px;
    font-size: 14px;
    line-height: 30px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    margin-bottom: 0;
    box-sizing: border-box;
  }

  .coupon_info {
    height: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 0;
    box-sizing: border-box;
  }

  .coupon_info span:first-child {
    border: 1px solid #e3544c;
    color: #e3544c;
    font-weight: bold;
    padding-right: 2px;
  }

  .coupon_info span {
    display: flex;
    height: 18px;
    line-height: 17px;
    font-size: 12px;
  }

  .coupon_info span i {
    background-color: #e3544c;
    color: #fff;
    font-weight: normal;
    padding: 0 3px;
    font-style: normal;
  }

  .price_info {
    height: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 0;
    box-sizing: border-box;
    color: #999;
  }

  .price_info span:first-child {
    font-size: 14px;
  }

  .orign_price {
    font-size: 12px;
    text-decoration: line-through;
  }

  .earn_info {
    height: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .earn_info span:first-child {
    font-size: 14px;
  }

  .earn_info span:last-child {
    font-size: 12px;
    color: #e3544c;
  }

  .sale_info {
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .sale_info span {
    font-size: 14px;
  }

  .goods_btn {
    box-sizing: border-box;
    font-size: 16px;
    height: 30px;
    line-height: 28px;
    border: 1px solid #e3544c;
    color: #e3544c;
    text-align: center;
    width: 82px;
    user-select: none;
    border-radius: 4px;
    cursor: pointer;
    padding: 0;
  }

  .store_info_wrapper {
    position: relative;
    box-sizing: border-box;
  }

  .store_info {
    width: 100%;
    background-color: #f8f8f8;
    height: 28px;
  }

  .mall_icon {
    width: 18px;
    height: 16px;
    background: url(https://t16img.yangkeduo.com/mms_static/cc8fb52750564465f46e204ae37dd9b1.png) no-repeat;
    background-size: 100% 100%;
    display: inline-block;
    margin-left: 10px;
    margin-right: 6px;
    position: relative;
    top: 6px;
  }

  .mall_name {
    font-size: 12px;
    color: #999;
    display: inline-block;
    width: 160px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    height: 28px;
    line-height: 28px;
    vertical-align: middle;
  }

  .security_icon {
    width: 14px;
    height: 16px;
    background: url(https://t16img.yangkeduo.com/mms_static/eca51a29c2f8c14b25ec1ac7c103ed2b.png) no-repeat;
    background-size: 100% 100%;
    display: inline-block;
    position: relative;
    top: 7px;
    left: 5px;
  }
</style>
