<template>
    <div class="container">
        <div class="card-decorate">
            <svg-icon v-if="productInfo.seckill_product_status === 0 && !editing" class="seckill-fail" icon-class="seckill_product_out"/>
            <el-card class="main-card" shadow="hover" :body-style='{padding:0}'>
                <div class="card-content">
                    <div style="padding-top: 20px;" v-if="!editing">
                        <div class="image-show">
                        <span class="image-preview-container">
                            <span v-for="picture in _pictures()" :key="_pictureKey(picture)">
                                <img class="image-preview" :src="picture" alt="暂无图片"/>
                            </span>
                        </span>
                        </div>
                        <div class="product-title">{{productInfo.name}}</div>
                        <div class="product-desc">{{productInfo.description}}</div>
                        <div class="price-container">
                            <div class="origin-price-container">
                                <span class="origin-price">会场价格: ¥{{productInfo.settlement_price}}</span>
                                <span class="origin-profit">佣金: ¥{{productInfo.akc_profit}}</span>
                            </div>
                            <div class="seckill-price-container">
                                <span class="current-price">秒杀价格: ¥{{productInfo.seckill_price}}</span>
                                <span class="seckill-profit">秒杀佣金: ¥{{productInfo.seckill_profit}} </span>
                            </div>
                        </div>
                        <div class="stock-container">
                            <div class="seckill-stock">秒杀库存: {{ productInfo.seckill_inventory }}</div>
                        </div>
                        <div class="stock-occupation">
                            <el-progress :percentage="productInfo.percentage_robbed" color="#f1394d"></el-progress>
                        </div>
                    </div>
                    <div v-else class="option-list">
                        <div class="option-close-container">
                            <el-button class="option-close" icon="el-icon-close" type="text" size="medium"
                                       @click="editing = false"/>
                        </div>
                        <div class="option">
                            <span class="option-key">禁用商品</span>
                            <el-switch
                                    v-model="forbid"
                                    active-color="#f1394d"
                                    inactive-color="#98c4f9"
                                    :active-text="forbid ? '已禁用' : '未禁用'"
                                    @change="_beforeDisableSeckillProduct"/>
                        </div>
                        <div class="option">
                            <span class="option-key">秒杀价</span>
                            <el-input class="option-input" v-model="editForm.seckill_price" placeholder="请输入秒杀价"
                                      size="mini" :disabled='true'/>
                        </div>
                        <div class="option">
                            <span class="option-key">秒杀佣金</span>
                            <el-input class="option-input" v-model="editForm.seckill_profit" placeholder="请输入秒杀佣金"
                                      size="mini" :disabled="true"/>
                        </div>
                        <div class="option">
                            <span class="option-key">秒杀库存</span>
                            <el-input class="option-input" v-model="editForm.seckill_inventory" placeholder="请输入秒杀库存"
                                      size="mini" :disabled="true"/>
                        </div>
                        <div class="option">
                            <span class="option-key">秒杀排序</span>
                            <el-input class="option-input" v-model="editForm.sort" placeholder="请输入秒杀排序" size="mini"/>
                        </div>
                    </div>
                    <div>
                        <el-button class="edit-button" :icon="editing ? 'el-icon-circle-check' : 'el-icon-edit'" type="text" :disabled="productInfo.seckill_product_status === 0"
                                   size="mini" @click="_onEditButtonClicked">{{ editing ? '确认' : '编辑' }}
                        </el-button>
                    </div>
                </div>
            </el-card>
        </div>
    </div>
</template>

<script>
  import { dateFtt } from '../../framework/utils/utils';

  export default {
    name: 'seckill-selected-product-card',
    props: {
      productInfo: {
        type: Object,
        default: {}
      },
      picked: {
        type: Boolean,
        default: false,
      },
    },
    data() {
      return {
        editing: false,
        forbid: false,
        editForm: {
          product_id: null,
          seckill_id: null,
          seckill_price: null,
          seckill_profit: null,
          seckill_inventory: null,
          sort: null,
          remark: null,
          product: null,
        },
      };
    },
    methods: {
      _pictureKey(picture) {
        return this.productInfo.picture.indexOf(picture);
      },

      _pictures() {
        if (!this.productInfo.picture) {
          return [];
        }

        const endIndex = Math.min(this.productInfo.picture.length - 1, 4);
        return this.productInfo.picture.slice(0, endIndex);
      },

      _onEditButtonClicked() {
        if (this.editing) {
          this.$emit('onEdit', this.editForm);
        } else {
          console.log(this.productInfo);
          this.editForm.product_id = this.productInfo.id;
          this.editForm.seckill_inventory = this.productInfo.seckill_inventory;
          this.editForm.seckill_price = this.productInfo.seckill_price;
          this.editForm.seckill_profit = this.productInfo.seckill_profit;
          this.editForm.sort = this.productInfo.seckill_product_sort;
          this.editForm.product = this.productInfo;
        }

        this.editing = !this.editing;
      },

      _formatDateForTimeStamp(timestamp) {
        const date = new Date(timestamp);
        return dateFtt('yyyy-MM-dd hh:mm:ss', date);
      },

      _beforeDisableSeckillProduct(value) {
        if (!value) {
          return;
        }

        this.$confirm('该操作将下架该秒商品，随后该商品将无法再编辑，是否继续？', '秒杀下架', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning' }).then(() => {
          this.editForm.status = this.forbid ? 0 : 1;
          this.$emit('onDelete', this.editForm);
          this.editing = false;
        }).catch(() => {
          this.forbid = false;
        });
      },
    },
  };
</script>

<style lang="scss" scoped>
    .container {
        font-family: "Microsoft YaHei", "微软雅黑", STXihei, "华文细黑", Georgia, "Times New Roman", Arial, sans-serif;
        margin: 15px;
        width: 280px;

        .card-decorate {
            position: relative;
            .seckill-fail {
                position: absolute;
                right: -13px;
                top: -13px;
                width: 45px;
                height: 45px;
            }

            .main-card {
                background-color: #FAFAFA;
                min-height: 261px;

                .option-close-main {
                    height: 30px;
                    min-width: 50px;
                    color: #f1394d;
                    font-weight: bold;
                }

                .card-content {
                    padding: 0 0 0 20px;

                    .image-show {
                        display: flex;
                        flex-direction: column;

                        .image-preview-container {
                            display: flex;
                            flex-direction: row;
                            height: 50px;
                            overflow: hidden;
                            margin-bottom: 5px;
                            margin-right: 20px;
                            margin-top: 5px;
                            background-color: #EEEEEE;
                            justify-content: space-around;

                            .image-preview {
                                width: 50px;
                                height: 50px;
                                object-fit: cover;
                            }
                        }
                    }

                    .product-title {
                        height: 22px;
                        margin-top: 10px;
                        margin-right: 20px;
                        word-wrap: break-word;
                        font: 14px bold;
                        overflow: hidden;
                    }

                    .product-desc {
                        height: 12px;
                        margin-top: 5px;
                        font-size: 12px;
                        font-weight: bold;
                        color: #999;
                        overflow: hidden;
                        margin-right: 20px;
                    }

                    .price-container {
                        margin: 10px 20px 0 0;
                        display: flex;
                        flex-direction: column;
                        justify-content: space-between;

                       .origin-price-container, .seckill-price-container {
                            display: flex;
                            flex-direction: row;
                            justify-content: space-between;
                            margin-bottom: 8px;

                            .current-price {
                                color: #f1394d;
                                font-size: 13px;
                                margin-right: 5px;
                            }

                            .origin-profit, .seckill-profit, .origin-price {
                                color: #555;
                                font-size: 13px;
                            }
                        }
                    }

                    .stock-container {
                        color: #555;
                        font-size: 13px;
                        margin-bottom: 10px;
                    }

                    .edit-button {
                        width: calc(100% - 20px);
                        font-size: 14px;
                        color: #f1394d;
                        margin: 5px 20px 10px 0;

                        &:hover {
                            background-color: #f1394d;
                            color: white;
                        }
                    }

                    .option-list {
                        .option-close-container {
                            position: relative;
                            height: 38px;

                            .option-close {
                                position: absolute;
                                right: 0;
                                bottom: 0;
                                color: #676767;
                                font-weight: bold;
                                min-width: 50px;
                            }
                        }

                        .option-title {
                            color: #999;
                            font-size: 14px;
                            margin-bottom: 10px;
                        }

                        .option {
                            display: flex;
                            flex-direction: row;
                            align-items: center;
                            color: #999;
                            margin-bottom: 10px;
                            font-size: 13px;
                            padding-right: 20px;

                            .option-key {
                                width: 80px;
                            }

                            .option-input {
                                max-width: 250px;
                            }
                        }
                    }
                }
            }
        }
    }

</style>