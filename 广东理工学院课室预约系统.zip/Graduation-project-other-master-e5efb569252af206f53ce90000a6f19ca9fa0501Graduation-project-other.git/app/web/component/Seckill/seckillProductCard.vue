<template>
    <div class="container">
        <el-card class="main-card" shadow="hover" :body-style='{padding:0}'>
            <div class="image-show">
                <span class="image-main-container">
                    <img class="image-main" :src="currentPic || productInfo.picture[0]" alt="暂无图片"/>
                    <span class="image-mask">
                        <i class="el-icon-zoom-in" @click.stop="_showPreview"></i>
                    </span>
                </span>
                <span class="image-preview-container">
                     <span v-for="picture in _pictures()" :key="_pictureKey(picture)">
                    <img class="image-preview" :src="picture" alt="暂无图片" @mouseover="changeMainPic(picture)"/>
                </span>
                </span>
            </div>
            <div class="product-title">{{productInfo.name}}</div>
            <div class="product-desc">{{productInfo.description}}</div>
            <div class="price-container">
                <div>
                    <span class="current-price">¥{{productInfo.settlement_price}}</span>
                    <span class="origin-price">¥{{productInfo.akc_tag_price}}</span>
                </div>
                <div class="add-price-container">
                    <span class="add-price">{{productInfo.akc_profit}}+(¥{{productInfo.add_price}})</span>
                </div>
            </div>
            <div class="profit-rate">
                佣金比 {{(productInfo.akc_profit / Math.max(1, productInfo.settlement_price)).toFixed(2) * 100}}%
            </div>
            <div class="sku-container">
                <div v-for="sku in productInfo.sku_list" :key="sku.skuId">
                    <div class="sku-container-line">
                        <span class="sku-name">{{ _skuDesc(sku)}}</span>
                        <span class="sku-stock">库存:  {{ sku.skuInventory}}</span>
                    </div>
                </div>
            </div>
            <div class="product-stock-container">
                <span class="product-stock">总库存: {{ productInfo.stock}}</span>
                <span class="product-stock">规格数： {{productInfo.sku_list.length}}</span>
            </div>
            <div class="time-label-container">
                <div class="time-label">活动开始: {{_formatDateForTimeStamp(productInfo.start_time * 1000)}}</div>
                <div class="time-label">活动结束: {{_formatDateForTimeStamp(productInfo.end_time * 1000)}}</div>
            </div>
            <div class="opt-container">
                <el-button class="edit-button" icon="el-icon-edit" type="text" size="mini" @click="_onEditButtonClicked">编辑</el-button>
                <el-button class="add-button" :icon="selected ? 'el-icon-star-on' : 'el-icon-star-off'" type="text" size="mini" @click="_selectButtonClicked">{{ selected ? '活动中' :  '选择' }}</el-button>
            </div>
        </el-card>
        <el-dialog :visible.sync="previewVisible" append-to-body>
            <img :src="currentPic" width="100%" alt=""/>
        </el-dialog>
    </div>
</template>

<script>
  import { dateFtt } from '../../framework/utils/utils';

  export default {
    name: 'seckill-product-card',
    props: {
      productInfo: {
        type: Object,
        default: {},
      },
      selected: {
        type: Boolean,
        default: false,
      },
    },
    data() {
      return {
        currentPic: this.productInfo.picture[0] || '',
        previewVisible: false,
      };
    },
    methods: {
      changeMainPic(pic) {
        this.currentPic = pic;
      },

      _pictureKey(picture) {
        return this.productInfo.picture.indexOf(picture);
      },

      _pictures() {
        if (!this.productInfo.picture) {
          return [];
        }

        const endIndex = Math.min(this.productInfo.picture.length - 1, 4);
        return this.productInfo.picture.slice(0, endIndex);
      },

      _showPreview() {
        this.previewVisible = true;
      },

      _skuDesc(sku) {
        let desc = '';

        const attrList = sku.attributeList;
        for (const index in attrList) {
          const attr = attrList[index];
          const value = attr.attributeValue;
          desc += ` ${value}`;
        }

        return desc;
      },

      _onEditButtonClicked() {
        this.$emit('onEdit', this.productInfo);
      },

      _selectButtonClicked() {
        this.$emit('onSelect', this.productInfo);
      },

      _formatDateForTimeStamp(timestamp) {
        const date = new Date(timestamp);
        return dateFtt('yyyy-MM-dd hh:mm:ss', date);
      },
    },
  };

</script>

<style lang="scss" scoped>
    .container {
        font-family: "Microsoft YaHei", "微软雅黑", STXihei, "华文细黑", Georgia, "Times New Roman", Arial, sans-serif;
        margin: 15px;
        width: 280px;

        .main-card {
            background-color: #FAFAFA;
            padding: 20px 0 0 20px;

            .image-show {
                display: flex;
                flex-direction: column;

                .image-preview-container {
                    display: flex;
                    flex-direction: row;
                    height: 50px;
                    overflow: hidden;
                    margin-bottom: 5px;
                    margin-right: 20px;
                    margin-top: 5px;
                    background-color: #EEEEEE;
                    justify-content: space-around;

                    .image-preview {
                        width: 50px;
                        height: 50px;
                        object-fit: cover;
                    }
                }

                .image-main-container {
                    position: relative;
                    margin-right: 20px;
                    display: flex;
                    justify-content: center;

                    .image-main {
                        margin-left: 10px;
                        width: 120px;
                        height: 120px;
                        object-fit: cover;
                    }

                    .image-mask {
                        position: absolute;
                        width: 100%;
                        height: 100%;
                        left: 0;
                        top: 0;
                        color: white;
                        opacity: 0;
                        font-size: 20px;
                        background-color: rgba(0, 0, 0, .5);
                        transition: opacity .3s;
                        display: flex;
                        align-items: center;
                        flex-direction: row;
                        justify-content: space-around;

                        &:hover {
                            opacity: 1;
                            transition: opacity .3s;
                        }
                    }
                }
            }

            .product-title {
                height: 22px;
                margin-top: 10px;
                margin-right: 20px;
                word-wrap: break-word;
                font: 14px bold;
                overflow: hidden;
            }

            .product-desc {
                height: 12px;
                margin-top: 5px;
                font-size: 12px;
                font-weight: bold;
                color: #999999;
                overflow: hidden;
                margin-right: 20px;
            }

            .price-container {
                margin-top: 8px;
                display: flex;
                flex-direction: row;
                justify-content: space-between;
                align-items: center;

                .current-price {
                    color: #f1394d;
                    font-size:  13px;
                    margin-right: 5px;
                }

                .origin-price {
                    color: #AAAAAA;
                    font-size: 13px;
                    text-decoration: line-through;
                    text-decoration-color: #AAAAAA;
                }

                .add-price-container {
                    height: 20px;
                    background-color: #f1394d;
                    color: white;
                    border-top-left-radius: 10px;
                    border-bottom-left-radius: 10px;
                    align-items: center;
                    display: flex;
                    font-size:  13px;
                    padding: 2.5px  5px 0 8px;
                    box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);

                    .add-price {
                        font-size: 13px;
                    }

                    .ack-price {
                        font-size: 13px;
                    }
                }
            }

            .sku-container {
                background-color: #F0F0F0;
                height: 40px;
                padding: 10px 5px;
                margin-right: 20px;
                margin-top: 7px;
                overflow: auto;
                border-radius: 5px;

                .sku-container-line {
                    display: flex;
                    flex-direction: row;
                    justify-content: space-between;
                    font-size: 13px;
                    margin-bottom: 3px;
                }
            }

            .profit-rate {
                margin-top: 5px;
                font-size: 13px;
                color: #999;
            }

            .product-stock-container {
                display: flex;
                flex-direction: row;
                justify-content: space-between;
                align-items: center;
                margin-right: 20px;

                .product-stock {
                    margin-top: 8px;
                    font-size: 13px;
                    font-weight: bold;
                    color: #f1394d;
                }
            }


            .opt-container {
                display: flex;
                flex-direction: row;
                justify-content: space-between;

                .edit-button, .add-button {
                    width: calc(100% - 20px);
                    font-size: 14px;
                    color: #f1394d;
                    margin: 0 20px 10px 0;

                    &:hover {
                        background-color:  #f1394d;
                        color: white;
                    }
                }
            }

            .time-label-container {
                margin: 5px 20px 0 0;
                padding: 5px 0;
                border-top: dashed #eee 2px;

                .time-label {
                    font-size: 13px;
                    margin-bottom: 3px;
                    color: #999;
                }
            }
        }
    }

</style>