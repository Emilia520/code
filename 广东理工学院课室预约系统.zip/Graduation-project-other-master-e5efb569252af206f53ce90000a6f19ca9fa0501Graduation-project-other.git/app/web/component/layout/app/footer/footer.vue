<template>
  <footer class="footer">
    <div class="container">
      <div class="footer-main"><p class="footer-main-title">基于egg + vue2 + webpack2 工程示例</p></div>
      <div class="footer-social"><span><div class="el-popover footer-popover" style="width: 120px; display: none;">
        <div class="footer-popover-title"></div>
      </div></span></div>
    </div>
  </footer>
</template>
<style>
  @import "./footer.css";
</style>
<script type="text/babel">
  export default{}
</script>
