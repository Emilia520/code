<template>
    <div class="preview-card-container" :class="{'is-active' : typeof source === 'string'}">
        <el-upload
                class="avatar-uploader"
                :action="action"
                :on-success="_uploadSuccess"
                :before-upload="_beforeUpload"
                :show-file-list="false"
                :list-type="typeof source === 'string' && source.length !== 0 ? '' : 'picture-card'">
            <img v-if="source" :src="source" class="avatar" :width="width" :height="height" alt="">
            <i v-else class="el-icon-plus"></i>
            <div v-if="source" class="image-mask">
                <span class="show-preview">
                      <i class="el-icon-zoom-in" @click.stop="_showPreview"></i>
                </span>
                <span class="start-edit">
                    <i class="el-icon-edit" slot="trigger"></i>
                </span>
            </div>
        </el-upload>
        <el-dialog :visible.sync="previewVisible">
            <img :src="source" width="100%" alt=""/>
        </el-dialog>
    </div>
</template>

<script>
  import { uploadImg } from '@/api/uploadImg';

  export default {
    name: 'image-preview-card',
    data() {
      return {
        previewVisible: false,
      };
    },

    props: {
      source: {
        type: String,
        default: null
      },
      beforeUpload: {
        type: Function,
        default: null
      },
      uploadSuccess: {
        type: Function,
        default: null
      },
      action: {
        type: String,
        default: uploadImg
      },
      index: {
        type: Number,
        default: 0,
      },
      width: {
        type: String,
        default: '148px',
      },
      height: {
        type: String,
        default: '148px',
      }
    },

    methods: {
      _showPreview() {
        this.previewVisible = true;
      },

      _uploadSuccess(file) {
        if (this.uploadSuccess == null) {
          return;
        }

        this.uploadSuccess(file, this.index);
      },

      _beforeUpload(file) {
        if (this.beforeUpload == null) {
          return true;
        }

        return this.beforeUpload(file, this.index);
      }
    }
  };
</script>

<style lang="scss" scoped>

    .preview-card-container.is-active {
        border: none;
        position: relative;

        .image-mask {
            position: absolute;
            width: 100%;
            height: 100%;
            left: 0;
            top: 0;
            color: white;
            opacity: 0;
            font-size: 20px;
            background-color: rgba(0, 0, 0, .5);
            transition: opacity .3s;
            display: flex;
            align-items: center;
            flex-direction: row;
            justify-content: space-around;

            &:hover {
                opacity: 1;
                transition: opacity .3s;
            }
        }
    }

</style>