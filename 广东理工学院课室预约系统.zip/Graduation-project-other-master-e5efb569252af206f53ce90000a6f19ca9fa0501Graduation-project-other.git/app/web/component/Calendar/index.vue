<template>
    <div class="filter-container">
        <table class="calendar-table" width="100%" border="1">
            <tr>
                <th class='calendar-week-unit' v-for="weakDay in ['周日', '周一', '周二', '周三', '周四', '周五', '周六']">{{weakDay}}</th>
            </tr>
            <tr v-for="week in monthDays">
                <th v-for="day in week">
                    <slot name="calendarUnit" :timeStamp="day"></slot>
                </th>
            </tr>
        </table>
    </div>
</template>

<script>
  const assert = require('assert');

  export default {
    name: 'CalendarGrid',
    data: () => ({
      monthDays: [], // 当月日期的时间戳
      year: 0, // 当前表格关联的年份
      month: 0, // 当前表格关联的月份
    }),

    created() {
      this.calCurTimestamps();
    },

    props: {
      date: {
        type: Date,
        default: null,
      }
    },

    methods: {
      /**
       * 返回指定月份每天的Date实例队列
       */
      daysInMonth(year, month) {
        if (isNaN(year) || isNaN(month)) {
          return null;
        }

        const dayCount = new Date(year, month, 0).getDate();
        const days = [];

        for (let day = 1; day < dayCount; ++day) {
          days.push(new Date(year, month, day));
        }

        return days;
      },

      /**
       * 返回当月天数的按周划分的队列，每7天为一列，一个当月周数行，不存在的
       * 日期用null表示，结果最终格式如下示例
       * [null, null, null, null, 1, 2, 3],
       * [4, 5, 6, 7, 8, 9, 10],
       * ...,
       * [28, 29, 30, 31, null, null, null]
       *
       * @param days [Date(), ...] 当月每天的Date实例，精确到天，时间都在0点
       * @returns {*}  开头包含null，后续是时间戳的队列
       */
      timestampArr(days) {
        if (!Array.isArray(days) || days.length === 0) {
          return null;
        }

        const weekDay = days[0].getDay();
        assert(weekDay >= 0 && weekDay <= 6);

        const timeStamps = [];

        // 让第一天前的星期填空白数据
        for (let index = 0; index < weekDay; ++index) {
          timeStamps.push(null);
        }

        days.forEach(day => timeStamps.push(day.getTime() / 1000));

        const weekCount = Math.ceil(days.length / 7);
        const result = [];

        for (let weekIndex = 0; weekIndex < weekCount; ++weekIndex) {
          const aWeek = [];

          for (let index = 0; index < 7; ++index) {
            if (weekIndex * 7 + index < timeStamps.length) {
              aWeek.push(timeStamps[weekIndex * 7 + index]);
            } else {
              // 末尾也保存null
              aWeek.push(null);
            }
          }

          result.push(aWeek);
        }

        return result;
      },

      /**
       * 根据this.date获取对应月份的timestamp列表
       */
      calCurTimestamps() {
        let date = this.date;

        if (this.date == null) {
          date = new Date();
        }

        const year = date.getFullYear();
        const month = date.getMonth();

        this.monthDays = this.timestampArr(this.daysInMonth(year, month));
      }
    },
  };
</script>

<style lang="scss" scoped>

    .filter-container {
        overflow: scroll;
        font-family: "Microsoft YaHei", "微软雅黑", STXihei, "华文细黑", Georgia, "Times New Roman", Arial, sans-serif;

        .calendar-table {
            border: 1px solid #ebebeb;
            border-collapse: collapse;

            .calendar-week-unit {
                padding-top: 5px;
                height: 40px;
                text-align: center;
                border-top: none;
                color: white;
                background-color: #409EFF;
            }
        }
    }

</style>