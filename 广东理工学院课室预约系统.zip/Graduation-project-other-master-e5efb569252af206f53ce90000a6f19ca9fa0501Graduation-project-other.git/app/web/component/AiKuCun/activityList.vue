<template>
  <div>
    <el-row>
      <!-- <el-col :span="24">
        <div class="header-title">活动列表</div>
      </el-col> -->
      <!-- 筛选条件 start -->
      <el-col :span="24">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
          <el-form-item>
            <el-checkbox :checked="offSale" @change="setOffSale">下架</el-checkbox>
          </el-form-item>
          <el-form-item>
            <el-checkbox :checked="onSale" @change="setOnSale">上架</el-checkbox>
          </el-form-item>
            <el-form-item>
                <el-checkbox v-model="formInline.comingUp" @change="getList">预告</el-checkbox>
            </el-form-item>
        <el-form-item>
            <el-button type="'text" size="small" @click="updateMiniProgramVisibility()">{{mnpVisible ? "一键隐藏小程序展示" :  "一键开启小程序展示" }}  </el-button>
        </el-form-item>
        <el-form-item>
            <el-button type="button" size="small" style="position:relative;left:934px" @click="excelList(formInline)">一键导出商品信息</el-button>
        </el-form-item>
        </el-form>
      </el-col>
      <!-- 筛选条件 end -->
      <!-- 活动分类 start -->
      <el-col :span="24">
        <el-tabs @tab-click="onOptClick" style="height: 50px;">
            <el-tab-pane v-for="opt in optList" :key="opt.id" :label="opt.tag_name"></el-tab-pane>
        </el-tabs>
      </el-col>
      <!-- 活动分类 end -->
      <!-- 表格 start -->
      <el-col :span="24">
        <div class="card_wrapper">
            <el-card :body-style="{ padding: '0px'}" v-for="activity in tableData" :key="activity.id" class="activity_card" shadow="hover" >
              <!-- <a :href="`/shoppingTuan/activityDetail/${activity.id}`" style="cursor:pointer"> -->
              <div style="cursor:pointer" @click="$router.push({name: 'activityDetail',params: {id: activity.id, appType: appType}})" :style="{background: activity.type === 2 ? '#e5e5e5' : activity.type === 1 ? '#f5f5f5' : 'white'}">             
                <div class="logo_wrapper" :style="{background: activity.type === 2 ? '#e5e5e5' : activity.type === 1 ? '#f5f5f5' : 'white'}">
                    <div style="display:block;" :style="{background: activity.type === 2 ? '#e5e5e5' : activity.type === 1 ? '#f5f5f5' : 'white'}">
                        <img class="brand_logo" :src="activity.brand_logo_url">
                        <div style="font-size:8px;text-align:center;"><b>{{activity.brand}}</b></div>
                    </div>
                </div>
                <div class="content_wrapper" :style="{background: activity.type === 2 ? '#e5e5e5' : activity.type === 1 ? '#f5f5f5' : 'white'}">
                    <div style="font-size:14px; margin-bottom: 10px; overflow: hidden;"><nobr><b>{{activity.name}}</b></nobr></div>
                    <div class="content">活动ID：{{activity.id}}</div>
                    <div class="content">所属分类：{{activity.tag_name}}</div>
                    <div class="content">共 <b>{{activity.goods_num}}</b> 个商品</div>
                    <div class="content"><span style="color:#D1463A;font-size:12px;"><b>{{activity.min_discount / 10}} </b></span>折起</div>
                    <div class="content">开始时间：{{activity.start_date}}</div>
                    <div class="content">结束时间：{{activity.end_date}}</div>
                </div>
                 
                <div class="brand_type_wrapper" :style="{background: activity.type === 2 ? '#e5e5e5' : activity.type === 1 ? '#f5f5f5' : 'white'}">
                  <div class="content">{{activity.type_name}}</div>  
                </div>
                <div class="goods_thumbnail_wrapper" :style="{background: activity.type === 2 ? '#e5e5e5' : activity.type === 1 ? '#f5f5f5' : 'white'}">
                    <div v-for="(img,index) in bannersForActivity(activity)" :key="index" class="goods_thumbnail">
                        <img style="width:100%;" :src="img">
                    </div>
                </div>
                <div class="edit_area" :style="{background: activity.type === 2 ? '#e5e5e5' : activity.type === 1 ? '#f5f5f5' : 'white'}">
                    <el-button class="sel_button" v-if="activity.status === 0 || activity.status === -2" @click.stop="putOnSale(activity)" :style="{background: activity.type === 2 ? '#e5e5e5' : activity.type === 1 ? '#f5f5f5' : 'white'}">
                        <svg-icon icon-class="putOn" />
                        <span style="color:#1296db;">上 架</span>
                    </el-button>
                    <el-button class="sel_button" v-else @click.stop="pullOffSale(activity)" :style="{background: activity.type === 2 ? '#e5e5e5' : activity.type === 1 ? '#f5f5f5' : 'white'}">
                        <svg-icon icon-class="pullOff" />
                        <span>下 架</span>
                    </el-button>
                    <el-button class="sel_button" @click.stop="stick(activity)" :style="{background: activity.type === 2 ? '#e5e5e5' : activity.type === 1 ? '#f5f5f5' : 'white'}">
                        <svg-icon icon-class="stick" />
                        <span style="color:#1296db;">置 顶</span>
                    </el-button>
                    <el-button class="sel_button" @click.stop="edit(activity)" :style="{background: activity.type === 2 ? '#e5e5e5' : activity.type === 1 ? '#f5f5f5' : 'white'}">
                        <span style="color:#1296db;">编辑</span>
                        <span v-if="curCatIndex === 0" style="color:#1296db;">({{activity.sort}})</span>
                        <span v-else style="color:#1296db;">({{activity.cat_sort}})</span>
                    </el-button>
                    <el-button v-if="$store.getters.role < 3" class="sel_button" style="flex:1;" @click.stop="addPrice(activity)" :style="{background: activity.type === 2 ? '#e5e5e5' : activity.type === 1 ? '#f5f5f5' : 'white'}">
                        <span style="color:hotpink;">加价</span>
                    </el-button>
                    <el-button class="sel_button" style="flex:1;" @click.stop="editTag(activity)" :style="{background: activity.type === 2 ? '#e5e5e5' : activity.type === 1 ? '#f5f5f5' : 'white'}">
                        <span style="color:hotpink;">标签</span>
                    </el-button>
                    <el-button size="small" type="text" plain @click.stop="updateMiniProgramVisibility(activity)">{{activity.miniProgramVisible ? "小程序不可见": "小程序可见"}} </el-button>
                </div>
                  <div class="select-button" v-if="_allowSelectButton()">
                      <el-button class="add-button"
                                 :icon="hasSelectActivity(activity) ? 'el-icon-star-on' : 'el-icon-star-off'"
                                 type="text"
                                 size="mini"
                                 @click.stop="_selectButtonClicked(activity)">{{ hasSelectActivity(activity) ? '已选中' :  '选择' }}
                      </el-button>
                  </div>
              </div>
             
              <!-- </a> -->
            </el-card>
        </div>
      </el-col>
      <!-- 表格 end -->
      <!-- 分页 start -->
      <el-col :span="24">
        <div class="pagination" style="margin-top:20px;">
          <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="formInline.page" :page-sizes="[40, 80, 120, 160]" :page-size="formInline.pageSize" layout="total, sizes, prev, pager, next" :total="totalCount">
          </el-pagination>
        </div>
      </el-col>
      <!-- 分页 end -->
      <!-- 弹层 start -->
      <el-col :span="24">
        <el-dialog title="活动加价" :visible.sync="addPriceDialogFormVisible" width="300" @close="cancelAddPriceForm" append-to-body>
          <el-form :model="addPriceForm" :rules="addPriceRules" ref="addPriceForm">
            <el-form-item label="ID" label-width="120px" prop="id">
              <el-input :disabled="true" v-model="addPriceForm.id" placeholder="ID" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="活动名称" label-width="120px" prop="name">
              <el-input :disabled="true" v-model="addPriceForm.name" placeholder="活动名称" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="加价">
              <el-radio-group v-model="chooseAddRatio"  @change="chooseAddType"  >
                <el-radio :label="0" >
                  加价比例：<el-input v-model="addPriceForm.ratio" :disabled="chooseAddRatioHidden" />
                </el-radio>
                <br>
                <el-radio :label="1">
                  加价金额：<el-input v-model="addPriceForm.addPrice" :disabled="!chooseAddRatioHidden"  />
                </el-radio>
              </el-radio-group>
            </el-form-item>
         
            <el-form-item label="佣金比例(%)" label-width="120px">
              <el-radio-group v-model="chooseCommission"  @change="chooseCommissionType" >
                <el-radio :label="0" >
                  佣金比例(%)：<el-input v-model.number="addPriceForm.commissionRatio" :disabled="chooseCommissionHidden" />
                </el-radio>
                <br>
                <el-radio :label="1" >
                  <span style="color:red;"> 恢复默认佣金 </span>
                </el-radio>
              </el-radio-group>              
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="cancelAddPriceForm('addPriceForm')">取 消</el-button>
            <el-button type="primary" @click="confirmAddPriceForm('addPriceForm')">确 定</el-button>
          </div>
        </el-dialog>
      </el-col>
      <el-col :span="24">
        <el-dialog title="活动标签" :visible.sync="tagDialogFormVisible" width="300" @close="cancelTagForm" append-to-body>
          <el-form :model="tagForm" ref="tagForm">
            <el-form-item label="ID" label-width="120px" prop="id">
              <el-input :disabled="true" v-model="tagForm.id" placeholder="ID" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="活动名称" label-width="120px" prop="name">
              <el-input :disabled="true" v-model="tagForm.name" placeholder="活动名称" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="标签" label-width="120px" prop="tag">
              <el-select v-model="tagForm.tag">
                <el-option
                        v-for="item in labels"
                        :key="item.id"
                        :label="item.label"
                        :value="item.id">
                </el-option>
              </el-select>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="cancelTagForm('tagForm')">取 消</el-button>
            <el-button type="primary" @click="confirmTagForm('tagForm')">确 定</el-button>
          </div>
        </el-dialog>
      </el-col>
      <!-- 弹层 end -->
    </el-row>
      <el-dialog :title="dialogFormTitle" :visible.sync="dialogFormVisible" width="300" @close="cancelForm" append-to-body>
          <el-form :model="addForm" :rules="rules" ref="addForm">
              <el-form-item label="活动ID" :label-width="formLabelWidth" prop="id">
                  <el-input :disabled="true" v-model="addForm.id" placeholder="ID" size="mini" clearable></el-input>
              </el-form-item>
               <el-form-item label="品牌ID" :label-width="formLabelWidth" prop="ownBrandId">
                  <el-input :disabled="true" v-model="addForm.ownBrandId" size="mini" clearable></el-input>
              </el-form-item>
              <el-form-item label="品牌名" :label-width="formLabelWidth" prop="ownBrandName">
                  <el-input :disabled="true" v-model="addForm.ownBrandName" size="mini" clearable></el-input>
              </el-form-item>
              <el-form-item label="活动名称" :label-width="formLabelWidth" prop="name">
                  <el-input v-model="addForm.name" placeholder="活动名称" size="mini" clearable></el-input>
              </el-form-item>
              <el-form-item label="权重" :label-width="formLabelWidth" prop="sort">
                  <el-input v-model.number="addForm.sort" placeholder="权重" size="mini" clearable></el-input>
              </el-form-item>
              <el-form-item label="所属分类" :label-width="formLabelWidth" prop="tag_name" v-if="showLastBuy">
                    <el-select v-model="addForm.cat_id" clearable placeholder="请选择">
                      <el-option
                        v-for="item in options"
                        :key="item.id"
                        :label="item.tag_name"
                        :value="item.id">
                      </el-option>
                    </el-select>
              </el-form-item>
              <el-form-item label="活动说明" :label-width="formLabelWidth" prop="description">
                  <el-input
                    type="textarea"
                    maxlength="200"
                    placeholder="请输入内容"
                    show-word-limit
                    v-model="addForm.description">
                  </el-input>
              </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
              <el-button @click="cancelForm('addForm')">取 消</el-button>
              <el-button type="primary" @click="confirmForm('addForm')">确 定</el-button>
          </div>
      </el-dialog>
  </div>
</template>

<script>
import { getCatList, getActivityList, stickActivity, updateSaleState, updateActivitySort, updateActivityAddPriceRatio, updateMiniProgramVisibility, updateTag, getMiniProgramGroupVisibility } from '@/api/groupbuy';

import ImagePreviewCard from '@/component/ImagePreview';
import { uploadImgNew } from '@/api/uploadImg';

export default {
  components: { ImagePreviewCard },
  name: 'akc-act-list',
  props: {
    appType: {
      type: Number,
      default: 0
    },
    onSelectActivity: {
      type: Function,
      default: null,
    },
    hasSelectActivity: {
      type: Function,
      default: null,
    }
  },
  data() {
    return {
      // 0: 默认100%， 1:恢复最低佣金
      chooseCommission: 0,
      chooseCommissionHidden: false,
      // 0按比例， 1按金额
      chooseAddRatio: 0,
      chooseAddRatioHidden: false,
      curCatIndex: 0,
      totalCount: 0,
      loading: false,
      offSale: true,
      onSale: true,
      mnpVisible: true,
      showLastBuy: true, // 最后疯抢所属分类
      formInline: {
        status: '',
        catId: 1,
        page: 1,
        pageSize: 40,
        type: 1,
        appType: 2,
        comingUp: false,
      },
      dialogFormVisible: false,
      addPriceDialogFormVisible: false,
      tagDialogFormVisible: false,
      dialogFormTitle: '',
      addForm: {
        id: 0,
        act: null,
        name: '',
        sort: 0,
        type: 1,
        appType: 2,
        hdImage: null,
        description: null,
        cat_id: null
      },
      addPriceForm: {
        id: 0,
        act: null,
        name: '',
        ratio: '',
        addPrice: 0,
        commissionRatio: 0
      },
      tagForm: {
        act: null,
        id: 0,
        name: '',
        tag: '',
      },
      rules: {
        sort: [{ required: true, message: '请输入权重', trigger: 'blur' },
          { type: 'number', min: 0, max: 9999999999, message: '权重为数字值，且范围为0～9999999999' }]
      },
      addPriceRules: {
        ratio: [{ required: true, message: '请输入加价比率，不得低于3%', trigger: 'blur' },
          { type: 'number', min: 3, max: 1000, message: '权重为数字值，且范围为3～1000' }],
        addPrice: [{ required: true, message: '输入加价金额', trigger: 'blur' },
          { type: 'number', min: 0, message: '权重为数字值，且范围为0～?' }
        ],
        commissionRatio: [{ required: true, message: '请输入佣金加价比率，默认为0', trigger: 'blur' }]
      },
      tableData: [],
      optList: [],
      options: [], // 编辑弹窗所属分类
      // 1- “爆款” 2- “新品” 3- “精选” 4- “大牌” 7- “秒杀”
      labels: [{ id: 0, label: '无' }, { id: 1, label: '爆款' }, { id: 2, label: '新品' }, { id: 3, label: '精选' }, { id: 4, label: '大牌' }, { id: 7, label: '秒杀' }],
      formLabelWidth: '120px',
      uploadImageAction: null, // 上传图片接口
    };
  },
  created() {
    // 筛选页面初始化
    this.uploadImageAction = uploadImgNew;
    this.formInline.page = 1;
    this.formInline.pageSize = 40;
    this.formInline.appType = this.appType;
    this.addForm.appType = this.appType;
    this.getData();
    this.getWXProgramGroupVisibility();
  },

  methods: {
    // 查询导出数据
    excelList() {
      const params = this.formInline;
      const query = Object.keys(params).map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`).join('&');
      console.log(query);
      window.location.href = `/api/groupbuy/putOutList?${query}`;
    },
    onSubmit() {
      this.getList();
    },
    chooseCommissionType(value) {
      this.chooseCommissionHidden = value === 1;
    },

    chooseAddType(value) {
      this.chooseAddRatioHidden = value === 1;
    },
    getData() {
      this.loading = true;
      Promise.all([getCatList({ appType: this.appType }), getActivityList(this.formInline)]).then(results => {
        // 解析分类列表
        let res = results[0].data;
        if (res.code === 10000) {
          this.optList = res.data;
          this.optList.push({ id: 10000, qxb_sort: 1000, tag_name: '待分类活动' });

          let arr = [];
          arr = res.data;
          for (const i in arr) {
            if (arr[i].id !== 1 && arr[i].id !== 10000) {
              this.options.push(arr[i]);
            }
          }
        }
        // 解析活动列表
        res = results[1].data;
        if (res.code === 10000) {
          this.totalCount = res.totalCount;
          this.tableData = res.data;
        }

        this.loading = false;
      });
    },
    getList() {
      this.loading = true;
      // 请求列表
      this.formInline.type = this.curCatIndex === 0 ? 1 : 2;
      getActivityList(this.formInline).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.totalCount = res.totalCount;
          this.tableData = res.data;
        }
        this.loading = false;
      });
    },
    getWXProgramGroupVisibility() {
      getMiniProgramGroupVisibility().then(response => {
        const visibleCount = response.data.data;
        this.mnpVisible = (visibleCount !== 0);
      });
    },
    onOptClick(val) {
      this.curCatIndex = parseInt(val.index);
      this.formInline.catId = this.optList[this.curCatIndex].id;
      this.formInline.page = 1;
      this.getList();
      this.showLastBuy = true;
    },
    // 分页
    handleSizeChange(pageSize) {
      this.formInline.pageSize = pageSize;
      this.getList();
    },
    // 页码变化时触发
    handleCurrentChange(page) {
      this.formInline.page = page;
      this.getList();
    },
    putOnSale(activity) {
      this.updateSaleStatus(activity.id, 1);
    },
    pullOffSale(activity) {
      this.updateSaleStatus(activity.id, 0);
    },
    stick(activity) {
      this.loading = true;
      const type = this.curCatIndex === 0 ? 1 : 2;
      stickActivity({ id: activity.id, type, appType: this.appType }).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.$message({
            message: '置顶成功',
            type: 'success'
          });
          this.getList();
        } else {
          this.loading = true;
        }
      });
    },
    edit(activity) {
      this.dialogFormTitle = '活动编辑';
      this.showLastBuy = true;
      this.addForm.id = activity.id;
      this.addForm.name = activity.name;
      this.addForm.ownBrandId = activity.ownBrandId;
      this.addForm.ownBrandName = activity.ownBrandName;
      this.addForm.description = activity.description;
      this.addForm.sort = this.curCatIndex === 0 ? activity.sort : activity.cat_sort;
      this.addForm.act = activity;
      this.addForm.hdImage = activity.selected_nice_img;
      if (this.formInline.catId !== 1) {
        this.addForm.cat_id = activity.tag_id;
      }
      this.dialogFormVisible = true;
      if (this.formInline.catId === 1) {
        this.showLastBuy = false;
      }
      if (this.formInline.catId === 10000) {
        this.addForm.cat_id = undefined;
      }
    },
    addPrice(activity) {
      this.addPriceForm.id = activity.id;
      this.addPriceForm.name = activity.name;
      this.addPriceForm.act = activity;
      this.addPriceForm.addPrice = 0;
      this.addPriceForm.ratio = activity.price_ratio ? parseInt(activity.price_ratio / 10) : 3;
      this.addPriceForm.commissionRatio = activity.commission_ratio ? parseInt(activity.commission_ratio / 10) : 100;
      this.addPriceDialogFormVisible = true;
      this.chooseAddRatio = 0;
      this.chooseAddRatioHidden = false;
    },
    editTag(activity) {
      this.tagForm.act = activity;
      this.tagForm.id = activity.id;
      this.tagForm.name = activity.name;
      this.tagForm.tag = activity.label || 0;
      this.tagDialogFormVisible = true;
    },
    updateMiniProgramVisibility(activity) {
      const params = {};

      if (typeof activity === 'undefined') {
        params.visible = this.mnpVisible ? 0 : 1;
        this.mnpVisible = !this.mnpVisible;
      } else {
        params.id = activity.id;
        params.visible = activity.miniProgramVisible === 1 ? 0 : 1;
      }

      this.loading = true;

      updateMiniProgramVisibility(params).then(response => {
        this.loading = false;

        const res = response.data;
        if (res.code === 10000) {
          this.$message({
            message: '更新成功',
            type: 'success'
          });

          this.getList();
        } else {
          this.$message({
            message: '更新失败',
            type: 'fail'
          });
        }
      });
    },
    confirmForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.loading = true;
          const type = this.curCatIndex === 0 ? 1 : 2;
          const sort = this.addForm.sort;
          const name = this.addForm.name;
          const cat_id = this.addForm.cat_id;
          const activity = this.addForm.act;
          const hdImage = this.addForm.hdImage;
          const description = this.addForm.description;
          updateActivitySort({ id: this.addForm.id, name, sort, type, hdImage, appType: this.appTypem, description, cat_id }).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.$message({
                message: '操作成功',
                type: 'success'
              });
              const sortField = type === 1 ? 'sort' : 'cat_sort';
              activity[sortField] = sort;
              activity.name = name;
              activity.selected_nice_img = hdImage;
              activity.description = description;
              this.dialogFormVisible = false;
              this.getList();
            } else {
              this.$message({
                message: '操作失败',
                type: 'fail'
              });
            }
            this.loading = false;
          });
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    cancelForm(formName) {
      // this.$refs[formName].resetFields();
      this.dialogFormVisible = false;
    },
    confirmAddPriceForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.loading = true;
          // 加价比例
          const ratio = this.addPriceForm.ratio;
          const commissionRatio = this.addPriceForm.commissionRatio;
          // 加价金额
          const addPrice = this.addPriceForm.addPrice;
          // 选择加价比例/金额
          const choose = this.chooseAddRatio;
          // 选择增加佣金比例/恢复最低佣金
          const chooseCommission = this.chooseCommission;
          const activity = this.addPriceForm.act;
          updateActivityAddPriceRatio({ id: this.addPriceForm.id, ratio, commissionRatio, addPrice, choose, chooseCommission }).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.$message({
                message: '操作成功',
                type: 'success'
              });
              this.addPriceDialogFormVisible = false;
              activity.price_ratio = ratio * 10;
              activity.commission_ratio = commissionRatio * 10;
            } else {
              this.$message({
                message: '操作失败',
                type: 'fail'
              });
            }
            this.loading = false;
          });
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    cancelAddPriceForm(formName) {
      this.addPriceDialogFormVisible = false;
    },
    confirmTagForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.loading = true;
          const label = this.tagForm.tag;
          updateTag({ id: this.tagForm.id, label, type: 0 }).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.$message({
                message: '操作成功',
                type: 'success'
              });
              this.tagDialogFormVisible = false;
              this.tagForm.act.label = label;
            } else {
              this.$message({
                message: '操作失败',
                type: 'fail'
              });
            }
            this.loading = false;
          });
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    cancelTagForm(formName) {
      this.tagDialogFormVisible = false;
    },
    setOffSale(val) {
      this.offSale = val;
      this.updateStatusInForm();
      this.getList();
    },
    setOnSale(val) {
      this.onSale = val;
      this.updateStatusInForm();
      this.getList();
    },
    updateStatusInForm() {
      if (this.onSale && this.offSale) {
        // 如果上下架状态都要查询，则条件传空，服务器会直接不判断这个条件
        this.formInline.status = '';
      } else if (this.onSale && !this.offSale) {
        this.formInline.status = 1;
      } else if (!this.onSale && this.offSale) {
        this.formInline.status = 0;
      } else if (!this.onSale && !this.offSale) {
        // 如果上下架状态都不选，则服务器会根据这个码直接返回空数据，因为不可能存在这种状态的值
        this.formInline.status = 9999;
      }
    },
    updateSaleStatus(id, status) {
      this.loading = true;
      updateSaleState({ id, status, appType: this.appType }).then(response => {
        const res = response.data;
        this.loading = false;

        if (res.code === 10000) {
          this.$message({
            message: '操作成功',
            type: 'success'
          });
          this.getList();
        }
      });
    },
    bannersForActivity(activity) {
      if (typeof activity === 'undefined') {
        return [];
      }

      if (!activity.hasOwnProperty('banner') || typeof activity.banner !== 'string') {
        return [];
      }

      return JSON.parse(activity.banner).slice(0, 3);
    },
    _uploadImageSuccess(response, index) {
      this.addForm.hdImage = response.data;
    },
    _allowSelectButton() {
      return this.onSelectActivity !== null && this.hasSelectActivity !== null;
    },
    _selectButtonClicked(activity) {
      this.onSelectActivity(activity);
    },
  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .card_wrapper {
    width: 100%;
    display: -webkit-flex;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;

      .activity_card {
        width: 320px;
        margin: 15px;

        .logo_wrapper {
            width: 80px;
            height: 100px;
            float: left;
            display: flex;
            padding: 5px;
            align-items: center;

            .brand_logo {
                width: 100%;
            }
        }

        .content_wrapper {
            width: 240px;
            margin-left: 80px;
            padding: 10px;

            .content {
                font-size: 10px;
                margin-bottom: 5px;
                font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            }
        }

        .brand_type_wrapper {
          position: relative;
          left: 270px;
          top: 159px;
          color: red;
        }

        .goods_thumbnail_wrapper {
            width: 100%;
            height: 100px;
            display: flex;
            flex-direction: row;
            background-color: #FAFAFA;
            overflow: hidden;

            .goods_thumbnail {
                margin: 10px 13px;
                width: 80px;
                height: 80px;
            }
        }

          .edit_area {
              width: 100%;
              padding: 5px;
              display: block;

              .sel_button {
                  flex: 3;
                  height: 30px;
                  font-size: 14px;
                  padding: 5px;
                  text-align: center;
                  border: 1px gray;
              }
          }

          .add-button {
              width: calc(100% - 40px);
              font-size: 14px;
              color: #f1394d;
              margin: 0 20px 10px 20px;

              &:hover {
                  background-color:  #f1394d;
                  color: white;
              }
          }
      }
  }

  .image-preview-container {
      display: flex;
      flex-direction: row;
      justify-content: center;
  }
</style>
