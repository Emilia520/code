<template>
    <div class="goods_wrapper">
        <el-card class="goods_card" :body-style="{ padding: '0px' }">
            <div class="wrapper">
                <div class="picture">
                    <div style="width: 185px; height: 180px;">
                        <img class="big-picture" :src="goods.pictures[0]" alt="暂无图片">
                    </div>
                    <div class="small-picture">
                        <div>
                            <img :src="goods.pictures[1]" alt="暂无图片">
                        </div>
                        <div>
                            <img :src="goods.pictures[2]" alt="暂无图片">
                        </div>
                        <div>
                            <img :src="goods.pictures[3]" alt="暂无图片">
                        </div>
                    </div>
                </div>
                <div class="content">
                    <h1>{{goods.name}}</h1>
                    <p>
                        <span>{{goods.description}}</span>
                    </p>
                    <div class="price">
                        <div>
                            <span style="font-size:20px;">¥{{goods.settlement_price}}</span>
                            <span class="line-through">¥{{goods.akc_tag_price}}</span>
                        </div>
                        <span style="font-size:14px;">代购费:{{goods.akc_profit}} (+¥{{goods.add_price}})</span>
                    </div>
                    <div class="sku">
                        <div class="sku-box">
                            <ul>
                                <li v-for="sku in goods.skuList" :key="sku.skuId">
                                    <span>{{sku}}</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="button" @click.prevent="onTap()">
                        {{btnTitle}}
                    </div>
                </div>
            </div>
        </el-card>
    </div>
</template>

<script>
  import { getGoodsList } from '@/api/groupbuy';
//   import RangeSelector from '@/component/RangeSelector';

  export default {
    name: 'akc-goods-item',
    props: {
      btnTitle: {
        type: String,
        default: '添加'
      },
      goods: {
        type: Object
      }
    },
    data: () => {
      return {

      };
    },
    methods: {
      onTap() {
        this.$emit('onSelect');
      }
    }
  };
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .goods_wrapper {
        width: 100%;
        display: -webkit-flex;
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        .goods_card {
            margin: 0 45px 15px 0;
            border: 1px solid;
            box-shadow: 0 1px 5px 0 rgba(2,15,29,-4.82);
            .wrapper {
                display: flex;
                -webkit-box-pack: justify;
                -ms-flex-pack: justify;
                justify-content: space-between;
                margin: 4px;
                padding: 15px 20px;
                width: 513px;
                height: 278px;
                overflow: hidden;
                .picture {
                    width: 185px;
                    .big-picture {
                        width: 100%;
                        height: 100%;
                    }
                    .small-picture {
                        display: flex;
                        flex-wrap: nowrap;
                        -webkit-box-pack: justify;
                        justify-content: space-between;
                        margin-top: 5px;
                        div {
                            width: 60px;
                            height: 60px;
                            img {
                                width: 100%;
                                height: 100%;
                            }
                        }
                    }
                }
                .content {
                    position: relative;
                    width: 270px;
                    text-align: left;
                    h1 {
                        margin-bottom: 10px;
                        font-size: 15px;
                        font-weight: 700;
                        color: #2d2d2d;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                        height: 21px;
                    }
                    p {
                        font-size: 13px;
                        line-height: 17px;
                        font-weight: 400;
                        color: #262626;
                    }
                    .price {
                        margin: 5px 0;
                        display: flex;
                        color: #f1394d;
                        flex-wrap: nowrap;
                        -webkit-box-pack: justify;
                        justify-content: space-between;
                        -webkit-box-align: end;
                        align-items: flex-end;
                        height: 28px;
                        .line-through {
                            color: #8d8d8d;
                            font-size: 11px;
                            text-decoration: line-through;
                        }
                    }
                    .sku {
                        .sku-box {
                            height: 76px;
                            overflow: hidden;
                            ul li {
                                display: inline-block;
                                margin: 0 10px 5px 0;
                                padding: 0 5px;
                                max-width: 260px;
                                height: 22px;
                                text-align: center;
                                line-height: 22px;
                                color: #262626;
                                font-size: 12px;
                                background: #f2f1f1;
                            }
                        }
                    }
                    .button {
                        position: absolute;
                        right: 0;
                        bottom: 0;
                        display: flex;
                        -webkit-box-pack: center;
                        justify-content: center;
                        -webkit-box-align: center;
                        align-items: center;
                        width: 100px;
                        height: 32px;
                        color: #fff;
                        background: #f1394d;
                        border: 1px solid #f1394d;
                        border-radius: 4px;
                        cursor: pointer;
                    }
                }
            }
        }
    }
</style>
