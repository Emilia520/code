<template>
    <div class="app-container">
        <el-row>
            <el-col :span="24">
                <div class="head-area">
                    <div class="editable">
                        <span class="editable-content">{{text}}</span>
                        <svg-icon icon-class="pen"/>
                        <a href="javascript:void(0);" class="editable-toggle"></a>
                        <input value="111" class="editable-input" style="display: none;">
                    </div>
                    <div class="detail">
                        <span>{{shareTime}}</span>
                        <!--<span style="margin-left: 41px">商品个数：{{totalCount}}/200个</span>-->
                    </div>
                </div>
            </el-col>
            <!-- 表格 start -->
            <el-col :span="24">
                <el-table
                        :data="tableData"
                        style="width: 100%"
                        v-loading="loading">
                    <el-table-column
                            label="商品信息"
                            width="310">
                        <template slot-scope="scope">
                            <div class="item-info-wrapper">
                                <div class="item-img">
                                    <img :src="activityVisible ? scope.row.brandLogoUrl : scope.row.images[0]"
                                         style="width:100px;height:100px;">
                                </div>
                                <ul class="attr">
                                    <li>
                                        <svg-icon icon-class="mall" style="width:15px;height:15px;"/>
                                        <span>{{scope.row.description}}</span>
                                    </li>
                                </ul>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="排序"
                            width="120">
                        <template slot-scope="scope">
                            <div class="number">
                                <span>{{scope.row.ListSort}}</span>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="名字"
                            width="220">
                        <template slot-scope="scope">
                            <div class="number">
                                <span>{{scope.row.name}}</span>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column v-if="!activityVisible"
                                     label="文案"
                                     width="220">
                        <template slot-scope="scope">
                            <div class="number" style="white-space: pre-line;">
                                {{scope.row.shareContent}}
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column v-if="!activityVisible"
                                     label="图片"
                                     width="300">
                        <template slot-scope="scope">
                            <div class="number">
                                <img :src="scope.row.images[0]" style="width:100px;height:100px;">
                                <img :src="scope.row.images[1]" style="width:100px;height:100px;">
                                <img :src="scope.row.images[2]" style="width:100px;height:100px;">
                                <img :src="scope.row.images[3]" style="width:100px;height:100px;">
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="品牌logo"
                            width="200">
                        <template slot-scope="scope">
                            <div class="number">
                                <img :src="scope.row.brandLogoUrl" style="width:100px;height:100px;">
                                <!--<span>{{scope.row.brandName}}</span>-->
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="品牌banner" v-if="activityVisible"
                            width="200">
                        <template slot-scope="scope">
                            <div class="number">
                                <img :src="scope.row.banner[0]" style="width:125px;height:58px;">
                                <!--<span>{{scope.row.brandName}}</span>-->
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="展示时间" v-if="activityVisible"
                            width="200">
                        <template slot-scope="scope">
                            <div class="number">
                                <span>{{scope.row.showTime}}</span>
                                <!--<span>{{scope.row.brandName}}</span>-->
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="操作"
                            width="120">
                        <template slot-scope="scope">
                            <div class="button-area">
                                <div class="button" @click.prevent="del(scope.row)">
                                    删除
                                </div>
                            </div>
                            <div class="button-area">
                                <div class="button" @click.prevent="updateChoiceList(scope.row)">
                                    修改
                                </div>
                            </div>
                        </template>
                    </el-table-column>
                </el-table>
                <!-- 弹层 start -->
                <el-col :span="24">
                    <el-dialog title="修改" :visible.sync="dialogFormVisible" width="300" @close="cancelForm">
                        <el-form :model="row" ref="row">
                            <el-form-item label="ID" :label-width="formLabelWidth" prop="id">
                                <el-input :disabled="true" v-model="row.hotId" placeholder="ID" size="mini"
                                          clearable></el-input>
                            </el-form-item>
                            <el-form-item label="商品名" :label-width="formLabelWidth" v-if="!activityVisible" width="350"
                                          height="300">
                                <emoji-text-input v-model="row.goodsName"
                                                  :inputWidth="300"></emoji-text-input>
                            </el-form-item>
                            <el-form-item label="商品文案" :label-width="formLabelWidth" v-if="!activityVisible" width="350"
                                          height="300">
                                <emoji-text-input v-model="row.shareContent"
                                                  :inputWidth="300"></emoji-text-input>
                            </el-form-item>
                            <el-form-item label="排序" :label-width="formLabelWidth">
                                <el-input class="input" placeholder="排序" v-model="row.ListSort"></el-input>
                            </el-form-item>

                            <el-form-item label="品牌logo" :label-width="formLabelWidth">
                                <el-upload class="avatar-uploader" :action="uploadImg" :show-file-list="false"
                                           :on-success="handleAvatarSuccess"
                                           :list-type="row.brandLogoUrl? '' : 'picture-card'">
                                    <img v-if="row.brandLogoUrl" :src="row.brandLogoUrl" class="avatar" alt=""
                                         style="width:100px;height:100px;">
                                    <i v-else class="el-icon-plus"></i>
                                </el-upload>
                            </el-form-item>

                            <el-form-item label="品牌banner" :label-width="formLabelWidth" v-if="activityVisible">
                                <el-upload class="avatar-uploader" :action="uploadImg" :show-file-list="false"
                                           :on-success="handleAvatarSuccess5"
                                           :list-type="row.banner[0]? '' : 'picture-card'">
                                    <img v-if="row.banner[0]" :src="row.banner[0]" class="avatar" alt=""
                                         style="width:125px;height:58px;">
                                    <i v-else class="el-icon-plus"></i>
                                </el-upload>
                            </el-form-item>
                            <el-form-item label="展示时间" :label-width="formLabelWidth" prop="sort">
                                <el-date-picker v-model="row.showTime" type="datetime" placeholder="选择日期时间">
                                </el-date-picker>
                            </el-form-item>
                            <el-form-item label="图片" :label-width="formLabelWidth" v-if="!activityVisible">
                                <div class="avatar-uploader-container">
                                    <el-upload class="avatar-uploader" :action="uploadImg" :show-file-list="false"
                                               :on-success="handleAvatarSuccess1"
                                               :list-type="row.images[0]? '' : 'picture-card'">
                                        <img v-if="row.images[0]" :src="row.images[0]" class="avatar" alt=""
                                             style="width:100px;height:100px;">
                                        <i v-else class="el-icon-plus"></i>
                                    </el-upload>
                                    <el-upload class="avatar-uploader" :action="uploadImg" :show-file-list="false"
                                               :on-success="handleAvatarSuccess2"
                                               :before-upload="beforeAvatarUpload(row)"
                                               :list-type="row.images[1]? '' : 'picture-card'">
                                        <img v-if="row.images[1]" :src="row.images[1]" class="avatar" alt=""
                                             style="width:100px;height:100px;">
                                        <i v-else class="el-icon-plus"></i>
                                    </el-upload>
                                    <el-upload class="avatar-uploader" :action="uploadImg" :show-file-list="false"
                                               :on-success="handleAvatarSuccess3"
                                               :list-type="row.images[2]? '' : 'picture-card'">
                                        <img v-if="row.images[2]" :src="row.images[2]" class="avatar" alt=""
                                             style="width:100px;height:100px;">
                                        <i v-else class="el-icon-plus"></i>
                                    </el-upload>
                                    <el-upload class="avatar-uploader" :action="uploadImg" :show-file-list="false"
                                               :on-success="handleAvatarSuccess4"
                                               :list-type="row.images[3]? '' : 'picture-card'">
                                        <img v-if="row.images[3]" :src="row.images[3]" class="avatar" alt=""
                                             style="width:100px;height:100px;">
                                        <i v-else class="el-icon-plus"></i>
                                    </el-upload>
                                </div>
                            </el-form-item>
                        </el-form>
                        <div slot="footer" class="dialog-footer">
                            <el-button @click="cancelForm('row')">取 消</el-button>
                            <el-button type="primary" @click="confirmForm('row')">确 定</el-button>
                        </div>
                    </el-dialog>
                </el-col>
                <!-- 弹层 end -->
            </el-col>
            <!-- 表格 end -->

        </el-row>
        <div slot="footer">
            <el-button type="primary" @click="add()">给爆款库添加商品</el-button>
        </div>
        <!-- 分页 start -->
        <el-col :span="24">
            <div class="pagination" style="margin-top:10px;margin-bottom: 20px;">
                <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                               :current-page="page" :page-sizes="[20, 40, 80, 120]"
                               :page-size="pageSize" layout="total, sizes, prev, pager, next"
                               :total="totalCount">
                </el-pagination>
            </div>
        </el-col>
        <!-- 分页 end -->
    </div>
</template>

<script>
  import {addHotGoods, delGoods, delHotGoods, findHotGoods, selectActivity, updateGoodsHotList} from '@/api/groupbuy';
  import {uploadImg} from '@/api/uploadImg';
  import EmojiTextInput from '@/component/EmojiTextArea/';
  import {timestampToTime} from 'framework/utils/chanageTime';

  export default {
    components: { EmojiTextInput },
    name: 'akc-hot-detail',
    props: {
      text: {
        type: String
      },
      hotId: {
        type: Number
      },
      shareTime: {
        type: String
      },
      appType: {
        type: Number,
        default: 2
      },
      confirmBtnTitle: {
        type: String,
        default: '添加爆款'
      },
      cancelBtnTitle: {
        type: String,
        default: '取消爆款'
      }
    },
    data() {
      return {
        //   text: this.$route.params.text,
        //   shareTime: this.$route.params.share_time,
        uploadImg,
        dialogFormVisible: false,
        activityVisible: false,
        dialogFormTitle: '',
        tableData: [],
        totalCount: 0,
        page: 1,
        pageSize: 20,
        type: 1,
        //   hotId: this.$route.params.id,
        row: {
          id: 0,
          images: [],
          banner: [],
          brandLogoUrl: '',
          goodsName: '',
          hotId: 0,
          ListSort: 0,
          shareContent: new Date(),
          showTime: ''
        },
        formLabelWidth: '120px',
        rules: {
          sort: [{ required: true, message: '请输入权重', trigger: 'blur' },
            { type: 'number', min: 0, max: 9999, message: '权重为数字值，且范围为0～9999' }]
        },

      };
    },
    created() {
      this.type = this.appType;
      this.getList();
    },
    methods: {

      // 分页
      handleSizeChange(pageSize) {
        this.pageSize = pageSize;
        this.getList();
      },
      // 页码变化时触发
      handleCurrentChange(page) {
        this.page = page;
        this.getList();
      },
      handleAvatarSuccess(res, file) {
        this.row.brandLogoUrl = res.data;
      },
      handleAvatarSuccess1(res, file) {
        this.row.images[0] = res.data;
        const imgs = this.row.images;
        this.row.images = [];
        this.row.images = imgs;
      },
      handleAvatarSuccess2(res, file) {
        this.row.images[1] = res.data;
        const imgs = this.row.images;
        this.row.images = [];
        this.row.images = imgs;
      },
      handleAvatarSuccess3(res, file) {
        this.row.images[2] = res.data;
        const imgs = this.row.images;
        this.row.images = [];
        this.row.images = imgs;
      },
      handleAvatarSuccess4(res, file) {
        this.row.images[3] = res.data;
        const imgs = this.row.images;
        this.row.images = [];
        this.row.images = imgs;
      },
      handleAvatarSuccess5(res, file) {
        this.row.banner[0] = res.data;
        const imgs = this.row.banner;
        this.row.banner = [];
        this.row.banner = imgs;
      },
      beforeAvatarUpload(row) {
        this.row = row;
      },
      cancelForm(formName) {
        this.dialogFormVisible = false;
      },
      confirmForm(row) {
        const id = this.row.hotId;
        const brand_url = this.row.brandLogoUrl;
        const goods_name = this.row.goodsName;
        const sort = this.row.ListSort;
        const shareContent = this.row.shareContent;
        const showTime = new Date(this.row.showTime).getTime() / 1000;
        const img_url = JSON.stringify(this.row.images);
        const banner = JSON.stringify(this.row.banner);
        updateGoodsHotList({
          id,
          brand_url,
          goods_name,
          img_url,
          sort,
          shareContent,
          banner,
          showTime
        }).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.$message({
              message: '操作成功',
              type: 'success'
            });
            this.$emit('update', this.data);
          } else {
            this.$message({ type: 'error', message: res.msg || '修改失败' });
          }
          this.dialogFormVisible = false;
          this.getList();
        });
      },
      getList() {
        this.loading = false;
        const hot_id = this.hotId;
        const type = this.type;
        console.log('type',type);
        const page = this.page;
        const pageSize = this.pageSize;
        if (this.hotId === 0) {
          // 查询活动
          selectActivity({ hot_id, page, pageSize, type }).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.tableData = res.data;
              for (const i in this.tableData) {
                const info = this.tableData[i];
                info.showTime = timestampToTime(info.showTime);
                console.log(info);
                info.images = info.images ? info.images : [];
                info.banner = info.banner ? JSON.parse(info.banner) : [];
                if (info.hotBanner != null) {
                  const img = JSON.parse(info.hotBanner);
                  info.banner = img;
                }
                if (info.brandUrl != null) {
                  info.brandLogoUrl = info.brandUrl;
                }
              }
              this.totalCount = res.count;
            }
            this.activityVisible = true;
            this.loading = false;
          });
        } else {
          // 请求列表
          findHotGoods({ hot_id }).then(response => {
            const res = response.data;
            if (res.code === 10000) {
              this.tableData = res.data;
              for (const i in this.tableData) {
                const row = this.tableData[i];
                const imgs = JSON.parse(row.picture);
                let num = row.description;
                let arr = num.split('、');
                row.images = imgs;
                if (row.goodsName != null) {
                  row.name = row.goodsName;
                } else {
                  row.name = arr[0] + ' ' + row.name;
                }
                if (row.imgUrl != null) {
                  const img = JSON.parse(row.imgUrl);
                  row.images = img;
                }
                if (row.brandUrl != null) {
                  row.brandLogoUrl = row.brandUrl;
                }
                if (row.shareContent == null) {
                  let specification = '';
                  const skus = JSON.parse(row.skus_attribute_list);
                  for (const i in skus) {
                    const sku = skus[i];
                    specification += sku.attributeValue + "/";
                  }
                  // row.shareContent ="【规格】"+ specification+"\n"+
                  //     "【原价】"+row.akc_tag_price+"\n"+
                  //     "【秒杀价】"+row.settlement_price;
                  row.shareContent = `👉【规格】${specification}\n👉【原价】${row.akc_tag_price}\n👉【秒杀价】${row.settlement_price}`;
                }
              }
              console.log(this.tableData);
              this.activityVisible = false;
            }
            this.loading = false;
          });
        }

      },
      selectTimeAfter() {
        const startDate = this.selectTimes2[0].getTime() / 1000;
        this.addForm.showTime = startDate;
      },
      updateChoiceList(row) {
        this.row.goods_id = row.id;
        this.row.hotId = row.hotId;
        this.row.ListSort = row.ListSort;
        this.row.images = row.images;
        this.row.banner = row.banner;
        this.row.brandLogoUrl = row.brandLogoUrl;
        this.row.goodsName = row.name;
        this.row.shareContent = row.shareContent;
        this.dialogFormVisible = true;
      },
      onConfirm(goods) {
        this.loadingGoods = true;
        addHotGoods({
          goods_id: goods.id,
          activity_id: goods.aikucun_activity_id,
          hot_id: this.hotId
        }).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.getList();
            this.$message({
              message: '添加成功！',
              type: 'success'
            });
            goods.hot_status = 1;
          } else {
            this.$message({
              message: `操作失败！失败原因:${res.msg}`,
              type: 'error'
            });
          }
          this.loadingGoods = false;
        });
      },
      onCancel(goods) {
        this.loadingGoods = false;
        delHotGoods({ goods_id: goods.id }).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.getList();
            this.$message({
              message: '删除成功！',
              type: 'success'
            });
            goods.hot_status = 0;
          } else {
            this.$message({
              message: `操作失败！失败原因:${res.msg}`,
              type: 'error'
            });
          }
          this.loadingGoods = false;
        });
      },
      add() {
        this.$router.push({
          name: 'qxbChooseGoods',
          params: {
            hotId: this.hotId,
            appType: this.appType,
          }
        });
      },
      del(goods) {
        this.loadingGoods = false;
        delGoods({ id: goods.hotId }).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.getList();
            this.$message({
              message: '删除成功！',
              type: 'success'
            });
            goods.hot_status = 0;
          } else {
            this.$message({
              message: `操作失败！失败原因:${res.msg}`,
              type: 'error'
            });
          }
          this.loadingGoods = false;
        });
      }
    }
  };
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .head-area {
        width: 630px;
        position: relative;
        margin-left: 10px;
        display: block;
        font-size: 12px;
        line-height: 1.42857;
        font-family: "Microsoft YaHei", 微软雅黑, STXihei, 华文细黑, Georgia, "Times New Roman", Arial, sans-serif;
        -webkit-font-smoothing: antialiased;

        .editable {
            color: rgb(51, 51, 51);

            .editable-content {
                font-size: 20px;
            }

        }

        .detail {
            margin-top: 6px;
            color: #999;
        }

    }

    .item-info-wrapper {
        position: relative;
        padding: 14px 10px;
        text-align: left;
        font-size: 12px;
        color: #666;
        line-height: 1.42857;
        font-family: "Microsoft YaHei", 微软雅黑, STXihei, 华文细黑, Georgia, "Times New Roman", Arial, sans-serif;
        -webkit-font-smoothing: antialiased;

        .item-img {
            float: left;
            width: 100px;
            height: 100px;
        }

        .attr {
            max-width: 171px;
            margin-left: 115px;
            height: 100px;

            li {
                margin-bottom: 5px;
                padding: 2px 4px;

                a {
                    outline: 0;
                    text-decoration: none;
                }

            }
            .coupon-info {
                height: 16px;
                align-items: center;
                box-sizing: border-box;

                span:first-child {
                    border: 1px solid #e3544c;
                    color: #e3544c;
                    font-weight: bold;
                    padding-right: 2px;
                    margin-right: 10px;
                }

                span {
                    height: 16px;
                    line-height: 16px;
                    font-size: 12px;

                    i {
                        background-color: #e3544c;
                        color: #fff;
                        font-weight: normal;
                        padding: 0 3px;
                        font-style: normal;
                    }

                }
            }
        }
        ul {
            list-style-type: none;
            list-style-image: none;
            margin: 0;
            padding: 0;
        }

        li {
            display: list-item;
            text-align: -webkit-match-parent;
        }

    }

    .button-area {
        margin: 5px 0;
        display: flex;
        justify-content: space-between;
        height: 32px;
        .button {
            // position: absolute;
            // right: 0;
            // bottom: 0;
            display: flex;
            -webkit-box-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            align-items: center;
            width: 100px;
            height: 32px;
            color: #fff;
            background: #f1394d;
            border: 1px solid #f1394d;
            border-radius: 4px;
            cursor: pointer;
        }
        .cancel-button {
            // position: absolute;
            // right: 0;
            // bottom: 0;
            display: flex;
            -webkit-box-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            align-items: center;
            width: 100px;
            height: 32px;
            color: #fff;
            background: #746c6c;
            border: 1px solid #746c6c;
            border-radius: 4px;
            cursor: pointer;
        }
    }

    .number {
        color: rgb(51, 51, 51);
        line-height: 1.42857;
        font-size: 12px;
        font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    }

    .op-btn {
        margin-left: 10px;
        margin-bottom: 10px;
    }

    .avatar-uploader-container {
        display: flex;
        flex-direction: row;
        justify-content: flex-start;

        .avatar-uploader {
            display: inline-block;
            margin-right: 16px;
        }
    }

</style>
