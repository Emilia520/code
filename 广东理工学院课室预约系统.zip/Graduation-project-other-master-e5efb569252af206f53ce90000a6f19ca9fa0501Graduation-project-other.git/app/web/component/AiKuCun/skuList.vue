<template>
  <div v-loading="loading">
    <el-row>
      <!-- 活动分类 start -->
      <el-col :span="24">
        <el-tabs @tab-click="onOptClick" style="height: 50px;">
            <el-tab-pane v-for="opt in optList" :key="opt.id" :label="opt.tag_name"></el-tab-pane>
        </el-tabs>
      </el-col>
      <!-- 活动分类 end -->
      <!-- 表格 start -->
      <el-col :span="24">
        <div class="card_wrapper">
            <el-card :body-style="{ padding: '0px'}" v-for="activity in tableData" :key="activity.id" class="activity_card" >
              <!-- <a :href="`/shoppingTuan/activityDetail/${activity.id}`" style="cursor:pointer"> -->
              <div style="cursor:pointer" @click="showActivityGoods(activity)">
                <div class="logo_wrapper">
                    <div style="display:block;">
                        <img class="brand_logo" :src="activity.brand_logo_url">
                        <div style="font-size:8px;text-align:center;"><b>{{activity.brand}}</b></div>
                    </div>
                </div>
                <div class="content_wrapper">
                    <div style="font-size:14px;"><nobr><b>{{activity.name}}</b></nobr></div>
                    <div class="content">所属分类：{{activity.tag_name}}</div>
                    <div class="content">共 <b>{{activity.goods_num}}</b> 个商品</div>
                    <div class="content"><span style="color:#D1463A;font-size:12px;"><b>{{activity.min_discount / 10}} </b></span>折起</div>
                    <div class="content">开始时间：{{activity.start_date}}</div>
                    <div class="content">结束时间：{{activity.end_date}}</div>
                </div>
                <div class="goods_thumbnail_wrapper">
                    <div v-for="img in (activity.banner && JSON.parse(activity.banner) || []).slice(0, 3)" :key="img" class="goods_thumbnail">
                        <img style="width:100%;" :src="img">
                    </div>
                </div>
                <div class="edit_area">
                    <el-button class="sel_button" @click.stop="addActivity(activity)" icon="el-icon-download el-icon--left">
                        <span style="color:#1296db;">{{activityBtnTitle}}</span>
                    </el-button>
                </div>
              </div>
              <!-- </a> -->
            </el-card>
        </div>
      </el-col>
      <!-- 表格 end -->
      <!-- 分页 start -->
      <el-col :span="24">
        <div class="pagination" style="margin-top:20px;">
          <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="formInline.page" :page-sizes="[40, 80, 120, 160]" :page-size="formInline.pageSize" layout="total, sizes, prev, pager, next" :total="totalCount">
          </el-pagination>
        </div>
      </el-col>
      <!-- 分页 end -->
      <!-- 弹层 start -->
      <el-col :span="24">
        <el-dialog title="商品列表" :visible.sync="dialogFormVisible" width="75%" @close="closeGoodsList">
          <div class="goods_wrapper">
            <el-card :body-style="{ padding: '0px' }" v-for="goods in goodsList" :key="goods.id"
                     class="goods_card">
                <div class="goods_img_wrapper">
                    <img :src="goods.pictures[0]" class="goods_thumb">
                </div>
                <div class="goods_info_wrapper">
                    <p class="goods_title">{{goods.name}}</p>
                    <!-- <p class="coupon_info">
                        <span v-if="goods.coupon_info"><i>券</i>{{goods.coupon_info}}</span>
                        <span v-if="goods.coupon_info">剩余{{goods.coupon_remain_count}}张</span>
                    </p> -->
                    <p class="price_info">
                        <span>折后价: <b>￥{{goods.settlement_price}}</b></span>
                        <span class="orign_price">价格￥{{goods.akc_tag_price}}</span>
                    </p>
                    <p class="earn_info">
                        <span>利润: <b>￥{{goods.akc_profit}}</b></span>
                        <span>折扣: {{(goods.discount_rate / 10).toFixed(1)}}折</span>
                    </p>
                    <!-- <div class="sale_info">
                        <span>销量: {{goods.volume}}</span>
                    </div> -->
                    <!-- <div class="store_info">
                        <span class="mall_icon"></span>
                        <span class="mall_name">{{goods.shop_title}}</span>
                    </div> -->
                    <div>
                        <span>
                            <el-button class="goods_btn" @click.prevent="addGoods(goods)"
                                        icon="el-icon-download el-icon--left">{{itemBtnTitle}}</el-button>
                        </span>
                    </div>
                </div>
            </el-card>
          </div>
        </el-dialog>
      </el-col>
      <!-- 弹层 end -->
    </el-row>
  </div>
</template>

<script>
import { getCatList, getActivityList, getGoodsList } from '@/api/groupbuy';

export default {
  name: 'akc-sku-list',
  props: {
    activityBtnTitle: {
      type: String,
      default: '选 取'
    },
    itemBtnTitle: {
      type: String,
      default: '选 取'
    }
  },
  data() {
    return {
      curCatIndex: 0,
      totalCount: 0,
      loading: false,
      formInline: {
        status: '',
        catId: 1,
        page: 1,
        pageSize: 40,
        type: 1,
        appType: 2
      },
      dialogFormVisible: false,
      tableData: [],
      optList: [],
      goodsList: [],
      formLabelWidth: '120px',
    };
  },
  methods: {
    didPresent() {
      if (this.tableData.length === 0) {
        this.getData();
      }
    },
    onSubmit() {
      this.getList();
    },
    getData() {
      this.loading = true;
      Promise.all([getCatList({ appType: this.appType }), getActivityList(this.formInline)]).then(results => {
        // 解析分类列表
        let res = results[0].data;
        if (res.code === 10000) {
          this.optList = res.data;
        }
        // 解析活动列表
        res = results[1].data;
        if (res.code === 10000) {
          this.totalCount = res.totalCount;
          this.tableData = res.data;
        }

        this.loading = false;
      });
    },
    getList() {
      this.loading = true;
      // 请求列表
      this.formInline.type = this.curCatIndex === 0 ? 1 : 2;
      getActivityList(this.formInline).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          this.totalCount = res.totalCount;
          this.tableData = res.data;
        }
        this.loading = false;
      });
    },
    onOptClick(val) {
      this.curCatIndex = parseInt(val.index);
      this.formInline.catId = this.optList[this.curCatIndex].id;
      this.formInline.page = 1;
      this.getList();
    },
    showActivityGoods(activity) {
      this.loading = true;
      // 请求列表
      getGoodsList({ actId: activity.id }).then(response => {
        const res = response.data;
        if (res.code === 10000) {
          for (const i in res.data) {
            const data = res.data[i];
            data.pictures = JSON.parse(data.picture);
            const skuList = [];
            const skus = JSON.parse(data.sku_list);
            for (const j in skus) {
              const sku = skus[j];
              let str = '';
              for (const k in sku.attributeList) {
                const attr = sku.attributeList[k];
                if (attr.attributeName === '尺码') {
                  str += attr.attributeValue + '码';
                }
                if (attr.attributeName === '颜色') {
                  str += attr.attributeValue;
                }
              }
              skuList.push(str);
            }

            data.skuList = skuList;
          }

          this.goodsList = res.data;
        } else {
          this.goodsList = [];
        }
        this.loading = false;
        this.dialogFormVisible = true;
      });
    },
    closeGoodsList() {
      this.dialogFormVisible = false;
    },
    // 分页
    handleSizeChange(pageSize) {
      this.formInline.pageSize = pageSize;
      this.getList();
    },
    // 页码变化时触发
    handleCurrentChange(page) {
      this.formInline.page = page;
      this.getList();
    },
    addActivity(activity) {
      this.$emit('onSelectAct', activity);
    },
    addGoods(goods) {
      this.$emit('onSelectGoods', goods);
    }
  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .card_wrapper {
    width: 100%;
    display: -webkit-flex;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;

    .activity_card {
      width: 320px;
      height: 240px;
      margin: 15px;

      .logo_wrapper {
        width: 80px;
        height: 100px;
        float: left;
        display:flex;
        padding: 5px;
        align-items:center;

        .brand_logo {
          width: 100%;
        }
      }

      .content_wrapper {
        width: 240px;
        height: 100px;
        margin-left: 80px;
        padding: 10px;

        .content {
          font-size: 10px;
          font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        }
      }

      .goods_thumbnail_wrapper {
        width: 100%;
        height: 100px;
        display: flex;
        flex-direction: row;
        background-color: #FAFAFA;

        .goods_thumbnail {
          margin: 10px 13px;
          width: 80px;
          height: 80px;
        }
      }

      .edit_area {
        width: 100%;
        height: 40px;
        padding: 5px;
        display: flex;

        .sel_button {
          flex: 3;
          height: 30px;
          border: 1px;
          font-size: 14px;
          padding: 5px;
          text-align: center;
          border-color: gray;
        }
      }
    }
  }

  .goods_wrapper {
        width: 100%;
        display: -webkit-flex;
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
    }

    .goods_card {
        margin-bottom: 20px;
        margin-right: 20px;
        width: 224px;
        height: 382px;
        background-color: #fff;
        font-size: 0;
        position: relative;
        box-sizing: border-box;
        font-family: PingFang SC, Microsoft YaHei, Segoe UI, Helvetica Neue, Helvetica, Arial, sans-serif, SimSun !important;
    }

    .goods_img_wrapper {
        width: 100%;
        height: 224px;
        position: relative;
        background-color: #ebedf5;
        box-sizing: border-box;
    }

    .goods_thumb {
        width: 224px;
        height: 224px;
        position: absolute;
        left: 0;
        top: 0;
        vertical-align: initial;
        border-style: none;
        box-sizing: border-box;
    }

    .goods_info_wrapper {
        width: 100%;
        height: 220px;
        padding: 10px 10px 0;
        box-sizing: border-box;
        color: #999;
    }

    .goods_info_wrapper b {
        font-size: 12px;
        font-weight: bold;
        color: #666666;
    }

    .goods_title {
        color: #666666;
        height: 30px;
        font-size: 12px;
        line-height: 30px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        margin-bottom: 0;
        box-sizing: border-box;
    }

    .coupon_info {
        height: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0;
        box-sizing: border-box;
    }

    .coupon_info span:first-child {
        border: 1px solid #e3544c;
        color: #e3544c;
        font-weight: bold;
        padding-right: 2px;
    }

    .coupon_info span {
        display: flex;
        height: 18px;
        line-height: 17px;
        font-size: 12px;
    }

    .coupon_info span i {
        background-color: #e3544c;
        color: #fff;
        font-weight: normal;
        padding: 0 3px;
        font-style: normal;
    }

    .price_info {
        height: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0;
        box-sizing: border-box;
        color: #999;
    }

    .price_info span:first-child {
        font-size: 12px;
    }

    .orign_price {
        font-size: 12px;
        text-decoration: line-through;
    }

    .earn_info {
        height: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .earn_info span:first-child {
        font-size: 12px;
    }

    .earn_info span:last-child {
        font-size: 12px;
        color: #FF5500;
    }

    .sale_info {
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .sale_info span {
        font-size: 12px;
    }

    .goods_btn {
        font-size: 12px;
        height: 40px;
        width: 100%;
        line-height: 40px;
        color: #666;
        text-align: center;
        display: inline-block;
        user-select: none;
        cursor: pointer;
        vertical-align: center;
        padding: 0;
        border-color: transparent;
    }

    .store_info {
        width: 100%;
        height: 30px;
        line-height: 30px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        font-size: 12px;
        vertical-align: center;
        background-color: #FCFCFC;
    }

    .mall_icon {
        width: 12px;
        height: 12px;
        background: url(https://t16img.yangkeduo.com/mms_static/cc8fb52750564465f46e204ae37dd9b1.png) no-repeat;
        background-size: 100% 100%;
        display: inline-block;
        margin-right: 5px;
    }

    .mall_name {
        height: 30px;
        position: absolute;
    }

    .security_icon {
        width: 14px;
        height: 16px;
        background: url(https://t16img.yangkeduo.com/mms_static/eca51a29c2f8c14b25ec1ac7c103ed2b.png) no-repeat;
        background-size: 100% 100%;
        display: inline-block;
        position: relative;
        top: 7px;
        left: 5px;
    }
</style>
