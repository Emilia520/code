<template>
    <div class="app-container">
        <el-row>
            <el-col :span="24">
                <div class="head-area">
                    <div class="editable">
                        <span class="editable-content">每日分享素材</span>
                        <svg-icon icon-class="pen"/>
                    </div>
                    <div class="detail">
                        <!--<span style="margin-left: 41px">商品个数：{{totalCount}}/200个</span>-->
                    </div>
                </div>
            </el-col>
            <el-row>
                <el-col>
                    <el-button v-show="!addVisible" size="mini" icon="el-icon-plus"
                               @click="add()">新增每日分享素材
                    </el-button>
                    <el-row v-show="addVisible">
                        <el-form :model="row" :rules="rules" ref="row">
                            <el-form-item label="分享内容" :label-width="formLabelWidth" prop="text"
                                          style="text-anchor: start">
                                <emoji-text-input v-model="row.text"
                                                  :inputWidth="300"></emoji-text-input>
                            </el-form-item>
                            <el-form-item label="回复内容" :label-width="formLabelWidth" prop="text"
                                          style="text-anchor: start">
                                <emoji-text-input v-model="row.reply_text"
                                                  :inputWidth="300"></emoji-text-input>
                            </el-form-item>
                            <el-form-item label="图片" :label-width="formLabelWidth" prop="text"
                                          style="text-anchor: start">
                                <div class="avatar-uploader-container">
                                    <el-upload class="avatar-uploader" :action="uploadImgNew" :show-file-list="false"
                                               :on-success="handleAvatarSuccess1"
                                               :list-type="row.images[0]? '' : 'picture-card'">
                                        <img v-if="row.images[0]" :src="row.images[0]" class="avatar" alt=""
                                             style="width:100px;height:100px;">
                                        <i v-else class="el-icon-plus"></i>
                                    </el-upload>
                                </div>
                            </el-form-item>
                        </el-form>
                        <el-button type="primary" @click="createForm('row')" size="mini">创建</el-button>
                        <el-button type="info" @click="onCancelAddChoiceList" size="mini">取消</el-button>
                    </el-row>
                </el-col>
            </el-row>
            <el-table-column label="操作" width="100">
                <template slot-scope="scope">
                    <el-button type="danger" size="small" @click="deleteMsg(scope.row)" style="margin-top:10px">
                        删除
                    </el-button>
                </template>
            </el-table-column>
            <!-- 表格 start -->
            <el-col :span="24">
                <el-table
                        :data="tableData"
                        style="width: 100%"
                        v-loading="loading">
                    <el-table-column
                            label="运营者"
                            width="310">
                        <template slot-scope="scope">
                            <div class="item-info-wrapper">
                                <div class="item-img">
                                    <img :src="scope.row.avatarUrl" style="width:100px;height:100px;">
                                </div>
                                <ul class="attr">
                                    <li>
                                        <svg-icon icon-class="mall" style="width:15px;height:15px;"/>
                                        <span>{{scope.row.userName}}</span>
                                    </li>
                                </ul>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="排序"
                            width="120">
                        <template slot-scope="scope">
                            <div class="number">
                                <span>{{scope.row.sort}}</span>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="发布的内容"
                            width="220">
                        <template slot-scope="scope">
                            <div class="number">
                                <span>{{scope.row.text}}</span>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="回复的内容"
                            width="220">
                        <template slot-scope="scope">
                            <div class="number">
                                <span>{{scope.row.reply_text}}</span>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="图片"
                            width="300">
                        <template slot-scope="scope">
                            <div class="number">
                                <img :src="scope.row.images[0]" style="width:100px;height:100px;">
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="操作"
                            width="120">
                        <template slot-scope="scope">
                            <div class="button-area">
                                <div class="button" @click.prevent="del(scope.row)">
                                    删除
                                </div>
                            </div>
                            <div class="button-area">
                                <div class="button" @click.prevent="updateChoiceList(scope.row)">
                                    修改
                                </div>
                            </div>
                        </template>
                    </el-table-column>
                </el-table>
                <!-- 弹层 start -->
                <el-col :span="24">
                    <el-dialog title="修改" :visible.sync="dialogFormVisible" width="300" @close="cancelForm">
                        <el-form :model="row" ref="row">
                            <el-form-item label="ID" :label-width="formLabelWidth" prop="id">
                                <el-input :disabled="true" v-model="row.id" placeholder="ID" size="mini"
                                          clearable></el-input>
                            </el-form-item>

                            <el-form-item label="排序" :label-width="formLabelWidth">
                                <el-input class="input" placeholder="排序" v-model="row.sort"></el-input>
                            </el-form-item>
                            <el-form-item label="发布的内容" :label-width="formLabelWidth" width="350" height="300">
                                <emoji-text-input v-model="row.text"
                                                  :inputWidth="300"></emoji-text-input>
                            </el-form-item>
                            <el-form-item label="回复的内容" :label-width="formLabelWidth" width="350" height="300">
                                <emoji-text-input v-model="row.reply_text"
                                                  :inputWidth="300"></emoji-text-input>
                            </el-form-item>

                            <el-form-item label="图片" :label-width="formLabelWidth">
                                <div class="avatar-uploader-container">
                                    <el-upload class="avatar-uploader" :action="uploadImg" :show-file-list="false"
                                               :on-success="handleAvatarSuccess1"
                                               :list-type="row.images[0]? '' : 'picture-card'">
                                        <img v-if="row.images[0]" :src="row.images[0]" class="avatar" alt=""
                                             style="width:100px;height:100px;">
                                        <i v-else class="el-icon-plus"></i>
                                    </el-upload>
                                </div>
                            </el-form-item>
                        </el-form>
                        <div slot="footer" class="dialog-footer">
                            <el-button @click="cancelForm('row')">取 消</el-button>
                            <el-button type="primary" @click="confirmForm('row')">确 定</el-button>
                        </div>
                    </el-dialog>
                </el-col>
                <!-- 弹层 end -->
            </el-col>
            <!-- 表格 end -->

        </el-row>
        <!-- 分页 start -->
        <el-col :span="24">
            <div class="pagination" style="margin-top:10px;margin-bottom: 20px;">
                <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                               :current-page="page" :page-sizes="[20, 40, 80, 120]"
                               :page-size="pageSize" layout="total, sizes, prev, pager, next"
                               :total="totalCount">
                </el-pagination>
            </div>
        </el-col>
        <!-- 分页 end -->
    </div>
</template>

<script>
  import { delGoods, selectShare, updateShareHotList, createShareHotList } from '@/api/groupbuy';
  import { uploadImgNew } from '@/api/uploadImg';
  import EmojiTextInput from '@/component/EmojiTextArea/';

  export default {
    components: { EmojiTextInput },
    name: 'akc-share-detail',
    props: {
      text: {
        type: String
      },
      hotId: {
        type: Number
      },
      shareTime: {
        type: String
      },
      appType: {
        type: Number,
        default: 2
      },
      confirmBtnTitle: {
        type: String,
        default: '添加爆款'
      },
      cancelBtnTitle: {
        type: String,
        default: '取消爆款'
      }
    },
    data() {
      return {
        //   text: this.$route.params.text,
        //   shareTime: this.$route.params.share_time,
        uploadImgNew,
        dialogFormVisible: false,
        activityVisible: false,
        editingChoiceListName: null, // 正在编辑新选品队列名称
        addVisible: false,
        dialogFormTitle: '',
        tableData: [],
        totalCount: 0,
        page: 1,
        pageSize: 20,
        shareData: [],
        //   hotId: this.$route.params.id,
        row: {
          id: 0,
          images: [],
          reply_text: '',
          text: '',
          hotId: 0,
          sort: 0,
        },
        formLabelWidth: '120px',
        rules: {
          sort: [{ required: true, message: '请输入权重', trigger: 'blur' },
            { type: 'number', min: 0, max: 9999, message: '权重为数字值，且范围为0～9999' }]
        },

      };
    },
    created() {
      this.getList();
    },
    methods: {
      onCancelAddChoiceList() {
        this.addVisible = false;
      },
      // 分页
      handleSizeChange(pageSize) {
        this.pageSize = pageSize;
        this.getList();
      },
      // 页码变化时触发
      handleCurrentChange(page) {
        this.page = page;
        this.getList();
      },
      handleAvatarSuccess1(res, file) {
        this.row.images[0] = res.data;
        const imgs = this.row.images;
        this.row.images = [];
        this.row.images = imgs;
      },
      beforeAvatarUpload(row) {
        this.row = row;
      },
      cancelForm(formName) {
        this.dialogFormVisible = false;
      },
      confirmForm(row) {
        const id = this.row.id;
        const text = this.row.text;
        const reply_text = this.row.reply_text;
        const sort = this.row.sort;
        const img_url = JSON.stringify(this.row.images);
        updateShareHotList({ id, text, img_url, sort, reply_text }).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.$message({
              message: '操作成功',
              type: 'success'
            });
            this.$emit('update', this.data);
          } else {
            this.$message({ type: 'error', message: res.msg || '修改失败' });
          }
          this.dialogFormVisible = false;
          this.getList();
        });
      },
      createForm(row) {
        const text = this.row.text;
        const reply_text = this.row.reply_text;
        const img_url = JSON.stringify(this.row.images);
        createShareHotList({ text, img_url, reply_text }).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.$message({
              message: '操作成功',
              type: 'success'
            });
            this.$emit('update', this.data);
          } else {
            this.$message({ type: 'error', message: res.msg || '修改失败' });
          }
          this.addVisible = false;
          this.getList();
        });
      },
      getList() {
        this.loading = false;
        const hot_id = this.hotId;
        const page = this.page;
        const pageSize = this.pageSize;
        // 查询活动
        selectShare({ hot_id, page, pageSize }).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.tableData = res.data;
            for (const i in this.tableData) {
              const info = this.tableData[i];
              info.images = info.img_url ? JSON.parse(info.img_url) : [];
              console.log(info.images[0]);
            }
            this.totalCount = res.count;
            console.log(this.tableData);
          }
          this.activityVisible = true;
          this.loading = false;
        });
      },
      updateChoiceList(row) {
        this.row.id = row.id;
        this.row.sort = row.sort;
        this.row.images = row.images;
        this.row.reply_text = row.reply_text;
        this.row.text = row.text;
        this.dialogFormVisible = true;
      },
      add() {
        this.row.images = [];
        this.row.reply_text = '';
        this.row.text = '';
        this.addVisible = true;
      },
      del(goods) {
        this.loadingGoods = false;
        delGoods({ id: goods.id }).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.getList();
            this.$message({
              message: '删除成功！',
              type: 'success'
            });
            goods.hot_status = 0;
          } else {
            this.$message({
              message: `操作失败！失败原因:${res.msg}`,
              type: 'error'
            });
          }
          this.loadingGoods = false;
        });
      }
    }
  };
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .head-area {
        width: 630px;
        position: relative;
        margin-left: 10px;
        display: block;
        font-size: 12px;
        line-height: 1.42857;
        font-family: "Microsoft YaHei", 微软雅黑, STXihei, 华文细黑, Georgia, "Times New Roman", Arial, sans-serif;
        -webkit-font-smoothing: antialiased;

        .editable {
            color: rgb(51, 51, 51);

            .editable-content {
                font-size: 20px;
            }

        }

        .detail {
            margin-top: 6px;
            color: #999;
        }

    }

    .item-info-wrapper {
        position: relative;
        padding: 14px 10px;
        text-align: left;
        font-size: 12px;
        color: #666;
        line-height: 1.42857;
        font-family: "Microsoft YaHei", 微软雅黑, STXihei, 华文细黑, Georgia, "Times New Roman", Arial, sans-serif;
        -webkit-font-smoothing: antialiased;

        .item-img {
            float: left;
            width: 100px;
            height: 100px;
        }

        .attr {
            max-width: 171px;
            margin-left: 115px;
            height: 100px;

            li {
                margin-bottom: 5px;
                padding: 2px 4px;

                a {
                    outline: 0;
                    text-decoration: none;
                }

            }

            .coupon-info {
                height: 16px;
                align-items: center;
                box-sizing: border-box;

                span:first-child {
                    border: 1px solid #e3544c;
                    color: #e3544c;
                    font-weight: bold;
                    padding-right: 2px;
                    margin-right: 10px;
                }

                span {
                    height: 16px;
                    line-height: 16px;
                    font-size: 12px;

                    i {
                        background-color: #e3544c;
                        color: #fff;
                        font-weight: normal;
                        padding: 0 3px;
                        font-style: normal;
                    }

                }
            }
        }

        ul {
            list-style-type: none;
            list-style-image: none;
            margin: 0;
            padding: 0;
        }

        li {
            display: list-item;
            text-align: -webkit-match-parent;
        }

    }

    .button-area {
        margin: 5px 0;
        display: flex;
        justify-content: space-between;
        height: 32px;

        .button {
            // position: absolute;
            // right: 0;
            // bottom: 0;
            display: flex;
            -webkit-box-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            align-items: center;
            width: 100px;
            height: 32px;
            color: #fff;
            background: #f1394d;
            border: 1px solid #f1394d;
            border-radius: 4px;
            cursor: pointer;
        }

        .cancel-button {
            // position: absolute;
            // right: 0;
            // bottom: 0;
            display: flex;
            -webkit-box-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            align-items: center;
            width: 100px;
            height: 32px;
            color: #fff;
            background: #746c6c;
            border: 1px solid #746c6c;
            border-radius: 4px;
            cursor: pointer;
        }
    }

    .number {
        color: rgb(51, 51, 51);
        line-height: 1.42857;
        font-size: 12px;
        font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    }

    .op-btn {
        margin-left: 10px;
        margin-bottom: 10px;
    }

    .avatar-uploader-container {
        display: flex;
        flex-direction: row;
        justify-content: flex-start;

        .avatar-uploader {
            display: inline-block;
            margin-right: 16px;
        }
    }

</style>
