<template xmlns:v-on="http://www.w3.org/1999/xhtml">
    <div class="base" style="padding-top:20px; padding-left: 20px;">
        <el-col :span="24">
            <el-form :inline="true" :model="formInline" class="demo-form-inline">
                <el-form-item>
                    <el-checkbox :checked="offSale" @change="setOffSale">下架</el-checkbox>
                </el-form-item>
                <el-form-item>
                    <el-checkbox :checked="onSale" @change="setOnSale">上架</el-checkbox>
                </el-form-item>
            </el-form>
        </el-col>
        <div style="margin-bottom: 30px;">
            <span style="font-size: 20px; color: #333;">我的选品库</span>
            <span style="font-size: 12px; color: #999;">(共{{ choiceListData.length}}个)</span>
        </div>
        <div class="list-container">
            <el-card style="margin:10px; background-color: #FAFAFC" shadow="hover">
                <div style="width: 301px; height: 203px; text-align: center;" v-on:click="showQuickAdd=true"
                     v-show="!showQuickAdd">
                    <i style="width: 50px; height: 50px; margin-top: 70px; font-size:30px" class="el-icon-plus"></i>
                    <div style="font-size: 14px; color: #666;">新建分组</div>
                </div>
                <div class="quick-add-container" v-show="showQuickAdd">
                    <div class="input-title">新建选品库</div>
                    <!-- 弹层 start -->
                    <el-col :span="24">
                        <el-dialog title="新建分组" :visible.sync="dialogFormVisible" width="300" @close="cancelForm">
                            <el-form :model="addForm" :rules="rules" ref="addForm">
                                <el-form-item label="品牌介绍" :label-width="formLabelWidth" prop="text">
                                    <el-input class="input" :placeholder="'品牌介绍'" v-model="addForm.text"></el-input>
                                </el-form-item>
                                <el-form-item label="建议分享时间" :label-width="formLabelWidth"
                                              prop="share_time">
                                    <el-date-picker v-model="addForm.share_time" type="datetime" placeholder="选择日期时间">
                                    </el-date-picker>
                                </el-form-item>
                                <el-form-item label="客户端展示时间" :label-width="formLabelWidth"
                                              prop="share_time">
                                    <el-date-picker v-model="addForm.on_sale_time" type="datetime" placeholder="选择日期时间">
                                    </el-date-picker>
                                </el-form-item>
                                <el-form-item label="排序" :label-width="formLabelWidth" prop="sort">
                                    <el-input class="input" :placeholder="'排序'"
                                              v-model.number="addForm.sort"></el-input>
                                </el-form-item>
                            </el-form>
                            <div slot="footer" class="dialog-footer">
                                <el-button @click="cancelForm('addForm')">取 消</el-button>
                                <el-button type="primary" @click="confirmForm('addForm')">确 定</el-button>
                            </div>
                        </el-dialog>
                    </el-col>
                    <!-- 弹层 end -->

                    <div class="input-button-container">
                        <el-button class="input-ok" type="primary" size="mini" @click="createChoiceList">创建
                        </el-button>
                        <el-button class="input-cancel" type="info" size="mini" @click="showQuickAdd=false">取消
                        </el-button>
                    </div>
                </div>
            </el-card>
            <div v-show="choiceListData.length !== 0" v-for="data in choiceListData" :key="data.choice_list_id">
                <choice-list-card class="choice-list-card" :data="data"
                                  @delete="removeChoiceList" @click="showDetail(data)" @update="fetchChoiceList">
                </choice-list-card>
            </div>
        </div>
        <!-- 分页 start -->
        <el-col :span="24">
            <div class="pagination" style="margin-top:10px;margin-bottom: 20px;">
                <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                               :current-page="formInline.page" :page-sizes="[20, 40, 80, 120]"
                               :page-size="formInline.pageSize" layout="total, sizes, prev, pager, next"
                               :total="totalCount">
                </el-pagination>
            </div>
        </el-col>
        <!-- 分页 end -->
    </div>
</template>

<script>
    import ChoiceListCard from '@/component/HotListCard';
    import { findGoodsHotList } from '@/api/groupbuy';
    import { deleteGoodsHotList } from '@/api/groupbuy';
    import { delGoodsHotList } from '@/api/groupbuy';
    import { createHotGoodsList } from '@/api/groupbuy';
    import { dateFtt } from '@/framework/utils/utils';

    export default {
      components: { ChoiceListCard },
      name: 'akc-choice-opt',
      props: {
        appType: {
          type: Number,
          default: 0
        }
      },
      data() {
        return {
          totalCount: 0,
          formLabelWidth: '120px',
          loading: false,
          showQuickAdd: false, // 是否显示快速添加按钮
          dialogFormVisible: false,
          choiceListData: [], // 选品列表
          addingChoiceListName: null, // 新增选品库列表的名称
          onSale: true,
          offSale: true,
          addForm: {
            text: '',
            share_time: new Date(),
            on_sale_time: new Date(),
            sort: 0,
            appType: 2
          },
          formInline: {
            status: '',
            page: 1,
            pageSize: 20,
            appType: 2
          },
          rules: {
            sort: [{ required: true, message: '请输入权重', trigger: 'blur' },
              { type: 'number', min: 0, max: 9999, message: '权重为数字值，且范围为0～9999' }]
          },
        };
      },
      created() {
        // 筛选页面初始化
        this.formInline.page = 1;
        this.formInline.pageSize = 20;
        this.formInline.appType = this.appType;
        this.addForm.appType = this.appType;
        this.fetchChoiceList();
      },
      nowTime() {
        return `${dateFtt('yyyy-MM-dd hh:mm:ss', new Date())}`;
      },
      methods: {
        fetchChoiceList() {
          this.loading = true;

          findGoodsHotList(this.formInline).then(res => {
            this.loading = false;
            this.choiceListData = res.data.code === 10000 ? res.data.data : [];
            this.totalCount = res.data.totalCount;
            for (const i in this.choiceListData) {
              const item = this.choiceListData[i];
              item.pics = [];
              if (!item.picture || item.picture.length === 0) {
                continue;
              }

              const picsArr = item.picture.split('"||"');
              for (const j in picsArr) {
                try {
                  const itemPicArr = JSON.parse(picsArr[j]);
                  item.pics.push(itemPicArr[0] ? itemPicArr[0] : '');
                } catch (e) {
                  item.pics.push('');
                }
              }
            }
          })
          ;
        },

        /**
             * 删除指定的选品队列
             * @param choiceList
             */
        removeChoiceList(choiceList) {
          this.$confirm('该操作会导致关联投放位上的数据同时清空，是否确认删除？', '确认删除', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            deleteGoodsHotList(choiceList).then(res => {
              if (res.data.code !== 10000
              ) {
                this.$message({ type: 'error', message: res.data.msg || '删除选品列表失败' });
                return;
              }

              const index = this.choiceListData.findIndex(item => {
                return item.choice_list_id === choiceList.choice_list_id;
              })
                ;

              if (index >= 0 && index < this.choiceListData.length) {
                this.choiceListData.splice(index, 1);
              }
            })
            ;
          }).
            catch(() => {}
            )
          ;
        },

        defaultListName() {
          return `创建于 ${dateFtt('yyyy-MM-dd hh:mm:ss', new Date())}`;
        },

        createChoiceList() {
          this.dialogFormVisible = true;
        },
        confirmForm(formName) {
          this.$refs[formName].validate(valid => {
            if (valid) {
              createHotGoodsList(this.addForm).then(res => {
                this.fetchChoiceList();
                if (res.data.code === 10000) {
                  this.choiceListData.unshift({ choice_list_id: res.data.data.insert_id, list_name: name });
                  this.showQuickAdd = false;
                } else {
                  this.$message({ type: 'error', message: res.data.msg || '添加选品列表失败' });
                }
              })
              ;
              this.dialogFormVisible = false;
            }
          }
          )
          ;
        },
        setOffSale(val) {
          this.offSale = val;
          this.updateStatusInForm();
          this.fetchChoiceList();
        },
        setOnSale(val) {
          this.onSale = val;
          this.updateStatusInForm();
          this.fetchChoiceList();
        },
        updateStatusInForm() {
          if (this.onSale && this.offSale) {
            // 如果上下架状态都要查询，则条件传空，服务器会直接不判断这个条件
            this.formInline.status = '';
          } else if (this.onSale && !this.offSale) {
            this.formInline.status = 1;
          } else if (!this.onSale && this.offSale) {
            this.formInline.status = 0;
          } else if (!this.onSale && !this.offSale) {
            // 如果上下架状态都不选，则服务器会根据这个码直接返回空数据，因为不可能存在这种状态的值
            this.formInline.status = 9999;
          }
        },
        // 分页
        handleSizeChange(pageSize) {
          this.formInline.pageSize = pageSize;
          this.fetchChoiceList();
        },
        // 页码变化时触发
        handleCurrentChange(page) {
          this.formInline.page = page;
          this.fetchChoiceList();
        },
        cancelForm(formName) {
          // this.$refs[formName].resetFields();
          this.dialogFormVisible = false;
        },
        showDetail(data) {
          this.$router.push({
            name: this.appType === 2 ? 'hotDetail' : 'qxbHotDetail',
            params: {
              id: data.id,
              text: data.text,
              shareTime: data.share_time,
              appType: this.appType
            }
          });
        }
      }
    };
</script>

<style lang="scss" scoped>

    .base {
        font-family: "Microsoft YaHei", "微软雅黑", STXihei, "华文细黑", Georgia, "Times New Roman", Arial, sans-serif;
    }

    .list-container {
        display: flex;
        flex-wrap: wrap;
    }

    .choice-list-card {
        margin: 10px;
    }

    .quick-add-container {
        width: 301px;
        height: 203px;
        padding: 30px 5px 20px 5px;

    .input-title {
        font-size: 28px;
        color: #409EFF;
    }

    .input {
        margin-top: 20px;
        font-size: 13px;
    }

    .input-button-container {
        margin-top: 20px;
        text-align: center;

    .input-ok {
        min-width: calc(50% - 8px);
        min-height: 36px;
    }

    .input-cancel {
        min-width: calc(50% - 8px);
        min-height: 36px;
        margin-left: 10px;
    }

    }
    }

</style>