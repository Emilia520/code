<template>
    <div class="filter-list-container">
        <div class="filter-container">
            <span class="filter-key">商品信息</span>
            <el-input class="name-input" placeholder="请输入商品名称或商品ID" v-model="formInline.productName" clearable/>
        </div>
        <div class="filter-container">
            <span class="filter-key">折扣率</span>
            <el-select class='filter-filter' v-model="formInline.discountFilter" placeholder="请选择">
                <el-option v-for="type in sortTypes"
                           :key="type"
                           :label="type"
                           :value="type">
                </el-option>
            </el-select>
            <el-input class="filter-input" :placeholder="_isRangeFilter('discountFilter') ? '最低折扣' : '筛选折扣'" v-model="formInline.discount[0]" clearable/>
            <el-input v-if="_isRangeFilter('discountFilter')" class="filter-input" placeholder="最高折扣" v-model="formInline.discount[1]" clearable/>
            <el-select class='filter-filter' v-model="formInline.discountSort" placeholder="排序" @change="getList">
                <el-option v-for="type in sortMethods"
                           :key="type.id"
                           :label="type.name"
                           :value="type.id">
                </el-option>
            </el-select>
        </div>
        <div class="filter-container">
            <span class="filter-key">加价</span>
            <el-select class="filter-filter" v-model="formInline.addPriceFilter" placeholder="请选择">
                <el-option v-for="type in sortTypes"
                           :key="type"
                           :label="type"
                           :value="type">
                </el-option>
            </el-select>
            <el-input class="filter-input" :placeholder="_isRangeFilter('addPriceFilter') ? '最低加价' : '筛选加价'" v-model="formInline.addPrice[0]" clearable/>
            <el-input v-if="_isRangeFilter('addPriceFilter')" class="filter-input" placeholder="最高加价" v-model="formInline.addPrice[1]" clearable/>
            <el-select class='filter-filter' v-model="formInline.addPriceSort" placeholder="排序" @change="getList">
                <el-option v-for="type in sortMethods"
                           :key="type.id"
                           :label="type.name"
                           :value="type.id">
                </el-option>
            </el-select>
        </div>
        <div class="filter-container">
            <span class="filter-key">价格</span>
            <el-select class="filter-filter" v-model="formInline.priceFilter" placeholder="请选择">
                <el-option v-for="type in sortTypes"
                           :key="type"
                           :label="type"
                           :value="type">
                </el-option>
            </el-select>
            <el-input class="filter-input" :placeholder="_isRangeFilter('priceFilter') ? '最低价格' : '筛选价格'" v-model="formInline.price[0]" clearable/>
            <el-input v-if="_isRangeFilter('priceFilter')" class="filter-input" placeholder="最高价格" v-model="formInline.price[1]" clearable/>
            <el-select class='filter-filter' v-model="formInline.priceSort" placeholder="排序" @change="getList">
                <el-option v-for="type in sortMethods"
                           :key="type.id"
                           :label="type.name"
                           :value="type.id">
                </el-option>
            </el-select>
        </div>
        <div class="filter-container">
            <span class="filter-key">结束日期</span>
            <el-select class='filter-filter' v-model="formInline.endTimeSort" placeholder="排序" @change="getList">
                <el-option v-for="type in sortMethods"
                           :key="type.id"
                           :label="type.name"
                           :value="type.id">
                </el-option>
            </el-select>
        </div>
        <div class="filter-container-checkbox">
            <el-checkbox class="filter-checkbox" v-model="formInline.filterSoldOut" @change="getList">只看有库存</el-checkbox>
            <el-checkbox class="filter-checkbox" v-model="formInline.onSale_only" @change="getList">只看上架</el-checkbox>
            <el-checkbox class="filter-checkbox" v-model="formInline.hyk_only" @change="getList">只看好衣库</el-checkbox>
            <el-checkbox class="filter-checkbox" v-model="formInline.allow_predicate" style="margin-left: 0;" @change="getList">包含预告</el-checkbox>
        </div>
        <div class="filter-container-checkbox">
            <el-checkbox v-model="formInline.easyForMarketing" @change="getList">佣金比和规格数优先</el-checkbox>
            <div class="filter-container-checkbox-tips">勾选后结果按佣金比和SKU从高到低排序，但筛选过程会多耗时一些</div>
        </div>
        <div class="filter-container">
            <el-button class="filter-button" type="primary" @click="filterProducts">筛选</el-button>
        </div>
        <div class="filter-tips">数据默认按照商品"排序"字段从大到小排序</div>
        <div class="category-list-container" v-for="subList in categoryList" :key="categoryList.indexOf(subList)">
            <el-checkbox-group class="category-container" v-model="formInline.categories" v-for="category in subList" :key="category.id" @change="getList">
                <el-checkbox style="min-width: 100px;" :label="category.id"> {{ category.tag_name }}</el-checkbox>
            </el-checkbox-group>
        </div>
    </div>
</template>

<script>
  import { getCatList } from '../../api/groupbuy';

  export default {
    name: 'productFilter',
    created() {
      this._getCategoryList();
    },
    data() {
      return {
        categoryList: [],
        formInline: {
          page: 1,
          pageSize: 50,
          productName: null,
          filterSoldOut: true,
          onSale_only: true,
          hyk_only: false,
          allow_predicate: false,
          easyForMarketing: false,
          categories: [],
          discount: [null, null],
          discountFilter: null,
          discountSort: 0,
          addPrice: [null, null],
          addPriceFilter: null,
          addPriceSort: 0, // 0 无排序, 1 正序, 2 逆序
          price: [null, null],
          priceFilter: null,
          priceSort: 0,
          clickNum: [null, null],
          clickFilter: null,
          clickSort: 0,
          endTimeSort: 0,
        },
        sortTypes: ['=', '>', '>=', '<', '<=', '~', null],
        sortMethods: [{ id: 0, name: '无排序' }, { id: 1, name: '升序' }, { id: 2, name: '降序' }],
      };
    },
    methods: {
      getList() {
        this.formInline.page = 1;
        this.$emit('getList', this.formInline);
      },

      _getCategoryList() {
        this.loading = true;

        getCatList({ appType: 1 }).then(response => {
          const resData = response.data;
          console.log('cat list', resData);
          if (resData.code === 10000) {
            this.categoryList = this._shortenCategories(resData.data);
          }
        });
      },

      filterProducts() {
        this.formInline.page = 1;
        this.getList();
      },

      _isRangeFilter(keyword) {
        if (!this.formInline.hasOwnProperty(keyword)) {
          return false;
        }

        return this.formInline[keyword] === '~';
      },

      _shortenCategories(categoryList) {
        let end = 0;
        const result = [];

        categoryList = categoryList.filter(item => item.tag_name !== '最后疯抢');

        do {
          const len = Math.min(8, categoryList.length - end);
          const subList = categoryList.slice(end, end + len);
          result.push(subList);
          end += len;
        } while (end <= categoryList.length - 1);

        console.log(result);
        return result;
      },
    },
  };
</script>

<style lang="scss" scoped>
    .filter-list-container {
        .filter-container {
            display: flex;
            flex-direction: row;
            align-items: center;
            margin-top: 10px;

            .filter-key {
                font-size: 15px;
                margin-right: 10px;
                min-width: 60px;
            }

            .filter-filter {
                width: 110px;
                margin-right: 5px;
            }

            .filter-sort {
                min-width: 100px;
            }

            .name-input {
                width: 350px;
                margin-right: 5px;
            }

            .filter-input {
                width: 120px;
                margin-right: 5px;
            }

            .filter-button {
                min-width: 420px;
            }
        }

        .filter-tips {
            font-size: 12px;
            color: lightcoral;
            margin-top: 5px;
            margin-bottom: 20px;
        }

        .filter-container-checkbox {
            width: 420px;
            padding: 20px;
            border: solid #eee 1px;
            margin-top: 10px;
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            flex-wrap: wrap;
            align-items: flex-start;

            &:hover {
                border: solid #579ff8 1px;
            }

            .filter-checkbox {
                margin-bottom: 5px;
            }

            .filter-container-checkbox-tips {
                font-size: 12px;
                color: lightcoral;
                margin-top: 5px;
            }
        }

        .category-list-container {
            display: flex;
            flex-direction: row;
            align-items: flex-start;

            .category-container {
                margin-top: 5px;
            }
        }
    }

</style>