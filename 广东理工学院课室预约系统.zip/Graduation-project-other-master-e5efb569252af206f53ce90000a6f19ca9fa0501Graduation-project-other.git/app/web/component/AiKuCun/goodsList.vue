<template>
    <div v-loading="loadingGoods">
      <el-button style="position: absolute;left: 1500px;top: -3px;" @click="modifyBrand()">修改商品所属品牌</el-button>
       <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
        <div class="goods_wrapper">

            <el-card class="goods_card" :body-style="{ padding: '0px' }" v-for="(goods,index) in tableData" :key="goods.id" >
             <el-checkbox-group v-model="isChoice" @change="handleCheckedIdChange">
              <el-checkbox  :label="tableData[index].id" size="medium"></el-checkbox>
             </el-checkbox-group>
                <div class="wrapper">
                    <div class="picture">
                        <div style="width: 185px; height: 180px;">
                            <img class="big-picture" :src="goods.pictures[0]" alt="暂无图片">
                        </div>
                        <div class="small-picture">
                            <div>
                                <img :src="goods.pictures[1]" alt="暂无图片">
                            </div>
                            <div>
                                <img :src="goods.pictures[2]" alt="暂无图片">
                            </div>
                            <div>
                                <img :src="goods.pictures[3]" alt="暂无图片">
                            </div>
                        </div>
                    </div>
                    <div class="content">
                        <h1>{{goods.name}}</h1>
                        <p>商品ID: {{ goods.id }}</p>
                      
						<p v-if=" goods.qxb_status === 0"> 下架中</p>
                        <p v-if="goods.qxb_status === 1"> 上架中</p>
                        <p>供应商品牌名： {{goods.supBrandName}}</p>
                        <p>品牌库品牌名： {{goods.ownBrandName}}</p>                        <p>
                            <span>{{goods.description}}</span>
                        </p>                        <div class="price">
                            <div>
                                <span style="font-size:20px;">¥{{goods.settlement_price}}</span>
                                <span class="line-through">¥{{goods.akc_tag_price}}</span>
                            </div>
                            <span style="font-size:14px;">佣金:{{goods.akc_profit}} (加价：¥{{goods.add_price}})</span>
                        </div>
                        <div class="sku">
                            <div class="sku-box">
                                <ul>
                                    <li v-for="sku in goods.skuList" :key="sku.skuId">
                                        <span>{{sku}}</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="button-area">
                          <div class="button" @click.prevent="onEdit(goods)">
                            编 辑
                          </div>
                          <el-button type="danger" plain @click="onUpdateDataStatus(goods)">上下架</el-button>
                          <div class="stock">
                            库存: {{goods.stock}}件
                          </div>
                        </div>
                    </div>
                </div>
            </el-card>
        </div>
        <!-- 弹层 start -->
        <el-dialog :title="dialogFormTitle" :visible.sync="dialogFormVisible" width="300" @close="cancelForm">
          <el-form :model="addForm" :rules="rules" ref="addForm">
            <el-form-item label="ID" :label-width="formLabelWidth" prop="id">
              <el-input :disabled="true" v-model="addForm.id" placeholder="ID" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="商品描述" :label-width="formLabelWidth" prop="name">
              <el-input v-model="addForm.name" placeholder="商品描述" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item v-if="$store.getters.role < 3" label="建议零售价" :label-width="formLabelWidth" prop="akcPrice">
              <el-input :disabled="true" v-model.number="addForm.akcPrice" placeholder="建议零售价" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item v-if="$store.getters.role < 3" label="结算价" :label-width="formLabelWidth" prop="akcSettlementPrice">
              <el-input :disabled="true" v-model.number="addForm.akcSettlementPrice" placeholder="结算价" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item label="排序" :label-width="formLabelWidth" prop="sort">
              <el-input v-model.number="addForm.sort" placeholder="排序" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item v-if="$store.getters.role < 5 && addForm.goods && (addForm.goods.type === 0 || addForm.goods.type === 4)" label="加价" :label-width="formLabelWidth" prop="addPrice">
              <el-input v-model.number="addForm.addPrice" placeholder="加价" size="mini" clearable></el-input>
            </el-form-item>
            <el-form-item v-if="$store.getters.role < 5" label="佣金(%)" :label-width="formLabelWidth" prop="commissionRatio">
              <el-radio-group v-model="chooseCommission"  @change="chooseCommissionType" >
                <el-radio :label="0" >
                  佣金比例(%)：<el-input v-model.number="addForm.commissionRatio"  size="mini" :disabled="chooseCommissionHidden" />
                </el-radio>
                <br>
                <el-radio :label="1" >
                  <span style="color:red;"> 恢复默认佣金 </span>
                </el-radio>
                <br>
                <el-radio :label="-1" >
                  <span style="color:green;"> 不修改佣金 </span>
                </el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="标签" :label-width="formLabelWidth" prop="tag">
              <el-select v-model="addForm.tag" size="small">
                <el-option
                        v-for="item in labels"
                        :key="item.id"
                        :label="item.label"
                        :value="item.id">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="商品首图" class="time-width"  label-width="120px">
              <el-upload
                class="avatar-uploader"
                :action="uploadImg"
                :show-file-list="false"
                :on-success="handleAvatarSuccess"
                :list-type="addForm.image ? '' : 'picture-card'">
                <img v-if="addForm.image" :src="addForm.image" class="avatar" width="120" height="120">
                <i v-else class="el-icon-plus"></i>
              </el-upload>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="cancelForm('addForm')">取 消</el-button>
            <el-button type="primary" @click="confirmForm('addForm')">确 定</el-button>
          </div>
        </el-dialog>
        <!-- 弹层 end -->
        <!-- 修改商品所属品牌弹层 start -->
          <el-dialog title="修改商品所属品牌" :visible.sync="dialogModifyBrand" width="500px" @close="cancelModifyBrand">
            <div class="isEditBrand">
              <el-form>
                <el-form-item label="品牌名:">
                  <el-select v-model="editBrand.brand_id" filterable remote placeholder="请输入关键词" :remote-method="remoteMethod" :loading="loading" style="width:265px;margin-right:70px;">
                      <el-option v-for="item in options" :key="item.id" :label="item.brand_name" :value="item.id" />
                  </el-select>
                </el-form-item>
                  <el-button type="primary" @click="editBrandType(editBrand)" @keyup.enter="editBrandType(editBrand)">确 定</el-button>
                  <el-button @click="cancelModifyBrand()">取 消</el-button>
              </el-form>
            </div>
          </el-dialog>
        <!-- 修改商品所属品牌弹层 end -->
          <el-backtop >
                <div>回到顶部</div>
          </el-backtop>
    </div>
</template>

<script>

  import { getGoodsList, updateGoodsInfo, updateSaleStateOnGoods, batchGoodsBindOwnBrand } from '@/api/groupbuy';
  import { uploadImg } from '@/api/uploadImg';
  import { searchName } from '@/api/brand';
  export default {
    name: 'akc-goods-list',
    props: {
      confirmBtnTitle: {
        type: String,
        default: '添加爆款'
      },
      cancelBtnTitle: {
        type: String,
        default: '取消爆款'
      },
      appType: {
        type: Number,
        default: 0
      }
    },
    data: () => {
      return {
        // 0: 默认100%， 1:恢复最低佣金， -1:不修改佣金
        chooseCommission: 0,
        chooseCommissionHidden: false,
        updateData: {},
        tableData: [],
        checkBoxList: [],
        uploadImg,
        loadingGoods: false,
        formInline: {
          page: 1,
          pagesize: 30
        },
        addForm: {
          goods: null,
          id: 0,
          name: '',
          akcPrice: 0,
          akcSettlementPrice: 0,
          settlementPrice: 0,
          addPrice: 0,
          commissionRatio: 0,
          image: '',
          sort: 0,
  
          tag: 0,
          brand_id: undefined,
        },
        rules: {
          addPrice: [{ required: true, message: '请输入加价金额', trigger: 'blur' },
            { type: 'number', min: 0, max: 999, message: '金额为数字值，且范围为0～999' }],
          commissionRatio: [{ required: true, message: '请输入佣金比例', trigger: 'blur' },
            { type: 'number', min: 0, max: 100, message: '填写数字 0~100' }],
          sort: [{ required: true, message: '请输入排序（数字越大越靠前）', trigger: 'blur' },
            { type: 'number', min: 0, max: 999999, message: '排序为数字值，且范围为0～999999' }],
          name: [{ required: true, message: '请输入商品标题描述', trigger: 'blur' }],
          image: [{ required: true, message: '请上传商品首图', trigger: 'blur' }]
        },
        formLabelWidth: '100px',
        dialogFormVisible: false,
        dialogFormTitle: '商品编辑',
        dialogModifyBrand: false, // 修改商品所属品牌
        isIndeterminate: false,
        checkAll: false,
        loading: false,
        searchName: [], // 品牌名查询模糊搜索
        options: [], // 品牌名模糊搜索
        isChoice: [],
        checkedCities: [],
        editBrand: {
          brand_id: undefined,
          goods_ids: []
        },
        ownActivityId: 0,
        // 1- “爆款” 2- “新品” 3- “精选” 4- “大牌” 7- “秒杀”
        labels: [{ id: 0, label: '无' }, { id: 1, label: '爆款' }, { id: 2, label: '新品' }, { id: 3, label: '精选' }, { id: 4, label: '大牌' }, { id: 7, label: '秒杀' }],
      };
    },
    methods: {
      chooseCommissionType(value) {
        this.chooseCommissionHidden = value !== 0;
      },
      didPresent(actId, force = false) {
        console.log(`appType: ${this.appType}`);
        this.ownActivityId = actId;
        if (this.tableData.length === 0 || force) {
          this.getList();
        }
      },
      getList() {
        const actId = this.ownActivityId;
        this.loadingGoods = true;
        // 请求列表
        getGoodsList({ actId, appType: this.appType }).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            for (const i in res.data) {
              const data = res.data[i];
              data.pictures = JSON.parse(data.picture);
              const skuList = [];
              const skus = JSON.parse(data.sku_list);
              for (const j in skus) {
                const sku = skus[j];
                let str = '';
                for (const k in sku.attributeList) {
                  const attr = sku.attributeList[k];
                  if (attr.attributeName === '尺码') {
                    str += attr.attributeValue + '码';
                  }
                  if (attr.attributeName === '颜色') {
                    str += attr.attributeValue;
                  }
                }
                skuList.push(str);
              }

              data.skuList = skuList;
            }

            this.tableData = res.data;
            console.log(this.tableData);
            this.searchNameList();
          } else {
            this.tableData = [];
          }
          this.loadingGoods = false;
        });
      },
      onUpdateDataStatus(goods) {
        const updateData = {
          id: goods.id,
          raelId: goods.real_goods_id,
          appType: 1,
          status: Number(goods.qxb_status) === 1 ? 0 : 1
        };

        updateSaleStateOnGoods(updateData).then(response => {
          const res = response.data;
          if (res.code === 10000) {
            this.$message('修改状态成功');
            this.getList();
          } else {
            this.$message(res.message);
          }
        });
      },
      onEdit(goods) {
        console.log(goods);
        this.addForm.goods = goods;
        this.addForm.id = goods.id;
        this.addForm.name = goods.name;
        this.addForm.akcPrice = goods.akc_price;
        this.addForm.akcSettlementPrice = goods.akc_settlement_price;
        this.addForm.addPrice = goods.add_price;
        this.addForm.akc_price = goods.akc_price; 
        this.addForm.commissionRatio = 100;
        this.addForm.tag = goods.label;
        this.addForm.sort = this.appType === 1 ? goods.qxb_sort : goods.sort;
        this.addForm.image = goods.pictures[0];
        this.addForm.type = goods.type;
        this.addForm.settlementPrice = goods.settlement_price;
        this.dialogFormVisible = true;
      },
      confirmForm(formName) {
        console.log(this.addForm);
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.loading = true;
            const addPrice = this.addForm.addPrice;
            const akcPrice = this.addForm.akc_price;
            const settlementPrice = this.addForm.type === 0 || this.addForm.type === 4 ? (akcPrice + addPrice) : this.addForm.settlementPrice;
            const goods = this.addForm.goods;
            const name = this.addForm.name;
            const image = this.addForm.image;
            const sort = this.addForm.sort;
            const commissionRatio = this.addForm.commissionRatio;
            const akcSettlementPrice = this.addForm.akcSettlementPrice;
            const label = this.addForm.tag;
            // 选择增加佣金比例/恢复最低佣金
            const chooseCommission = this.chooseCommission;
            const pictures = goods.pictures.slice();
            pictures[0] = image;
            updateGoodsInfo({ appType: this.appType, id: this.addForm.id, name, addPrice, akcPrice, commissionRatio, akcSettlementPrice, akcTagPrice: goods.akc_tag_price, sort, label, settlementPrice, picture: JSON.stringify(pictures), chooseCommission }).then(response => {
              const res = response.data;
              if (res.code === 10000) {
                this.$message({
                  message: '操作成功',
                  type: 'success'
                });
                goods.add_price = parseFloat(parseFloat(addPrice).toFixed(2));
                goods.settlement_price = parseFloat(parseFloat(settlementPrice).toFixed(2));
                goods.name = name;
                goods.pictures = pictures;
                goods.label = label;
                if (this.appType === 1) {
                  goods.qxb_sort = sort;
                } else {
                  goods.sort = sort;
                }
                // this.$refs[formName].resetFields();
                this.dialogFormVisible = false;
                this.getList();
              } else {
                this.$message({
                  message: '操作失败',
                  type: 'fail'
                });
              }
              this.loading = false;
            });
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
      // 查询品牌分类
      searchNameList() {
        searchName().then(response => {
          const resData = response.data;
          if (resData.code === 10000) {
            this.searchName = resData.data;
          }
        });
      },
      remoteMethod(query) {
        if (query !== '') {
          this.loading = true;
          setTimeout(() => {
            this.loading = false;
            this.options = this.searchName.filter(item => {
              return item.brand_name.toLowerCase().indexOf(query.toLowerCase()) > -1;
            });
          }, 200);
        } else {
          this.options = [];
        }
      },
      cancelForm(formName) {
      // this.$refs[formName].resetFields();
        this.dialogFormVisible = false;
      },
      cancelModifyBrand() {
        this.dialogModifyBrand = false;
      },
      handleAvatarSuccess(res, file) {
        console.log('上传图片：', res.data);
        this.addForm.image = res.data;
      },
      handleCheckAllChange(val) {
        for (const i in this.tableData) {
          this.checkBoxList.push(this.tableData[i].id);
        }
        if (val === true) {
          this.isChoice = this.checkBoxList;
        } else {
          this.isChoice = this.checkBoxList = [];
        }
        console.log(this.isChoice);
        this.isIndeterminate = false;
      },
      handleCheckedIdChange(value) {
        if (value.length !== 0) {
          this.isIndeterminate = true;
        } else {
          this.isIndeterminate = false;
        }
        console.log(this.isChoice);
      },
      // 修改分类所属品牌按钮
      modifyBrand() {
        if (this.isChoice.length !== 0) {
          this.dialogModifyBrand = true;
          this.options = [];
          this.editBrand.brand_id = undefined;
          this.editBrand.goods_ids = this.isChoice;
        } else {
          this.$message('请选择要修改的品牌');
          this.dialogModifyBrand = false;
        }

      },
      editBrandType(params) {
        console.log(params);
        batchGoodsBindOwnBrand(params).then(response => {
          const resData = response.data;
          if (resData.code === 10000) {
            this.$message(resData.msg);
            this.getList();
            this.dialogModifyBrand = false;
            this.isChoice = [];
            this.isIndeterminate = false;
          } else {
            this.$message(resData.msg);
          }
        });
      }
    }
  };
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .goods_wrapper {
        width: 100%;
        display: -webkit-flex;
        display: flex;
        margin-top: 30px;
        flex-direction: row;
        flex-wrap: wrap;
        .goods_card {
            margin: 0 45px 15px 0;
            border: 1px solid;
            box-shadow: 0 1px 5px 0 rgba(2,15,29,-4.82);
            .wrapper {
                display: flex;
                -webkit-box-pack: justify;
                -ms-flex-pack: justify;
                justify-content: space-between;
                margin: 4px;
                padding: 15px 20px;
                width: 513px;
                height:400px;
                overflow: hidden;
                .picture {
                    width: 185px;
                    .big-picture {
                        width: 100%;
                        height: 100%;
                    }
                    .small-picture {
                        display: flex;
                        flex-wrap: nowrap;
                        -webkit-box-pack: justify;
                        justify-content: space-between;
                        margin-top: 5px;
                        div {
                            width: 60px;
                            height: 60px;
                            img {
                                width: 100%;
                                height: 100%;
                            }
                        }
                    }
                }
                .content {
                    position: relative;
                    width: 270px;
                    text-align: left;
                    h1 {
                        margin-bottom: 10px;
                        font-size: 15px;
                        font-weight: 700;
                        color: #2d2d2d;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                        height: 21px;
                    }
                    p { 
                        font-size: 13px;
                        line-height: 17px;
                        font-weight: 400;
                        color: #262626;
                        span {
                          display: -webkit-box;
                          -webkit-box-orient: vertical;
                          -webkit-line-clamp: 3;
                          overflow: hidden;
                          
                        }
                    }
                    .price {
                        margin: 5px 0;
                        display: flex;
                        color: #f1394d;
                        flex-wrap: nowrap;
                        -webkit-box-pack: justify;
                        justify-content: space-between;
                        -webkit-box-align: end;
                        align-items: flex-end;
                        height: 28px;
                        .line-through {
                            color: #8d8d8d;
                            font-size: 11px;
                            text-decoration: line-through;
                        }
                    }
                    .sku {
                        .sku-box {
                            max-height: 50px;
                            overflow: auto;
                            ul li {
                                display: inline-block;
                                margin: 0 10px 5px 0;
                                padding: 0 5px;
                                max-width: 260px;
                                height: 22px;
                                text-align: center;
                                line-height: 22px;
                                color: #262626;
                                font-size: 12px;
                                background: #f2f1f1;
                            }
                        }
                    }
                    .button-area {
                      margin: 5px 0;
                      display: flex;
                      justify-content: space-between;
                      height: 32px;
                      .button {
                        // position: absolute;
                        // right: 0;
                        // bottom: 0;
                        display: flex;
                        -webkit-box-pack: center;
                        justify-content: center;
                        -webkit-box-align: center;
                        align-items: center;
                        width: 100px;
                        height: 32px;
                        color: #fff;
                        background: #f1394d;
                        border: 1px solid #f1394d;
                        border-radius: 4px;
                        cursor: pointer;
                      }
                      .stock {
                        // position: absolute;
                        // right: 0;
                        // bottom: 0;
                        display: flex;
                        -webkit-box-pack: center;
                        justify-content: center;
                        -webkit-box-align: center;
                        align-items: center;
                        width: 100px;
                        height: 32px;
                        line-height: 30px;
                        color: #f1394d;
                      }
                    }
                }
            }
        }
    }
    .isEditBrand{
       text-align:center;
    }
</style>
