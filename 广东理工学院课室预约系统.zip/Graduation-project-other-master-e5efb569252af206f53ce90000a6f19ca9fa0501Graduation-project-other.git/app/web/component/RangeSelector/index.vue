<template>
    <div class="range-selector">
        <div class="filter-wrapper ">
            <span class="label">{{label}}</span>
            <div class="filter-input-wrapper">
                <input type="text" v-model="range[0]" @blur="notify()">
                <span>{{unit}}</span>
            </div>
            <span class="blank">-</span>
            <div class="filter-input-wrapper">
                <input type="text" v-model="range[1]" @blur="notify()">
                <span>{{unit}}</span>
            </div>
        </div>
    </div>
</template>

<script>
export default {
  name: 'range-selector',
  model: {
    prop: 'range',
    event: 'change'
  },
  props: {
    unit: {
      type: String,
      default: ''
    },
    label: {
      type: String,
      default: ''
    },
    range: {
      type: Array,
    }
  },
  methods: {
    notify() {
      this.$emit('change', this.range);
    }
  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.range-selector {
    width: 270px;
    position: relative;

    .filter-wrapper {
        width: 395px;
        position: relative;
        background-color: #fff;
        z-index: 0;
        height: 50px;
        display: flex;
        align-items: center;
        color: #606266;
        box-sizing: border-box;
        margin: 0px;
        padding: 0px;
        .label {
            display: block;
            margin-left: 20px;
        }
        span {
            line-height: 50px;
        }
        .filter-input-wrapper {
            width: 90px;
            height: 30px;
            border: 1px solid #eee;
            border-radius: 2px;
            padding-left: 10px;
            box-sizing: border-box;
            display: flex;
            align-items: center;
            input {
                font-size: 14px;
                line-height: 14px;
                width: 40px;
                height: 100%;
                margin-right: 10px;
                color: #898989;
                resize: none;
                border: 0;
                outline: 0;
                -webkit-appearance: none;
                overflow: visible;
                font-family: inherit;
            }
            span {
                color: #ababab;
                font-size: 14px;
                width: 30px;
                height: 28px;
                line-height: 28px;
                text-align: center;
                border-left: 1px solid #eee;
                background: #f9f9f9;
            }
            .blank {
                margin: 0 5px;
                color: #999;
            }
        }
        .button-wrapper {
            display: none;
            span:first-child {
                height: 28px;
                border: 1px solid #e3544c;
                border-radius: 3px;
                color: #fff;
                background-color: #e3544c;
                text-align: center;
                width: 50px;
            }
            span {
                font-size: 14px;
                line-height: 30px;
                cursor: pointer;
            }
        }
        .options {
            display: none;
            width: 100%;
            ul {
                width: 100%;
                border-top: 1px solid;
                margin-bottom: 0;
                list-style: none;
                display: block;
                margin-block-start: 1em;
                margin-block-end: 1em;
                margin-inline-start: 0px;
                margin-inline-end: 0px;
                padding-inline-start: 40px;
                li {
                    font-size: 14px;
                    width: 100%;
                    height: 40px;
                    line-height: 40px;
                    box-sizing: border-box;
                    padding-left: 20px;
                    display: list-item;
                    text-align: -webkit-match-parent;
                }
            }
        }
    }
}

</style>

