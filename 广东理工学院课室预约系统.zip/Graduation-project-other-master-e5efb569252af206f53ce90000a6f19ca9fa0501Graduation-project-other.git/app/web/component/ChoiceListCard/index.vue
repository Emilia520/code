<template xmlns:v-on="http://www.w3.org/1999/xhtml">
    <el-card class="card" shadow="hover" body-style="padding:0">
        <div class="container" v-on:click="onClick">
            <div class="close-container">
                <i class="el-icon-close" style="height: 24px; width: 24px;" @click.stop="onDelete"></i>
            </div>
            <div class="card-title">{{data.list_name}}</div>
            <div class="count-container">
                <span class="card-count-title">商品数量:  </span>
                <span class="card-count">{{Array.isArray(data.item_list) ? data.item_list.length : 0}} </span>
            </div>
            <div class="pic-container">
                <div class="empty-container" v-show="!Array.isArray(data.item_list) || data.item_list.length === 0">
                    <p class="empty">空</p>
                </div>
                <div class="item-pic-col" v-if="Array.isArray(data.item_list) && data.item_list.length !== 0">
                    <img class="item-pic" v-for="item in (data.item_list.slice(0, 5))" :src="item.pic_url"/>
                </div>
            </div>
            <div class="footer-container">
                <slot name = footer></slot>
            </div>
        </div>
    </el-card>
</template>

<script>
  export default {
    name: 'choice-list-card',

    props: {
      data: {
        type: Object,
        default: null,
      },
    },

    methods: {
      onDelete() {
        this.$emit('delete', this.data);
      },

      onClick() {
        this.$emit('click', this.data);
      }
    }
  };
</script>

<style lang="scss" scoped>

    .container {
        font-family: "Microsoft YaHei", "微软雅黑", STXihei, "华文细黑", Georgia, "Times New Roman", Arial, sans-serif;

        .close-container {
            height: 32px;
            padding-top: 10px;
        }

        .card-title {
            white-space: nowrap;
            text-overflow: ellipsis;
            font-size: 16px;
            color: #666;
            padding: 10px 20px 0;
        }

        .el-icon-close {
            position: relative;
            left: 311px;
            visibility: hidden;
        }

        .count-container {
            padding-left: 20px;
            margin-top: 16px;
            margin-bottom: 10px;

            .card-count-title {
                color: #999;
                font-size: 12px;
            }

            .card-count {
                color: #333;
                font-size: 12px;
            }
        }

        .pic-container {
            padding: 10px;
            background-color: #FAFAFA;
            width: 342px;
            height: 88px;
            overflow: hidden;
            margin: 30px 0;

            .empty-container {
                width: 58px;
                height: 58px;
                background-color: #F0F0F0;
                margin: 0;
                padding: 12px;

                .empty {
                    font-size: 30px;
                    color: white;
                    margin: 0;
                    text-align: center;
                }
            }

            .item-pic-col {
                height: 72px;
                width: 72px;
                display: inline-flex;

                .item-pic {
                    width: 100%;
                    height: 100%;
                    object-fit: contain;
                    margin-right: 10px;
                }
            }
        }
    }

    .container:hover {
        .card-title {
            color: #409EFF;
        }

        .el-icon-close {
            color: #999;
            position: relative;
            left: 311px;
            visibility: visible;
        }
    }

</style>