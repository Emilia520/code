// app/controller/test.js
const Controller = require('egg').Controller;

class LoginController extends Controller {
  async auth() {
    const body = this.ctx.request.body;
    const username = body.username;
    const password = body.password;
    const result = await this.ctx.service.auth.verifyUserInfo(username, password);
    this.ctx.body = result;
  }
}

module.exports = LoginController;