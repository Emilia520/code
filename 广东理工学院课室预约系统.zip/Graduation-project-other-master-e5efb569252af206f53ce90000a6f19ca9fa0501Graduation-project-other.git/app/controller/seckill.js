const Controller = require('egg').Controller;

class SeckillController extends Controller {
  // 获取秒杀列表
  async getSeckillList() {
    const ctx = this.ctx;
    const result = await ctx.service.seckill.getSeckillList(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
    ctx.body.data = result.data;
  }

  // 创建秒杀记录
  async createSeckillLists() {
    const ctx = this.ctx;
    const result = await ctx.service.seckill.createSeckillLists(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
    ctx.body.data = result.data;
  }

  // 添加商品到秒杀活动
  async addProductToSeckillList() {
    const ctx = this.ctx;
    const result = await ctx.service.seckill.addProductToSeckillList(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
    ctx.body.data = result.data;
  }

  // 更新秒杀记录中的一个商品
  async updateProductInSeckillList() {
    const ctx = this.ctx;
    const result = await ctx.service.seckill.updateProductInSeckillList(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
    ctx.body.data = result.data;
  }

  // 删除秒杀商品
  async removeProductFromSeckillList() {
    const ctx = this.ctx;
    const result = await ctx.service.seckill.removeProductFromSeckillList(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
  }
}

module.exports = SeckillController;