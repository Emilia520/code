'use strict';

const Controller = require('egg').Controller;

class ExhistoryController extends Controller {
  async historyList() {
    const ctx = this.ctx;
    const result = await ctx.service.exhistory.historyList(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
      total:result.total
    }
  }

  async selectAppiont() {
    const ctx = this.ctx;
    const result = await ctx.service.exhistory.selectAppiont(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
      stotal:result.stotal
    }
  }
}

module.exports = ExhistoryController;
