/**
 * 选品列表相关接口
 * @type {module:egg.Controller}
 */

const Controller = require('egg').Controller;

class ChoiceListController extends Controller {
  async addChoiceList() {
    const ctx = this.ctx;
    const listName = ctx.request.body.list_name;
    const result = await ctx.service.choicelist.addChoiceList(listName);

    ctx.body = {};
    ctx.body.msg = result.msg;
    ctx.body.code = result.code;
    ctx.body.data = result.data;
  }

  async choiceList() {
    const ctx = this.ctx;
    const listName = ctx.request.body.list_name;
    const result = await ctx.service.choicelist.choiceList(listName);

    ctx.body = {};
    ctx.body.data = result;
    ctx.body.msg = '';
    ctx.body.code = 10000;
  }

  async choiceListCalendar() {
    const ctx = this.ctx;
    const params = ctx.request.body;
    const result = await this.ctx.service.choicelist.choiceListCalendar(params);

    ctx.body = {};
    ctx.body.data = result;
    ctx.body.msg = result.msg;
    ctx.body.code = result.code;
  }

  async copyChoiceList() {
    const ctx = this.ctx;
    const dateTime = ctx.request.body.date_time;
    const offerPos = ctx.request.body.offer_pos;
    const choiceList = ctx.request.body.choice_list;
    const result = await this.ctx.service.choicelist.copyChoiceList(dateTime, offerPos, choiceList);

    ctx.body = {};
    ctx.body.data = result;
    ctx.body.msg = '';
    ctx.body.code = 10000;
  }

  async deleteChoiceList() {
    const ctx = this.ctx;
    const choiceList = ctx.request.body.choice_list;
    const offerPos = ctx.request.body.offer_pos || -1;
    const dateTime = ctx.request.body.date_time || -1;
    const result = await ctx.service.choicelist.deleteChoiceList(choiceList, offerPos, dateTime);

    ctx.body = {};
    ctx.body.data = result.data;
    ctx.body.msg = result.msg;
    ctx.body.code = result.code;
  }

  async optChoiceListItem() {
    const ctx = this.ctx;
    const choiceList = ctx.request.body.choice_list;
    const itemList = ctx.request.body.item_list;
    const opt = ctx.request.body.opt;
    const result = await ctx.service.choicelist.optChoiceListItem(choiceList, itemList, opt);

    ctx.body = {};
    ctx.body.data = result.data;
    ctx.body.msg = result.msg;
    ctx.body.code = result.code;
  }

  async detail() {
    const ctx = this.ctx;
    const result = await ctx.service.choicelist.detail(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
    ctx.body.data = result.info;
  }

  async addCalendar() {
    const ctx = this.ctx;
    const result = await ctx.service.choiceList.addCalendar(ctx.request.body);

    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
  }
}

module.exports = ChoiceListController;