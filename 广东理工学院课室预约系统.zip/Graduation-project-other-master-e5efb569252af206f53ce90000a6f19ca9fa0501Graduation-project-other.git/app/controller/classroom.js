'use strict';

const Controller = require('egg').Controller;

class ClassroomController extends Controller {
  async checkClass() {
    const ctx = this.ctx;
    const result = await ctx.service.classroom.checkClass(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
      total: result.total
    };
  }
  async deletClass() {
    const ctx = this.ctx;
    const result = await ctx.service.classroom.deletClass(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
    };
  }
  async addClass() {
    const ctx = this.ctx;
    const result = await ctx.service.classroom.addClass(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
    };
  }

  async selectAll() {
    const ctx = this.ctx;
    const result = await ctx.service.classroom.selectAll(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
      stotal: result.stotal
    };
  }
  async updateState() {
    const ctx = this.ctx;
    const result = await ctx.service.classroom.updateState(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
    };
  }
}

module.exports = ClassroomController;
