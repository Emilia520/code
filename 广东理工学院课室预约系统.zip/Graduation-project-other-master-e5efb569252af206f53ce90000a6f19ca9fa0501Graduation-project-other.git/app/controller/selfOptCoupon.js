const Controller = require('egg').Controller;

class SelfOptCouponController extends Controller {
  // 优惠券列表
  async couponList() {
    const ctx = this.ctx;
    const result = await ctx.service.selfOptCoupon.couponList(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
    ctx.body.data = result.data;
    ctx.body.totalCount = result.totalCount;
  }

  // 新增优惠券
  async addCoupon() {
    const ctx = this.ctx;
    const result = await ctx.service.selfOptCoupon.addCoupon(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
  }

  // 更新优惠券
  async updateCoupon() {
    const ctx = this.ctx;
    const result = await ctx.service.selfOptCoupon.updateCoupon(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
  }

  async productsOverallIDs() {
    const ctx = this.ctx;
    const result = await ctx.service.selfOptCoupon.productsOverallIDs(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
    ctx.body.data = result.data;
  }

  // 根据类型获取优惠券的关联数据
  async couponAttachments() {
    const ctx = this.ctx;
    const result = await ctx.service.selfOptCoupon.couponAttachments(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
    ctx.body.data = result.data;
    ctx.body.totalCount = result.totalCount;
  }

  // 优惠券的查询关键字
  async couponSearchKeywords() {
    const ctx = this.ctx;
    const result = await ctx.service.selfOptCoupon.couponSearchKeywords(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
    ctx.body.data = result.data;
  }
}

module.exports = SelfOptCouponController;
