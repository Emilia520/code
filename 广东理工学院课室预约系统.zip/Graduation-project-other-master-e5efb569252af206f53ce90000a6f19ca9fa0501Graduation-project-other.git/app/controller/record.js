'use strict';

const Controller = require('egg').Controller;

class RecordController extends Controller {
  async historyRecord() {
    const ctx = this.ctx;
    const result = await ctx.service.record.historyRecord(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
      total:result.total
    }
  }

  async updateState() {
    const ctx = this.ctx;
    const result = await ctx.service.record.updateState(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
    }
  }

  async findRecord() {
    const ctx = this.ctx;
    const result = await ctx.service.record.findRecord(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
      searchTotal:result.searchTotal
    }
  }

}
module.exports = RecordController;
