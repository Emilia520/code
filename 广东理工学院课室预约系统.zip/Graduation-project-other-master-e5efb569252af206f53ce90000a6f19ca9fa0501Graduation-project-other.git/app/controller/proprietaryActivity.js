const Controller = require('egg').Controller;

class ProprietaryActivity extends Controller {
  // 获取活动列表
  async getActivityList() {
    const ctx = this.ctx;
    const result = await ctx.service.proprietaryActivity.getActivityList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.data = result.list;
    ctx.body.totalCount = result.totalCount;
    ctx.body.msg = '成功';
  }

  // 获取活动
  async getActivityListById() {
    const ctx = this.ctx;
    const result = await ctx.service.proprietaryActivity.getActivityListById(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.data = result.list;
    ctx.body.msg = '成功';
  }
  // 获取活动商品
  async getGoodsList() {
    const ctx = this.ctx;
    const result = await ctx.service.proprietaryActivity.getGoodsList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.data = result.list;
    ctx.body.msg = '成功';
  }
  // 更新活动文案
  async updateActivityListById() {
    const ctx = this.ctx;
    const result = await ctx.service.proprietaryActivity.updateActivityListById(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }
  // 创建活动
  async createActivity() {
    const ctx = this.ctx;
    const result = await ctx.service.proprietaryActivity.createActivity(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }
  // 更新活动商品
  async updateGoods() {
    const ctx = this.ctx;
    const result = await ctx.service.proprietaryActivity.updateGoods(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }
  // 删除活动商品
  async deleteGoods() {
    const ctx = this.ctx;
    const result = await ctx.service.proprietaryActivity.deleteGoods(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }
  // 添加商品
  async createGoods() {
    const ctx = this.ctx;
    const result = await ctx.service.proprietaryActivity.createGoods(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }
  // 获取商品详情
  async getGoodsById() {
    const ctx = this.ctx;
    const result = await ctx.service.proprietaryActivity.getGoodsById(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.data = result.list;
    ctx.body.msg = '成功';
  }
  // 检查商品
  async checkGoods() {
    const ctx = this.ctx;
    const result = await ctx.service.proprietaryActivity.checkGoods(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.data = result.list;
    ctx.body.msg = '成功';
  }
  // 更新活动规则
  async updateActivityListRoleById() {
    const ctx = this.ctx;
    const result = await ctx.service.proprietaryActivity.updateActivityListRoleById(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.data = result.list;
    ctx.body.msg = '成功';
  }
}

module.exports = ProprietaryActivity;