'use strict';

const Controller = require('egg').Controller;

class UserRoleController extends Controller {
  async userInfo() {
    const ctx = this.ctx;
    const result = await ctx.service.userRole.userInfo(ctx.request.body);
    ctx.body = {
        msg: result.msg,
        code: result.code,
        data: result.data,
        total:result.total
    }
  }

  async selectInfo() {
    const ctx = this.ctx;
    const result = await ctx.service.userRole.selectInfo(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
      stotal:result.stotal
    }
  }

  async userRecord() {
    const ctx = this.ctx;
    const result = await ctx.service.userRole.userRecord(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
  
    }
  }
}

module.exports = UserRoleController;
