const Controller = require('egg').Controller;
const Excel = require('exceljs');

class StatisticsController extends Controller {
  async newerInfo() {
    const ctx = this.ctx;
    const result = await ctx.service.statistics.newerInfo(ctx.request.body);
    console.log('result.total ', result.totalCount);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.totalCount = result.totalCount;
    ctx.body.data = result.list;
  }

  async exportNewerInfo() {
    const ctx = this.ctx;
    ctx.query.pageNum = parseInt(ctx.query.pageNum);
    ctx.query.pageSize = parseInt(ctx.query.pageSize);
    const result = await ctx.service.statistics.newerInfo(ctx.query);
    const workbook = new Excel.Workbook();
    const worksheet = workbook.addWorksheet('小店数据');
    const headers = [
      { header: '会员id', width: 10 },
      { header: '所在地', width: 20 },
      { header: '会员昵称', width: 20 },
      { header: '会员手机', width: 20 },
      { header: '会员角色', width: 20 },
      { header: '会员邀请码', width: 20 },
      { header: '被推广者手机', width: 20 },
      { header: '推广明细', width: 40 }
    ];
    worksheet.columns = headers;

    for (const i in result.list) {
      const info = result.list[i];
      let role = '神秘身份';
      if (info.role_id === 1) {
        role = 'Lv1';
      } else if (info.role_id === 2) {
        role = 'Lv2';
      } else if (info.role_id === 3) {
        role = '合伙人';
      } else if (info.role_id === 4) {
        role = '校园合伙人';
      } else if (info.role_id === 5) {
        role = '校园大使';
      }
      worksheet.addRow([
        info.id,
        info.province + '-' + info.city + '-' + info.area,
        info.name,
        info.phone,
        role,
        info.code,
        info.mobile,
        info.detail
      ]);
    }

    ctx.set('Content-Type', 'application/octet-stream');
    ctx.attachment('newerInfo.xlsx');
    ctx.acceptsCharsets('utf-8');
    const data = await workbook.xlsx.writeBuffer();
    ctx.body = data;
  }
}

module.exports = StatisticsController;