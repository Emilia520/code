const Controller = require('egg').Controller;

class TbController extends Controller {
  // 导入分类信息
  async importCat() {
    const ctx = this.ctx;
    const result = await ctx.service.tb.importCat(ctx.request.body);
    ctx.body = result;
  }
  // 商品列表
  async goodsList() {
    const ctx = this.ctx;
    const result = await ctx.service.tb.goodsList(ctx.request.body);
    // 设置响应体和状态码;
    ctx.body = {};
    ctx.body.code = result.data.error == '0' ? 10000 : Number(result.error);
    ctx.body.msg = result.data.msg;
    if (result.data.result_list) {
      ctx.body.totalCount = result.data.total_results || 0;
      ctx.body.data = result.data.result_list || [];
    } else if (result.data.data) {
      ctx.body.totalCount = 1;
      ctx.body.data = [result.data.data];
    }

  }
  // 热销高佣商品列表
  async hotSaleList() {
    const ctx = this.ctx;
    const result = await ctx.service.tb.hotSaleList(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = 'ok';
    ctx.body.data = result.data.data;
    ctx.body.totalCount = result.data.count;
  }
  // 单品转链
  async convertUrl() {
    const ctx = this.ctx;
    const result = await ctx.service.tb.genPromotionUrl(ctx.request.body);
    ctx.body = result;
  }
  // 生成发单图
  // async genSharedPict() {
  //   const ctx = this.ctx;
  //   const url = await ctx.service.tb.genSharedPict(ctx.request.body);
  //   ctx.body = {};
  //   ctx.body.code = 10000;
  //   ctx.body.msg = '成功';
  //   ctx.body.data = url;
  // }
  // 获取淘宝订单数据
  async summaryData(params) {
    const ctx = this.ctx;
    const result = await ctx.service.tb.summaryData(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result.list;
  }
}

module.exports = TbController;