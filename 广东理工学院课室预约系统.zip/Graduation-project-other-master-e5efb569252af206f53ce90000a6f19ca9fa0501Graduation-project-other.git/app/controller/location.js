const Controller = require('egg').Controller;

class LocationController extends Controller {
  async provinces() {
    const ctx = this.ctx;
    const result = await ctx.service.location.provinces();
    ctx.body = result;
  }

  async cities() {
    const ctx = this.ctx;
    const result = await ctx.service.location.cities();
    ctx.body = result;
  }

  async areas() {
    const ctx = this.ctx;
    const result = await ctx.service.location.areas();
    ctx.body = result;
  }

  async regions() {
    const ctx = this.ctx;
    const result = await ctx.service.location.regions();
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result;
  }
}

module.exports = LocationController;