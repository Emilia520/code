const Controller = require('egg').Controller;

class Tb1688Controller extends Controller {
  async updateCategories() {
    const { ctx } = this;
    await ctx.service.tb1688.updateCategories([130822220, 130823000, 130822002, 123614001, 201128501]);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async getCategory() {
    const { ctx } = this;
    const result = await ctx.service.tb1688.getCategory(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result.data;
  }

  async goodsList() {
    const { ctx } = this;
    const result = await ctx.service.tb1688.goodsList(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result.list;
    ctx.body.totalCount = result.totalCount;
  }

  async catList() {
    const { ctx } = this;
    const result = await ctx.service.tb1688.catList();
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result;
  }
}

module.exports = Tb1688Controller;