const Controller = require('egg').Controller;

class ZTController extends Controller {
  // 充值
  async charge() {
    const ctx = this.ctx;
    const result = await ctx.service.zhitong.charge(ctx.request.body);
    // 设置响应体和状态码
    // ctx.body = {};
    // ctx.body.code = result.data.resultCode === 999999 ? 10000 : result.data.resultCode;
    // ctx.body.msg = result.data.resultMessage;
    // ctx.body.data = result.data.data;
    ctx.body = result;
  }

  // 查询
  async queryOrder() {
    const ctx = this.ctx;
    const result = await ctx.service.zhitong.queryOrder(ctx.request.body);
    // 设置响应体和状态码
    // ctx.body = {};
    // ctx.body.code = result.data.resultCode === 999999 ? 10000 : result.data.resultCode;
    // ctx.body.msg = result.data.resultMessage;
    // ctx.body.data = result.data.data;
    ctx.body = result;
  }
}

module.exports = ZTController;