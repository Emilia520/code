const Controller = require('egg').Controller;
const Excel = require('exceljs');
// const nodeExcel = require('excel-export');

class ShopController extends Controller {
  // 获取行业信息
  async business() {
    const ctx = this.ctx;
    const result = await ctx.service.shop.business();
    // 设置响应体和状态码
    if (result.data != null) {
      ctx.body = {};
      ctx.body.code = result.data.code;
      ctx.body.msg = result.data.msg;
      ctx.body.data = result.data.data;
    }
  }

  // 获取小店信息
  async infos() {
    const ctx = this.ctx;
    const result = await ctx.service.shop.infos(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.totalCount = result.totalCount;
    ctx.body.data = result.list;
  }

  // async export1() {
  //   const ctx = this.ctx;
  //   const result = await ctx.service.shop.infos(ctx.request.body);
  //   const conf = {};
  //   conf.name = 'mysheet';// 表格名
  //   const alldata = [];
  //   for (const i in result.list) {
  //     const info = result.list[i];
  //     const role = info.role_id == 1 ? 'Lv1' : (info.role_id == 2 ? 'Lv2' : '合伙人');
  //     alldata.push([
  //       info.id,
  //       info.shop,
  //       info.province + '-' + info.city + '-' + info.area,
  //       info.business1 + '-' + info.business2,
  //       role + ' ' + info.code,
  //       info.phone,
  //       info.userName + ' ' + info.idCard,
  //       info.facade,
  //       info.licence,
  //       info.invitation_user_id,
  //       info.active == 1 ? '已激活' : '未激活'
  //     ]);
  //   }

  //   const headers = [
  //     { caption: 'id', type: 'string', width: 10 },
  //     { caption: '店铺名称', type: 'string', width: 10 },
  //     { caption: '所在地', type: 'string', width: 10 },
  //     { caption: '行业信息', type: 'string', width: 10 },
  //     { caption: '会员信息', type: 'string', width: 10 },
  //     { caption: '手机号', type: 'string', width: 10 },
  //     { caption: '绑定信息', type: 'string', width: 10 },
  //     { caption: '门头照', type: 'string', width: 10 },
  //     { caption: '营业执照', type: 'string', width: 10 },
  //     { caption: '邀请人用户ID', type: 'string', width: 10 },
  //     { caption: '激活状态', type: 'string', width: 10 }
  //   ];
  //   // 决定列名和类型
  //   conf.cols = headers;
  //   conf.rows = alldata;// 填充数据
  //   const elsx = nodeExcel.execute(conf);
  //   console.log('elsx,', elsx);
  //   const data = new Buffer(elsx, 'binary');
  //   ctx.set('Content-Type', 'application/vnd.openxmlformats');
  //   ctx.set('Content-Disposition', "attachment; filename*=UTF-8' 'shop.xlsx");
  //   ctx.body = data;
  // }

  async export() {
    const ctx = this.ctx;
    ctx.query.pageNum = parseInt(ctx.query.pageNum);
    ctx.query.pageSize = parseInt(ctx.query.pageSize);
    const result = await ctx.service.shop.infos(ctx.query);
    const workbook = new Excel.Workbook();
    const worksheet = workbook.addWorksheet('小店数据');
    const headers = [
      { header: 'id', width: 10 },
      { header: '店铺名称', width: 20 },
      { header: '所在地', width: 20 },
      { header: '行业信息', width: 20 },
      { header: '会员信息', width: 20 },
      { header: '手机号', width: 20 },
      { header: '绑定信息', width: 20 },
      { header: '门头照', width: 20 },
      { header: '营业执照', width: 20 },
      { header: '邀请人用户ID', width: 20 },
      { header: '激活状态', width: 20 }
    ];
    worksheet.columns = headers;

    for (const i in result.list) {
      const info = result.list[i];
      let role = '神秘身份';
      if (info.role_id === 1) {
        role = 'Lv1';
      } else if (info.role_id === 2) {
        role = 'Lv2';
      } else if (info.role_id === 3) {
        role = '合伙人';
      } else if (info.role_id === 4) {
        role = '校园合伙人';
      } else if (info.role_id === 5) {
        role = '校园大使';
      }
      worksheet.addRow([
        info.id,
        info.shop,
        info.province + '-' + info.city + '-' + info.area,
        info.business1 + '-' + info.business2,
        role + ' ' + info.code,
        info.phone,
        info.userName + ' ' + info.idCard,
        info.facade,
        info.licence,
        info.invitation_user_id,
        info.active == 1 ? '已激活' : '未激活'
      ]);
    }

    ctx.set('Content-Type', 'application/octet-stream');
    ctx.attachment('shop.xlsx');
    ctx.acceptsCharsets('utf-8');
    const data = await workbook.xlsx.writeBuffer();
    ctx.body = data;
  }
}

module.exports = ShopController;