const Controller = require('egg').Controller;

class BrandController extends Controller {

  // 品牌类型列表
  async brandTypes() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.brandTypes();
    console.log(JSON.stringify(result));
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }

  // 品牌标签列表
  async brandLebals() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.brandLebals(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }

  // 待入库的商品列表 分页
  async noAddBrandDBList() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.noAddBrandDBList(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
      totalCount: result.totalCount
    };
  }

  // 品牌绑定
  async brandBind() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.brandBind(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }

  // 批量修改运营标签
  async brandListAddTag() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.brandListAddTag(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }

  // 品牌 加入/移出 黑名单
  async brandMVBanned() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.brandMVBanned(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }

  // 库中的品牌信息 分页，可筛选 [已入库、黑名单共用接口]
  async brandList() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.brandList(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
      totalCount: result.totalCount
    };
  }

  // 新增品牌
  async brandCreate() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.brandCreate(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }

  // 修改品牌
  async brandUpdate() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.brandUpdate(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }

  // 查看品牌信息
  async brandInfo() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.brandInfo(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }

  // 分类列表
  async listTag() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.tagInfo(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }
  // 根据id查询tag_name
  async getTagName() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.getTagName(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }
  // 待入库绑定品牌模糊搜索
  async searchName() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.searchName(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }

  // 待入库新建品牌信息查询
  async noAddGetInformtion() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.noAddGetInformtion(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }
  // 已入库删除品牌
  async deleteSinceBrand() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.deleteSinceBrand(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }

  async getMd5() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.getMd5(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }

  async sendMessage() {
    const ctx = this.ctx;
    const result = await ctx.service.brand.sendMessage(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }
}


module.exports = BrandController;