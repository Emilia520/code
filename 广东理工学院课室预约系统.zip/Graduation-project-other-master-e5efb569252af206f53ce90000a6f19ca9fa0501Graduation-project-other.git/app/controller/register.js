'use strict';

const Controller = require('egg').Controller;
class RegisterController extends Controller {
   //插入数据到用户账号表和插入数据到个人信息表
   async reAccount() {
    const ctx = this.ctx;
    const result = await ctx.service.register.reAccount(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }
  // //插入数据到个人信息表
  // async reInformation(){
  //   const ctx = this.ctx;
  //   const result = await ctx.service.register.reInformation(ctx.request.body);
  //   ctx.body = {
  //     msg: result.msg,
  //     code: result.code,
  //     data: result.data
  //   };
  // }

}

module.exports = RegisterController;
