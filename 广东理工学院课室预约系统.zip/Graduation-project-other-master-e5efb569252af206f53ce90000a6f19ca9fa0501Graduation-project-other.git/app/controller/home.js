const Controller = require('egg').Controller;

class HomeController extends Controller {
  async banner() {
    const ctx = this.ctx;
    const result = await ctx.service.home.banner(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.totalCount = result.totalCount;
    ctx.body.data = result.list;
  }

  async addBanner() {
    const ctx = this.ctx;
    await ctx.service.home.addBanner(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async updateBannerList() {
    const ctx = this.ctx;
    await ctx.service.home.updateBannerList(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async editBannerList() {
    const ctx = this.ctx;
    await ctx.service.home.editBannerList(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async deleteBanner() {
    const ctx = this.ctx;
    await ctx.service.home.deleteBanner(ctx.query.id);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async updateClient() {
    const ctx = this.ctx;
    await ctx.service.home.updateClient(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async getClient() {
    const ctx = this.ctx;
    const result = await ctx.service.home.getClient(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result.list;
    ctx.body.totalCount = result.totalCount;
  }

  async getRedisKeys() {
    const ctx = this.ctx;
    const result = await ctx.service.home.getRedisKeys(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result.list;
  }

  async delRedisKeys() {
    const ctx = this.ctx;
    await ctx.service.home.delRedisKeys(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async getBannerList() {
    const ctx = this.ctx;
    const result = await ctx.service.home.getBannerList(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result.list;
    ctx.body.totalCount = result.totalCount;
  }
  async createBannerList() {
    const ctx = this.ctx;
    await ctx.service.home.createBannerList(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }
  async createClientList() {
    const ctx = this.ctx;
    await ctx.service.home.createClientList(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async getBannerById() {
    const ctx = this.ctx;
    const result = await ctx.service.home.getBannerById(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result.list;
  }

  async updateBanner() {
    const ctx = this.ctx;
    await ctx.service.home.updateBanner(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }


  async getBanner() {
    const ctx = this.ctx;
    const result = await ctx.service.home.getBanner(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result.list;
  }
}

module.exports = HomeController;