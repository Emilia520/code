'use strict';

const Controller = require('egg').Controller;

class AppointmentController extends Controller {
  async insertTime() {
    const ctx = this.ctx;
    const result = await ctx.service.appointment.insertTime(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
    };
  }
  async recordAppiont() {
    const ctx = this.ctx;
    const result = await ctx.service.appointment.recordAppiont(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
    };
  }

  async judgeAppiont() {
    const ctx = this.ctx;
    const result = await ctx.service.appointment.judgeAppiont(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
    };
  }
}

module.exports = AppointmentController;
