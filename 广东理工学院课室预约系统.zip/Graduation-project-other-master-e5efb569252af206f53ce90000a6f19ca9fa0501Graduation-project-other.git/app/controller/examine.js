'use strict';

const Controller = require('egg').Controller;

class ExamineController extends Controller {
  async userAppiont() {
    const ctx = this.ctx;
    const result = await ctx.service.examine.userAppiont(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
      total:result.total
    }
  }
  async successAppiont() {
    const ctx = this.ctx;
    const result = await ctx.service.examine.successAppiont(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
    }
  }

  async failedAppiont() {
    const ctx = this.ctx;
    const result = await ctx.service.examine.failedAppiont(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
    }
  }

  async changeState() {
    const ctx = this.ctx;
    const result = await ctx.service.examine.changeState();
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
    }
  }

  async updateNull() {
    const ctx = this.ctx;
    const result = await ctx.service.examine.updateNull();
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
    }
  }

  async selectOther() {
    const ctx = this.ctx;
    const result = await ctx.service.examine.selectOther(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
      stotal:result.stotal
    }
  }
  
}

module.exports = ExamineController;
