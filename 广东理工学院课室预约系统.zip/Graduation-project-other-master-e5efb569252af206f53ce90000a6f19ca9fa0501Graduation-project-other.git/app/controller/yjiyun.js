const Controller = require('egg').Controller;

class YJYController extends Controller {

  async auth() {
    const ctx = this.ctx;
    const result = await ctx.service.yjiyun.auth();
    ctx.body = result;
  }

  async updateWXGroupList() {
    const ctx = this.ctx;
    const result = await ctx.service.yjiyun.updateWXGroupList();
    ctx.body = result;
  }

  async updateRobotList() {
    const ctx = this.ctx;
    const result = await ctx.service.yjiyun.updateRobotList();
    ctx.body = result;
  }

  async wxValidGroupList() {
    const ctx = this.ctx;
    const result = await ctx.service.yjiyun.wxValidGroupList();
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result;
  }

  async queryRobotGroups() {
    const ctx = this.ctx;
    const result = await ctx.service.yjiyun.queryRobotGroups(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result.list;
    ctx.body.totalCount = result.count;
  }
}
module.exports = YJYController;