'use strict';

const Controller = require('egg').Controller;

class AppReordController extends Controller {
  async listReord() {
    const ctx = this.ctx;
    const result = await ctx.service.appReord.listReord(ctx.request.body);
    ctx.body = {
        msg: result.msg,
        code: result.code,
        data: result.data,
        total:result.total
    }

  }
  async ownList() {
    const ctx = this.ctx;
    const result = await ctx.service.appReord.ownList(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data,
      stotal:result.stotal
    }
  }
}

module.exports = AppReordController;
