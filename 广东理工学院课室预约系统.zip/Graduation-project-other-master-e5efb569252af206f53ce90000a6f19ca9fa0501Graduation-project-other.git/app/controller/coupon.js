const Controller = require('egg').Controller;

class CouponController extends Controller {
  async update() {
    const ctx = this.ctx;
    const result = await ctx.service.coupon.update();
    ctx.body = result;
  }

  async updateCoupon() {
    const ctx = this.ctx;
    const result = await ctx.service.coupon.updateCoupon(this.ctx.params.id);
    ctx.body = result;
  }
}

module.exports = CouponController;