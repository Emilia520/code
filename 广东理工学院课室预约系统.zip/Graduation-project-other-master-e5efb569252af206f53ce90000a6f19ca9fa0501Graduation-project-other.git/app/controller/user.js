const Controller = require('egg').Controller;

class UserController extends Controller {
  async info() {
    const ctx = this.ctx;
    const pageNum = isNaN(Number(ctx.query.pageNum)) ? 1 : Number(ctx.query.pageNum);
    const pageSize = isNaN(Number(ctx.query.pageSize)) ? 10 : Number(ctx.query.pageSize);
    const role_id = isNaN(Number(ctx.query.role_id)) ? 0 : Number(ctx.query.role_id);
    const id = isNaN(Number(ctx.query.id)) ? 0 : Number(ctx.query.id);
    const name = (ctx.query.name && ctx.query.name.length > 0) ? ctx.query.name : null;
    const phone = (ctx.query.phone && ctx.query.phone.length > 0) ? ctx.query.phone : null;
    const shop = (ctx.query.shop && ctx.query.shop.length > 0) ? ctx.query.shop : null;
    const options = {
      pageNum,
      pageSize,
      name,
      role_id,
      id,
      phone,
      shop
    };
    const res = await ctx.service.user.info(options);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = res;
  }

  async upQxbCaptain() {
    const ctx = this.ctx;
    const result = await ctx.service.user.upQxbCaptain(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    if (result.code === 10000) {
      ctx.body.code = 10000;
      ctx.body.msg = '成功';
    } else {
      ctx.body.code = 20000;
      ctx.body.msg = result.msg;
    }
  }

  async upQxbPartner() {
    const ctx = this.ctx;
    const result = await ctx.service.user.upQxbPartner(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    if (result.code === 10000) {
      ctx.body.code = 10000;
      ctx.body.msg = '成功';
    } else {
      ctx.body.code = 20000;
      ctx.body.msg = result.msg;
    }
  }

  async findRegion() {
    const ctx = this.ctx;
    const result = await ctx.service.user.findRegion(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    if (result) {
      ctx.body.code = 10000;
      ctx.body.msg = '成功';
      ctx.body.data = result;
    } else {
      ctx.body.code = 20000;
      ctx.body.msg = result.msg;
    }
  }
  async checkCode() {
    const ctx = this.ctx;
    const result = await ctx.service.user.checkCode(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    if (!result) {
      ctx.body.code = 10000;
      ctx.body.msg = '成功';
    } else {
      ctx.body.code = 20000;
      ctx.body.msg = result;
    }
  }

  async checkPhone() {
    const ctx = this.ctx;
    const result = await ctx.service.user.checkPhone(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    if (!result) {
      ctx.body.code = 10000;
      ctx.body.msg = '成功';
    } else {
      ctx.body.code = 20000;
      ctx.body.msg = result;
    }
  }

  async createUser() {
    const ctx = this.ctx;
    const result = await ctx.service.user.createUser(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    if (!result) {
      ctx.body.code = 10000;
      ctx.body.msg = '成功';
    } else {
      ctx.body.code = 20000;
      ctx.body.msg = result;
    }
  }

}

module.exports = UserController;