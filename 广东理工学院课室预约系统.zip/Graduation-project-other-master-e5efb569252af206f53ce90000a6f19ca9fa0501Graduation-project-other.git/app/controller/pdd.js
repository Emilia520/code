const Controller = require('egg').Controller;
const Excel = require('exceljs');
const path = require('path');
const fs = require('fs');
const os = require('os');
const pipe = require('multipipe');
const compressing = require('compressing');

class PddController extends Controller {
  async updateSku() {
    const ctx = this.ctx;
    ctx.service.pdd.updateSku();
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }
  // 商品列表
  async goodsList() {
    const ctx = this.ctx;
    const result = await ctx.service.pdd.goodsList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.totalCount = result.totalCount;
    ctx.body.data = result.list ? result.list : [];
  }
  // 商品类目列表
  async categoryList() {
    const ctx = this.ctx;
    const result = await ctx.service.pdd.categoryList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result.list ? result.list : [];
  }
  // 商品标签列表
  async optList() {
    const ctx = this.ctx;
    const result = await ctx.service.pdd.optList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result.list ? result.list : [];
  }
  // 转链
  async genPromotionUrl() {
    const ctx = this.ctx;
    const result = await ctx.service.pdd.genPromotionUrl(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result.list ? result.list : [];
  }

  async sendRobotMsgImmediately() {
    const ctx = this.ctx;
    const result = await ctx.service.pdd.sendRobotMsgImmediately(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result;
  }

  async themeList() {
    const ctx = this.ctx;
    const result = await ctx.service.pdd.themeList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.totalCount = result.totalCount;
    ctx.body.data = result.list;
  }

  async themeGoodsList() {
    const ctx = this.ctx;
    const result = await ctx.service.pdd.themeGoodsList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.totalCount = result.totalCount;
    ctx.body.data = result.list;
  }

  async orderData() {
    const ctx = this.ctx;
    const result = await ctx.service.pdd.orderData(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.totalCount = result.totalCount;
    ctx.body.data = result.list;
  }

  async orderStatusData() {
    const ctx = this.ctx;
    const result = await ctx.service.pdd.orderStatusData(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result.list;
  }

  async summaryData(params) {
    const ctx = this.ctx;
    const result = await ctx.service.pdd.summaryData(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result.list;
  }

  async groupInfo(params) {
    const ctx = this.ctx;
    const result = await ctx.service.pdd.groupInfo(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.totalCount = result.totalCount;
    ctx.body.data = result.list;
  }

  async mkdir() {
    const ctx = this.ctx;
    const list = [{ id: 1, name: 'yy' }, { id: 2, name: 'xx' }];
    ctx.body = {};
    const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'qxb-'));
    let count = 0;
    while (count < 10) {
      const workbook = new Excel.Workbook();
      const worksheet = workbook.addWorksheet('测试数据');
      const headers = [
        { header: 'id', width: 10 },
        { header: '姓名', width: 20 }
      ];
      worksheet.columns = headers;

      for (const i in list) {
        const info = list[i];
        worksheet.addRow([
          info.id,
          info.name
        ]);
      }

      await workbook.xlsx.writeFile(path.join(folder, 'test' + count + '.xlsx'));
      ++count;
    }

    const zipStream = new compressing.zip.Stream();
    fs.readdirSync(folder).forEach(function(file) {
      zipStream.addEntry(path.join(folder, file));
    });

    pipe(zipStream, ctx.res, (err) => {
      console.log(err);
    });

    ctx.set('Content-Type', 'application/octet-stream');
    ctx.attachment('test.zip');
    ctx.body = ctx.res;
  }
}
module.exports = PddController;