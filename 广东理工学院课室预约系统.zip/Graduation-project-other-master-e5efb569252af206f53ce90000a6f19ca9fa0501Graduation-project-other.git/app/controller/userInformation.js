'use strict';

const Controller = require('egg').Controller;

class UserInformationController extends Controller {
  async searchMs() {
    const ctx = this.ctx;
    const result = await ctx.service.userInformation.searchMs(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }
  async changeMS() {
    const ctx = this.ctx;
    const result = await ctx.service.userInformation.changeMS(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }
  async updatePs() {
    const ctx = this.ctx;
    const result = await ctx.service.userInformation.updatePs(ctx.request.body);
    ctx.body = {
      msg: result.msg,
      code: result.code,
      data: result.data
    };
  }
}

module.exports = UserInformationController;
