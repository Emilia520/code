const Controller = require('egg').Controller;

class GBController extends Controller {
  async activityCats() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.activityCats(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result;
  }

  async activityList() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.activityList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result.list;
    ctx.body.totalCount = result.totalCount;
  }

  async stick() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.stick(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async updateSaleState() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.updateSaleState(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async updateSaleStateOnGoods() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.updateSaleStateOnGoods(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async updateActivitySort() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.updateActivitySort(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async goodsList() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.goodsList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result;
  }

  async updateGoodsInfo() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.updateGoodsInfo(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async uploadHotGoods() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.uploadHotGoods(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async selectActivity() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.selectActivity(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.data = result.list;
    ctx.body.count = result.totalCount;
    ctx.body.msg = '成功';
  }

  async selectShare() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.selectShare(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.data = result.list;
    ctx.body.count = result.totalCount;
    ctx.body.msg = '成功';
  }

  async cancelHotGoods() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.cancelHotGoods(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async afterSaleOrderList() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.afterSaleOrderList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result.list;
    ctx.body.totalCount = result.totalCount;
  }
  async createHotGoodsList() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.createHotGoodsList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.id = result;
  }
  async addGoodsToHotList() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.addGoodsToHotList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }
  async delGoodsHotList() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.delGoodsHotList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }
  async deleteGoodsHotList() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.deleteGoodsHotList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }
  async addGoodsHotList() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.addGoodsHotList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }
  async delGoods() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.delGoods(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }
  async findGoodsHotList() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.findGoodsHotList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.data = result.list;
    ctx.body.totalCount = result.totalCount;
    ctx.body.msg = '成功';
  }
  async findHotGoods() {
    const ctx = this.ctx;
    const list = await ctx.service.groupbuy.findHotGoods(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.data = list;
    ctx.body.msg = '成功';
  }
  async updateSortGoodsHotList() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.updateSortGoodsHotList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }
  async updateGoodsHotList() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.updateGoodsHotList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async updateShareHotList() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.updateShareHotList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async createShareHotList() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.createShareHotList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async andHotAct() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.andHotAct(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async afterSaleRefund() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.afterSaleRefund(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
  }

  async afterSaleApprove() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.afterSaleApprove(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
    ctx.body.data = result.data;
  }

  async afterSaleReject() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.afterSaleReject(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async updateAfterSaleImages() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.updateAfterSaleImages(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async uploadLogistics() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.uploadLogistics(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
    ctx.body.data = result.data;
  }

  async updateActivityAddPriceRatio() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.updateActivityAddPriceRatio(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
  }

  async afterSaleReasonList() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.afterSaleReasonList();
    ctx.body = {};
    ctx.body = result;
  }

  // 更新订单状态
  async updateOrderStatus() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.updateOrderStatus(ctx.request.body);
    ctx.body = {};
    ctx.body = result;
  }

  // 更新商家回寄单号
  async updateStoreDeliveryInfo() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.updateStoreDeliveryInfo(ctx.request.body);
    ctx.body = {};
    ctx.body = result;
  }

  // 更新商家回寄信息
  async updateSellerDeliveryInfo() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.updateSellerDeliveryInfo(ctx.request.body);
    ctx.body = {};
    ctx.body = result;
  }

  // 更新售后订单
  async updateACKAfterSaleOrder() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.updateACKAfterSaleOrder(ctx.request.body);
    ctx.body = {};
    ctx.body = result;
  }

  // 更新活动对小程序的可见性
  async updateMiniProgramVisibility() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.updateMiniProgramVisibility(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async getMiniProgramGroupVisibility() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.getMiniProgramGroupVisibility(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
    ctx.body.data = result.data;
  }

  // 更新商品或者活动标签
  async updateTag() {
    const ctx = this.ctx;
    await ctx.service.groupbuy.updateTag(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  // 返回所有活动时间内可见活动的有效商品列表
  async allOnSaleGoods() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.allOnSaleGoods(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = '成功';
    ctx.body.data = result.data;
    ctx.body.count = result.total;
  }

  // 重新发起售后
  async restartAfterSale() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.restartAfterSale(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
  }

  // 根据订单号直接发起售后
  async applyAfterSale() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.applyAfterSale(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
  }

  // 取消售后
  async cancelAfterSale() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.cancelAfterSale(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
  }

  // 已手工退款
  async alreadyRefund() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.alreadyRefund(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
  }

  // 298团长礼包列表
  async listCaptainGoods() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.listCaptainGoods(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.data = result.data;
    ctx.body.msg = result.msg;
  }

  // 298团长礼包信息修改
  async updateCaptainGoods() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.updateCaptainGoods(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
  }

  // 新增298团长礼包
  async createCaptainGoods() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.createCaptainGoods(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
  }

  // 分类列表
  async listTag() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.listTag(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.data = result.data;
    ctx.body.msg = result.msg;
  }

  // 小程序可见的分类列表
  async listTagForWXMiniProgram() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.listTagForWXMiniProgram(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.data = result.data;
    ctx.body.msg = result.msg;
  }

  // 品牌列表
  async listBrand() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.listBrand(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.data = result.data;
    ctx.body.msg = result.msg;
  }

  // 新增品牌
  async createBrand() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.createBrand(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.data = result.data;
    ctx.body.msg = result.msg;
  }

  // 自营活动的非自营商品的活动列表
  async listOwnActNoOwnGoodsAct() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.listOwnActNoOwnGoodsAct(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.data = result.data;
    ctx.body.msg = result.msg;
  }

  // 修改自营活动的非自营商品的商品
  async updateOwnActNoOwnGoodsAct() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.updateOwnActNoOwnGoodsAct(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.data = result.data;
    ctx.body.msg = result.msg;
  }

  // 新增自营活动的非自营商品的活动
  async createOwnActNoOwnGoodsAct() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.createOwnActNoOwnGoodsAct(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
  }

  // 新增自营活动的非自营商品的活动
  async createNoOwnGoods() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.createNoOwnGoods(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
  }

  // 根据order_id获取商品信息
  async productForAfterSaleOrder() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.productForAfterSaleOrder(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.code;
    ctx.body.msg = result.msg;
    ctx.body.data = result.data;
  }

  // 根据自营活动ID获取商品列表
  async listOwnActGoods() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.listOwnActGoods(ctx.request.body);
    ctx.body = {
      code: result.code,
      msg: result.msg,
      data: result.data
    };
  }

  // 修改自营活动商品列表的顺序
  async updateGoodsSort() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.updateGoodsSort(ctx.request.body);
    ctx.body = {
      code: result.code,
      msg: result.msg,
      data: result.data
    };
  }

  // 删除自营活动商品
  async deleteGoodsSort() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.deleteGoodsSort(ctx.request.body);
    ctx.body = {
      code: result.code,
      msg: result.msg,
      data: result.data
    };
  }

  // 自营活动自营商品的活动列表
  async ownActOwnGoodsActList() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.ownActOwnGoodsActList(ctx.request.body);
    ctx.body = {
      code: result.code,
      msg: result.msg,
      data: result.data
    };
  }

  // 自营活动自营商品的商品列表
  async ownActOwnGoodsList() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.ownActOwnGoodsList(ctx.request.body);
    ctx.body = {
      code: result.code,
      msg: result.msg,
      data: result.data
    };
  }

  // 自营活动自营商品 活动上下架
  async statusUpdateAct() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.statusUpdateAct(ctx.request.body);
    ctx.body = {
      code: result.code,
      msg: result.msg
    };
  }

  // 自营活动自营商品 商品上下架
  async statusUpdateGoods() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.statusUpdateGoods(ctx.request.body);
    ctx.body = {
      code: result.code,
      msg: result.msg
    };
  }

  // 自营活动自营商品 活动编辑
  async ownActEdit() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.ownActEdit(ctx.request.body);
    ctx.body = {
      code: result.code,
      msg: result.msg
    };
  }

  // 自营活动自营商品 商品编辑
  async ownGoodsEdit() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.ownGoodsEdit(ctx.request.body);
    ctx.body = {
      code: result.code,
      msg: result.msg
    };
  }

  // 自营活动自营商品 活动新增
  async ownActAdd() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.ownActAdd(ctx.request.body);
    ctx.body = {
      code: result.code,
      msg: result.msg
    };
  }

  // 自营活动自营商品 商品新增
  async ownGoodsAdd() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.ownGoodsAdd(ctx.request.body);
    ctx.body = {
      code: result.code,
      msg: result.msg
    };
  }

  // 自营活动自营商品 商品规格查看
  async ownGoodsSkuSee() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.ownGoodsSkuSee(ctx.request.body);
    ctx.body = {
      code: result.code,
      msg: result.msg,
      data: result.data
    };
  }

  // 自营活动自营商品 商品规格新增
  async ownGoodsSkuAdd() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.ownGoodsSkuAdd(ctx.request.body);
    ctx.body = {
      code: result.code,
      msg: result.msg
    };
  }

  // 自营活动自营商品 商品规格编辑
  async ownGoodsSkuEdit() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.ownGoodsSkuEdit(ctx.request.body);
    ctx.body = {
      code: result.code,
      msg: result.msg
    };
  }

  // 批量绑定商品的品牌库品牌
  async batchGoodsBindOwnBrand() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.batchGoodsBindOwnBrand(ctx.request.body);
    ctx.body = {
      code: result.code,
      msg: result.msg
    };
  }

  /**
   * 导出活动列表的商品信息
   */
  async putOutList() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.putOutList(ctx.query);
    ctx.set('Content-Type', 'application/octet-stream');
    ctx.acceptsCharsets('utf-8');
    ctx.attachment('actGoodsList.xlsx');
    ctx.body = result;
  }

  /**
   * 导出搜索到的商品列表信息
   */
  async exportGoodsList() {
    const ctx = this.ctx;
    const result = await ctx.service.groupbuy.exportGoodsList(ctx.query);
    ctx.set('Content-Type', 'application/octet-stream');
    ctx.acceptsCharsets('utf-8');
    ctx.attachment('seaGoodsList.xlsx');
    ctx.body = result;
  }
}


module.exports = GBController;