const Controller = require('egg').Controller;
const FormStream = require('formstream');

class ImageController extends Controller {
  async upload() {
    const { ctx } = this;
    // 获取前端上传的文件流
    const fileStream = await ctx.getFileStream();
    const form = new FormStream();
    ctx.body = {};

    if (fileStream) {
      console.log(fileStream.fieldname, fileStream.filename);
      form.stream(fileStream.fieldname, fileStream, fileStream.filename);
      const result = await ctx.curl(ctx.app.config.api.img_host + '/helper/uploadCdn', {
      // 必须指定 method，支持 POST，PUT
        method: 'POST',
        // 生成符合 multipart/form-data 要求的请求 headers
        headers: form.headers(),
        // 以 stream 模式提交
        stream: form,
        // 明确告诉 HttpClient 以 JSON 格式处理响应 body
        dataType: 'json',
      });

      ctx.body = result.data;
    }
  }

  async composeGroupbuyPoster() {
    const { ctx } = this;
    const result = await this.service.image.composeGroupbuyPoster(ctx.request.body);
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result;
  }

  async genQRCode() {
    await this.service.image.genQRCode('【在售价】￥98.9\n【抢购价】￥18.9\n-----------------\n复制这条信息，(USiObs0uhVa)，打开【手机淘宝】即可抢购');
  }

  async getCORSImage() {
    const { ctx } = this;
    const result = await ctx.curl(ctx.query.img);
    ctx.set(result.headers);
    ctx.body = result.data;
  }
}
module.exports = ImageController;