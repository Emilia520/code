const Controller = require('egg').Controller;

class RobotController extends Controller {
  async list() {
    const ctx = this.ctx;
    const result = await ctx.service.robot.list();
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result;
  }

  async robotMsgList() {
    const ctx = this.ctx;
    const result = await ctx.service.robot.robotMsgList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.totalCount = result.totalCount;
    ctx.body.data = result.list;
    ctx.body.group = result.groupInfo;
  }

  async revokeMsg() {
    const ctx = this.ctx;
    await ctx.service.robot.revokeMsg(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async uploadCalendarMsg() {
    const ctx = this.ctx;
    await ctx.service.robot.uploadCalendarMsg(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async genPromoteInfo() {
    const ctx = this.ctx;
    const result = await ctx.service.robot.genPromoteInfo(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result;
  }

  async addGroupInfo() {
    const ctx = this.ctx;
    const result = await ctx.service.robot.addGroupInfo(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = result;
  }

  async updateRobotGroupInfo() {
    const ctx = this.ctx;
    await ctx.service.robot.updateRobotGroupInfo(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  // 获取机器人群分类列表
  async groupCategoryList() {
    const ctx = this.ctx;
    const result = await ctx.service.robot.groupCategoryList();
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
    ctx.body.data = result;
  }

  // 更新机器人群分类信息
  async updateGroupCategoryInfo() {
    const ctx = this.ctx;
    await ctx.service.robot.updateGroupCategoryInfo(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  // 添加机器人群分类
  async addGroupCategory() {
    const ctx = this.ctx;
    await ctx.service.robot.addGroupCategory(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = 10000;
    ctx.body.msg = '成功';
  }

  async addRobotGroups() {
    const ctx = this.ctx;
    const res = await ctx.service.robot.addRobotGroups(ctx.request.body);
    ctx.body = {};
    ctx.body.code = res.code;
    ctx.body.msg = res.msg;
  }

  async loadRobotGroupsForDB() {
    const ctx = this.ctx;
    const res = await ctx.service.robot.loadRobotGroupsForDB(ctx.request.body);
    ctx.body = {};
    ctx.body.code = res.code;
    ctx.body.msg = res.msg;
    ctx.body.data = res.data;
  }
}

module.exports = RobotController;