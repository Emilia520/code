const Controller = require('egg').Controller;

class AKCController extends Controller {
  // 获取活动列表
  async activityList() {
    const ctx = this.ctx;
    const result = await ctx.service.aikucun.activityList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = result.data.resultCode === 999999 ? 10000 : result.data.resultCode;
    ctx.body.msg = result.data.resultMessage;
    ctx.body.data = result.data.data;
  }

  // 获取活动商品列表
  async productList() {
    const ctx = this.ctx;
    const result = await ctx.service.aikucun.productList(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = result.data.resultCode === 999999 ? 10000 : result.data.resultCode;
    ctx.body.msg = result.data.resultMessage;
    ctx.body.data = result.data.data;
  }

  // 创建售后单
  async createAfterSaleBill() {
    const ctx = this.ctx;
    const result = await ctx.service.aikucun.createAfterSaleBill(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = result.data.resultCode === 999999 ? 10000 : result.data.resultCode;
    ctx.body.msg = result.data.resultMessage;
    ctx.body.data = result.data.data;
  }

  // 修改售后单
  async updateAfterSaleBill() {
    const ctx = this.ctx;
    const result = await ctx.service.aikucun.updateAfterSaleBill(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = result.data.resultCode === 999999 ? 10000 : result.data.resultCode;
    ctx.body.msg = result.data.resultMessage;
    ctx.body.data = result.data.data;
  }

  // 查询售后单
  async queryAfterSaleBill() {
    const ctx = this.ctx;
    const result = await ctx.service.aikucun.queryAfterSaleBill(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = result.data.resultCode === 999999 ? 10000 : result.data.resultCode;
    ctx.body.msg = result.data.resultMessage;
    ctx.body.data = result.data.data;
  }

  // 上传快递单
  async uploadlogistics() {
    const ctx = this.ctx;
    const result = await ctx.service.aikucun.uploadlogistics(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = result.data.resultCode === 999999 ? 10000 : result.data.resultCode;
    ctx.body.msg = result.data.resultMessage;
    ctx.body.data = result.data.data;
  }

  // 取消售后单
  async cancelAfterSaleBill() {
    const ctx = this.ctx;
    const result = await ctx.service.aikucun.cancelAfterSaleBill(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = result.data.resultCode === 999999 ? 10000 : result.data.resultCode;
    ctx.body.msg = result.data.resultMessage;
    ctx.body.data = result.data.data;
  }

  // 查询订单售后状态
  async queryOrderLogisticsStatus() {
    const ctx = this.ctx;
    const result = await ctx.service.aikucun.queryOrderLogisticsStatus(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = result.data.resultCode === 999999 ? 10000 : result.data.resultCode;
    ctx.body.msg = result.data.resultMessage;
    ctx.body.data = result.data.data;
  }

  // 查询订单状态
  async queryOrder() {
    const ctx = this.ctx;
    const result = await ctx.service.aikucun.queryOrder(ctx.request.body);
    // 设置响应体和状态码
    ctx.body = {};
    ctx.body.code = result.data.resultCode === 999999 ? 10000 : result.data.resultCode;
    ctx.body.msg = result.data.resultMessage;
    ctx.body.data = result.data.data;
  }

  // 通过外部订单号查询爱库存订单详情
  async queryOrderByExternalOrderID() {
    const ctx = this.ctx;
    const result = await ctx.service.aikucun.queryOrderByExternalOrderID(ctx.request.body);
    ctx.body = {};
    ctx.body.code = result.data.resultCode === 999999 ? 10000 : result.data.resultCode;
    ctx.body.msg = result.data.resultMessage;
    ctx.body.data = result.data.data;
  }
}

module.exports = AKCController;