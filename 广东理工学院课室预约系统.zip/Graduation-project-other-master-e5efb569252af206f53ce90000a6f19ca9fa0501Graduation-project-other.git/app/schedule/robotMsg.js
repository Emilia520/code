
module.exports = {
  schedule: {
    interval: '2400m', // 2分钟间隔
    type: 'worker',
    immediate: true,
    disable:true
  },

  async task(ctx) {
    const results = await ctx.service.robot.scheduleUpdateMsgList();
    // ctx.logger.info('添加了新发送任务', results);
    console.log('添加了新发送任务', results.length + '个');
    // 检查小程序消息转发队列
    await ctx.service.robotMiniProgram.scheduleSendMsg();
  },
};
