
module.exports = {
  schedule: {
    cron: '0 0 */3 * * *', // 每三小时准点执行一次
    type: 'worker', // 指定所有的 worker 都需要执行
    disable:true
  },

  async task(ctx) {
    const results = await ctx.service.yjiyun.updateWXGroupList();
    ctx.logger.info('更新群信息', results);
    await ctx.service.yjiyun.updateRobotList();
  },
};
