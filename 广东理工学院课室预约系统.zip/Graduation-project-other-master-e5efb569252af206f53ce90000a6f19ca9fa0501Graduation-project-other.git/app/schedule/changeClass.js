
module.exports =(app)=>{
  return{
    schedule: {
      cron: '0 0,5,15,20,25,50,55 8,9,10,11,12,14,15,16,17 * * ? ', // 每三小时准点执行一次  
    //   interval: '3s',
      type: 'worker', // 指定所有的 worker 都需要执行
      // disable:true
    },
    async task(ctx) {
     await ctx.service.examine.changeState();

    },

  }
};
  