/*
 * @Author: yuzc
 * @Date: 2018-05-30 14:25:46
 * @Last Modified by: yuzc
 * @Last Modified time: 2018-05-30 15:27:34
 * 错误处理中间件
 */
const ErrCode = require('../utils/errorCode');

module.exports = () => {
  return function* (next) {
    try {
      this.logger.info('经过了errorHandler');
      yield* next;
    } catch (err) {
      // 注意：自定义的错误统一处理函数捕捉到错误后也要 `app.emit('error', err, this)`
      // 框架会统一监听，并打印对应的错误日志
      // this.app.emit('error', err, this);
      // 自定义错误时异常返回的格式
      this.logger.error(err);
      this.body = {
        code: err.code || ErrCode.ERROR_CODE_SERVER_DEFAULT,
        success: false,
        msg: err.msg || '未知错误',
      };
    }
  };
};
