/*
 * @Author: yuzc
 * @Date: 2018-05-30 14:25:46
 * @Last Modified by: yuzc
 * @Last Modified time: 2018-05-30 15:27:34
 * 用户账号校验中间件
 */
module.exports = () => {
  return async function auth(ctx, next) {
    const url = ctx.request.url;
    if (url.indexOf('/api') !== -1 && !isInWhiteList(url)) {
      const result = await ctx.service.auth.verifyToken();
      if (result.code !== 10000) {
        ctx.body = result;
        return;
      }
    }

    await next();

    function isInWhiteList(url) {
      const whiteList = ['/api/login', '/api/image', '/api/coupon/update', '/api/yjiyun/updateRobotList', '/api/aikucun', '/api/yjiyun/updateGroupInfo', '/api/tb1688', '/api/groupbuy/putOutList', '/api/groupbuy/exportGoodsList'];
      let found = false;
      for (const i in whiteList) {
        const obj = whiteList[i];
        if (url.indexOf(obj) !== -1) {
          found = true;
          break;
        }
      }
      return found;
    }
  };
};