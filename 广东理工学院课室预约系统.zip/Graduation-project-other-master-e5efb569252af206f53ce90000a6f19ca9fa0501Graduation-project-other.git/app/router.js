module.exports = app => {
  app.get('/api/article/list', app.controller.app.list);
  app.get('/api/article/:id', app.controller.app.detail);

  app.post('/api/login', app.controller.login.auth);

  app.post('/api/home/banner', app.controller.home.banner);
  app.post('/api/home/banner/add', app.controller.home.addBanner);
  app.post('/api/home/banner/update', app.controller.home.updateBanner);
  app.get('/api/home/banner/delete', app.controller.home.deleteBanner);


  app.post('/api/home/getClient', app.controller.home.getClient);
  app.post('/api/home/getBannerList', app.controller.home.getBannerList);
  app.post('/api/home/getBannerById', app.controller.home.getBannerById);
  app.post('/api/home/updateBannerList', app.controller.home.updateBannerList);
  app.post('/api/home/updateClient', app.controller.home.updateClient);
  app.post('/api/home/getBanner', app.controller.home.getBanner);
  app.post('/api/home/getRedisKeys', app.controller.home.getRedisKeys);
  app.post('/api/home/delRedisKeys', app.controller.home.delRedisKeys);
  app.post('/api/home/editBannerList', app.controller.home.editBannerList);
  app.post('/api/home/createBannerList', app.controller.home.createBannerList);
  app.post('/api/home/createClientList', app.controller.home.createClientList);


  app.post('/api/user/upQxbCaptain', app.controller.user.upQxbCaptain);
  app.post('/api/user/upQxbPartner', app.controller.user.upQxbPartner);
  app.post('/api/user/findRegion', app.controller.user.findRegion);
  app.post('/api/user/checkCode', app.controller.user.checkCode);
  app.post('/api/user/checkPhone', app.controller.user.checkPhone);
  app.post('/api/user/createUser', app.controller.user.createUser);


  app.post('/api/image/upload', app.controller.image.upload);
  app.get('/api/image/genQRCode', app.controller.image.genQRCode);
  app.get('/api/image/getImage', app.controller.image.getCORSImage);
  app.post('/api/image/genGroupbuyPoster', app.controller.image.composeGroupbuyPoster);

  app.get('/api/user/info', app.controller.user.info);

  app.get('/api/coupon/update', app.controller.coupon.update);
  app.get('/api/coupon/update/:id', app.controller.coupon.updateCoupon);

  app.get('/api/location/provinces', app.controller.location.provinces);
  app.get('/api/location/cities', app.controller.location.cities);
  app.get('/api/location/areas', app.controller.location.areas);
  app.get('/api/location/regions', app.controller.location.regions);

  app.get('/api/shop/business', app.controller.shop.business);
  app.post('/api/shop/infos', app.controller.shop.infos);
  app.get('/api/shop/export', app.controller.shop.export);

  app.post('/api/statistics/newerInfo', app.controller.statistics.newerInfo);
  app.get('/api/statistics/newerInfo/export', app.controller.statistics.exportNewerInfo);

  app.post('/api/pdd/goodsList', app.controller.pdd.goodsList);
  app.post('/api/pdd/categoryList', app.controller.pdd.categoryList);
  app.post('/api/pdd/optList', app.controller.pdd.optList);
  // app.post('/api/pdd/sendRealtimeMsg', app.controller.pdd.sendRobotMsgImmediately);
  app.post('/api/pdd/themeList', app.controller.pdd.themeList);
  app.post('/api/pdd/themeGoodsList', app.controller.pdd.themeGoodsList);
  app.post('/api/pdd/getOrderData', app.controller.pdd.orderData);
  app.post('/api/pdd/getOrderStatusData', app.controller.pdd.orderStatusData);
  app.post('/api/pdd/orderChartData', app.controller.pdd.summaryData);
  app.post('/api/pdd/getWXGroupInfo', app.controller.pdd.groupInfo);
  // app.get('/api/pdd/updateSku', app.controller.pdd.updateSku);
  // app.get('/api/pdd/mkdir', app.controller.pdd.mkdir);

  app.post('/api/tb/goodsList', app.controller.tb.goodsList);
  app.post('/api/tb/hotSaleList', app.controller.tb.hotSaleList);
  app.post('/api/tb/importCat', app.controller.tb.importCat);
  app.post('/api/tb/convert', app.controller.tb.convertUrl);
  // app.post('/api/tb/sharedPict', app.controller.tb.genSharedPict);
  app.post('/api/tb/orderChartData', app.controller.tb.summaryData);

  app.get('/api/tb1688/updateCategories', app.controller.tb1688.updateCategories);
  app.post('/api/tb1688/getCategory', app.controller.tb1688.getCategory);
  app.get('/api/tb1688/catList', app.controller.tb1688.catList);
  app.post('/api/tb1688/goodsList', app.controller.tb1688.goodsList);

  app.get('/api/yjiyun/auth', app.controller.yjiyun.auth);
  app.get('/api/yjiyun/updateGroupInfo', app.controller.yjiyun.updateWXGroupList);
  app.get('/api/yjiyun/updateRobotList', app.controller.yjiyun.updateRobotList);
  app.get('/api/yjiyun/wxGroupList', app.controller.yjiyun.wxValidGroupList);
  app.post('/api/yjiyun/queryRobotGroups', app.controller.yjiyun.queryRobotGroups);

  app.post('/api/robot/revokeMsg', app.controller.robot.revokeMsg);
  app.post('/api/robot/groupMsgList', app.controller.robot.robotMsgList);
  app.post('/api/robot/uploadCalendarMsg', app.controller.robot.uploadCalendarMsg);
  app.post('/api/robot/genPromotionInfo', app.controller.robot.genPromoteInfo);
  app.post('/api/robot/addGroup', app.controller.robot.addGroupInfo);
  app.post('/api/robot/updateGroup', app.controller.robot.updateRobotGroupInfo);
  app.get('/api/robot/list', app.controller.robot.list);
  app.get('/api/robot/groupCategory/get', app.controller.robot.groupCategoryList);
  app.post('/api/robot/groupCategory/update', app.controller.robot.updateGroupCategoryInfo);
  app.post('/api/robot/groupCategory/add', app.controller.robot.addGroupCategory);
  app.post('/api/robot/addRobotGroups', app.controller.robot.addRobotGroups);
  app.post('/api/robot/loadRobotGroupsForDB', app.controller.robot.loadRobotGroupsForDB);

  app.post('/api/choiceList/choiceList', app.controller.choicelist.choiceList);
  app.post('/api/choiceList/addChoiceList', app.controller.choicelist.addChoiceList);
  app.post('/api/choiceList/choiceListCalendar', app.controller.choicelist.choiceListCalendar);
  app.post('/api/choiceList/copyChoiceList', app.controller.choicelist.copyChoiceList);
  app.post('/api/choiceList/deleteChoiceList', app.controller.choicelist.deleteChoiceList);
  app.post('/api/choiceList/optChoiceListItem', app.controller.choicelist.optChoiceListItem);
  app.post('/api/choiceList/getDetail', app.controller.choicelist.detail);
  app.post('/api/choiceList/addCalendar', app.controller.choicelist.addCalendar);

  app.get('/api/groupbuy/putOutList', app.controller.groupbuy.putOutList);
  app.get('/api/groupbuy/exportGoodsList', app.controller.groupbuy.exportGoodsList);
  app.post('/api/groupbuy/actcats', app.controller.groupbuy.activityCats);
  app.post('/api/groupbuy/actList', app.controller.groupbuy.activityList);
  app.post('/api/groupbuy/stick', app.controller.groupbuy.stick);
  app.post('/api/groupbuy/updateSaleState', app.controller.groupbuy.updateSaleState);
  app.post('/api/groupbuy/updateSaleStateOnGoods', app.controller.groupbuy.updateSaleStateOnGoods);
  app.post('/api/groupbuy/updateActivitySort', app.controller.groupbuy.updateActivitySort);
  app.post('/api/groupbuy/updateActivityRatio', app.controller.groupbuy.updateActivityAddPriceRatio);
  app.post('/api/groupbuy/goodsList', app.controller.groupbuy.goodsList);
  app.post('/api/groupbuy/updateGoodsInfo', app.controller.groupbuy.updateGoodsInfo);
  app.post('/api/groupbuy/addHot', app.controller.groupbuy.uploadHotGoods);
  app.post('/api/groupbuy/delHot', app.controller.groupbuy.cancelHotGoods);
  app.post('/api/groupbuy/afterSale/list', app.controller.groupbuy.afterSaleOrderList);
  app.post('/api/groupbuy/createHotGoodsList', app.controller.groupbuy.createHotGoodsList);
  app.post('/api/groupbuy/addGoodsToHotList', app.controller.groupbuy.addGoodsToHotList);
  app.post('/api/groupbuy/delGoodsHotList', app.controller.groupbuy.delGoodsHotList);
  app.post('/api/groupbuy/deleteGoodsHotList', app.controller.groupbuy.deleteGoodsHotList);
  app.post('/api/groupbuy/addGoodsHotList', app.controller.groupbuy.addGoodsHotList);
  app.post('/api/groupbuy/updateSortGoodsHotList', app.controller.groupbuy.updateSortGoodsHotList);
  app.post('/api/groupbuy/updateGoodsHotList', app.controller.groupbuy.updateGoodsHotList);
  app.post('/api/groupbuy/updateShareHotList', app.controller.groupbuy.updateShareHotList);
  app.post('/api/groupbuy/createShareHotList', app.controller.groupbuy.createShareHotList);
  app.post('/api/groupbuy/selectActivity', app.controller.groupbuy.selectActivity);
  app.post('/api/groupbuy/selectShare', app.controller.groupbuy.selectShare);
  app.post('/api/groupbuy/andHotAct', app.controller.groupbuy.andHotAct);
  app.post('/api/groupbuy/delGoods', app.controller.groupbuy.delGoods);
  app.post('/api/groupbuy/findGoodsHotList', app.controller.groupbuy.findGoodsHotList);
  app.post('/api/groupbuy/findHotGoods', app.controller.groupbuy.findHotGoods);
  app.post('/api/groupbuy/afterSale/approve', app.controller.groupbuy.afterSaleApprove);
  app.post('/api/groupbuy/afterSale/reject', app.controller.groupbuy.afterSaleReject);
  app.post('/api/groupbuy/afterSale/updateImages', app.controller.groupbuy.updateAfterSaleImages);
  app.post('/api/groupbuy/afterSale/uploadLogistics', app.controller.groupbuy.uploadLogistics);
  app.post('/api/groupbuy/afterSale/refund', app.controller.groupbuy.afterSaleRefund);
  app.post('/api/groupbuy/afterSale/reasons', app.controller.groupbuy.afterSaleReasonList);
  app.post('/api/groupbuy/updateOrderAfterSaleStatus', app.controller.groupbuy.updateOrderStatus);
  app.post('/api/groupbuy/afterSale/updateDeliveryInfo', app.controller.groupbuy.updateStoreDeliveryInfo);
  app.post('/api/groupbuy/afterSale/updateSellerDeliveryInfo', app.controller.groupbuy.updateSellerDeliveryInfo);
  app.post('/api/groupbuy/afterSale/update', app.controller.groupbuy.updateACKAfterSaleOrder);
  app.post('/api/groupbuy/updateActivityWxVisibility', app.controller.groupbuy.updateMiniProgramVisibility);
  app.post('/api/groupbuy/updateTag', app.controller.groupbuy.updateTag);
  app.post('/api/groupbuy/allOnSaleGoods', app.controller.groupbuy.allOnSaleGoods);
  app.post('/api/groupbuy/restartAfterSale', app.controller.groupbuy.restartAfterSale);
  app.post('/api/groupbuy/applyAfterSale', app.controller.groupbuy.applyAfterSale);
  app.post('/api/groupbuy/cancelAfterSale', app.controller.groupbuy.cancelAfterSale);
  app.post('/api/groupbuy/alreadyRefund', app.controller.groupbuy.alreadyRefund);
  app.post('/api/groupbuy/listCaptainGoods', app.controller.groupbuy.listCaptainGoods);
  app.post('/api/groupbuy/createCaptainGoods', app.controller.groupbuy.createCaptainGoods);
  app.post('/api/groupbuy/updateCaptainGoods', app.controller.groupbuy.updateCaptainGoods);
  app.post('/api/groupbuy/listOwnActNoOwnGoodsAct', app.controller.groupbuy.listOwnActNoOwnGoodsAct);
  app.post('/api/groupbuy/updateOwnActNoOwnGoodsAct', app.controller.groupbuy.updateOwnActNoOwnGoodsAct);
  app.post('/api/groupbuy/createOwnActNoOwnGoodsAct', app.controller.groupbuy.createOwnActNoOwnGoodsAct);
  app.post('/api/groupbuy/listTag', app.controller.groupbuy.listTag);
  app.post('/api/groupbuy/listTagForWXMiniProgram', app.controller.groupbuy.listTagForWXMiniProgram);
  app.post('/api/groupbuy/listBrand', app.controller.groupbuy.listBrand);
  app.post('/api/groupbuy/createBrand', app.controller.groupbuy.createBrand);
  app.post('/api/groupbuy/createNoOwnGoods', app.controller.groupbuy.createNoOwnGoods);
  app.post('/api/groupbuy/listOwnActGoods', app.controller.groupbuy.listOwnActGoods);
  app.post('/api/groupbuy/updateGoodsSort', app.controller.groupbuy.updateGoodsSort);
  app.post('/api/groupbuy/deleteGoodsSort', app.controller.groupbuy.deleteGoodsSort);
  app.post('/api/groupbuy/getMiniProgramGroupVisibility', app.controller.groupbuy.getMiniProgramGroupVisibility);
  app.post('/api/groupbuy/productForAfterSaleOrder', app.controller.groupbuy.productForAfterSaleOrder);
  app.post('/api/groupbuy/ownActOwnGoodsActList', app.controller.groupbuy.ownActOwnGoodsActList);
  app.post('/api/groupbuy/ownActOwnGoodsList', app.controller.groupbuy.ownActOwnGoodsList);
  app.post('/api/groupbuy/statusUpdateAct', app.controller.groupbuy.statusUpdateAct);
  app.post('/api/groupbuy/statusUpdateGoods', app.controller.groupbuy.statusUpdateGoods);
  app.post('/api/groupbuy/ownActEdit', app.controller.groupbuy.ownActEdit);
  app.post('/api/groupbuy/ownGoodsEdit', app.controller.groupbuy.ownGoodsEdit);
  app.post('/api/groupbuy/ownActAdd', app.controller.groupbuy.ownActAdd);
  app.post('/api/groupbuy/ownGoodsAdd', app.controller.groupbuy.ownGoodsAdd);
  app.post('/api/groupbuy/ownGoodsSkuSee', app.controller.groupbuy.ownGoodsSkuSee);
  app.post('/api/groupbuy/ownGoodsSkuAdd', app.controller.groupbuy.ownGoodsSkuAdd);
  app.post('/api/groupbuy/ownGoodsSkuEdit', app.controller.groupbuy.ownGoodsSkuEdit);
  app.post('/api/groupbuy/batchGoodsBindOwnBrand', app.controller.groupbuy.batchGoodsBindOwnBrand);

  app.post('/api/groupbuy/brand/brandTypes', app.controller.brand.brandTypes);
  app.post('/api/groupbuy/brand/brandLebals', app.controller.brand.brandLebals);
  app.post('/api/groupbuy/brand/noAddBrandDBList', app.controller.brand.noAddBrandDBList);
  app.post('/api/groupbuy/brand/brandBind', app.controller.brand.brandBind);
  app.post('/api/groupbuy/brand/brandListAddTag', app.controller.brand.brandListAddTag);
  app.post('/api/groupbuy/brand/brandMVBanned', app.controller.brand.brandMVBanned);
  app.post('/api/groupbuy/brand/brandList', app.controller.brand.brandList);
  app.post('/api/groupbuy/brand/brandCreate', app.controller.brand.brandCreate);
  app.post('/api/groupbuy/brand/brandUpdate', app.controller.brand.brandUpdate);
  app.post('/api/groupbuy/brand/brandInfo', app.controller.brand.brandInfo);
  app.post('/api/groupbuy/brand/listTag', app.controller.brand.listTag);
  app.post('/api/groupbuy/brand/getTagName', app.controller.brand.getTagName);
  app.post('/api/groupbuy/brand/searchName', app.controller.brand.searchName);
  app.post('/api/groupbuy/brand/noAddGetInformtion', app.controller.brand.noAddGetInformtion);
  app.post('/api/groupbuy/brand/deleteSinceBrand', app.controller.brand.deleteSinceBrand);
  app.post('/api/groupbuy/brand/getMd5', app.controller.brand.getMd5);
  app.post('/api/groupbuy/brand/sendMessage', app.controller.brand.sendMessage);

  app.post('/api/aikucun/actList', app.controller.aikucun.activityList);
  app.post('/api/aikucun/productList', app.controller.aikucun.productList);
  app.post('/api/aikucun/afterSale/create', app.controller.aikucun.createAfterSaleBill);
  app.post('/api/aikucun/afterSale/update', app.controller.aikucun.updateAfterSaleBill);
  app.post('/api/aikucun/afterSale/query', app.controller.aikucun.queryAfterSaleBill);
  app.post('/api/aikucun/afterSale/cancel', app.controller.aikucun.cancelAfterSaleBill);
  app.post('/api/aikucun/afterSale/uploadlogistics', app.controller.aikucun.queryOrderLogisticsStatus);
  app.post('/api/aikucun/order/query', app.controller.aikucun.queryOrder);
  app.post('/api/aikucun/order/queryByExternal', app.controller.aikucun.queryOrderByExternalOrderID);

  app.post('/api/zhitong/charge', app.controller.zhitong.charge);
  app.post('/api/zhitong/query', app.controller.zhitong.queryOrder);

  app.post('/api/seckill/list', app.controller.seckill.getSeckillList);
  app.post('/api/seckill/create', app.controller.seckill.createSeckillLists);
  app.post('/api/seckill/addProduct', app.controller.seckill.addProductToSeckillList);
  app.post('/api/seckill/updateProduct', app.controller.seckill.updateProductInSeckillList);
  app.post('/api/seckill/removeProduct', app.controller.seckill.removeProductFromSeckillList);

  // 自营砍价活动相关
  app.post('/api/proprietaryActivity/getActivityList', app.controller.proprietaryActivity.getActivityList);
  app.post('/api/proprietaryActivity/getActivityListById', app.controller.proprietaryActivity.getActivityListById);
  app.post('/api/proprietaryActivity/updateActivityListById', app.controller.proprietaryActivity.updateActivityListById);
  app.post('/api/proprietaryActivity/createActivity', app.controller.proprietaryActivity.createActivity);
  app.post('/api/proprietaryActivity/getGoodsList', app.controller.proprietaryActivity.getGoodsList);
  app.post('/api/proprietaryActivity/getGoodsById', app.controller.proprietaryActivity.getGoodsById);
  app.post('/api/proprietaryActivity/updateGoods', app.controller.proprietaryActivity.updateGoods);
  app.post('/api/proprietaryActivity/deleteGoods', app.controller.proprietaryActivity.deleteGoods);
  app.post('/api/proprietaryActivity/createGoods', app.controller.proprietaryActivity.createGoods);
  app.post('/api/proprietaryActivity/checkGoods', app.controller.proprietaryActivity.checkGoods);
  app.post('/api/proprietaryActivity/updateActivityListRoleById', app.controller.proprietaryActivity.updateActivityListRoleById);

  // 雀享优品优惠券
  app.post('/api/selfOptCoupon/list', app.controller.selfOptCoupon.couponList);
  app.post('/api/selfOptCoupon/update', app.controller.selfOptCoupon.updateCoupon);
  app.post('/api/selfOptCoupon/addCoupon', app.controller.selfOptCoupon.addCoupon);
  app.post('/api/selfOptCoupon/attachment', app.controller.selfOptCoupon.couponAttachments);
  app.post('/api/selfOptCoupon/productsOverallIDs', app.controller.selfOptCoupon.productsOverallIDs);
  app.post('/api/selfOptCoupon/couponSearchKeywords', app.controller.selfOptCoupon.couponSearchKeywords);


/* -------------------------------------------------------------------------------------------------------------------------------------------------*/

//注册模块
app.post('/api/register/reAccount', app.controller.register.reAccount);
// app.post('/api/register/reInformation', app.controller.register.reInformation);

//个人信息管理模块
app.post('/api/userInformation/searchMs', app.controller.userInformation.searchMs);
app.post('/api/userInformation/changeMS', app.controller.userInformation.changeMS);
app.post('/api/userInformation/updatePs', app.controller.userInformation.updatePs);

//课室模块
app.post('/api/classroom/checkClass', app.controller.classroom.checkClass);
app.post('/api/classroom/deletClass', app.controller.classroom.deletClass);
app.post('/api/classroom/addClass', app.controller.classroom.addClass);
app.post('/api/classroom/selectAll', app.controller.classroom.selectAll);
app.post('/api/classroom/updateState', app.controller.classroom.updateState);


//预约模块
app.post('/api/appointment/insertTime', app.controller.appointment.insertTime);
app.post('/api/appointment/recordAppiont', app.controller.appointment.recordAppiont);
app.post('/api/appointment/judgeAppiont', app.controller.appointment.judgeAppiont);


//预约记录查询模块
app.post('/api/record/historyRecord', app.controller.record.historyRecord);
app.post('/api/record/updateState', app.controller.record.updateState);
app.post('/api/record/findRecord', app.controller.record.findRecord);

//管理员审批模块
app.post('/api/examine/userAppiont', app.controller.examine.userAppiont);
app.post('/api/examine/successAppiont', app.controller.examine.successAppiont);
app.post('/api/examine/failedAppiont', app.controller.examine.failedAppiont);
app.post('/api/examine/selectOther', app.controller.examine.selectOther);


//审批记录
app.post('/api/exhistory/historyList', app.controller.exhistory.historyList);
app.post('/api/exhistory/selectAppiont', app.controller.exhistory.selectAppiont);

//用户信息权限管理
app.post('/api/userRole/userInfo', app.controller.userRole.userInfo);
app.post('/api/userRole/selectInfo', app.controller.userRole.selectInfo);
app.post('/api/userRole/userRecord', app.controller.userRole.userRecord);

//用户预约记录查询
app.post('/api/appReord/listReord', app.controller.appReord.listReord);
app.post('/api/appReord/ownList', app.controller.appReord.ownList);


//定时任务
app.post('/api/examine/changeState', app.controller.examine.changeState);
app.post('/api/examine/updateNull', app.controller.examine.updateNull);


  // 这个必须放到最后，涉及到服务端渲染
  app.get('/*', app.controller.app.index);
};
