/*
 * @Author: yuzc
 * @Date: 2018-05-29 11:18:27
 * @Last Modified by: yuzc
 * @Last Modified time: 2018-07-09 15:42:48
 * 数据关系，sequelize.js关系定义
 */
'use strict';

module.exports = function(models) {
  models.user.hasOne(models.user_role_relation, {
    as: 'user_role',
    foreignKey: 'user_id'
  });
  models.user.hasOne(models.shop, {
    foreignKey: 'user_id'
  });
};
