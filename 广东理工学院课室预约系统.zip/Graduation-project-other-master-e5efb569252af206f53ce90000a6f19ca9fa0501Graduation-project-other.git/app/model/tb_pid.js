/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('tb_pid', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    pid: {
      type: DataTypes.STRING(255),
      allowNull: true,
      defaultValue: ''
    },
    pid_name: {
      type: DataTypes.CHAR(20),
      allowNull: true
    },
    status: {
      type: DataTypes.INTEGER(255),
      allowNull: true,
      defaultValue: '0'
    }
  }, {
    timestamps: false,
    tableName: 'tb_pid'
  });
};
