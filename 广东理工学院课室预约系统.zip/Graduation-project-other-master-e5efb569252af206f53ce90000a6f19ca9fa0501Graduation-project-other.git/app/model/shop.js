/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('shop', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    user_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      defaultValue: '0'
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true,
      defaultValue: ''
    },
    province_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      defaultValue: '0'
    },
    city_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      defaultValue: '0'
    },
    area_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      defaultValue: '0'
    },
    address: {
      type: DataTypes.STRING(255),
      allowNull: true,
      defaultValue: ''
    },
    people_name: {
      type: DataTypes.STRING(255),
      allowNull: true,
      defaultValue: ''
    },
    people_id_card: {
      type: DataTypes.STRING(255),
      allowNull: true,
      defaultValue: ''
    },
    phone: {
      type: DataTypes.STRING(255),
      allowNull: true,
      defaultValue: ''
    },
    invitation_user_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      defaultValue: '0'
    },
    business_license: {
      type: DataTypes.STRING(255),
      allowNull: true,
      defaultValue: ''
    },
    facade: {
      type: DataTypes.STRING(255),
      allowNull: true,
      defaultValue: ''
    },
    create_time: {
      type: DataTypes.BIGINT,
      allowNull: true,
      defaultValue: '0'
    },
    update_time: {
      type: DataTypes.BIGINT,
      allowNull: true,
      defaultValue: '0'
    },
    status: {
      type: DataTypes.INTEGER(255),
      allowNull: true,
      defaultValue: '0'
    }
  }, {
    timestamps: false,
    tableName: 'shop',
    indexes: [
      {
        fields: ['id', 'user_id', 'invitation_user_id']
      }
    ],
    underscored: true
  });
};
