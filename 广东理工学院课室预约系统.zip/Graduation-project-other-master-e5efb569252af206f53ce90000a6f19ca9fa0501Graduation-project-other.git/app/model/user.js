/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('user', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true,
      defaultValue: ''
    },
    phone: {
      type: DataTypes.STRING(255),
      allowNull: true,
      defaultValue: ''
    },
    avatar_url: {
      type: DataTypes.STRING(255),
      allowNull: true,
      defaultValue: ''
    },
    pid_id: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    invitation_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      defaultValue: '0'
    },
    create_time: {
      type: DataTypes.BIGINT,
      allowNull: true,
      defaultValue: '0'
    },
    update_time: {
      type: DataTypes.BIGINT,
      allowNull: true,
      defaultValue: '0'
    },
    province_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      defaultValue: '0'
    },
    city_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      defaultValue: '0'
    },
    area_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      defaultValue: '0'
    }
  }, {
    timestamps: false,
    tableName: 'user',
    indexes: [
      {
        fields: ['id', 'pid_id', 'phone', 'invitation_id']
      }
    ],
    underscored: true
  });
};
