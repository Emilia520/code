/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('user_role_relation', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    user_id: {
      type: DataTypes.BIGINT,
      allowNull: true
      // references: {
      //   model: this.ctx.service.db.user, // 既可以是表示表名的字符串，也可以是 Sequelize 模型
      //   key: 'id'
      // }
    },
    role_id: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    vip_start_time: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    vip_stop_time: {
      type: DataTypes.BIGINT,
      allowNull: true
    }
  }, {
    timestamps: false,
    tableName: 'user_role_relation',
    indexes: [
      {
        fields: ['id', 'user_id', 'role_id']
      }
    ],
    underscored: true
  });
};
