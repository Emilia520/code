/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('model_banner', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    start_time: {
      type: DataTypes.BIGINT,
      allowNull: true,
      defaultValue: '0'
    },
    stop_time: {
      type: DataTypes.BIGINT,
      allowNull: true,
      defaultValue: '0'
    },
    image_url: {
      type: DataTypes.STRING(500),
      allowNull: true,
      defaultValue: ''
    },
    url: {
      type: DataTypes.STRING(500),
      allowNull: true,
      defaultValue: ''
    },
    title: {
      type: DataTypes.STRING(255),
      allowNull: true,
      defaultValue: ''
    },
    sort: {
      type: DataTypes.INTEGER(20),
      allowNull: true,
      defaultValue: '0'
    }
  }, {
    timestamps: false,
    tableName: 'model_banner'
  });
};
