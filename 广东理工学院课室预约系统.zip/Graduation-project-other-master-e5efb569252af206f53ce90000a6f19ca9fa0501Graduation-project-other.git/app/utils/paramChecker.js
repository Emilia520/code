const ErrCode = require('./errorCode');

exports.paramType = {
  PARAM_TYPE_INT: 'int',
  PARAM_TYPE_FLOAT: 'float',
  PARAM_TYPE_ARRAY: 'array',
  PARAM_TYPE_VERSION: 'ver'
};

exports.check = (type, param, paramName = '') => {
  if (type == exports.paramType.PARAM_TYPE_INT || type == exports.paramType.PARAM_TYPE_FLOAT) {
    if (isNaN(param)) {
      throw { code: ErrCode.ERROR_CODE_PARAM, msg: '参数错误，参数应为数字类型，' + paramName + ' = ' + param };
    }
  } else if (type == exports.paramType.PARAM_TYPE_ARRAY) {
    if (!Array.isArray(param)) {
      throw { code: ErrCode.ERROR_CODE_PARAM, msg: '参数错误，参数应为数组类型，' + paramName + ' = ' + param };
    }
  } else if (type == exports.paramType.PARAM_TYPE_VERSION) {
    const vcodes = param.split('.');
    // 把字符串版本号转成数字类型
    for (const i in vcodes) {
      const vcode = parseInt(vcodes[i]);
      if (isNaN(vcode)) {
        throw { code: ErrCode.ERROR_CODE_PARAM, msg: '参数错误，非法版本号，' + paramName + ' = ' + param };
      } else {
        vcodes[i] = vcode;
      }
    }
  }
};