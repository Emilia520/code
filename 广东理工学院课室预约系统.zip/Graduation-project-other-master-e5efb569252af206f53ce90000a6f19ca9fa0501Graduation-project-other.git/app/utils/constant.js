const path = require('path');

exports.promoteType = {
  SINGLE_GOODS_PROMOTE: 1, // 单品推广
  CHANNEL_PROMOTE: 2, // 频道推广 1.9包邮、今日爆款、品牌清仓等
  RED_PACKAGE_PROMOTE: 3, // 红包推广
  THEME_PROMOTE: 4, // 主题推广
  BIG_WHEEL_PROMOTE: 5, // 大转盘推广
  ODDS_PROMOTE: 6, // 特惠推广 限时秒杀、电器专场等
  ACTIVITY_PROMOTE: 7 // 品牌特卖活动推广
};

exports.channelType = {
  FREE_POSTAGE_1_9: 0, // 1.9包邮
  TODAY_HOT_CAKE: 1, // 今日爆款
  BRAND_CLEARANCE: 2, // 品牌清仓
  TIME_LIMITED_SECKILL: 4, // 限时秒杀
  RECHARE_CENTER: 39997, // 充值中心
  ELECTRIC_CITY: 39999 // 电器城
};

exports.platform = {
  TB: 0,
  PDD: 3
};

exports.key = {
  PDD_WHEEL_COOKIE: 'qx_admin_pdd_wheel_cookie',
  WX_GROUP: 'qx_wxgroup',
  ROBOT_GROUP: 'qx_robot_group',
  ROBOT_MSG_QUEUEING: 'qx_robot_msg_queueing',
  AKC_REFUND: 'refund',
  OWN_ACT_NO_OWN_ACTIVITY_QXB: 'own_act_and_no_goods_act_id_QXB',
  OWN_ACT_NO_OWN_GOODS_QXB: 'own_act_and_no_goods_goods_list_id_QXB_',
  MINI_PROGRAM_MSG_QUEUE: 'qx_mini_program_msg_queue',
  MINI_PROGRAM_MSG_RESULT: 'qx_mini_program_msg_result',
  AIKUCUN_TAG_QXB_WX_MINI: 'AIKUCUN_TAG_QXB_WX_MINI',
};

exports.choiceListOfferPos = {
  HOME_PAGE_AD: 0, // 首页广告位
  CHOICEST_LIST: 1, // 好物推荐列表， choicest：精选的，最好的
  HOT_SALE_LIST: 2, // 爆款列表
  SERIES_LIST: 3, // 主题商品列表
  LOTTERY_LIST: 4, // 抽奖商品列表
};

/**
 * 选品队列商品item的操作动作枚举
 * @type {{add: number, remove: number, forward: number, backward: number}}
 */
exports.choiceListItemOpt = {
  ADD: 0,
  REMOVE: 1,
  FORWARD: 2, // 前移1位
  BACKWARD: 3, // 后移1位
};

exports.tklTempl = '【在售价】￥{reserve_price}\n【抢购价】￥{zk_final_price}\n-----------------\n复制这条信息，{tb_tkl}，打开【手机淘宝】即可抢购';
exports.tbBgImgUrl = path.resolve(__dirname, '../../static/tb_shared_bg.png');
exports.robotMsgStatus = {
  QUEUE: 1, // 发送队列中
  REVERT: 2, // 撤回
  SUCCESS: 3, // 全部成功
  SUCCESS_PARTIALLY: 4, // 部分成功
  FAILED: 5, // 全部失败
  EXCEPTION: 6 // 异常
};