/* eslint-disable no-extend-native */
const tbl = require('../model/tbl');
// const fs = require('fs');

exports.inArray = (arr, obj) => {
  for (const i in arr) {
    if (obj == arr[i]) {
      return true;
    }
  }
  return false;
};

exports.genReplaceSql = (tblName, obj) => {
  const objkeys = tbl[tblName];
  if (!objkeys) {
    return '';
  }

  const keys = [];
  const vals = [];
  for (const j in objkeys) {
    const key = objkeys[j];
    const val = obj[key];
    keys.push(key);
    if (val) {
      if (typeof val === 'string') {
        vals.push("'" + val + "'");
      } else {
        vals.push(val);
      }
    } else {
      vals.push('null');
    }
  }
  let sql = 'REPLACE INTO ' + tblName + ' (' + keys.join(',') + ') VALUES (' + vals.join(',') + ')';
  sql = sql.replace('\\', '');
  return sql;
};

exports.genInsertDupUpdateSql = (tblName, obj, dupKey, ignoreKeys = []) => {
  const objkeys = tbl[tblName];
  if (!objkeys) {
    return '';
  }

  const keys = [];
  const vals = [];
  const dupkeys = [];
  for (const j in objkeys) {
    const key = objkeys[j];
    if (this.inArray(ignoreKeys, key)) {
      continue;
    }

    const val = obj[key];
    keys.push(key);
    if (typeof (val) !== 'undefined' && val !== null) {
      if (typeof val === 'string') {
        vals.push("'" + val + "'");
      } else {
        vals.push(val);
      }
    } else {
      vals.push('null');
    }

    if (key !== dupKey) {
      dupkeys.push(`${key}=VALUES(${key})`);
    }
  }
  // let sql = 'INSERT INTO ' + tblName + ' (' + keys.join(',') + ') VALUES (' + vals.join(',') + ')';
  let sql = `INSERT INTO ${tblName} (${keys.join(',')}) VALUES (${vals.join(',')}) ON DUPLICATE KEY UPDATE ${dupkeys.join(',')}`;
  sql = sql.replace('\\', '');
  return sql;
};

exports.calRealLength = function(text) {
  let len = 0;
  for (let i = 0, l = text.length; i < l; ++i) {
    const c = text.charAt(i);
    if (escape(c).length > 4) {
      len += 2;
    } else if (c != '\r') {
      ++len;
    }
  }
  return len;
};

exports.subStringByRealLength = function(text, index, length) {
  let ret = '';
  if (!text) {
    return ret;
  }

  let cursor = 0;
  let len = 0;
  let step = 0;
  let enable = false;
  for (let i = 0, l = text.length; i < l; ++i) {
    if (length <= len) {
      break;
    }
    const c = text.charAt(i);
    if (index <= cursor) {
      ret += c;
      enable = true;
    }
    if (escape(c).length > 4) {
      step = 2;
    } else if (c != '\r') {
      step = 1;
    } else {
      step = 0;
    }

    cursor += step;
    if (enable) {
      len += step;
    }
  }

  return ret;
};

exports.isNotEmptyStr = function(str) {
  return typeof str === 'string' && str.length !== 0;
};

exports.dateFmt = (fmt, date) => {
  const o = {
    'M+': date.getMonth() + 1, // 月份
    'd+': date.getDate(), // 日
    'h+': date.getHours(), // 小时
    'm+': date.getMinutes(), // 分
    's+': date.getSeconds(), // 秒
    'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
    S: date.getMilliseconds() // 毫秒
  };
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(
      RegExp.$1,
      (date.getFullYear() + '').substr(4 - RegExp.$1.length)
    );
  }
  for (const k in o) {
    if (new RegExp('(' + k + ')').test(fmt)) {
      fmt = fmt.replace(
        RegExp.$1,
        RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length)
      );
    }
  }
  return fmt;
};
// 生成随机流水号
exports.genSerialNo = () => {
  const dateStr = this.dateFmt('yyyyMMddhhmmss', new Date());
  return dateStr + Math.random().toString(10).substr(3, 7);
};
