const Service = require('egg').Service;
const ErrCode = require('../utils/errorCode');
const checker = require('../utils/paramChecker');
const Constant = require('../utils/constant');

module.exports = () => {
  return class Home extends Service {

    /**
     *  版本配置资源
     */
    async versionList(filterParams = {}) {
      // 支持版本号，client类型和生效时间查询
      const queryClause = {};
      if (filterParams.startTime) {
        queryClause.start_time = this.app.mysql.literal(`>= ${filterParams.startTime}`);
      }

      if (filterParams.endTime) {
        queryClause.end_time = this.app.mysql.literal(`<= ${filterParams.endTime}`);
      }

      if (filterParams.startVersion) {
        queryClause.full_start_version = this.app.mysql.literal(`>= ${Home.convertVersionCodes()}`);
      }


      const querySQL = '';

    }

    async banner(params = {}) {
      const queryCondition = this.parseQueryCondition(params);
      const sql = `SELECT SQL_CALC_FOUND_ROWS * FROM (SELECT a.id, a.image_url, a.url, a.title, a.sort, b.start_version, b.end_version, b.start_time, b.end_time, b.client_id, 
      ${Home._expandVerSQL('b.end_version')} AS start_vcode, 
      ${Home._expandVerSQL('b.end_version')} AS end_vcode 
      FROM model_banner a, config_client b WHERE a.client_id = b.id) tmp ${queryCondition};`;

      console.log(sql);
      const list = await this.app.mysql.query(sql);
      const totalCountArr = await this.app.mysql.query('SELECT FOUND_ROWS();');
      return { list, totalCount: Object.values(totalCountArr[0])[0] };
    }

    async updateClient(params) {
      const id = params.id;
      const client_id = params.client_id;
      const start_version = params.start_version;
      const end_version = params.end_version;
      const start_time = params.start_time;
      const end_time = params.end_time;
      const status = params.status;
      const sort = params.sort;
      const sql = `update config_client 
                    set client_id = ${client_id},start_version='${start_version}',
                    end_version='${end_version}',start_time=${start_time},end_time=${end_time}
                    ,status = ${status},sort = ${sort}
                    where id = ${id}`;

      console.log(sql);
      const list = await this.app.mysql.query(sql);
      const totalCountArr = await this.app.mysql.query('SELECT FOUND_ROWS();');
      return { list, totalCount: Object.values(totalCountArr[0])[0] };
    }

    async getClient(params) {
      let list = [];
      let totalCount = 0;
      const client_id = params.client_id;
      const status = params.status;
      let where;
      if (client_id) {
        if (status) {
          where = `where client_id = ${client_id} and status = ${status}`;
        } else {
          where = `where client_id = ${client_id} `;
        }
      } else if (status) {
        where = `where status = ${status}`;
      }
      const pageNum = params.page || 1;
      const pageSize = params.pageSize || 10;
      const limit = `LIMIT ${(pageNum - 1) * pageSize}, ${pageSize}`;
      const sql = `select * from config_client 
                        ${where}
                        order by update_time desc
                          ${limit}`;
      list = await this.app.mysql.query(sql);
      const cntSql = `SELECT COUNT(*) 
                            from config_client  ${where} `;
      const totalCountArr = await this.app.mysql.query(cntSql);
      totalCount = totalCountArr && totalCountArr[0] ? Object.values(totalCountArr[0])[0] : 0;
      // 如果数量为0就不需要再查具体数据了
      if (totalCount > 0) {
        list = await this.app.mysql.query(sql);
      }
      return { list, totalCount };
    }

    async getBannerList(params) {
      let list = [];
      let totalCount = 0;
      const id = params.client_id;
      const key_type = params.key_type === -1 ? -1 : params.key_type || 1;
      const key = key_type !== -1 ? `and key_type  = ${key_type}` : '';

      const pageNum = params.page || 1;
      const pageSize = params.pageSize || 10;
      const limit = `LIMIT ${(pageNum - 1) * pageSize}, ${pageSize}`;
      const sql = `select * from model_config
                        where client_id = ${id} 
                         ${key}
                        order by end_time desc
                          ${limit}`;
      list = await this.app.mysql.query(sql);
      const cntSql = `SELECT COUNT(*) 
                          from model_config
                          where client_id = ${id} 
                          and key_type = ${key_type}  `;
      const totalCountArr = await this.app.mysql.query(cntSql);
      totalCount = totalCountArr && totalCountArr[0] ? Object.values(totalCountArr[0])[0] : 0;
      // 如果数量为0就不需要再查具体数据了
      if (totalCount > 0) {
        list = await this.app.mysql.query(sql);
      }
      return { list, totalCount };
    }

    async getBanner(params) {
      let list = [];
      const id = params.id;
      const sql = `select * from model_config where client_id = ${id} and  key_type in (1,10)`;
      list = await this.app.mysql.query(sql);
      return { list };
    }

    async getRedisKeys(params) {
      const list = await this.app.redis.get('db3').scan(0, 'count', 50);
      return { list };
    }

    async delRedisKeys(params) {
      for (const index in params) {
        await this.app.redis.get('db3').del(params[index]);
      }
    }

    async getBannerById(params) {
      const id = params.id;
      const sql = `select * from model_config where id = ${id} `;
      const list = await this.app.mysql.query(sql);
      return { list };
    }

    async updateBannerList(params) {
      const id = params.id;
      const value = params.value;
      const sql = `update model_config set value = '${value}' 
                        where id = ${id} `;
      await this.app.mysql.query(sql);
    }

    async editBannerList(params) {
      const id = params.id;
      const end_time = params.end_time;
      const start_time = params.start_time;
      const status = params.status;
      const sql = `update model_config set end_time = ${end_time},start_time = ${start_time},status = ${status}
                        where id = ${id} `;
      await this.app.mysql.query(sql);
    }

    async createBannerList(params) {
      const value = params.values ? params.values : '[]';
      const end_time = params.end_time;
      const start_time = params.start_time;
      const status = params.status;
      const client_id = params.client_id;
      const key = params.key_type;
      const type = params.type ? params.type : 0;
      const sql1 = `select * from config_client where id = ${client_id} `;
      const list = await this.app.mysql.query(sql1);
      /*     let key = '';
      const client = list[0].client_id;
      if (list[0].client_id === 10 || list[0].client_id === 11) {
        key = 10;
      } else {
        key = 1;
      }*/
      const sql2 = `insert into model_config set end_time = ${end_time},start_time = ${start_time},status = ${status},client_id = ${client_id},key_type = ${key},type = ${type},value = '${value}'
                     `;
      await this.app.mysql.query(sql2);
    }

    async createClientList(params) {
      const client_id = params.client_id;
      const start_version = params.start_version;
      const end_version = params.end_version;
      const start_time = params.start_time;
      const end_time = params.end_time;
      const status = params.status;
      const sort = params.sort;
      const sql = `insert into config_client 
                    set client_id = ${client_id},start_version='${start_version}',
                    end_version='${end_version}',start_time=${start_time},end_time=${end_time}
                    ,status = ${status},sort = ${sort}`;
      await this.app.mysql.query(sql);
    }

    async addBanner(params) {
      // 校验参数
      checker.check(checker.paramType.PARAM_TYPE_INT, params.sort, '权重');
      checker.check(checker.paramType.PARAM_TYPE_INT, params.client_id, '投放平台');
      checker.check(checker.paramType.PARAM_TYPE_INT, params.start_time, '生效起始时间');
      checker.check(checker.paramType.PARAM_TYPE_INT, params.end_time, '生效结束时间');
      checker.check(checker.paramType.PARAM_TYPE_VERSION, params.start_version, '生效起始版本');
      checker.check(checker.paramType.PARAM_TYPE_VERSION, params.end_version, '生效结束版本');

      const start_version = Home.convertVersionCodes(params.start_version).join('.');
      const end_version = Home.convertVersionCodes(params.end_version).join('.');

      let configId = 0;
      let result = await this.app.mysql.select('config_client', {
        where: {
          client_id: params.client_id,
          start_version,
          end_version,
          start_time: params.start_time,
          end_time: params.end_time
        }
      });

      if (result.length > 0) {
        // 如果找到已有配置则直接用已有的
        configId = result[0].id;
      } else {
        // 否则就创建一条新配置
        result = await this.app.mysql.insert('config_client', {
          client_id: params.client_id,
          start_version: params.start_version,
          end_version: params.end_version,
          start_time: params.start_time,
          end_time: params.end_time
        });

        if (result.affectedRows === 1) {
          configId = result.insertId;
        } else {
          throw { code: ErrCode.ERROR_CODE_DB_INSERT, msg: '写入banner配置失败' };
        }
      }

      result = await this.app.mysql.insert('model_banner', {
        image_url: params.image_url,
        url: params.url,
        title: params.title,
        sort: params.sort,
        client_id: configId
      });

      if (result.affectedRows !== 1) {
        throw { code: ErrCode.ERROR_CODE_DB_INSERT, msg: '写入banner数据失败' };
      }
    }

    async updateBanner(params) {
      // 校验参数
      checker.check(checker.paramType.PARAM_TYPE_INT, params.id, 'id');
      checker.check(checker.paramType.PARAM_TYPE_INT, params.sort, '权重');
      checker.check(checker.paramType.PARAM_TYPE_INT, params.client_id, '投放平台');
      checker.check(checker.paramType.PARAM_TYPE_INT, params.start_time, '生效起始时间');
      checker.check(checker.paramType.PARAM_TYPE_INT, params.end_time, '生效结束时间');
      checker.check(checker.paramType.PARAM_TYPE_VERSION, params.start_version, '生效起始版本');
      checker.check(checker.paramType.PARAM_TYPE_VERSION, params.end_version, '生效结束版本');

      const start_version = Home.convertVersionCodes(params.start_version).join('.');
      const end_version = Home.convertVersionCodes(params.end_version).join('.');

      let configId = 0;
      let result = await this.app.mysql.select('config_client', {
        where: {
          client_id: params.client_id,
          start_version,
          end_version,
          start_time: params.start_time,
          end_time: params.end_time
        }
      });

      if (result.length > 0) {
        // 如果找到已有配置则直接用已有的
        configId = result[0].id;
      } else {
        // 否则就创建一条新配置
        result = await this.app.mysql.insert('config_client', {
          client_id: params.client_id,
          start_version: params.start_version,
          end_version: params.end_version,
          start_time: params.start_time,
          end_time: params.end_time
        });

        if (result.affectedRows === 1) {
          configId = result.insertId;
        } else {
          throw { code: ErrCode.ERROR_CODE_DB_INSERT, msg: '写入banner配置失败' };
        }
      }

      result = await this.app.mysql.update('model_banner', {
        id: params.id,
        image_url: params.image_url,
        url: params.url,
        title: params.title,
        sort: params.sort,
        client_id: configId
      });

      if (result.affectedRows !== 1) {
        throw { code: ErrCode.ERROR_CODE_DB_INSERT, msg: '更新banner数据失败' };
      }
    }

    async deleteBanner(id) {
      // 校验参数
      checker.check(checker.paramType.PARAM_TYPE_INT, id, 'id');
      const sql = `delete from model_config
                        where id = ${id} `;
      await this.app.mysql.query(sql);

    }

    parseQueryCondition(params) {
      const whereConditions = [];
      const havingConditions = [];
      let where = '';
      let having = '';
      let limit = '';
      // 解析参数
      if (params.title) {
        whereConditions.push('title LIKE "%' + params.title + '%" ');
      }

      if (params.start_time) {
        whereConditions.push('start_time <= ' + params.start_time + ' ');
      }

      if (params.end_time) {
        whereConditions.push('end_time >= ' + params.end_time + ' ');
      }

      if (params.client_type) {
        whereConditions.push('client_type = ' + params.client_type + ' ');
      }

      if (whereConditions.length > 0) {
        where = 'WHERE ';
      }

      for (let index = 0; index < whereConditions.length; ++index) {
        where += (index === 0 ? '' : 'AND') + whereConditions[index];
      }

      if (params.start_version) {
        const vcodes = Home.convertVersionCodes(params.start_version);
        havingConditions.push(`start_vcode >= ${vcodes.map((code) => code.toString().padStart(5, '0')).join('')}`);
      }

      if (params.end_version) {
        const vcodes = Home.convertVersionCodes(params.end_version);
        havingConditions.push(`end_vcode <= ${vcodes.map((code) => code.toString().padStart(5, '0')).join('')}`);
      }

      if (havingConditions.length > 0) {
        having = 'HAVING ';
      }

      for (let i = 0; i < havingConditions.length; ++i) {
        having += (i === 0 ? '' : 'AND') + havingConditions[i];
      }

      having += ' ';

      const pageNum = params.pageNum != null ? params.pageNum : 1;
      const pageSize = params.pageSize != null ? params.pageSize : 10;
      limit = 'LIMIT ' + (pageNum - 1) * pageSize + ',' + pageSize;

      return where + having + 'ORDER BY id ' + limit;
    }

    static _convertVersionCodes(version_str) {
      const version = version_str.trim();
      let codes = version.split('.');

      // 版本号不足三位的，补足三位
      if (!codes[0]) {
        codes = ['0', '0', '0'];
      } else if (!codes[1]) {
        codes[1] = '0';
        codes[2] = '0';
      } else if (!codes[2]) {
        codes[2] = '0';
      }

      // 检查是否包含非数字字符
      codes.forEach(function(code) {
        if (isNaN(code)) {
          throw { code: ErrCode.ERROR_CODE_PARAM, msg: '参数错误，非法版本号，' + version_str };
        }
      });

      // 每段左填充0到5位后拼接
      return codes.map((code) => code.padStart(5, '0')).join('');
    }

    static _expandVerSQL(verAlias) {
      return `CONCAT(LPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(${verAlias}, '.', 1), '.', -1), 5, '0'), 
      LPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(${verAlias}, '.', 2), '.', -1), 5, '0'), 
      LPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(${verAlias}, '.', 3), '.', -1), 5, '0'))`;
    }
  };
};