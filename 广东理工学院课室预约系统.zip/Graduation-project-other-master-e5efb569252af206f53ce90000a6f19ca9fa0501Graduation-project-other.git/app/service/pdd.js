const Service = require('egg').Service;
const ErrCode = require('../utils/errorCode');
const utils = require('../utils/utils');
const checker = require('../utils/paramChecker');
const Constant = require('../utils/constant');
const crypto = require('crypto');
const client_id = '05e4a2ee4f4043ec8fae7e34ef1a8113';
const secret = '9b408bd1412b285863e5d99ce2c8a70e4041d789';

module.exports = () => {
  return class Pdd extends Service {
    async goodsList(params) {
      const ret = {};
      params.range_list = [];
      if (params.price_range && params.price_range.length > 1) {
        const rangeFrom = Number(params.price_range[0]);
        const rangeTo = Number(params.price_range[1]);
        if (!isNaN(rangeFrom) || !isNaN(rangeTo)) {
          const rangeObj = {};
          rangeObj.range_id = 1;
          // 原始数据是以“元”为单位，查询时需要转为“分”
          if (!isNaN(rangeFrom)) {
            rangeObj.range_from = rangeFrom * 100;
          }
          if (!isNaN(rangeTo) && rangeTo > 0) {
            rangeObj.range_to = rangeTo * 100;
          }
          params.range_list.push(rangeObj);
        }
        // 需要删除非拼多多查询字段
        delete params.price_range;
      }
      if (params.commission_range && params.commission_range.length > 1) {
        const rangeFrom = Number(params.commission_range[0]);
        const rangeTo = Number(params.commission_range[1]);
        if (!isNaN(rangeFrom) || !isNaN(rangeTo)) {
          const rangeObj = {};
          rangeObj.range_id = 2;
          // 原始数据是以“百分比”为单位，查询时需要转为”千分比“
          if (!isNaN(rangeFrom)) {
            rangeObj.range_from = rangeFrom * 10;
          }
          if (!isNaN(rangeTo) && rangeTo > 0) {
            rangeObj.range_to = rangeTo * 10;
          }
          params.range_list.push(rangeObj);
        }
        // 需要删除非拼多多查询字段
        delete params.commission_range;
      }
      params.range_list = JSON.stringify(params.range_list);
      console.log('params', params);
      const result = await this.sendRequest(params, 'pdd.ddk.goods.search');
      if (result.data && result.data.goods_search_response) {
        ret.list = result.data.goods_search_response.goods_list;
        ret.totalCount = result.data.goods_search_response.total_count;
      }

      return ret;
    }

    async categoryList(params) {
      const ret = {};
      const result = await this.sendRequest(params, 'pdd.goods.cats.get');
      if (result.data && result.data.goods_cats_get_response) {
        ret.list = result.data.goods_cats_get_response.goods_cats_list;
      }

      return ret;
    }

    async optList(params) {
      const ret = {};
      const result = await this.sendRequest(params, 'pdd.goods.opt.get');
      if (result.data && result.data.goods_opt_get_response) {
        ret.list = result.data.goods_opt_get_response.goods_opt_list;
      }

      return ret;
    }
    // 生成单品推广链接
    async genPromotionUrl(params) {
      const ret = {};
      const result = await this.sendRequest(params, 'pdd.ddk.goods.promotion.url.generate');
      if (result.data && result.data.goods_promotion_url_generate_response) {
        ret.list = result.data.goods_promotion_url_generate_response.goods_promotion_url_list;
      }

      return ret;
    }
    // 生成商城频道推广链接
    async genCMSPromotionUrl(params) {
      const ret = {};
      params.generate_short_url = true;
      params.we_app_web_view_short_url = true;
      params.we_app_web_view_url = false;
      const result = await this.sendRequest(params, 'pdd.ddk.cms.prom.url.generate');
      if (result.data && result.data.cms_promotion_url_generate_response) {
        ret.list = result.data.cms_promotion_url_generate_response.url_list;
      }

      return ret;
    }
    // 生成红包推广链接
    async genRPPromotionUrl(params) {
      const ret = {};
      params.generate_short_url = true;
      params.we_app_web_view_short_url = true;
      params.generate_weapp_webview = false;
      const result = await this.sendRequest(params, 'pdd.ddk.rp.prom.url.generate');
      if (result.data && result.data.rp_promotion_url_generate_response) {
        ret.list = result.data.rp_promotion_url_generate_response.url_list;
      }

      return ret;
    }
    // 生成主题推广链接
    async genThemePromotionUrl(params) {
      const ret = {};
      params.generate_short_url = true;
      params.we_app_web_view_short_url = true;
      const result = await this.sendRequest(params, 'pdd.ddk.theme.prom.url.generate');
      if (result.data && result.data.theme_promotion_url_generate_response) {
        ret.list = result.data.theme_promotion_url_generate_response.url_list;
      }

      return ret;
    }
    // 生成资源推广链接
    async genOddsPromotionUrl(params) {
      const ret = {};
      const result = await this.sendRequest(params, 'pdd.ddk.resource.url.gen');
      if (result.data && result.data.resource_url_response) {
        ret.list = [result.data.resource_url_response.single_url_list];
      }

      return ret;
    }
    // 生成大转盘推广链接
    async genBigWheelPromotionUrl(params) {
      const ctx = this.ctx;
      const ret = {};
      let cookie = await this.app.redis.get('db0').get(Constant.key.PDD_WHEEL_COOKIE);
      if (!cookie) {
        const cookieInfo = await this.app.mysql.select('config_read_data', {
          columns: ['cookie'],
          where: {
            type: 6,
            status: 1
          }
        });
        cookie = cookieInfo[0].cookie;
        this.app.redis.get('db0').set(Constant.key.PDD_WHEEL_COOKIE, cookie);
      }

      const result = await ctx.curl('https://jinbao.pinduoduo.com/network/api/lottery/url', {
        method: 'POST',
        headers: {
          Host: 'jinbao.pinduoduo.com',
          Accept: 'application/json, text/plain, */*',
          Origin: 'https://jinbao.pinduoduo.com',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Mobile Safari/537.36',
          'Content-Type': 'application/json;charset=UTF-8',
          Referer: 'https://jinbao.pinduoduo.com/promotion/mall-promotion',
          'Accept-Encoding': 'gzip, deflate, br',
          'Accept-Language': 'zh-CN,zh;q=0.9',
          Cookie: cookie
        },
        contentType: 'json',
        data: params,
        dataType: 'json'
      });

      if (result.data && result.data.result && result.data.result.urlList) {
        ret.list = result.data.result.urlList;
      }

      return ret;
    }
    // 获取推广主题列表
    async themeList(params) {
      const ret = {};
      const result = await this.sendRequest(params, 'pdd.ddk.theme.list.get');
      if (result.data && result.data.theme_list_get_response) {
        ret.list = result.data.theme_list_get_response.theme_list;
        ret.totalCount = result.data.theme_list_get_response.total;
      }

      return ret;
    }
    // 获取推广主题商品详情
    async themeGoodsList(params) {
      const ret = {};
      const result = await this.sendRequest(params, 'pdd.ddk.theme.goods.search');
      if (result.data && result.data.theme_list_get_response) {
        ret.list = result.data.theme_list_get_response.goods_list;
        ret.totalCount = result.data.theme_list_get_response.total;
      }

      return ret;
    }

    async sendRequest(params, type) {
      const ctx = this.ctx;
      params.client_id = client_id;
      params.timestamp = parseInt(new Date().getTime() / 1000);
      params.type = type;
      params.data_type = 'JSON';
      const keys = Object.keys(params).sort();
      let signKey = secret;
      for (const i in keys) {
        const key = keys[i];
        signKey += key + params[key];
      }

      signKey += secret;
      const hash = crypto.createHash('md5');
      hash.update(signKey);
      const sign = hash.digest('hex').toUpperCase();
      params.sign = sign;
      console.log('pdd req params ', params);
      const result = await ctx.curl('https://gw-api.pinduoduo.com/api/router', {
        method: 'POST',
        contentType: 'json',
        data: params,
        dataType: 'json'
      });

      return result;
    }

    // async updateSku() {
    //   const ctx = this.ctx;
    //   let cur_page = 1;
    //   const total = 100;
    //   const page_size = 100;
    //   do {
    //     const result = await this.goodsList({ page: cur_page, page_size, sort_type: 6, opt_id: 14, with_coupon: true });
    //     if (result.totalCount && result.list) {
    //       const list = result.list;
    //       await this.saveSkuList(list);
    //       ++cur_page;
    //     } else {
    //       break;
    //     }
    //   } while (cur_page < total);
    // }

    async orderData(params) {
      const condition = parseQueryCondition(params);
      const sql = `SELECT group_name, SUM(pdd_order_count) AS pdd_order_count, SUM(tb_order_count) AS tb_order_count, SUM(pdd_commission_sum) AS pdd_commission_sum, SUM(pdd_order_amount_sum) AS pdd_order_amount_sum, SUM(tb_commission_sum) AS tb_commission_sum, SUM(tb_order_amount_sum) AS tb_order_amount_sum
            FROM (SELECT c.pid, e.group_name, Count(c.pid) AS pdd_order_count, 0 AS tb_order_count, SUM(a.promotion_amount) AS pdd_commission_sum, SUM(a.order_amount) AS pdd_order_amount_sum, 0 AS tb_commission_sum, 0 AS tb_order_amount_sum
              FROM order_guide_pdd a, tb_pid c, robot_group_info e, robot_group_pid f
              WHERE a.order_status != -1
                AND a.order_status != 4
                AND a.pid = c.pid
                ${condition.where} 
                AND c.id = f.pid_id
                AND f.group_id = e.id
                AND e.enable = 1
              GROUP BY c.pid
              UNION
              SELECT c.pid, e.group_name, 0 AS pdd_order_count, Count(c.pid) AS tb_order_count, 0 AS pdd_commission_sum, 0 AS pdd_order_amount_sum, SUM(a.pub_share_pre_fee) AS tb_commission_sum, SUM(a.alipay_total_price) AS tb_order_amount_sum
                FROM order_guide_tb a, tb_pid c, robot_group_info e, robot_group_pid f
                WHERE a.tk_status != 13
                  AND a.pid = c.pid 
                  ${condition.where} 
                  AND c.id = f.pid_id
                  AND f.group_id = e.id
                  AND e.enable = 1
                GROUP BY c.pid) tmp 
            GROUP BY group_name 
          ${condition.limit}`;
      // const sql = `SELECT c.pid, e.remark AS group_name, Count(c.pid) AS order_count, SUM(a.promotion_amount) AS commission, SUM(a.order_amount) AS order_amount_sum
      //   FROM order_guide_pdd a, tb_pid c, robot_group_pid d, robot_group_info e, tb_pid f
      //   WHERE a.order_status != -1
      //     AND a.order_status != 4
      //     AND a.pid = c.pid
      //     ${condition.where}
      //     AND c.id = d.pid_id
      //     AND d.group_id = e.id
      //     AND e.
      //     AND f.community_code = e.community_code
      //   GROUP BY c.pid
      //   ${condition.limit}`;
      const cntSql = `SELECT COUNT(1) 
        FROM (SELECT c.pid, e.group_name, Count(c.pid) AS pdd_order_count, 0 AS tb_order_count, SUM(a.promotion_amount) AS pdd_commission_sum, SUM(a.order_amount) AS pdd_order_amount_sum, 0 AS tb_commission_sum, 0 AS tb_order_amount_sum
        FROM order_guide_pdd a, tb_pid c, robot_group_info e, robot_group_pid f
        WHERE a.order_status != -1
          AND a.order_status != 4
          AND a.pid = c.pid 
          ${condition.where} 
          AND c.id = f.pid_id
          AND f.group_id = e.id
          AND e.enable = 1
        GROUP BY c.pid
        UNION
        SELECT c.pid, e.group_name, 0 AS pdd_order_count, Count(c.pid) AS tb_order_count, 0 AS pdd_commission_sum, 0 AS pdd_order_amount_sum, SUM(a.pub_share_pre_fee) AS tb_commission_sum, SUM(a.alipay_total_price) AS tb_order_amount_sum
          FROM order_guide_tb a, tb_pid c, robot_group_info e, robot_group_pid f
          WHERE a.tk_status != 13
            AND a.pid = c.pid 
            ${condition.where} 
            AND c.id = f.pid_id
            AND f.group_id = e.id
            AND e.enable = 1
          GROUP BY c.pid) tmp 
      GROUP BY group_name`;

      let list = await this.app.mysql.query(sql);
      list = list ? list : [];
      const totalCountArr = await this.app.mysql.query(cntSql);
      const totalCount = totalCountArr && totalCountArr[0] ? Object.values(totalCountArr[0])[0] : 0;
      return { list, totalCount };

      function parseQueryCondition(params) {
        const page = params.page != null ? params.page : 1;
        const page_size = params.page_size != null ? params.page_size : 10;
        const limit = 'LIMIT ' + (page - 1) * page_size + ',' + page_size;
        let where = '';
        if (params.start_time && params.end_time) {
          where += 'AND a.order_create_time >= ' + params.start_time + ' AND a.order_create_time <= ' + params.end_time;
        }
        return { where, limit };
      }
    }

    // async orderStatusData(params) {
    //   const condition = parseQueryCondition(params);
    //   const sql = 'SELECT c.pid, e.remark AS group_name, a.order_status, Count(c.pid) AS order_count, SUM(a.promotion_amount) AS commission FROM order_guide_pdd a, user_pid b, tb_pid c, user_group_robot d, user_material_robot e WHERE a.user_id = b.user_id AND b.pid_id = c.id AND c.`type` = 5 AND b.user_id = d.user_id AND d.robot_id = e.id ' +
    //     condition.where + 'GROUP BY c.pid, a.order_status;';
    //   const list = await this.app.mysql.query(sql);
    //   return { list };

    //   function parseQueryCondition(params) {
    //     const queryConditions = [];
    //     let where = '';
    //     if (params.pids && params.pids.length > 0) {
    //       const pids = params.pids.map(item => {
    //         return '"' + item + '"';
    //       });
    //       queryConditions.push('c.pid IN (' + pids.join(',') + ') ');
    //     }

    //     for (const i in queryConditions) {
    //       const condition = queryConditions[i];
    //       where += 'AND ' + condition;
    //     }

    //     return { where };
    //   }
    // }

    async summaryData(params) {
      const condition = parseQueryCondition(params);
      const sql = `SELECT FROM_UNIXTIME(a.order_create_time, "%Y-%m-%d") AS order_date, a.order_status, COUNT(1) AS order_count, SUM(a.order_amount) AS order_amount_sum 
        FROM order_guide_pdd a 
        ${condition.where} 
        GROUP BY order_date, a.order_status ORDER BY order_date`;
      console.log(sql);
      const list = await this.app.mysql.query(sql);
      return { list };

      function parseQueryCondition(params) {
        let where = '';
        if (params.start_time && params.end_time) {
          where += 'WHERE a.order_create_time >= ' + params.start_time + ' AND a.order_create_time <= ' + params.end_time;
        }

        return { where };
      }
    }

    async groupInfo(params) {
      const condition = parseQueryCondition(params);
      const sql = 'SELECT d.name, f.pid, c.pid_name AS remark, a.group_name, a.group_member_count, a.category FROM robot_group_info a, robot_group_pid b, tb_pid c, user d, user_pid e, tb_pid f WHERE a.id = b.group_id AND a.community_code_id = c.id AND c.type = 10 AND b.pid_id = f.id AND f.type = 5 AND f.status = 1 AND f.id = e.pid_id AND e.user_id = d.id ' + condition.order + ' ' + condition.limit;
      const cntSql = 'SELECT COUNT(1) FROM robot_group_info a, robot_group_pid b, tb_pid c, user d, user_pid e, tb_pid f WHERE a.id = b.group_id AND a.community_code_id = c.id AND c.type = 10 AND b.pid_id = f.id AND f.type = 5 AND f.status = 1 AND f.id = e.pid_id AND e.user_id = d.id';
      const list = await this.app.mysql.query(sql);
      const totalCountArr = await this.app.mysql.query(cntSql);
      return { list, totalCount: Object.values(totalCountArr[0])[0] };

      function parseQueryCondition(params) {
        const page = params.page != null ? params.page : 1;
        const page_size = params.page_size != null ? params.page_size : 10;
        const limit = 'LIMIT ' + (page - 1) * page_size + ',' + page_size;
        let order = '';
        if (params.order && params.order.key) {
          order += 'ORDER BY ' + params.order.key;
          if (params.order.desc) {
            order += ' DESC';
          }
        }

        return { limit, order };
      }
    }
  };
};