'use strict';

const Service = require('egg').Service;

class ExhistoryService extends Service {
  async historyList(params) {
    const pageSize = params.pageSize < 1 || params.pageSize > 20 ? 20 : params.pageSize;
    const page = (params.page - 1) * pageSize;
    const limit = `limit ${page}, ${pageSize}`;
    const sql = ` SELECT *FROM approval_record WHERE 1=1 ORDER BY  time_stamp DESC ` + limit;
    const sqltotal = `SELECT COUNT(*) as total FROM approval_record `;
    const results = await this.app.mysql.query(sql);
    const total = await this.app.mysql.query(sqltotal);
    return { code: 10000, msg: '成功', data: results, total };
  }

  async selectAppiont(params) {
    if (typeof params.page !== 'undefined' && typeof params.pageSize !== 'undefined') {
      let page = params.page < 1 ? 1 : params.page;
      const pageSize = params.pageSize < 1 || params.pageSize > 30 ? 30 : params.pageSize;
      page = (page - 1) * pageSize;
      const roomnumber = params.snumber;
      const roomname = params.sroomname;
      const type = params.stype;
      const username = params.susername;
      const truename = params.struename;
      const time = params.sdateTime;
      const time_number = params.timesolt;
      const number = params.number;
      let conditions = '';
      if (typeof time_number !== 0 && time_number !== undefined && number !== '') {
        conditions = conditions + ` AND number = ${number} `;
      }
      if (typeof roomnumber !== 'undefined' && roomnumber !== '') {
        conditions = conditions + ` AND roomnumber = ${roomnumber} `;
      }
      if (typeof roomname !== 'undefined' && roomname !== '') {
        conditions = conditions + ` AND roomname LIKE "%${roomname}%" `;
      }
      if (typeof username !== 'undefined' && username !== '') {
        conditions = conditions + ` AND username LIKE "${username}" `;
      }
      if (typeof truenmame !== 'undefined' && truenmame !== '') {
        conditions = conditions + ` AND truename LIKE "%${truename}%" `;
      }
      if (typeof type !== 'undefined' && type !== 0) {
        conditions = conditions + ` AND type = ${type} `;
      }
      if (typeof time !== '' && time !== 0 && time !== undefined) {
        conditions = conditions + ` AND roomtime = ${time} `;
      }
      if (typeof time_number !== '' && time_number !== 0 && time_number !== undefined) {
        conditions = conditions + ` AND time_number = ${time_number} `;
      }
      const limit = `limit ${page}, ${pageSize}`;
      const sql = `SELECT * FROM approval_record WHERE 1=1 ` + conditions + limit;
      const searchTotal = `SELECT COUNT(*) as sum FROM approval_record WHERE 1=1 ` + conditions;
      const results = await this.app.mysql.query(sql);
      const stotal = await this.app.mysql.query(searchTotal);
      return { code: 10000, msg: '成功', data: results, stotal };

    }
  }
}


module.exports = ExhistoryService;
