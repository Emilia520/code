/**
 * 自营活动service层接口
 */

const Service = require('egg').Service;
const ErrorCode = require('../utils/errorCode');

module.exports = () => {
  return class ProprietaryActivity extends Service {
    /**
     * 查出数据库中所有的自行活动
     */
    async getActivityList(params) {
      let list = [];
      let totalCount = 0;
      const pageNum = params.page || 1;
      const pageSize = params.pageSize || 20;
      const limit = `LIMIT ${(pageNum - 1) * pageSize}, ${pageSize}`;
      const sql = `select * from proprietary_activities ${limit}`;
      const cntSql = `select count(1) from proprietary_activities`;
      const totalCountArr = await this.app.mysql.query(cntSql);
      totalCount = totalCountArr && totalCountArr[0] ? Object.values(totalCountArr[0])[0] : 0;
      // 如果数量为0就不需要再查具体数据了
      if (totalCount > 0) {
        list = await this.app.mysql.query(sql);
      }
      return { list, totalCount };
    }

    /**
     * 查出数据库中所有的自行活动
     */
    async getActivityListById(params) {
      const id = params.id;
      let list = [];
      const sql = `select * from proprietary_activities where id  = ${id}`;
      list = await this.app.mysql.query(sql);
      return { list };
    }

    /**
     * 创建新的活动
     */
    async createActivity(params) {
      const name = '';
      const title = params.title;
      const rule_content = params.rule_content;
      const free_sheet_rule_content = params.free_sheet_rule_content;
      const start_time = params.start_time;
      const end_time = params.end_time;
      const status = params.status;
      const join_condition = params.join_condition;
      const help_condition = params.help_condition;
      const sql = `insert into proprietary_activities (name,title,rule_content,free_sheet_rule_content,start_time,end_time,status,join_condition,help_condition) 
                    value ('${name}','${title}','${rule_content}','${free_sheet_rule_content}',${start_time},${end_time},${status},${join_condition},${help_condition}) `;
      await this.app.mysql.query(sql);
    }

    /**
     * 更新活动文案
     */
    async updateActivityListById(params) {
      const id = params.id;
      let activityContent = '';
      let floatingWindow = '';
      let addForm = '';
      if (params.activityContent) {
        activityContent = `activity_content = '${params.activityContent}'`;
      }
      if (params.floatingWindow) {
        floatingWindow = `floating_window = '${params.floatingWindow}'`;
      }
      if (params.addForm && params.addForm.title) {
        addForm = `name = '${params.addForm.name}',rule_content = '${params.addForm.rule_content}',title = '${params.addForm.title}',
        free_sheet_rule_content = '${params.addForm.free_sheet_rule_content}',
        start_time = ${params.addForm.start_time},end_time = ${params.addForm.end_time},status = '${params.addForm.status}',
        join_condition = '${params.addForm.join_condition}',help_condition = '${params.addForm.help_condition}'`;
      }
      console.log(addForm);
      const sql = `update proprietary_activities set ${activityContent} ${floatingWindow} ${addForm} where id  = ${id}`;
      await this.app.mysql.query(sql);
    }


    /**
     * 更新活动规则
     */
    async updateActivityListRoleById(params) {
      const id = params.id;
      const ruleContent = params.rule_content;
      const sql = `update proprietary_activities set rule_content = '${ruleContent}' where id  = ${id}`;
      await this.app.mysql.query(sql);
    }


    /**
     * 查出活动商品列表
     */
    async getGoodsList(params) {
      const id = params.id;
      let list = [];
      const sql = `select * from proprietary_goods where proprietary_activities_id  = ${id} order by sort desc`;
      list = await this.app.mysql.query(sql);
      return { list };
    }

    /**
     * 根据商品id查商品详情
     */
    async getGoodsById(params) {
      const id = params.id;
      let list = {};
      const sql = `select a.* from group_buy_goods a ,product_overall b  where a.id = b.product_id and b.id = ${id}`;
      list = await this.app.mysql.query(sql);
      return { list };
    }

    /**
     * 检查商品
     */
    async checkGoods(params) {
      const id = params.goodsId;
      let list = {};
      const sql = `select a.* from group_buy_goods a ,product_overall b,proprietary_goods c  where a.id = b.product_id and a.id = ${id} and c.product_over_id = b.id`;
      list = await this.app.mysql.query(sql);
      return { list };
    }

    /**
     * 根据商品id删除
     */
    async deleteGoods(params) {
      const id = params.goodsId;
      const sql = `delete from proprietary_goods where id = ${id}`;
      await this.app.mysql.query(sql);
    }

    /**
     * 更新商品信息
     */
    async updateGoods(params) {
      const id = params.id;
      const name = params.name;
      const picture = params.picture;
      const help_rule = params.help_rule;
      const min_purchasable_price = params.min_purchasable_price;
      const original_price = params.original_price;
      const postage = params.postage;
      const status = params.status;
      const inventory = params.inventory;
      const sql = `update proprietary_goods set name = '${name}',picture = '${picture}',help_rule = '${help_rule}',
      min_purchasable_price = ${min_purchasable_price},original_price = ${original_price},postage = ${postage}
      ,update_time = UNIX_TIMESTAMP(),status = ${status},inventory = ${inventory} where id = ${id}`;
      await this.app.mysql.query(sql);
    }

    /**
     * 创建一个新的商品信息
     */
    async createGoods(params) {
      if (typeof params.addForm.inventory !== 'null' && !isNaN(params.addForm.inventory) && params.addForm.inventory > 0) {
        const goodsId = params.addForm.goodsId;
        // 正常活动下架该商品
        const updateSql = `update group_buy_goods set qxb_status = 0 , status = 0 where id = ${goodsId}`;
        await this.app.mysql.query(updateSql);
        // 通过商品id查出overAllid
        const getGoodsSql = `select b.id,a.akc_tag_price from group_buy_goods a,product_overall b where a.id = b.product_id and a.id = ${goodsId}`;
        const product_over_id = await this.app.mysql.query(getGoodsSql);
        const productId = product_over_id[0].id;
        const productIdList = [];
        productIdList.push(productId);
        // solr 删除
        const result = this.ctx.curl(`${this.config.api.java_host}/groupBuy/productSolrDel`, {
          method: 'POST',
          contentType: 'json',
          data: {
            clientId: 'qxb_admin',
            productIds: productIdList,
            version: '1.0'
          },
          dataType: 'json'
        });
        const original_price = product_over_id[0].akc_tag_price;
        const activityId = params.activityId;
        const sort = params.addForm.sort;
        const help_rule = params.addForm.help_rule;
        const min_purchasable_price = params.addForm.min_purchasable_price;
        const postage = params.addForm.postage;
        const status = params.addForm.status;
        const inventory = params.addForm.inventory;
        const sql = `insert into proprietary_goods (product_over_id,proprietary_activities_id,
        help_rule,min_purchasable_price,postage,create_time,update_time,status,original_price,sort, inventory) 
        value (${productId},${activityId},'${help_rule}',${min_purchasable_price},
        ${postage},UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),${status},${original_price},${sort}, ${inventory})`;
        await this.app.mysql.query(sql);
    
        // 好衣库新的商品没有skuID，所以必须调用一次商品详情才可以
        await this.ctx.curl(`${this.config.api.java_host}/groupBuy/getGoodsDetail`, {
          method: 'POST',
          contentType: 'json',
          data: {
            goodsId: productId,
            clientId: 'qxb_admin',
            version: '1.0'
          },
          dataType: 'json'
        });
      }
    }
  };
};
