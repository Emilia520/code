const Service = require('egg').Service;
const Constant = require('../utils/constant');
const crypto = require('crypto');

module.exports = () => {
  return class Aikucun extends Service {
    // 活动活动信息
    async activityList(params) {
      const result = await this.sendRequest(params, '/activity/query');
      return result;
    }

    // 活动商品列表信息
    async productList(params) {
      const result = await this.sendRequest(params, '/product/list');
      return result;
    }

    // 创建售后单
    async createAfterSaleBill(params) {
      const result = await this.sendRequest(params, '/after-sale/new/create');
      return result;
    }

    // 修改售后单
    async updateAfterSaleBill(params) {
      const result = await this.sendRequest(params, '/after-sale/new/update');
      return result;
    }

    // 查询售后单
    async queryAfterSaleBill(params) {
      const result = await this.sendRequest(params, '/after-sale/new/query');
      return result;
    }

    // 上传快递单
    async uploadlogistics(params) {
      const result = await this.sendRequest(params, '/after-sale/new/uploadlogistics');
      return result;
    }

    // 取消售后单
    async cancelAfterSaleBill(params) {
      const result = await this.sendRequest(params, '/after-sale/new/cancel');
      return result;
    }

    // 查询订单物流消息
    async queryOrderLogisticsStatus(params) {
      const result = await this.sendRequest(params, '/order/queryLogistics');
      return result;
    }

    // 查询订单消息
    async queryOrder(params) {
      const result = await this.sendRequest(params, '/order/queryByOrderId');
      return result;
    }

    // 通过外部订单号查询订单详情
    async queryOrderByExternalOrderID(params) {
      const result = await this.sendRequest(params, '/order/queryByExternalOrderNo');
      return result;
    }

    // 查询商品库存
    async queryStock(params) {
      const result = await this.sendRequest(params, '/inventory/query');
      return result;
    }

    // 爱库存通用发送接口
    async sendRequest(params, urlAddition) {
      const ctx = this.ctx;
      // 第一步：补全基础参数
      params.appKey = this.config.akc.app_key;
      params.timestamp = parseInt(new Date().getTime() / 1000);
      params.version = '1.0';
      // 第二步：参数排序
      const reqObj = {};
      const keys = Object.keys(params).sort();
      for (const i in keys) {
        const key = keys[i];
        reqObj[key] = params[key];
      }
      // 第三步：整体转json
      const paramStr = JSON.stringify(reqObj);
      // 第四步：使用MD5/Base64加密串
      const secretStr = paramStr + this.config.akc.secret;
      const buffer = new Buffer(secretStr, 'utf-8');
      const base64Str = buffer.toString('base64');
      const hash = crypto.createHash('md5');
      hash.update(base64Str);
      const sign = hash.digest('hex').toUpperCase();
      // 第五步：sign填入请求体
      params.sign = sign;

      const result = await ctx.curl(`${this.config.akc.base_url}${urlAddition}`, {
        method: 'POST',
        contentType: 'json',
        data: params,
        dataType: 'json'
      });

      return result;
    }
  };
};