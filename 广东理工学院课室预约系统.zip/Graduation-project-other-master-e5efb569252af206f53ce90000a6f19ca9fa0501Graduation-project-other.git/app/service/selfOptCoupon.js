const Service = require('egg').Service;
const ErrorCode = require('../utils/errorCode');

const CouponTypes = {
  general: 0, // 全场通用
  product: 1, // 指定商品
  activity: 2, // 指定活动
  category: 3, // 指定品类
};

module.exports = () => {
  return class SelfOptCoupon extends Service {
    /**
     * 按条件获取优惠券列表
     * @param params
     * @returns {Promise<{msg: string, code: number}>}
     */
    async couponList(params) {
      let condition;
      const options = [];

      if (params.id === 0 || (params.id && !isNaN(params.id))) {
        options.push(params.id);
        condition = condition ? `${condition} AND coupon.id = ?` : ' WHERE coupon.id = ?';
      }

      if (params.type === 0 || params.type) {
        options.push(params.type);
        condition = condition ? `${condition} AND coupon.type = ?` : ' WHERE coupon.type = ?';
      }

      if (params.status === 0 || params.status) {
        options.push(params.status);
        condition = condition ? `${condition} AND coupon.status = ?` : ' WHERE coupon.status = ?';
      }

      if (params.start_time) {
        options.push(params.start_time);
        condition = condition ? `${condition} AND coupon.start_time >= ?` : ' WHERE coupon.start_time >= ?';
      }

      if (params.end_time) {
        options.push(params.end_time);
        condition = condition ? `${condition} AND coupon.end_time <= ?` : ' WHERE coupon.end_time <= ?';
      }

      const countSql = `SELECT COUNT(*) FROM coupon_shopping coupon ${condition || ''}`;
      const querySql = `SELECT
      coupon.*,
      e.coupon_use_num
      FROM
      coupon_shopping coupon
      LEFT JOIN (
        SELECT
          b.id,
          sum( c.use_num ) AS coupon_use_num
      FROM
          user_coupon c
      JOIN coupon_shopping b ON b.id = c.coupon_id
      GROUP BY
          c.coupon_id
    ) AS e ON coupon.id = e.id
    ${condition || ''}
    ORDER BY coupon.id DESC`;

      console.log(querySql);

      const response = { code: 10000, msg: '成功' };
      await this.app.mysql.beginTransactionScope(async conn => {
        const countResult = await conn.query(countSql, options);
        response.totalCount = countResult && countResult[0] ? Object.values(countResult[0])[0] : 0;

        if (response.totalCount === 0) {
          return { success: true };
        }

        response.data = await conn.query(querySql, options);
        response.data.forEach(item => {
          item.rule = JSON.parse(item.rule);
        });

        return { success: true };
      }, this.ctx);

      return response;
    }

    /**
     * 添加一张优惠券
     * @param params
     * @returns {Promise<{msg: string, code: number}>}
     */
    async addCoupon(params) {
      console.log(params);
      const attachIDs = params.attach_ids;
      const type = params.type;

      if (type !== CouponTypes.general && attachIDs.length === 0) {
        return { code: ErrorCode.ERROR_CODE_PARAM, msg: '未选择对应的活动或商品ID' };
      }

      const options = {};
      Object.assign(options, params);
      delete options.attach_ids;

      // 返回结果
      const response = { code: 10000, msg: '成功' };
      await this.app.mysql.beginTransactionScope(async conn => {
        // 优惠券表中新增一条记录
        const insertResult = await conn.insert('coupon_shopping', options);
        if (insertResult.affectedRows !== 1) {
          response.code = ErrorCode.ERROR_CODE_DB_INSERT;
          response.msg = '数据库新增优惠券信息失败';
          return { success: false };
        }

        // 全场通过无需填写关联表
        if (type === CouponTypes.general) {
          return { success: true };
        }

        // 在优惠券关联表插入数据
        const coupon_id = insertResult.insertId;

        for (const index in attachIDs) {
          const assign_id = attachIDs[index];
          const result = await conn.insert('coupon_range', {
            coupon_id,
            type,
            assign_id
          });

          if (result.affectedRows !== 1) {
            response.code = ErrorCode.ERROR_CODE_DB_INSERT;
            response.msg = '数据库新增优惠券绑定信息失败';
            return { success: false };
          }
        }

        return { success: true };
      }, this.ctx);

      return response;
    }

    /**
     * 更新一个优惠券
     * @param params
     * @returns {Promise<{msg: string, code: number}>}
     */
    async updateCoupon(params) {
      if (typeof params.id !== 'number') {
        return { code: ErrorCode.ERROR_CODE_PARAM, msg: '缺少优惠券ID' };
      }

      if (params.status === 1) {
        params.up_time = Date.now() / 1000;
      }

      const result = await this.app.mysql.update('coupon_shopping', params);

      if (result.affectedRows !== 1) {
        return { code: ErrorCode.ERROR_CODE_DB_UPDATE_FAILED, msg: '更新数据库失败' };
      }

      return { code: 10000, msg: '成功' };
    }

    /**
     * 根据商品ID队列，查找对应的product_overall表的ID队列
     * @param params
     * @returns {Promise<{msg: string, code: number}|{msg: string, code: number, data: *}>}
     */
    async productsOverallIDs(params) {
      const productIDs = params.product_ids;
      if (!Array.isArray(productIDs)) {
        return { code: ErrorCode.ERROR_CODE_PARAM, msg: '缺少商品ID队列' };
      }

      const overallIDs = await this.app.mysql.select('product_overall', {
        columns: ['id'],
        where: { product_id: productIDs }
      });

      const data = overallIDs.map(item => item.id);
      return { code: 10000, msg: '成功', data };
    }

    /**
     * 根据类型获取优惠券关联的商品或活动、分类
     * @param coupon
     * @returns {Promise<{msg: string, code: number}>}
     */
    async couponAttachments(coupon) {
      console.log(coupon);
      const coupon_id = coupon.id;
      const response = { code: 10000, msg: '成功' };

      if (coupon.type === CouponTypes.general) {
        return response;
      }

      await this.app.mysql.beginTransactionScope(async conn => {
        let assignIDs = await conn.select('coupon_range', {
          where: { coupon_id },
          columns: ['assign_id'],
        });

        response.totalCount = assignIDs.length;

        if (assignIDs.length === 0) {
          response.data = [];
          return { success: true };
        }

        assignIDs = assignIDs.map(item => item.assign_id);

        if (coupon.type === CouponTypes.product) {
          // 商品ID先查询product_overall然后查group_buy_goods
          const productIDs = await conn.select('product_overall', {
            columns: ['product_id'],
            where: { id: assignIDs },
          });

          if (productIDs.length === 0) {
            response.code = ErrorCode.ERROR_CODE_DB_UNEXPECTED_RESULT_COUNT;
            response.msg = '查询优惠券关联商品ID失败';
            return { success: false };
          }

          assignIDs = productIDs.map(item => item.product_id);
        }

        const tableName = coupon.type === CouponTypes.product ? 'group_buy_goods' : (coupon.type === CouponTypes.activity ? 'group_buy_goods_activity' : 'group_buy_tag');
        const attachName = coupon.type === CouponTypes.product ? '商品' : (coupon.type === CouponTypes.activity ? '活动' : '分类');
        const attachments = await conn.select(tableName, {
          where: { id: assignIDs }
        });

        if (attachments.length === 0) {
          response.code = ErrorCode.ERROR_CODE_DB_UNEXPECTED_RESULT_COUNT;
          response.msg = `查询优惠券关联${attachName}失败`;
          return { success: false };
        }

        response.data = attachments;
        return { success: true };
      }, this.ctx);

      return response;
    }

    /**
     * 查询优惠券的搜索关键字列表
     * @returns {Promise<{msg: string, code: number, data: *}>}
     */
    async couponSearchKeywords() {
      const responses = await this.app.mysql.select('config', { where: { key: 'couponKeyword' } });
      if (!Array.isArray(responses) || responses.length !== 1) {
        return { code: ErrorCode.ERROR_CODE_DB_UNEXPECTED_RESULT_COUNT, msg: '数据库字段格式有误' };
      }

      const response = responses[0];
      if (typeof response.value !== 'string') {
        return { code: ErrorCode.ERROR_CODE_DB_UNEXPECTED_RESULT_COUNT, msg: '数据库字段格式有误' };
      }

      const keywords = JSON.parse(response.value);
      return { code: 10000, msg: '成功', data: keywords };
    }
  };
};