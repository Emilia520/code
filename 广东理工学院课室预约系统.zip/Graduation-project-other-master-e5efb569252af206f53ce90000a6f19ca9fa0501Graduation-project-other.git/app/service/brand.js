const Service = require('egg').Service;
// const Constant = require('../utils/constant');
const ErrCode = require('../utils/errorCode');
const crypto = require('crypto');
const urlencode = require('urlencode');
module.exports = () => {
  return class Brand extends Service {
    // 品牌类型列表
    async brandTypes() {
      const results = await this.app.mysql.select('brand_type', {
        columns: ['id', 'type_name', 'type_code'],
      });

      return { code: 10000, msg: '成功', data: results };
    }

    // 品牌标签列表
    async brandLebals(params) {
      const results = await this.app.mysql.select('label', {
        columns: ['id', 'label_name'],
        where: { type: 2 }, // WHERE 条件
        orders: [['priority', 'desc']], // 排序
      });
      return { code: 10000, msg: '成功', data: results };
    }

    // 待入库的商品列表 分页
    async noAddBrandDBList(params) {
      const limitTime = 1569686400;
      const pageSize = params.pageSize < 1 || params.pageSize > 30 ? 30 : params.pageSize;
      const page = (params.page - 1) * pageSize;

      const fieldBrand = ' t11.id,t11.brand_name';
      const sqlBrand = `SELECT ${fieldBrand} FROM group_buy_aikucun_brand t11 WHERE 
                    EXISTS ( SELECT 1 FROM group_buy_goods_activity t0
                            INNER JOIN group_buy_tag t1 ON t0.cat_id = t1.id
                            WHERE t0.brand_id = t11.id AND t0.end_time > ${limitTime}
                    )  AND t11.brand_id is NULL
                   ORDER BY t11.id desc LIMIT ${page}, ${pageSize}`;
      const brandInfo = await this.app.mysql.query(sqlBrand);
      const tct = `SELECT COUNT(*) as num FROM group_buy_aikucun_brand t11 WHERE 
      EXISTS ( SELECT 1 FROM group_buy_goods_activity t0
              INNER JOIN group_buy_tag t1 ON t0.cat_id = t1.id
              WHERE t0.brand_id = t11.id AND t0.end_time > ${limitTime}
      )  AND t11.brand_id is NULL
     ORDER BY t11.id desc`;
      const totalCount = await this.app.mysql.query(tct);


      // 搜索品牌相关的活动信息
      const field = ' t0.id as activityId, t0.name, t1.id as tagId, t1.tag_name ';
      for (const iterator of brandInfo) {
        const actSQL = `SELECT ${field} FROM group_buy_goods_activity t0 INNER JOIN group_buy_tag t1 ON t0.cat_id = t1.id WHERE t0.brand_id = ${iterator.id} AND (t0.end_time > UNIX_TIMESTAMP() or t0.start_time = t0.end_time)`;
        const actInfo = await this.app.mysql.query(actSQL);

        iterator.actInfo = actInfo;
      }

      return { msg: '成功', code: 10000, data: brandInfo, totalCount };
    }

    // 品牌绑定
    async brandBind(params) {
      const brandId = params.brandId;
      const supplierBrandId = params.supplierBrandId;
      if (typeof brandId !== 'undefined' && typeof supplierBrandId !== 'undefined') {
        const supplierBrand = await this.app.mysql.get('group_buy_aikucun_brand', { id: supplierBrandId });
        if (typeof supplierBrand !== 'undefined') {
          const brand = await this.app.mysql.get('brand', { id: brandId });
          if (typeof brand !== 'undefined') {
            await this.app.mysql.update('group_buy_aikucun_brand', { id: supplierBrandId, brand_id: brandId });
          } else {
            return { msg: '品牌库中不存在该品牌', code: ErrCode.ERROR_CODE_PARAM };
          }
        } else {
          return { msg: '供应商品牌不存在', code: ErrCode.ERROR_CODE_PARAM };
        }
      } else {
        return { msg: '品牌参数缺失', code: ErrCode.ERROR_CODE_PARAM };
      }
      return { msg: '成功', code: 10000 };
    }
    // 待入库根据ID查询渠道品牌信息
    async noAddGetInformtion(params) {
      const results = await this.app.mysql.select('group_buy_aikucun_brand', {
        where: { id: params.id },
        columns: ['brand_name', 'brand_logo_url', 'description']
      });
      return { msg: '成功', code: 10000, data: results };
    }

    // 批量修改运营标签
    async brandListAddTag(params) {
      const brandIds = params._brandIds;
      const lebals = params.labelIds;
      if (typeof brandIds !== 'undefined'
        && typeof lebals !== 'undefined'
        && brandIds.length > 0 && lebals.length > 0) {
        // 开启事务
        const result = await this.app.mysql.beginTransactionScope(async conn => {
          const insertData = [];
          for (const iterator of brandIds) {
            // 将该品牌所有标签下架掉
            await conn.update('group_buy_label', { status: 1 }, { where: { target_id: iterator } });
            for (const iterator2 of lebals) {
              const label = [
                2, iterator, iterator2, 0
              ];
              insertData.push(label);
            }
          }
          // 插入数据库，存在就更新，不存在就插入
          const field = 'label_type, target_id, label, status';
          const insertSQL = `INSERT INTO group_buy_label (${field}) VALUES ? ON DUPLICATE KEY UPDATE status = 0`;
          conn.query(insertSQL, [insertData], function(err, rows, fields) {
            if (err) {
              return { msg: '批量插入数据库出错', code: ErrCode.ERROR_CODE_DB_UPDATE_FAILED };
            }
          });
        }, this.ctx);
        return { msg: '成功', code: 10000 };
      }
      return { msg: '参数错误', code: ErrCode.ERROR_CODE_PARAM };
    }

    // 品牌 加入/移出 黑名单
    async brandMVBanned(params) {
      const brand_id = params.brand_id;
      const isBanned = params.is_banned;
      if (typeof brand_id !== 'undefined' && typeof isBanned !== 'undefined') {
        const brandInfo = await this.app.mysql.get('brand', { id: brand_id });
        if (typeof brandInfo !== 'undefined') {
          const brand = {
            id: brand_id,
            is_banned: isBanned
          };
          // 如果是黑名单用户，那么就将自动下单的状态也设置为不自动下单
          if (Number(isBanned) === 1) {
            brand.auto_up_status = 0;
          }
          await this.app.mysql.update('brand', brand);
        } else {
          return { msg: '品牌不存在', code: ErrCode.ERROR_CODE_PARAM };
        }
      } else {
        return { msg: '品牌参数缺失', code: ErrCode.ERROR_CODE_PARAM };
      }
      return { msg: '成功', code: 10000 };
    }

    // 库中的品牌信息 分页，可筛选 [已入库、黑名单共用接口]
    async brandList(params) {

      let brandList = [];
      let totalBrandList = 0;
      if (typeof params.page !== 'undefined' && typeof params.pageSize !== 'undefined' && typeof params.is_banned !== 'undefined') {
        let page = params.page < 1 ? 1 : params.page;
        const pageSize = params.pageSize < 1 || params.pageSize > 30 ? 30 : params.pageSize;
        page = (page - 1) * pageSize;
        const is_banned = params.is_banned; // type=0 已入库， type=1 黑名单
        let conditions = '';
        if (typeof params.brand_id !== 'undefined' && params.brand_id !== '') {
          conditions = conditions + ` AND t0.id = ${params.brand_id} `;
        }
        if (typeof params.brand_name !== 'undefined' && params.brand_name !== '') {
          conditions = conditions + ` AND t0.brand_name like "%${params.brand_name}%" `;
        }
        if (typeof params.type_code !== 'undefined' && params.type_code !== '') {
          conditions = conditions + ` AND t0.type_code = ${params.type_code} `;
        }
        if (typeof params.auto_status !== 'undefined' && params.auto_status !== '') {
          conditions = conditions + ` AND t0.auto_up_status = ${params.auto_status} `;
        }
        conditions = conditions + ' AND t0.is_delete = 0 ';
        conditions = conditions + ` AND t0.is_banned = ${is_banned}  ORDER BY t0.id `;
        const query_str = ' t0.id, t0.brand_name, t0.type_code, t1.type_name,t0.auto_up_status, t0.icon, t0.`describe`, t0.is_banned, t0.que_sort ';
        const limit = `limit ${page}, ${pageSize}`;

        const sql = `SELECT ${query_str} FROM brand t0 INNER JOIN brand_type t1 ON t0.type_code = t1.type_code AND t1.status = 1 WHERE 1 = 1` + conditions + limit;
        const tct = 'SELECT COUNT(*) as sinceNum FROM brand t0 INNER JOIN brand_type t1 ON t0.type_code = t1.type_code AND t1.status = 1 WHERE 1 = 1' + conditions;
        totalBrandList = tct;
        brandList = await this.app.mysql.query(sql);

        for (const iterator of brandList) {
          // 供应商品牌信息
          const supplierBrand = await this.app.mysql.select('group_buy_aikucun_brand', {
            where: { brand_id: iterator.id },
            columns: ['id', 'brand_name']
          });
          iterator.supplier_brand_arr = supplierBrand;
          iterator.supplier_brand = supplierBrand.map(item => item.brand_name).join(' - ');
          // 品牌分类信息
          const supplierBrandIds = supplierBrand.map(item => item.id);
          if (supplierBrandIds.length > 0) {
            const query_tag_str = 't0.id,t0.tag_name';
            const sqlTag = `SELECT ${query_tag_str} FROM
                            group_buy_tag t0
                            INNER JOIN group_buy_goods_activity t1 ON t1.cat_id = t0.id AND t1.brand_id in ?
                            GROUP BY t1.cat_id`;
            const tag = await this.app.mysql.query(sqlTag, [[supplierBrandIds]]);
            iterator.tag_arr = tag;
            iterator.tag = tag.map(item => item.tag_name).join(' - ');

          }
          // 品牌标签信息
          const query_lebal_str = ' t1.label_name ';
          const sqlLabel = `SELECT ${query_lebal_str} FROM 
                            group_buy_label t0 
                            INNER JOIN label t1 ON t0.label = t1.id AND t1.type = 2
                            WHERE t0.target_id = ${iterator.id} AND t0.label_type = 2 AND t0.status = 0`;

          const labels = await this.app.mysql.query(sqlLabel);
          iterator.labels_arr = labels;
          iterator.labels = labels.map(item => item.label_name).join(' - ');
          iterator.auto_up_status_str = Number(iterator.auto_up_status) === 1 ? '自动上架' : '/';

        }
      } else {
        return { msg: '参数错误', code: ErrCode.ERROR_CODE_PARAM };
      }
      const totalCount = await this.app.mysql.query(totalBrandList);
      return { msg: '成功', code: 10000, data: brandList, totalCount };
    }

    // 删除已入库品牌
    async deleteSinceBrand(params) {
      if (typeof params.id !== null) {
        const row = {
          id: params.id,
          is_delete: 1
        };
        const result = await this.app.mysql.update('brand', row);
        return { msg: '成功', code: 10000, data: result };
      }
    }

    // 新增品牌
    async brandCreate(params) {

      let insertBrandId = -1;
      if (typeof params.brand_name !== 'undefined'
        && typeof params.type_code !== 'undefined'
        && typeof params.auto_up_status !== 'undefined'
        && typeof params.icon !== 'undefined') {
        const brandIds = await this.app.mysql.select('brand', {
          where: { brand_name: params.brand_name },
          columns: ['id']
        });
        if (brandIds.length === 0) {
          // 品牌基本信息
          const brand = {
            brand_name: params.brand_name,
            type_code: params.type_code,
            auto_up_status: params.auto_up_status,
            icon: params.icon,
            describe: params.describe,
            is_banned: 0,
            que_sort: 0
          };
          // 品牌标签信息设置
          const labels = [];
          if (typeof params.labels !== 'undefined') {
            for (const iterator of params.labels) {
              const item = {
                label_type: 2,
                target_id: -1,
                label: iterator,
                status: 0
              };
              labels.push(item);
            }
          }
          // 品牌资源位配置
          const brand_resources = [];
          if (typeof params.brand_resources !== 'undefined') {
            for (const iterator of params.brand_resources) {
              const resource = {
                tag_id: iterator.tag_id,
                resources: iterator.resources,
                brand_id: -1,
                status: 1
              };
              brand_resources.push(resource);
            }
          }
          // 开启事务
          const result = await this.app.mysql.beginTransactionScope(async conn => {
            // 新增品牌
            const insertBrand = await conn.insert('brand', brand);
            if (insertBrand.affectedRows === 1) {
              // 新增标签
              if (labels.length > 0) {
                for (const iterator of labels) {
                  iterator.target_id = insertBrand.insertId;
                  await conn.insert('group_buy_label', iterator);
                }
              }
              // 新增品牌资源
              if (brand_resources.length > 0) {
                for (const iterator of brand_resources) {
                  iterator.brand_id = insertBrand.insertId;
                  await conn.insert('brand_resource', iterator);
                }
              }
            }
            insertBrandId = insertBrand.insertId;
          }, this.ctx);

        } else {
          return { msg: '品牌已存在，不能新增', code: ErrCode.ERROR_CODE_PARAM };
        }
      } else {

        return { msg: '品牌参数缺失', code: ErrCode.ERROR_CODE_PARAM };
      }
      return { msg: '成功', code: 10000, data: insertBrandId };
    }

    // 修改品牌
    async brandUpdate(params) {
      if (typeof params.id !== 'undefined') {
        const brandInfo = await this.app.mysql.get('brand', { id: params.id });

        if (typeof brandInfo !== 'undefined') {
          // 品牌基本信息
          const brand = {
            id: params.id,
            brand_name: params.brand_name,
            type_code: params.type_code,
            auto_up_status: params.auto_up_status,
            icon: params.icon,
            describe: params.describe
          };

          // 品牌标签信息设置
          const labels = [];

          if (typeof params.lebalIds !== 'undefined') {
            for (const iterator of params.lebalIds) {
              const item = {
                label_type: 2,
                target_id: params.id,
                label: iterator,
                status: 0
              };
              labels.push(item);
            }
          }

          // 品牌资源位配置
          const brand_resources = [];
          if (typeof params.bannerResource !== 'undefined') {
            for (const iterator of params.bannerResource) {
              if (typeof iterator.tag_id !== 'undefined') {
                const resource = {
                  tag_id: iterator.tag_id,
                  resources: iterator.resources,
                  brand_id: params.id,
                  status: 1
                };
                brand_resources.push(resource);
              }
            }
          }

          // 开启事务
          const result = await this.app.mysql.beginTransactionScope(async conn => {
            // 修改品牌信息
            await conn.update('brand', brand);
            // 该品牌所有标签都下架
            await conn.update('group_buy_label', { status: 1 }, { where: { label_type: 2, target_id: brand.id } }); // 更新 posts 表中的记录
            // 修改标签
            if (labels.length > 0) {
              for (const iterator of labels) {
                const lebal_id = await conn.select('group_buy_label', {
                  where: { label_type: iterator.label_type, target_id: brand.id, label: iterator.label },
                  columns: ['id']
                });
                if (lebal_id.length > 0) {
                  iterator.id = lebal_id[0].id;
                  await conn.update('group_buy_label', iterator);
                } else {
                  if (Number(iterator.status) === 0) {
                    await conn.insert('group_buy_label', iterator);
                  }
                }
              }
            }

            await this.app.mysql.update('brand_resource', { status: 0 }, { where: { brand_id: brand.id } }); // 更新 posts 表中的记录
            // 新增品牌资源
            if (brand_resources.length > 0) {
              for (const iterator of brand_resources) {
                const resource_id = await this.app.mysql.select('brand_resource', {
                  where: { brand_id: iterator.brand_id, tag_id: iterator.tag_id },
                  columns: ['id']
                });
                if (resource_id.length > 0) {
                  iterator.id = resource_id[0].id;
                  await this.app.mysql.update('brand_resource', iterator);
                } else {
                  if (Number(iterator.status) === 1) {
                    await conn.insert('brand_resource', iterator);
                  }
                }
              }
            }
          }, this.ctx);
          return { msg: '品牌信息修改成功', code: 10000 };
        } else {
          return { msg: '查不到该品牌的信息', code: ErrCode.ERROR_CODE_PARAM };
        }
      } else {
        return { msg: '品牌ID缺失', code: ErrCode.ERROR_CODE_PARAM };
      }
    }

    async tagInfo() {
      const results = await this.app.mysql.select('group_buy_tag', {
        where: { admin_status: 1 }
      });
      return { msg: '成功', code: 10000, data: results };
    }

    // 根据id查询tag_name
    async getTagName(params) {
      const results = await this.app.mysql.get('group_buy_tag', { id: params.id });
      return { msg: '成功', code: 10000, data: results };
    }
    // 待入库模糊搜索
    async searchName(params) {
      const results = await this.app.mysql.select('brand', {
        where: { is_banned: 0, is_delete: 0 },
        columns: ['id', 'brand_name']
      });
      return { msg: '成功', code: 10000, data: results };
    }


    // 查看品牌信息
    // 需要的参数，自营库中的品牌信息
    async brandInfo(params) {
      let brand;
      if (params.brand_id !== null && !isNaN(params.brand_id)) {
        brand = await this.app.mysql.get('brand', { id: params.brand_id });
        if (brand !== null) {
          brand.auto_up_status_str = Number(brand.auto_up_status) === 1 ? '自动上架' : '默认下架';
          // 获取该品牌的标签名
          let lebalName;
          const labelId = await this.app.mysql.select('group_buy_label', {
            where: { label_type: 2, target_id: params.brand_id, status: 0 },
            columns: ['label']
          });
          const labelIds = labelId.map(item => item.label);
          if (labelId.length > 0) {
            lebalName = await this.app.mysql.select('label', {
              where: { id: labelIds },
              columns: ['id', 'label_name']
            });
          }
          brand.lebalName = lebalName;
          if (typeof lebalName !== 'undefined' && lebalName.length > 0) {
            brand.lebalIds = lebalName.map(item => item.id);
          }


          // 获取品牌分类类型
          const type = await this.app.mysql.select('brand_type', {
            where: { type_code: brand.type_code, status: 1 },
            columns: ['id', 'type_name', 'type_code']
          });
          brand.typeName = (typeof type[0] !== 'undefined') ? type[0].type_name : '';
          brand.typeId = (typeof type[0] !== 'undefined') ? type[0].id : '';
          brand.type_code = (typeof type[0] !== 'undefined') ? type[0].type_code : '';
          // 获取品牌的通用banner
          const sqlResource = 'SELECT t0.tag_id, if(t0.tag_id=0, ? , t1.tag_name) as tag_name, t0.resources FROM brand_resource t0 left JOIN group_buy_tag t1 ON t0.tag_id = t1.id WHERE t0.brand_id = ? AND t0.`status` = ?';
          const bannerResource = await this.app.mysql.query(sqlResource, ['通用', params.brand_id, 1]);
          brand.bannerResource = bannerResource;
        }
      }
      return { msg: '成功', code: 10000, data: brand };
    }

    async getMd5(params) {
      const hash = crypto.createHash('md5');
      hash.update(params.kk);
      const password_sign = hash.digest('hex');
      console.log('===================' + JSON.stringify(hash) + '======');
      return { msg: '成功', code: 10000, data: password_sign };
    }


    // //获取时间戳
    // async getMd5() {
    //   const time = (Date.parse(new Date()))/1000;
      
    //   return { msg: '成功', code: 10000, data: time};
    // }

    async sendMessage(params) {
      params = {
        mobile: '15099830231',
        param: urlencode('code:7777')
      };

      const requestUrl = `http://dingxin.market.alicloudapi.com/dx/sendSms?mobile=${params.mobile}&
      param=${params.param}&tpl_id=TP1711063`;
      console.log('=================' + requestUrl);
      const sendmsg = await this.ctx.curl(requestUrl, {
        method: 'POST',
        headers: {
          'Content-type': 'application/x-www-form-urlencoded; charset=utf-8',
          Authorization: 'APPCODE 788bb08246a14a3badd3c929f93be2bc',
        }
      });
      return { msg: '成功', code: 10000, data: sendmsg };
    }
  };
};