/**
 * sequelize.js的初始化服务类
 * Created by ocean on 18/05/29
 * 具体如何使用Sequelize可以参考 http://docs.sequelizejs.com/manual/tutorial/querying.html#basics
 */

'use strict';

const Service = require('egg').Service;
const Sequelize = require('sequelize');
const path = require('path');
const fs = require('fs');

let _models;
let _sequelize;

function initSequelize(app) {
  if (_sequelize) {
    return _sequelize;
  }
  const mysqlConf = app.config.mysql.client;
  const sequelizeLog = app.config.mysql.sequelizeLog;

  _sequelize = new Sequelize(mysqlConf.database, mysqlConf.user, mysqlConf.password, {
    host: mysqlConf.host,
    port: mysqlConf.port,
    dialect: mysqlConf.connector,
    operatorsAliases: false, // disable aliases
    pool: {
      max: mysqlConf.connectionLimit,
      min: 2,
      idle: 30000,
    },
    timezone: mysqlConf.timezone,
    logging: sequelizeLog ? console.log : false,
  });
  return _sequelize;
}

class DBService extends Service {
  constructor(ctx) {
    super(ctx);
    this.sequelize = initSequelize(ctx.app);
    this.loadModels();
  }

  loadModels() {
    if (_models) {
      for (const key in _models) {
        this[key] = _models[key];
      }
      return;
    }
    const that = this;
    const modelPath = path.resolve(__dirname, '../model/');
    _models = {};

    fs.readdirSync(modelPath)
      .filter(function(file) {
        return file.indexOf('.') !== 0 && file !== 'relation.js';
      })
      .forEach(function(file) {
        try {
		  const model = that.sequelize.import(path.join(modelPath, file));
          _models[model.name] = model;
          that[model.name] = model;
        } catch (err) {
          that.app.logger.error(`import error, file:${file}, err:${err}`);
        }
      });

    that._loadRelations();
  }

  _loadRelations() {
    const relation = require('../model/relation');
    relation(_models);
  }
}

module.exports = DBService;
