const Service = require('egg').Service;
const utils = require('../utils/utils');
const crypto = require('crypto');

module.exports = () => {
  return class ZhiTong extends Service {
    // 触发充值
    async charge(params) {
      params.dtCreate = utils.dateFmt('yyyyMMddhhmmss', new Date());
      params.serialno = utils.genSerialNo();
      const result = await this.sendRequest(params, '/buy.do');
      return result;
    }

    // 查询
    async queryOrder(params) {
      const result = await this.sendRequest(params, '/queryBizOrder.do');
      return result;
    }

    // 直通通用发送接口
    async sendRequest(params, urlAddition) {
      const ctx = this.ctx;
      // 第一步：补全基础参数
      params.userId = this.config.zt.userId;

      // 第二步：构造原始加密串
      let valStr = '';
      const keys = Object.keys(params).sort();
      for (const i in keys) {
        const key = keys[i];
        valStr += params[key];
      }
      // 第三步：使用MD5/Base64加密串
      valStr += this.config.zt.secret;
      const buffer = new Buffer(valStr, 'utf-8');
      const base64Str = buffer.toString();
      const hash = crypto.createHash('md5');
      hash.update(base64Str);
      const sign = hash.digest('hex').toLowerCase();
      // 第四步：sign填入请求体
      params.sign = sign;

      const result = await ctx.curl(`${this.config.zt.base_url}${urlAddition}`, {
        method: 'GET',
        dataType: 'json',
        data: params,
      });

      console.log('请求充值结果', urlAddition, result);
      return result;
    }
  };
};