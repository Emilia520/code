'use strict';

const Service = require('egg').Service;
const crypto = require('crypto');
class RegisterService extends Service {
  async reAccount(params) {
    const name =params.name;
    const role =params.role;
    const truename =params.truename;
    const retime = params.retime;
    const type = params.type;
    const number = params.number;
    const telephone = params.telephone;
    let contact = params.contact;
    //密码进行MD5加密
    let password = '';
    if(params.password!==null&&params.password!==undefined){
      const hash = crypto.createHash('md5');
      hash.update(params.password);
      password = hash.digest('hex');
    }
    if(contact===undefined||contact===''){
      contact = '无';
    }
    const conn = await this.app.mysql.beginTransaction(); // 初始化事务
    const field = 'account_name,password_sign,role_id,truename,registration_date,type'; //需要插入的字段名
    const sql =`INSERT INTO admin_user(${field})VALUES('${name}','${password}',${role},'${truename}',${retime},${type});`; //插入sql
    const inforfield = 'truename,account_name,telephone,contact,number,type,role_id,registration_date';
    // const sql =`INSERT INTO admin_user(${field})VALUES('test',null,3,null,null);`; //插入sql
    const informsql =`INSERT INTO user_information(${inforfield})VALUES('${truename}','${name}',${telephone},'${contact}',${number},${type},${role},${retime});`; //插入sql
    try { 
      await conn.query(sql);
      await conn.query(informsql);
      await conn.commit(); // 提交事务
      return { code: 10000, msg: '成功', data: '插入成功'};
    } catch (err) {
      // error, rollback
      console.log('----------事务执行失败----------');
      await conn.rollback(); // 一定记得捕获异常后回滚事务！！
      throw err;
    }
  }

 
}

module.exports = RegisterService;
