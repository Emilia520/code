const Service = require('egg').Service;
const utils = require('../utils/utils');
const Constant = require('../utils/constant');
const msgList = [];
const robotGroupsMap = {};

module.exports = () => {
  return class Robot extends Service {
    // 获取机器人列表
    async list() {
      const sql = `SELECT a.id, a.nickname, a.alias_name, a.head_img, a.robot_status, a.robot_key, a.wxid, a.last_login_time, COUNT(b.id) AS group_count
        FROM robot a LEFT JOIN robot_group_info b
        ON a.id = b.robot_id
        GROUP BY a.id
        ORDER BY a.id`;
      const result = await this.app.mysql.query(sql);
      return result;
    }

    // 新版本上传消息
    async uploadCalendarMsg(params) {
      console.log(params);
      const ctx = this.ctx;
      await this.app.mysql.beginTransactionScope(async conn => {
        for (const i in params) {
          const obj = params[i];
          // 先记录运营日历消息
          await conn.insert('admin_calendar_msg', {
            goods_id: obj.goods_id,
            desc: obj.desc,
            wx_group_cats: JSON.stringify(obj.wx_group_cats),
            wx_group_ids: JSON.stringify(obj.wx_group_ids),
            send_text: obj.send_text,
            send_img: obj.send_img,
            send_file: obj.send_file,
            send_time: obj.send_time,
            send_link: obj.send_link,
            from_friend: obj.from_friend,
            operator: obj.operator,
            status: 0,
            type: obj.type,
            promote_type: obj.promote_type,
            channel_type: obj.channel_type,
          });
          // 再录入商品信息到商品库
          if (obj.goods_info) {
            if (obj.type === 1) {
              obj.goods_info.small_images = JSON.stringify(obj.goods_info.small_images);
              const sql = utils.genReplaceSql('sku_tb', obj.goods_info);
              if (!sql) {
                this.logger.error('genReplaceSql(sku_tb)失败');
                continue;
              }
              await this.app.mysql.query(sql);
            } else if (obj.type === 3) {
              obj.goods_info.goods_gallery_urls = JSON.stringify(obj.goods_info.goods_gallery_urls);
              obj.goods_info.opt_ids = JSON.stringify(obj.goods_info.opt_ids);
              obj.goods_info.cat_ids = JSON.stringify(obj.goods_info.cat_ids);
              const sql = utils.genReplaceSql('sku_pdd', obj.goods_info);
              if (!sql) {
                this.logger.error('genReplaceSql(sku_pdd)失败');
                continue;
              }
              await this.app.mysql.query(sql);
            }
          }
        }
      }, ctx);

      // 尝试更新队列
      this.scheduleUpdateMsgList();
    }

    // 更新发送消息队列
    async scheduleUpdateMsgList() {
      let results = [];
      const looping = await this.app.redis.get('db2').get(Constant.key.ROBOT_MSG_QUEUEING);
      if (!looping) {
        const ctx = this.ctx;
        const curTime = new Date().getTime() / 1000;
        await this.app.mysql.beginTransactionScope(async conn => {
          const sql = `SELECT * FROM admin_calendar_msg WHERE status = 0 AND send_time <= ${curTime} ORDER BY send_time DESC LIMIT 1;`;
          results = await conn.query(sql);
          for (const i in results) {
            const msg = results[i];
            console.log('add msg to queue.', msg);
            msg.wx_group_cats = JSON.parse(msg.wx_group_cats);
            msg.wx_group_ids = JSON.parse(msg.wx_group_ids);
            msgList.push(msg);
            await this.updateMsgStatus(msg, Constant.robotMsgStatus.QUEUE);
          }
        }, ctx);

        this.loopSendNextRobotMsg();
      }

      return results;
    }

    // 默认获取拼多多
    async getPidInfo(msg, types = [5]) {
      // 获取发送消息所需要的群活码、pid、群等信息
      let info = [];
      // 如果消息是以群分类来发送的，则忽略上传上来的群组信息
      if (msg.wx_group_cats && msg.wx_group_cats.length > 0) {
        info = await this.getGroupPidInfoByCategory(msg.wx_group_cats, types);
      } else if (msg.wx_group_ids && msg.wx_group_ids.length > 0) {
        info = await this.getGroupPidInfoByGroups(msg.wx_group_ids, types);
      } else if (msg.adminUser) {
        info = await this.getGroupPidInfoByAdminUser(msg.adminUser, types);
      }
      return info;
    }

    /*
    * desc: 根据群分类来获取群pid等信息
    * param: categories 群分类。6:测试群；1:社会导购群；2:校园特卖群; 3:鲸主义; 4:社会特卖群; 5:低频低价
    *        type 平台类型 1.淘宝;5.拼多多
    */
    async getGroupPidInfoByCategory(categories, types) {
      if (categories.length === 0) {
        return [];
      }
      const categoriesStr = `(${categories.join(',')})`;
      const typesStr = `(${types.join(',')})`;
      let info = await this.app.redis.get('db2').get(`${Constant.key.WX_GROUP}_${categoriesStr}_${typesStr}`);
      if (!info) {
        const sql = `SELECT * FROM (SELECT a.id AS group_id, a.user_id, f.type, e.pid, c.pid AS communityCode, GROUP_CONCAT(a.group_wxid) AS groupWxidsStr, GROUP_CONCAT(a.group_name Separator '||') AS groupNames, NULL AS robotKey, a.send_type AS sendType
          FROM robot_group_info a, robot_group_pid b, tb_pid c, tb_pid e, user f
          WHERE a.category IN ${categoriesStr}
            AND a.enable = 1
            AND a.send_type = 0
            AND a.user_id = f.id
            AND a.community_code_id = c.id
            AND c.type = 10
            AND a.id = b.group_id
            AND b.pid_id = e.id
            AND e.type IN ${typesStr}
            AND e.status IN (1, 6)
          GROUP BY communityCode) tmp1 UNION (SELECT a.id AS group_id, a.user_id, f.type, e.pid, NULL AS communityCode, GROUP_CONCAT(a.group_wxid) AS groupWxidsStr, GROUP_CONCAT(a.group_name Separator '||') AS groupNames, d.robot_key AS robotKey, a.send_type AS sendType
          FROM robot_group_info a, robot_group_pid b, robot d, tb_pid e, user f
          WHERE a.category IN ${categoriesStr}
            AND a.enable = 1
            AND a.send_type = 1
            AND a.user_id = f.id
            AND a.robot_id = d.id
            AND a.id = b.group_id
            AND b.pid_id = e.id
            AND e.type IN ${typesStr}
            AND e.status IN (1, 6)
          GROUP BY b.pid_id)`;
        info = await this.app.mysql.query(sql);
        if (info.length > 0) {
          this.app.redis.get('db2').set(`${Constant.key.WX_GROUP}_${categoriesStr}_${typesStr}`, JSON.stringify(info), 'EX', 3600);
        }
      } else {
        info = JSON.parse(info);
      }
      return info;
    }

    /*
    * desc: 根据群数组来获取群pid等信息
    * param: categories 群分类。6:测试群；1:社会导购群；2:校园特卖群; 3:鲸主义; 4:社会特卖群; 5:低频低价
    *        type 平台类型 1.淘宝;5.拼多多
    */
    async getGroupPidInfoByGroups(groupWxids, types) {
      if (groupWxids.length === 0) {
        return [];
      }
      const condition = JSON.stringify(groupWxids).replace('[', '(').replace(']', ')');
      const typesStr = `(${types.join(',')})`;
      const sql = `SELECT * FROM (SELECT a.id AS group_id, a.user_id, f.type, e.pid, c.pid AS communityCode, GROUP_CONCAT(a.group_wxid) AS groupWxidsStr, GROUP_CONCAT(a.group_name Separator '||') AS groupNames, NULL AS robotKey, a.send_type AS sendType
        FROM robot_group_info a, robot_group_pid b, tb_pid c, tb_pid e, user f
        WHERE a.group_wxid IN ${condition}
          AND a.enable = 1
          AND a.send_type = 0
          AND a.user_id = f.id
          AND a.community_code_id = c.id
          AND c.type = 10
          AND a.id = b.group_id
          AND b.pid_id = e.id
          AND e.type IN ${typesStr}
          AND e.status IN (1, 6)
        GROUP BY communityCode) tmp1 UNION (SELECT a.id AS group_id, a.user_id, f.type, e.pid, NULL AS communityCode, GROUP_CONCAT(a.group_wxid) AS groupWxidsStr, GROUP_CONCAT(a.group_name Separator '||') AS groupNames, d.robot_key AS robotKey, a.send_type AS sendType
        FROM robot_group_info a, robot_group_pid b, robot d, tb_pid e, user f
        WHERE a.group_wxid IN ${condition}
          AND a.enable = 1
          AND a.send_type = 1
          AND a.user_id = f.id
          AND a.robot_id = d.id
          AND a.id = b.group_id
          AND b.pid_id = e.id
          AND e.type IN ${typesStr}
          AND e.status IN (1, 6)
        GROUP BY b.pid_id)`;
      return await this.app.mysql.query(sql);
    }

    async getGroupPidInfoByAdminUser(adminUser, types) {
      if (!adminUser) {
        return [];
      }
      const typesStr = `(${types.join(',')})`;
      const sql = `SELECT NULL as group_id, a.app_user_id AS user_id, d.type, c.pid, NULL AS communityCode, NULL AS groupWxidsStr, NULL AS groupNames, NULL AS robotKey, NULL AS sendType
        FROM admin_user a, user_pid b, tb_pid c, user d
        WHERE a.account_name = '${adminUser}' 
          AND a.app_user_id = d.id
          AND d.id = b.user_id
          AND b.pid_id = c.id 
          AND c.type IN ${typesStr}
          AND c.status IN (1, 6)`;
      return await this.app.mysql.query(sql);
    }

    // 发送普通消息或卡片消息
    async sendNormalMsg(msg) {
      if (msg.type === 0 && !msg.send_img && !msg.send_text) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.FAILED, '待发送的图片与文本皆为空');
        return;
      }

      // 对于卡片消息，要求这4个字段都不能空
      if (msg.type === 4 && (!msg.send_text || !msg.send_link || !msg.desc || !msg.send_img)) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.FAILED, '待发送卡片消息缺少一个或多个消息参数');
        return;
      }

      // 获取发送消息所需要的群活码、pid、群等信息
      const info = await this.getPidInfo(msg);
      if (info.length === 0) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.FAILED, '获取不到相应的pid信息');
        return;
      }

      let successCount = 0;
      const reasonObj = {};
      // 开始遍历所有需要发送的群，逐一发送消息
      for (const i in info) {
        const obj = info[i];

        // 构造发送数据
        const sendData = { data: [] };

        if (msg.type === 0) {
          if (msg.send_text) {
            sendData.data.push({
              msgType: 1,
              content: msg.send_text
            });
          }

          if (msg.send_img) {
            sendData.data.push({
              msgType: 3,
              content: msg.send_img
            });
          }

          if (msg.send_file) {
            sendData.data.push({
              msgType: this.isImageLink(msg.send_file) ? 3 : 49,
              content: msg.send_file
            });
          }
        } else if (msg.type === 4) {
          sendData.data.push({
            msgType: 16,
            appType: 1,
            link: msg.send_link,
            title: msg.desc,
            description: msg.send_text,
            coverImgFile: msg.send_img
          });
        }

        // 发送消息
        const result = await this.service.yjiyun.sendWXGroupMsgImmediately(sendData, obj);
        if (!(result && result.data && result.data.code === '0')) {
          this.statisticErrReason(reasonObj, result.data.msg);
          continue;
        }

        ++successCount;
      }

      if (successCount === 0) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.FAILED, this.getReasonStr(reasonObj));
      } else if (successCount < info.length) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.SUCCESS_PARTIALLY, this.getReasonStr(reasonObj));
      } else {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.SUCCESS);
      }
    }

    // 发送淘宝消息
    async sendTbMsg(msg) {
      // 先获取发单图所需要的商品信息
      let goods;
      const results = await this.app.mysql.select('sku_tb', {
        columns: ['num_iid', 'reserve_price', 'zk_final_price', 'coupon_info'],
        where: {
          num_iid: msg.goods_id
        }
      });
      if (results.length > 0) {
        goods = results[0];
      }
      if (!goods || !goods.zk_final_price) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.FAILED, '商品信息不全，无法构造分享图');
        return;
      }

      // 获取发送消息所需要的群活码、pid、群等信息
      const info = await this.getPidInfo(msg, [1, 14]);
      if (info.length === 0) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.FAILED, '获取不到相应的pid信息');
        return;
      }

      // 生成通用图片模版
      goods.title = msg.desc;
      goods.pict_url = msg.send_img;
      // 注意！！！以下注释不要删除！！！注释掉的是淘宝的发单图的生成，使用了中间页的方案，但随时可能切换回来

      // const templateUrl = await this.service.tb.genCommonTemplate(goods);
      // if (!templateUrl) {
      //   await this.updateMsgStatus(msg, 5, '生成通用图片模版失败');
      //   return;
      // }

      const reasonObj = {};
      let successCount = 0;
      // 开始遍历所有需要发送的群，逐一发送消息
      for (const i in info) {
        const obj = info[i];
        // 获取淘口令
        const tkl = await this.service.tb.getTkl(obj.pid, msg.goods_id);
        if (!tkl) {
          this.statisticErrReason(reasonObj, '淘口令');
          continue;
        }
        // 注意！！！以下注释不要删除！！！注释掉的是淘宝的发单图的生成，使用了中间页的方案，但随时可能切换回来

        // 生成二维码
        // const qrCode = await this.service.tb.genQRCode(goods, tkl);
        // if (!qrCode) {
        //   this.statisticErrReason(reasonObj, '生成二维码');
        //   continue;
        // }
        // 合成最终图片
        // const imgUrl = await this.service.tb.composePict(templateUrl, qrCode);
        // if (!imgUrl) {
        //   utils.deleteFile(templateUrl);
        //   utils.deleteFile(qrCode);
        //   this.statisticErrReason(reasonObj, '生成图片');
        //   continue;
        // }

        // 构造发送数据
        const imgUrl = goods.pict_url;
        const sendData = { data: [] };
        if (msg.send_text) {
          let sendText = msg.send_text;
          if (msg.send_text.indexOf('{{promote_url}}')) {
            const longUrl = await this.service.tb.genPromotePageUrl(goods, tkl);
            const promoteUrl = await this.genShortUrl(longUrl);
            if (promoteUrl) {
              sendText = msg.send_text.replace('{{promote_url}}', promoteUrl);
            } else if (longUrl) {
              sendText = msg.send_text.replace('{{promote_url}}', longUrl);
            } else {
              sendText = msg.send_text.replace('{{promote_url}}', '打开图片长按识别二维码');
            }
          }
          sendData.data.push({
            msgType: 1,
            content: sendText
          });
        }
        sendData.data.push({
          msgType: 3,
          content: imgUrl
        });

        // 发送消息
        const result = await this.service.yjiyun.sendWXGroupMsgImmediately(sendData, obj);
        if (!(result && result.data && result.data.code === '0')) {
          this.logger.error(`发送失败:${result.data.msg},code:${sendData.communityCode},group:${sendData.groupWxids}`);
          this.statisticErrReason(reasonObj, result.data.msg);
          continue;
        }

        ++successCount;
      }

      // 注意！！！以下注释不要删除！！！注释掉的是淘宝的发单图的生成，使用了中间页的方案，但随时可能切换回来
      // utils.deleteFile(qrCode);
      if (successCount === 0) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.FAILED, this.getReasonStr(reasonObj));
      } else if (successCount < info.length) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.SUCCESS_PARTIALLY, this.getReasonStr(reasonObj));
      } else {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.SUCCESS);
      }
      // 注意！！！以下注释不要删除！！！注释掉的是淘宝的发单图的生成，使用了中间页的方案，但随时可能切换回来
      // utils.deleteFile(templateUrl);
    }

    // 发送爱库存品牌团购消息
    async sendAkcMsg(msg) {
      // 先判断必要参数
      if (!msg.goods_id) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.FAILED, 'goods_id为空');
        return;
      }
      // 获取发送消息所需要的群活码、pid、群等信息
      const info = await this.getPidInfo(msg);
      if (info.length === 0) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.FAILED, '获取不到相应的pid信息');
        return;
      }

      const reasonObj = {};
      let successCount = 0;
      // 开始遍历所有需要发送的群，逐一发送消息
      for (const i in info) {
        const obj = info[i];

        const sendData = { data: [] };
        if (msg.send_text) {
          let sendText;
          if (msg.send_text.indexOf('{{promote_url}}')) {
            let longUrl;
            if (msg.promote_type === Constant.promoteType.SINGLE_GOODS_PROMOTE) {
              longUrl = await this.service.groupbuy.genGoodsPromotionUrl({
                userId: obj.user_id,
                userType: obj.type,
                id: msg.goods_id,
                groupId: obj.group_id
              });
            } else if (msg.promote_type === Constant.promoteType.ACTIVITY_PROMOTE) {
              longUrl = await this.service.groupbuy.genActivityPromotionUrl({
                userId: obj.user_id,
                userType: obj.type,
                id: msg.goods_id,
                groupId: obj.group_id
              });
            }

            if (longUrl) {
              const promoteUrl = await this.genShortUrl(longUrl);
              if (promoteUrl) {
                sendText = msg.send_text.replace('{{promote_url}}', promoteUrl);
              } else {
                sendText = msg.send_text.replace('{{promote_url}}', longUrl);
              }
            } else {
              this.statisticErrReason(reasonObj, '生成推广链接失败');
            }
          } else {
            sendText = msg.send_text;
          }

          if (sendText) {
            sendData.data.push({
              msgType: 1,
              content: sendText
            });

            if (msg.send_img) {
              sendData.data.push({
                msgType: 3,
                content: msg.send_img
              });
            }

            if (msg.send_file) {
              sendData.data.push({
                msgType: this.isImageLink(msg.send_file) ? 3 : 49,
                content: msg.send_file
              });
            }
          } else {
            this.statisticErrReason(reasonObj, '发送文案异常');
          }
        } else {
          this.statisticErrReason(reasonObj, '缺少发送文案');
        }

        // 发送消息
        const result = await this.service.yjiyun.sendWXGroupMsgImmediately(sendData, obj);
        if (!(result && result.data && result.data.code === '0')) {
          this.statisticErrReason(reasonObj, result.data.msg);
          continue;
        }

        ++successCount;
        await this.sleepAMoment();
      }

      if (successCount === 0) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.FAILED, this.getReasonStr(reasonObj));
      } else if (successCount < info.length) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.SUCCESS_PARTIALLY, this.getReasonStr(reasonObj));
      } else {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.SUCCESS);
      }
    }

    async sleepAMoment() {
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          resolve(true);
        }, 1500);
      });
    }

    // 发送拼多多消息
    async sendPddMsg(msg) {
      // 先判断必要参数
      if (msg.promote_type === Constant.promoteType.SINGLE_GOODS_PROMOTE && !msg.goods_id) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.FAILED, 'goods_id为空');
        return;
      }
      // 获取发送消息所需要的群活码、pid、群等信息
      const info = await this.getPidInfo(msg);
      if (info.length === 0) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.FAILED, '获取不到相应的pid信息');
        return;
      }

      let successCount = 0;
      const reasonObj = {};
      // 开始遍历所有需要发送的群，逐一发送消息
      for (const i in info) {
        const obj = info[i];
        // 根据pid转链
        const p_id = obj.pid;
        let ret;
        let promoteUrl;
        let sendText;
        if (msg.promote_type === Constant.promoteType.SINGLE_GOODS_PROMOTE) {
          ret = await this.service.pdd.genPromotionUrl({ p_id, goods_id_list: JSON.stringify([msg.goods_id]) });
        } else if (msg.promote_type === Constant.promoteType.CHANNEL_PROMOTE) {
          ret = await this.service.pdd.genCMSPromotionUrl({
            p_id_list: JSON.stringify([p_id]),
            channel_type: msg.channel_type
          });
        } else if (msg.promote_type === Constant.promoteType.RED_PACKAGE_PROMOTE) {
          ret = await this.service.pdd.genRPPromotionUrl({ p_id_list: JSON.stringify([p_id]) });
        } else if (msg.promote_type === Constant.promoteType.THEME_PROMOTE) {
          ret = await this.service.pdd.genThemePromotionUrl({ p_id, theme_id_list: JSON.stringify([msg.goods_id]) });
        } else if (msg.promote_type === Constant.promoteType.BIG_WHEEL_PROMOTE) {
          ret = await this.service.pdd.genBigWheelPromotionUrl({ pidList: [p_id] });
        } else if (msg.promote_type === Constant.promoteType.ODDS_PROMOTE) {
          ret = await this.service.pdd.genOddsPromotionUrl({ pid: p_id, resource_type: msg.channel_type });
        }

        if (ret.list && ret.list.length > 0) {
          promoteUrl = ret.list[0].short_url || ret.list[0].shortUrl;
          if (promoteUrl) {
            sendText = msg.send_text.replace('{{promote_url}}', promoteUrl);
          } else {
            this.statisticErrReason(reasonObj, '转链');
          }
        } else {
          this.statisticErrReason(reasonObj, '转链');
        }

        // 构造发送数据体
        const sendData = { data: [] };
        if (sendText) {
          sendData.data.push({
            msgType: 1,
            content: sendText
          });
        }
        if ((msg.promote_type === Constant.promoteType.SINGLE_GOODS_PROMOTE || msg.promote_type === Constant.promoteType.THEME_PROMOTE) && msg.send_img) {
          sendData.data.push({
            msgType: 3,
            content: msg.send_img
          });
        }
        if ((msg.promote_type === Constant.promoteType.SINGLE_GOODS_PROMOTE || msg.promote_type === Constant.promoteType.THEME_PROMOTE) && msg.send_file) {
          sendData.data.push({
            msgType: this.isImageLink(msg.send_file) ? 3 : 49,
            content: msg.send_file
          });
        }

        // 发送消息
        const result = await this.service.yjiyun.sendWXGroupMsgImmediately(sendData, obj);
        if (!(result && result.data && result.data.code === '0')) {
          this.statisticErrReason(reasonObj, result.data.msg);
          continue;
        }

        ++successCount;
      }

      if (successCount === 0) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.FAILED, this.getReasonStr(reasonObj));
      } else if (successCount < info.length) {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.SUCCESS_PARTIALLY, this.getReasonStr(reasonObj));
      } else {
        await this.updateMsgStatus(msg, Constant.robotMsgStatus.SUCCESS);
      }
    }

    async loopSendNextRobotMsg() {
      const msg = msgList.shift();
      try {
        await this.app.redis.get('db2').set(Constant.key.ROBOT_MSG_QUEUEING, '1');
        const ctx = this.ctx;
        if (msg) {
          // 开始处理消息
          if (msg.type === 0 || msg.type === 4) {
            await this.sendNormalMsg(msg);
          } else if (msg.type === 1) {
            await this.sendTbMsg(msg);
          } else if (msg.type === 3) {
            await this.sendPddMsg(msg);
          } else if (msg.type === 5) {
            await this.sendAkcMsg(msg);
          } else if (msg.type === 7) {
            await this.service.robotMiniProgram.addMsgToQueue(msg);
          }

          console.log('处理一条消息' + msg.id + ', 还剩下' + msgList.length + '条消息');
          this.logger.info('处理一条消息' + msg.id + ', 还剩下' + msgList.length + '条消息');
        }

        // 准备发送下一条消息
        if (msgList.length > 0) {
          const that = this;
          setTimeout(that.loopSendNextRobotMsg.bind(that), 5000);
        } else {
          await this.app.redis.get('db2').set(Constant.key.ROBOT_MSG_QUEUEING, '');
        }
      } catch (err) {
        this.logger.error('发送机器人消息异常', err);
        await this.app.redis.get('db2').set(Constant.key.ROBOT_MSG_QUEUEING, '');
        if (msg) {
          await this.updateMsgStatus(msg, Constant.robotMsgStatus.EXCEPTION, '发送机器人消息异常');
        }
      }
    }

    async getGroupInfo() {
      let info = await this.app.redis.get('db2').get(`${Constant.key.ROBOT_GROUP}`);
      if (!info) {
        info = {};
        const groups = await this.app.mysql.select('robot_group_info', {
          columns: ['group_wxid', 'group_name']
        });
        for (const i in groups) {
          const obj = groups[i];
          info[obj.group_wxid] = obj.group_name;
        }
        if (Object.keys(info).length > 0) {
          await this.app.redis.get('db2').set(`${Constant.key.ROBOT_GROUP}`, JSON.stringify(info), 'EX', 3600);
        }
      } else {
        info = JSON.parse(info);
      }

      return info;
    }

    async robotMsgList(params) {
      const ctx = this.ctx;
      const pageNum = params.page || 1;
      const pageSize = params.page_size || 100;
      const limit = `LIMIT ${(pageNum - 1) * pageSize}, ${pageSize}`;
      const where = parseQueryCondition(params);
      let list;
      let totalCountArr;
      let groupInfo;
      await this.app.mysql.beginTransactionScope(async conn => {
        const cntSql = `SELECT count(1) FROM admin_calendar_msg ${where}`;
        const sql = `SELECT * FROM admin_calendar_msg ${where} ORDER BY send_time DESC ${limit}`;
        list = await conn.query(sql);
        totalCountArr = await conn.query(cntSql);
        groupInfo = await this.getGroupInfo();

        return { success: true };
      }, ctx);

      function parseQueryCondition(params) {
        const queryConditions = [];
        let where = '';
        if (params.operator) {
          queryConditions.push('operator = "' + params.operator + '" ');
        }

        if (params.goods_id) {
          queryConditions.push('goods_id = "' + params.goods_id + '" ');
        }

        if (params.start_time) {
          queryConditions.push('send_time >= ' + params.start_time + ' ');
        }

        if (params.end_time) {
          queryConditions.push('send_time <= ' + params.end_time + ' ');
        }

        if (params.status) {
          queryConditions.push('status = ' + params.status + ' ');
        }

        for (const i in queryConditions) {
          const condition = queryConditions[i];
          if (i === 0) {
            where += 'WHERE ' + condition;
          } else {
            where += 'AND ' + condition;
          }
        }

        return where;
      }

      return { list, totalCount: Object.values(totalCountArr[0])[0], groupInfo };
    }

    async genPromoteInfo(params) {
      let types = [];
      const result = {};
      // 淘宝的转链
      if (params.type === 1) {
        types = [1, 14];
      } else if (params.type === 3) {
        types = [5];
      } else {
        return result;
      }
      // 获取发送消息所需要的群活码、pid、群等信息
      let param;
      if (params.wx_group_id) {
        param = { wx_group_ids: [params.wx_group_id] };
      } else if (params.adminUser) {
        param = { adminUser: params.adminUser };
      }
      const info = await this.getPidInfo(param, types);
      if (info.length === 0) {
        return result;
      }

      const pidInfo = info[0];
      if (params.type === 1) {
        const info = await this.service.tb.genPromoteInfo(pidInfo.pid, params.goods_id);
        result.short_url = info.coupon_short_url;
        result.tbk_pwd = info.tbk_pwd;
      } else if (params.type === 3) {
        let ret;
        if (params.promote_type === Constant.promoteType.SINGLE_GOODS_PROMOTE) {
          ret = await this.service.pdd.genPromotionUrl({
            p_id: pidInfo.pid,
            goods_id_list: JSON.stringify([params.goods_id])
          });
        } else if (params.promote_type === Constant.promoteType.CHANNEL_PROMOTE) {
          ret = await this.service.pdd.genCMSPromotionUrl({
            p_id_list: JSON.stringify([pidInfo.pid]),
            channel_type: params.channel_type
          });
        } else if (params.promote_type === Constant.promoteType.RED_PACKAGE_PROMOTE) {
          ret = await this.service.pdd.genRPPromotionUrl({ p_id_list: JSON.stringify([pidInfo.pid]) });
        } else if (params.promote_type === Constant.promoteType.THEME_PROMOTE) {
          ret = await this.service.pdd.genThemePromotionUrl({
            p_id: pidInfo.pid,
            theme_id_list: JSON.stringify([params.goods_id])
          });
        } else if (params.promote_type === Constant.promoteType.BIG_WHEEL_PROMOTE) {
          ret = await this.service.pdd.genBigWheelPromotionUrl({ pidList: [pidInfo.pid] });
        } else if (params.promote_type === Constant.promoteType.ODDS_PROMOTE) {
          ret = await this.service.pdd.genOddsPromotionUrl({ pid: pidInfo.pid, resource_type: params.channel_type });
        }

        if (ret && ret.list && ret.list.length > 0) {
          result.short_url = ret.list[0].short_url || ret.list[0].shortUrl;
        }
      }

      return result;
    }

    async revokeMsg(params) {
      if (params.id) {
        await this.updateMsgStatus(params, Constant.robotMsgStatus.REVERT);
      }
      return;
    }

    /*
    * desc: 更新运营日历消息状态
    * param: msg 消息体
    *        status 状态 0:未处理；1:处理中，无法撤回；2:撤回；3:已处理（全部成功）；4:已处理（部分成功）；5:已处理（全部失败）
    */
    async updateMsgStatus(msg, status, reason = '', conn = this.app.mysql) {
      return await conn.update('admin_calendar_msg', {
        status,
        reason
      }, {
        where: {
          id: msg.id
        }
      });
    }

    async genShortUrl(url) {
      // let shortUrl = null;
      // if (!url) {
      //   return shortUrl;
      // }

      // try {
      //   const { ctx } = this;
      //   const encodedUrl = encodeURIComponent(url);
      //   const result = await ctx.curl(`https://915.im/api.ashx?format=json&userId=2776&key=3A6F4FA94E8F7D23204ACC061405C22C&url=${encodedUrl}`, {
      //     dataType: 'json'
      //   });

      //   if (result && result.data && result.data.url) {
      //     shortUrl = result.data.url;
      //   } else {
      //     console.log(result.data);
      //   }
      // } catch (e) {
      //   this.logger.error(`生成短链失败，原始URL：${url}；异常信息：${e}`);
      //   shortUrl = null;
      // }

      // return shortUrl;

      return null;
    }

    async genBaiduShortUrl(url) {
      let shortUrl = null;
      if (!url) {
        return shortUrl;
      }

      try {
        const { ctx } = this;
        const result = await ctx.curl('https://dwz.cn/admin/v2/create', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json; charset=UTF-8',
            Token: 'ed3b02e679327988613fe14a2c597381'
          },
          data: {
            Url: url,
            TermOfValidity: '1-year'
          },
          dataType: 'json'
        });
        if (result && result.data && result.data.Code === 0) {
          shortUrl = result.data.ShortUrl;
        }
      } catch (e) {
        this.logger.error(`生成短链失败，原始URL：${url}；异常信息：${e}`);
        shortUrl = null;
      }

      return shortUrl;
    }

    statisticErrReason(reasonObj, key) {
      if (reasonObj[key]) {
        reasonObj[key] += 1;
      } else {
        reasonObj[key] = 1;
      }
    }

    getReasonStr(obj) {
      let str = '';
      const keys = Object.keys(obj);
      for (const i in keys) {
        const key = keys[i];
        str += `失败原因:${key},失败个数:${obj[key]}\n`;
      }
      return str;
    }

    // 添加机器人群
    async addGroupInfo(params) {
      const result = { code: 10001, msg: '未知错误' };
      if (!params.robotKey || !params.robotId || !params.phone || !params.type || !params.groupName || !params.category) {
        result.msg = '缺少必要参数';
        return result;
      }

      let user;
      let groupInfo;
      // 先找群主信息
      let ret = await this.app.mysql.select('user', {
        where: {
          phone: params.phone,
          type: params.type
        }
      });

      if (ret && ret.length > 0) {
        user = ret[0];
      } else {
        result.msg = '没找到该用户';
        return result;
      }
      // 然后找群信息
      ret = await this.service.yjiyun.queryRobotGroups({ robotKey: params.robotKey });
      if (ret.count > 0) {
        let found = false;
        for (const i in ret.list) {
          const info = ret.list[i];
          if (info.displayName === params.groupName) {
            found = true;
            groupInfo = info;
          }
        }

        if (!found) {
          result.msg = '在该机器人下找不到该群名对应的群';
          return result;
        }
      } else {
        result.msg = '该机器人下没有群';
        return result;
      }

      // 尝试往robot_group_info表添加一条记录
      ret = await this.app.mysql.insert('robot_group_info', {
        group_wxid: groupInfo.wxid,
        group_name: groupInfo.displayName,
        group_member_count: groupInfo.groupMemberCount,
        robot_id: params.robotId,
        status: 1,
        create_time: groupInfo.createTime,
        update_time: groupInfo.updateTime,
        enable: 1,
        category: params.category,
        send_type: 1,
        user_id: user.id
      });

      if (ret.affectedRows === 1 && ret.insertId) {
        const groupId = ret.insertId;
        const transRet = await this.app.mysql.beginTransactionScope(async conn => {
          // 找到淘宝pid
          ret = await conn.query(`select b.id from user_pid a, tb_pid b where a.user_id = ${user.id} and a.pid_id = b.id and b.type = 14 and b.status = 1`);
          const relationPid = (ret && ret.length > 0) ? ret[0].id : null;

          ret = await conn.query('select id from tb_pid where type = 5 and status = 0 limit 1');
          const pddPid = (ret && ret.length > 0) ? ret[0].id : null;

          if (pddPid) {
            await conn.update('tb_pid', {
              id: pddPid,
              status: 6
            });

            await conn.insert('user_pid', {
              user_id: user.id,
              pid_id: pddPid
            });

            await conn.insert('robot_group_pid', {
              group_id: groupId,
              pid_id: pddPid
            });
          }

          if (relationPid) {
            await conn.insert('robot_group_pid', {
              group_id: groupId,
              pid_id: relationPid
            });
          }

          return { success: true };
        }, this.ctx);
        console.log('transRet:', transRet);
        result.code = 10000;
        result.msg = '成功';
      } else {
        result.msg = '创建群信息时失败';
      }

      return result;
    }

    // 批量将有机云的微信群记录添加到数据库
    // params中已经包含了微信群信息
    async addRobotGroups(params) {
      console.log('params', params);

      if (params.robotID === null ||
        params.category === null ||
        params.phone === null ||
        !Array.isArray(params.groups)
      ) {
        return { code: -1, msg: '缺少参数' };
      }

      // 先找到群主信息
      const ret = await this.app.mysql.select('user', {
        where: {
          phone: params.phone,
          type: params.type || 1,
        }
      });

      if (!ret || ret.length === 0) {
        return { code: -1, msg: '未找到群主数据' };
      }

      const user = ret[0];
      const response = { code: -1, msg: '未知错误' };

      console.log('user', user);

      const transRet = await this.app.mysql.beginTransactionScope(async conn => {
        for (const index in params.groups) {
          const group = params.groups[index];

          // 尝试往robot_group_info表添加一条记录
          let ret = await this.app.mysql.insert('robot_group_info', {
            group_wxid: group.wxid,
            group_name: group.displayName,
            group_member_count: group.groupMemberCount,
            robot_id: params.robotID,
            status: 1,
            create_time: group.createTime,
            update_time: group.updateTime,
            enable: 1,
            category: params.category,
            send_type: 1,
            user_id: user.id
          });

          if (ret.affectedRows !== 1 && !ret.insertId) {
            response.msg = '插入群信息失败';
            return { success: false };
          }

          const groupId = ret.insertId;

          // 找到淘宝pid
          ret = await conn.query(`select b.id from user_pid a, tb_pid b where a.user_id = ${user.id} and a.pid_id = b.id and b.type = 14 and b.status = 1`);
          const relationPid = (ret && ret.length > 0) ? ret[0].id : null;

          ret = await conn.query('select id from tb_pid where type = 5 and status = 0 limit 1');
          const pddPid = (ret && ret.length > 0) ? ret[0].id : null;

          if (pddPid) {
            await conn.update('tb_pid', { id: pddPid, status: 6 });
            await conn.insert('user_pid', { user_id: user.id, pid_id: pddPid });
            await conn.insert('robot_group_pid', { group_id: groupId, pid_id: pddPid });
          }

          if (relationPid) {
            await conn.insert('robot_group_pid', { group_id: groupId, pid_id: relationPid });
          }
        }

        response.code = 10000;
        response.msg = '成功';
        return { success: true };
      }, this.ctx);

      return response;
    }

    // 更新机器人群信息
    async updateRobotGroupInfo(params) {
      await this.app.mysql.update('robot_group_info', {
        id: params.id,
        group_name: params.groupName,
        category: params.category
      });
    }

    // 获取机器人群分类列表
    async groupCategoryList() {
      return await this.app.mysql.select('robot_group_category');
    }

    // 更新机器人群分类信息
    async updateGroupCategoryInfo(params) {
      await this.app.mysql.update('robot_group_category', { id: params.id, name: params.name });
    }

    // 添加机器人群分类
    async addGroupCategory(params) {
      await this.app.mysql.insert('robot_group_category', { name: params.name });
    }

    // 从数据库加载机器人群信息
    async loadRobotGroupsForDB(params) {
      const robotID = params.robot_id;
      const options = {};

      if (typeof robotID === 'string' || typeof robotID === 'number') {
        options.where = { robot_id: robotID };
      }

      const res = await this.app.mysql.select('robot_group_info', options);
      return { code: 10000, msg: '成功', data: res };
    }

    isImageLink(url) {
      return url.indexOf('.jpg') !== -1 || url.indexOf('.jpeg') !== -1 || url.indexOf('.png') !== -1 || url.indexOf('.webp') !== -1;
    }
  };
};
