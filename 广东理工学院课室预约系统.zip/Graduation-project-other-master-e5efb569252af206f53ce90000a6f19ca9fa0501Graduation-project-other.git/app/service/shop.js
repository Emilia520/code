const Service = require('egg').Service;

module.exports = () => {
  return class Shop extends Service {
    async business() {
      const ctx = this.ctx;
      const result = await ctx.curl(ctx.app.config.api.img_host + '/shop/shopBusiness', {
        method: 'POST',
        contentType: 'json',
        data: {
          clientId: 'qxb_admin',
          version: '1.0'
        },
        dataType: 'json'
      });

      return result;
    }

    async infos(params = {}) {
      const ctx = this.ctx;
      const queryCondition = this.parseQueryCondition(params);
      //   const tmpShopSql = '(SELECT * FROM shop ' + queryCondition + ')';
      const sql = 'SELECT SQL_CALC_FOUND_ROWS * FROM (SELECT a.id, \
        a.name AS shop, \
        a.province_id, \
        b.province, \
        a.city_id, \
        c.city, \
        a.area_id, \
        d.area, \
        a.business_id, \
        a.second_business_id, \
        f.name AS nickname, \
        g.role_id, \
        h.code, \
        f.phone, \
        a.people_name AS userName, \
        a.people_id_card AS idCard, \
        a.business_license AS licence, \
        a.facade, \
        a.invitation_user_id, \
        IF(a.user_id IN (SELECT aaa.user_id FROM order_newer aaa, record_newer_action bbb WHERE aaa.order_code = bbb.order_code AND bbb.status = 1 GROUP BY aaa.user_id), 1, 0) AS active \
        FROM shop a, config_province b, config_city c, config_area d, user f, user_role_relation g, user_invitation h \
        WHERE a.province_id = b.id \
        AND a.city_id = c.id \
        AND a.area_id = d.id \
        AND a.user_id = f.id \
        AND a.user_id = g.user_id \
        AND f.invitation_id = h.id) tmp LEFT JOIN (SELECT aa.id AS sid, bb.business AS business1, cc.business AS business2 FROM shop aa, shop_business bb, shop_business cc WHERE bb.id = aa.business_id AND cc.id = aa.second_business_id) i ON tmp.id = i.sid ' + queryCondition + ';';
      console.log(sql);
      const list = await this.app.mysql.query(sql);
      const totalCountArr = await this.app.mysql.query('SELECT FOUND_ROWS();');
      return { list, totalCount: Object.values(totalCountArr[0])[0] };
    }

    parseQueryCondition(params) {
      const queryConditions = [];
      let where = '';
      let limit = '';
      // 解析参数
      if (params.provinces && params.provinces.length > 0) {
        queryConditions.push('province_id IN (' + params.provinces.join(',') + ') ');
      }

      if (params.cities && params.cities.length > 0) {
        queryConditions.push('city_id IN (' + params.cities.join(',') + ') ');
      }

      if (params.areas && params.areas.length > 0) {
        queryConditions.push('area_id IN (' + params.areas.join(',') + ') ');
      }

      if (params.businesses1 && params.businesses1.length > 0) {
        queryConditions.push('business_id IN (' + params.businesses1.join(',') + ') ');
      }

      if (params.businesses2 && params.businesses2.length > 0) {
        queryConditions.push('second_business_id IN (' + params.businesses2.join(',') + ') ');
      }

      if (params.shop && params.shop.length > 0) {
        queryConditions.push('shop = "' + params.shop + '" ');
      }

      if (params.phone && params.phone.length > 0) {
        queryConditions.push('phone = ' + params.phone + ' ');
      }

      if (params.bindInfo && params.bindInfo.length > 0) {
        // 长度小于10的暂时认为是姓名，其余为身份证
        if (params.bindInfo.length < 10) {
          queryConditions.push('userName = ' + params.bindInfo + ' ');
        } else {
          queryConditions.push('idCard = ' + params.bindInfo + ' ');
        }
      }

      if (queryConditions.length > 0) {
        where = 'WHERE ';
      }

      for (const i in queryConditions) {
        const condition = queryConditions[i];
        if (i < 1) {
          where += condition;
        } else {
          where += 'AND ' + condition;
        }
      }

      const pageNum = params.pageNum != null ? params.pageNum : 1;
      const pageSize = params.pageSize != null ? params.pageSize : 10;
      limit = 'LIMIT ' + (pageNum - 1) * pageSize + ',' + pageSize;

      return where + 'ORDER BY id ' + limit;
    }
  };
};