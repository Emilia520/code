const Service = require('egg').Service;
const ErrCode = require('../utils/errorCode');
const checker = require('../utils/paramChecker');
const utils = require('../utils/utils');
const gm = require('gm');
const qr = require('qr-image');
const FormStream = require('formstream');
const path = require('path');
const fs = require('fs');
const os = require('os');
const uuid = require('uuid');
const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'qx-admin-'));

module.exports = () => {
  return class Image extends Service {
    async uploadImage(imgReadStream) {
      let imgUrl = '';
      const ctx = this.ctx;
      if (imgReadStream) {
        const form = new FormStream();
        form.stream('file', imgReadStream, 'xxx.jpg');
        const result = await ctx.curl(ctx.app.config.api.img_host + '/helper/uploadCdn', {
          // 必须指定 method，支持 POST，PUT
          method: 'POST',
          // 生成符合 multipart/form-data 要求的请求 headers
          headers: form.headers(),
          // 以 stream 模式提交
          stream: form,
          // 明确告诉 HttpClient 以 JSON 格式处理响应 body
          dataType: 'json',
        });

        if (result.data && result.data.code === 10000 && result.data.data) {
          imgUrl = result.data.data;
        }
      }
      return imgUrl;
    }

    async composeGroupbuyPoster(params) {
      const pics = params.pics;

      if (!pics || pics.length < 4) {
        return null;
      }

      let ret = '';
      const picPaths = [];
      for (const i in pics) {
        const pictPath = path.join(folder, uuid.v1() + '.jpg');
        picPaths.push(pictPath);
        await this.downloadFromRemoteUrl(pics[i], pictPath);
      }

      const imgPath = await new Promise(resolve => {
        const that = this;
        try {
          const tmpPath = path.join(folder, uuid.v1() + '.jpg');
          gm(400, 530, '#FFF5F5F5')
            .setFormat('JPEG')
            .quality(100)
            .draw(`image Over 10, 10, 380, 380 "${picPaths[0]}"`)
            .draw(`image Over 10, 400, 120, 120 "${picPaths[1]}"`)
            .draw(`image Over 140, 400, 120, 120 "${picPaths[2]}"`)
            .draw(`image Over 270, 400, 120, 120 "${picPaths[3]}"`)
            .write(tmpPath, function(err) {
              try {
                for (const i in picPaths) {
                  fs.unlinkSync(picPaths[i]);
                }
              } catch (e) {
                console.log(`删除文件'${picPaths}'异常：${e}`);
                this.logger.error(`删除文件'${picPaths}'异常：${e}`);
              } finally {
                if (!err) {
                  console.log('done,', tmpPath);
                  ret = tmpPath;
                  resolve(ret);
                } else {
                  that.logger.error('生成图片出现异常', err);
                  resolve(ret);
                }
              }
            });
        } catch (e) {
          this.logger.error(`合成淘宝分享图异常，${e}，文件路径：${folder}`);
          resolve(ret);
        }
      });

      let url = null;
      if (imgPath.length > 0) {
        const imgStream = fs.createReadStream(imgPath);
        url = await this.uploadImage(imgStream);
        fs.unlinkSync(imgPath);
      }

      return url;
    }

    // async composeTbPoster(goodsInfo, bgImg, qrCode = '') {
    //   if (!goodsInfo || !goodsInfo.title || !goodsInfo.pict_url || !goodsInfo.reserve_price || !goodsInfo.zk_final_price || !bgImg) {
    //     return null;
    //   }

    //   const pictPath = path.join(folder, uuid.v1() + '.jpg');
    //   await this.downloadFromRemoteUrl(goodsInfo.pict_url, pictPath);
    //   return new Promise(resolve => {
    //     const that = this;
    //     let ret = '';
    //     try {
    //       const tmpPath = path.join(folder, uuid.v1() + '.jpg');
    //       const imgObj = gm(bgImg)
    //         .draw('image Over 0, 0, 704, 704 "' + pictPath + '"')
    //         .fontSize(34)
    //         .fill('#434343')
    //         .font('./static/PingFang Medium.ttf');
    //       const realLen = utils.calRealLength(goodsInfo.title);
    //       if (realLen <= 24) {
    //         imgObj.drawText(37, 790, goodsInfo.title);
    //       } else {
    //         const first = utils.subStringByRealLength(goodsInfo.title, 0, 24);
    //         let second = utils.subStringByRealLength(goodsInfo.title, 24, 22);
    //         // 如果截取之后的两行文案跟原来文案一样，则直接显示，否则需要在第二行文案后面加上'...'
    //         if (goodsInfo.title != first + second) {
    //           second += '...';
    //         }
    //         imgObj.drawText(37, 764, first)
    //           .drawText(37, 811, second);
    //       }
    //       if (qrCode) {
    //         imgObj.draw('image Over 471, 741, 200, 200 "' + qrCode + '"');
    //       }

    //       imgObj.fontSize(24)
    //         .fill('#858585')
    //         .drawText(37, 889, '原价 ¥' + goodsInfo.reserve_price)
    //         .drawLine(90, 881, 90 + utils.calRealLength('¥' + goodsInfo.reserve_price) * 18, 881)
    //         .fontSize(24)
    //         .fill('#FF7621')
    //         .drawText(37, 935, (goodsInfo.coupon_price > 0 ? '券后价' : '折后价'))
    //         .fontSize(30)
    //         .drawText(120, 935, '¥' + (goodsInfo.coupon_price > 0 ? goodsInfo.coupon_price : goodsInfo.zk_final_price))
    //         .write(tmpPath, function(err) {
    //           try {
    //             fs.unlinkSync(pictPath);
    //           } catch (e) {
    //             this.logger.error(`删除文件'${pictPath}'异常：${e}`);
    //           } finally {
    //             if (!err) {
    //               console.log('done,', tmpPath);
    //               ret = tmpPath;
    //               resolve(ret);
    //             } else {
    //               that.logger.error('生成图片出现异常', err);
    //               resolve(ret);
    //             }
    //           }
    //         });
    //     } catch (e) {
    //       this.logger.error(`合成淘宝分享图异常，${e}，文件路径：${folder}`);
    //       resolve(ret);
    //     }
    //   });
    // }

    // async composeTbQr(bgImg, qrCode) {
    //   if (!bgImg || !qrCode) {
    //     return null;
    //   }
    //   return new Promise(resolve => {
    //     const that = this;
    //     let ret = '';
    //     try {
    //       const tmpPath = path.join(folder, uuid.v1() + '.jpg');
    //       gm(bgImg)
    //         .draw('image Over 471, 741, 200, 200 "' + qrCode + '"')
    //         .write(tmpPath, function(err) {
    // if (!err) {
    //   console.log('done,', tmpPath);
    //   ret = tmpPath;
    //   resolve(ret);
    // } else {
    //   that.logger.error('生成图片出现异常', err);
    //   resolve(ret);
    // }
    //         });
    //     } catch (e) {
    //       console.log('fuck', e);
    //       resolve(ret);
    //     }
    //   });
    // }

    async genQRCode(text) {
      let imgUrl = '';
      const ctx = this.ctx;
      try {
        // 大小默认5，二维码周围间距默认1
        const img = qr.image(text || '', { type: 'jpg', size: 200 });
        imgUrl = await this.uploadImage(img);
      } catch (e) {
        this.logger.error('生成二维码异常', e);
      }

      return imgUrl;
    }

    async genQRCodeTmpPath(text) {
      return new Promise(resolve => {
        let qrPath = '';
        const ctx = this.ctx;
        try {
        // 大小默认5，二维码周围间距默认1
          const img = qr.image(text || '', { type: 'jpg', size: 200 });
          const tmp = path.join(folder, uuid.v1() + '.jpg');
          const writer = fs.createWriteStream(tmp);
          img.pipe(writer);
          writer.on('finish', () => {
            qrPath = tmp;
            resolve(qrPath);
          });

        } catch (e) {
          this.logger.error('生成二维码异常', e);
          resolve(qrPath);
        }
      });
    }

    async downloadFromRemoteUrl(url, path) {
      const ctx = this.ctx;
      await ctx.curl(url, {
        writeStream: fs.createWriteStream(path),
      });

      return;
    }
  };
};