const Service = require('egg').Service;
const Constant = require('../utils/constant');
const ErrCode = require('../utils/errorCode');
const checker = require('../utils/paramChecker');
const Excel = require('exceljs');
const path = require('path');
const fs = require('fs');
const os = require('os');

module.exports = () => {
  return class GroupBuy extends Service {
    // 品牌活动页相关接口
    async activityCats(params) {
      const appType = params.appType;
      const sortField = appType === 2 ? 'sort' : 'qxb_sort';
      const result = await this.app.mysql.select('group_buy_tag', {
        where: { admin_status: [0, 1] },
        columns: ['id', 'tag_name', sortField],
        orders: [[sortField, 'desc']],
      });
      return result;
    }

    async activityList(params) {
      const ctx = this.ctx;
      const pageNum = params.page || 1;
      const pageSize = params.pageSize || 40;
      const catId = params.catId;
      const status = params.status;
      const type = params.type;
      const appType = params.appType;
      const comingUp = params.comingUp;
      const now = new Date().getTime() / 1000;
      const otherID = '(SELECT id FROM group_buy_tag WHERE admin_status IN(0,1))';
      let sortFieldStr = 'sort';
      let catSortFieldStr = 'cat_sort';
      let sortField = type === 1 ? 'sort' : 'cat_sort';
      let statusField = 'status';
      // appType 为2时是校品团app
      if (appType !== 2) {
        sortField = type === 1 ? 'qxb_sort' : 'qxb_cat_sort';
        statusField = 'qxb_status';
        sortFieldStr = 'qxb_sort';
        catSortFieldStr = 'qxb_cat_sort';
      }
      // let condition = catId === 1 ? '' : `AND a.cat_id = ${catId} `;
      let condition = catId === 1 ? '' : catId === 10000 ? `AND a.cat_id  NOT IN ${otherID} ` : `AND a.cat_id = ${catId} `;
      if (comingUp) {
        condition += `AND a.start_time > ${now} `;
      }
      // } else {
      //   condition += `AND a.start_time <= ${now}`;
      // }

      let list = [];
      let totalCount = 0;
      if (status === '' || status === 0 || status === 1) {
        if (status === 0) {
          condition += `AND a.${statusField} IN (0, -2) `;
        } else if (status === 1) {
          condition += `AND a.${statusField} = 1 `;
        } else {
          condition += `AND a.${statusField} != -1 `;
        }

        const brandTypePriorityCountSQL = `SELECT COUNT(1) as num FROM group_buy_goods_activity a , group_buy_aikucun_brand c
        LEFT JOIN brand t4 ON t4.id = c.brand_id
        LEFT JOIN brand_type t5 ON t4.type_code = t5.type_code AND t5.status = 1 
        WHERE a.end_time > ${now} AND a.brand_id = c.id ${condition};`;

        const brandTypePriorityCount = await this.app.mysql.query(brandTypePriorityCountSQL);
        // 总页码
        totalCount = brandTypePriorityCount[0].num;
        // 排序优先级 sort -> actStartTime, 增加返回字段type：1展示颜色 background: #f5f5f5;  2展示颜色 background: #e5e5e5;
        // 查询优先级最高的活动信息
        const limit = `LIMIT ${(pageNum - 1) * pageSize}, ${pageSize}`;
        const brandTypePrioritySQL = `SELECT tmp.*, r.price_ratio, r.commission_ratio, l.label FROM (
        SELECT a.activity_id,a.description,a.id, a.name, a.wx_mini_program_show AS miniProgramVisible, a.${sortFieldStr} AS sort, a.${catSortFieldStr} AS cat_sort, a.${statusField} AS status, FROM_UNIXTIME(a.start_time, '%Y-%m-%d %H:%i:%S') AS start_date, FROM_UNIXTIME(a.end_time, '%Y-%m-%d %H:%i:%S') AS end_date, a.banner, a.min_discount, a.goods_num, a.selected_nice_img, b.tag_name,b.id AS tag_id, c.brand_logo_url,t4.id AS ownBrandId,t4.brand_name AS ownBrandName, c.brand_name, FROM_UNIXTIME(a.start_time,'%Y%m%d') as actStartTime, ifnull(t5.type_name, '无类型') as type_name, IFNULL(t5.id,6) as typeCode, CASE IFNULL(t5.id,6) WHEN 5 THEN 1 WHEN 6 THEN 2 ELSE 0 END AS type             
          FROM group_buy_goods_activity a, group_buy_tag b, group_buy_aikucun_brand c
            LEFT JOIN brand t4 ON t4.id = c.brand_id
            LEFT JOIN brand_type t5 ON t4.type_code = t5.type_code AND t5.status = 1
            WHERE a.end_time > ${now} ${condition} AND a.cat_id = b.id AND a.brand_id = c.id 
            ORDER BY a.${sortField} DESC, actStartTime DESC, typeCode ASC ${limit}) tmp 
        LEFT JOIN group_buy_goods_add_price_ratio r ON r.activity_id = tmp.id 
        LEFT JOIN group_buy_label l on l.label_type = 0 and l.target_id = tmp.id;`;
        list = await this.app.mysql.query(brandTypePrioritySQL);
      }
      return { list, totalCount };
    }
    /**
     * 多SQL查询列表的分页算法
     * diff 是当前查询条数和之前的SQL的总数的差值，这个值是肯定大于0的
     * 如果 diff<pageSize 那么就是新列表的第一页, limit 0,diff
     * 如果 diff>pageSize 那么就是新列表的其他页，limit diff, x
     *    x = diff  - (其他列表的总长度和pageSize之和的取整 * pageSize)
     * @param {页码} pageNum
     * @param {每页多少个} pageSize
     * @param {其他列表的总长度} otherTotal
     */
    calculateLimit(pageNum, pageSize, otherTotal) {
      const diff = pageNum * pageSize - otherTotal;
      const pageNumRes = diff < pageSize ? 0 : diff - pageSize;
      const pageSizeRes = diff < pageSize ? diff : pageSize;
      return { pageNum: pageNumRes, pageSize: pageSizeRes };
    }

    async updateMiniProgramVisibility(params) {
      const id = params.id;
      const visible = params.visible;

      const actIdList = [];
      actIdList.push(id);
      if (typeof id === 'number') {
        const result = await this.app.mysql.update('group_buy_goods_activity', { id, wx_mini_program_show: visible });
        const act = await this.app.mysql.query(`select * from group_buy_goods_activity where id = ${id}`);
        if (act[0].qxb_status === 1) {
          this.ctx.curl(`${this.config.api.java_host}/groupBuy/solrAddByActId`, {
            method: 'POST',
            contentType: 'json',
            data: {
              clientId: 'qxb_admin',
              actIds: actIdList,
              version: '1.0'
            },
            dataType: 'json'
          });
        }
        return { success: result.affectedRows === 1 };
      } else {
        const result = await this.app.mysql.query(`UPDATE group_buy_goods_activity SET wx_mini_program_show = ${visible}`);
        this.ctx.curl(`${this.config.api.java_host}/groupBuy/productSolrAdd`);
        return { success: true };
      }
    }

    async getMiniProgramGroupVisibility() {
      const result = await this.app.mysql.query('SELECT COUNT(*) FROM group_buy_goods_activity WHERE wx_mini_program_show = 1');
      const totalCount = result && result[0] ? Object.values(result[0])[0] : 0;
      return { code: 10000, msg: '成功', data: totalCount };
    }

    async stick(params) {
      const id = params.id;
      const type = params.type;
      const appType = params.appType;
      let sortField = type === 1 ? 'sort' : 'cat_sort';
      // appType 为2时是校品团app
      if (appType !== 2) {
        sortField = type === 1 ? 'qxb_sort' : 'qxb_cat_sort';
      }
      const results = await this.app.mysql.select('group_buy_goods_activity', {
        orders: [[sortField, 'desc']],
        limit: 1
      });
      const sort = results.length === 1 ? (results[0][sortField] + 1 >= 10000 ? results[0][sortField] + 1 : 10000) : 10000;
      await this.app.mysql.update('group_buy_goods_activity', {
        id,
        [sortField]: sort
      });
      return { success: true };
    }

    async updateSaleStateOnGoods(params) {
      const id = params.id;
      const appType = params.appType;
      const status = params.status > 0 ? 1 : 0;
      const statusField = appType === 2 ? 'status' : 'qxb_status';
      await this.app.mysql.update('group_buy_goods', {
        id,
        [statusField]: status
      });

      const goodsIds = [];
      goodsIds.push(params.raelId);
      if (status === 0) {
        const result = this.ctx.curl(`${this.config.api.java_host}/groupBuy/productSolrDel`, {
          method: 'POST',
          contentType: 'json',
          data: {
            clientId: 'qxb_admin',
            productIds: goodsIds,
            version: '1.0'
          },
          dataType: 'json'
        });
      } else if (status === 1) {
        const result = this.ctx.curl(`${this.config.api.java_host}/groupBuy/productSolrAddList`, {
          method: 'POST',
          contentType: 'json',
          data: {
            clientId: 'qxb_admin',
            productIds: goodsIds,
            version: '1.0'
          },
          dataType: 'json'
        });
      }
      return { success: true };
    }

    async updateSaleState(params) {
      const id = params.id;
      const appType = params.appType;
      const status = params.status > 0 ? 1 : 0;
      const statusField = appType === 2 ? 'status' : 'qxb_status';
      await this.app.mysql.update('group_buy_goods_activity', {
        id,
        [statusField]: status
      });

      const actIdList = [];
      actIdList.push(id);
      if (status === 0) {
        const result = this.ctx.curl(`${this.config.api.java_host}/groupBuy/solrDelByActId`, {
          method: 'POST',
          contentType: 'json',
          data: {
            clientId: 'qxb_admin',
            actIds: actIdList,
            version: '1.0'
          },
          dataType: 'json'
        });
      } else if (status === 1) {
        const result = this.ctx.curl(`${this.config.api.java_host}/groupBuy/solrAddByActId`, {
          method: 'POST',
          contentType: 'json',
          data: {
            clientId: 'qxb_admin',
            actIds: actIdList,
            version: '1.0'
          },
          dataType: 'json'
        });
      }
      return { success: true };
    }

    async updateActivitySort(params) {
      const id = params.id;
      const sort = params.sort;
      const type = params.type;
      const appType = params.appType;
      const name = params.name;
      const description = params.description;
      const selected_nice_img = params.hdImage;
      const cat_id = params.cat_id;
      let sortField = type === 1 ? 'sort' : 'cat_sort';
      // appType 为2时是校品团app
      if (appType !== 2) {
        sortField = type === 1 ? 'qxb_sort' : 'qxb_cat_sort';
      }
      await this.app.mysql.update('group_buy_goods_activity', {
        id,
        name,
        selected_nice_img,


        [sortField]: sort,
        description,
        cat_id
      });
      return { success: true };
    }

    // 更新活动或者商品标签
    async updateTag(params) {
      const targetId = params.id;
      const type = params.type;
      const label = params.label;
      const list = await this.app.mysql.select('group_buy_label', {
        where: {
          label_type: type,
          target_id: targetId
        }
      });

      if (list.length === 0) {
        if (label > 0) {
          await this.app.mysql.insert('group_buy_label', {
            label_type: type,
            target_id: targetId,
            label
          });
        }
      } else {
        await this.app.mysql.update('group_buy_label', {
          label
        }, {
          where: {
            label_type: type,
            target_id: targetId
          }
        });
      }

      return { success: true };
    }

    // 品牌活动商品相关接口
    async goodsList(params) {
      const id = parseInt(params.actId);
      const appType = params.appType;
      const sortField = appType === 1 ? 'qxb_sort' : 'sort';

      const sql = `select tmp.*, l.label from (
      
        select c.id AS real_goods_id,a.*,b.id as supBrandId, b.brand_name as supBrandName,IFNULL( bd2.id, bd.id ) AS ownBrandId, ifNull( bd2.brand_name, bd.brand_name ) AS ownBrandName, b.brand_logo_url 
          from group_buy_goods a  LEFT JOIN brand bd2 ON a.own_brand_id = bd2.id, group_buy_aikucun_brand b left join brand bd on bd.id = b.brand_id, product_overall c 
          where a.own_activity_id = ${id} AND a.aikucun_brand_id = b.id AND a.id = c.product_id AND c.order_type = case a.type when 0 then 2 when 1 then 3 when 2 then 4 when 3 then 6 when 4 then 13 else 999 end
          ) tmp left join group_buy_label l on tmp.id = l.target_id and l.label_type = 1 order by tmp.${sortField} desc;`;

      const list = await this.app.mysql.query(sql);
      const map = {};
      const querySkuList = [];
      let activityId = '';
      // 构造查询库存的请求参数
      for (const i in list) {
        const goods = list[i];
        // 只有爱库存的商品需要查询库存
        if (goods.type !== 0) {
          continue;
        }
        if (activityId === '') {
          activityId = goods.aikucun_activity_id;
        }

        const skuList = JSON.parse(goods.sku_list);
        for (const j in skuList) {
          const sku = skuList[j];
          map[sku.skuId] = goods;
          goods.stock = 0;
          querySkuList.push(sku.skuId);

        }
      }
      if (querySkuList.length > 0) {
        const result = await this.service.aikucun.queryStock({ liveId: activityId, skuIds: querySkuList });
        const res = result.data;
        if (res.resultCode === 999999 && res.data && res.data.liveId === activityId && res.data.inventoryList) {
          const inventoryList = res.data.inventoryList;
          for (const i in inventoryList) {
            const inventory = inventoryList[i];
            map[inventory.skuId].stock += parseInt(inventory.currentStock);
          }
        }
      }

      return list;
    }

    // 获取所有活动时间内已上架的活动的上架商品
    async allOnSaleGoods(params) {
      const now = Math.floor(Date.now() / 1000);
      const pageNum = params.page || 1;
      const pageSize = params.pageSize || 50;
      const filterEmpty = params.filterSoldOut;
      const categories = params.categories;
      const profitAndChoice = params.easyForMarketing;
      const onSaleOnly = params.onSale_only;
      const hykOnly = params.hyk_only;
      const akcOnly = params.akc_only;
      const limit = `LIMIT ${(pageNum - 1) * pageSize}, ${pageSize}`;

      let nameCondition = '';
      if (params.productName) {
        if (!isNaN(params.productName)) {
          nameCondition = ` AND a.id = ${params.productName}`;
        } else {
          nameCondition = ` AND a.name LIKE '%${params.productName}%'`;
        }
      }

      let discountCondition = '';
      if (params.discount && params.discountFilter) {
        if (params.discountFilter === '~') {
          discountCondition = ` AND a.discount_rate >= ${params.discount[0]} AND a.discount_rate <= ${params.discount[1]}`;
        } else {
          discountCondition = ` AND a.discount_rate ${params.discountFilter} ${params.discount[0]}`;
        }
      }

      let addPriceCondition = '';
      if (params.addPrice && params.addPriceFilter) {
        if (params.addPriceFilter === '~') {
          addPriceCondition = ` AND a.add_price >= ${params.addPrice[0]} AND a.add_price <= ${params.addPrice[1]}`;
        } else {
          addPriceCondition = ` AND a.add_price ${params.addPriceFilter} ${params.addPrice[0]}`;
        }
      }

      let priceCondition = '';
      if (params.price && params.priceFilter) {
        if (params.priceFilter === '~') {
          priceCondition = ` AND a.settlement_price >= ${params.price[0]} AND a.settlement_price <= ${params.price[1]}`;
        } else {
          priceCondition = ` AND a.settlement_price ${params.priceFilter} ${params.price[0]}`;
        }
      }

      let clickNumCondition = '';
      if (params.clickNum && params.clickFilter) {
        if (params.clickFilter === '~') {
          clickNumCondition = ` AND a.click_num >= ${params.clickNum[0]} AND a.click_num <= ${params.clickNum[1]}`;
        } else {
          clickNumCondition = ` AND a.click_num ${params.clickFilter} ${params.clickNum[0]}`;
        }
      }

      // 关于活动结束时间的筛选
      let durationCondition = '';
      if (params.durationNum && params.durationFilter) {
        if (params.durationFilter === '~') {
          durationCondition = ` AND (b.end_time - b.start_time)/3600 >= ${params.durationNum[0]} AND (b.end_time - b.start_time)/3600 <= ${params.durationNum[1]}`;
        } else {
          durationCondition = ` AND (b.end_time - b.start_time)/3600 ${params.durationFilter} ${params.durationNum[0]}`;
        }
      }

      // 关于佣金的筛选
      let commissionCondition = '';
      if (params.commissionNum && params.commissionFilter) {
        if (params.commissionFilter === '~') {
          commissionCondition = ` AND a.akc_profit >= ${params.commissionNum[0]} AND a.akc_profit <= ${params.commissionNum[1]}`;
        } else {
          commissionCondition = ` AND a.akc_profit ${params.commissionFilter} ${params.commissionNum[0]}`;
        }
      }

      let categoryCondition = '';
      if (Array.isArray(categories) && categories.length !== 0) {
        categoryCondition = ` AND b.cat_id IN (${categories.join(',')})`;
      }

      let statusCondition = ' AND b.qxb_status != -1';
      if (onSaleOnly) {
        statusCondition = ' AND a.qxb_status = 1 AND b.qxb_status = 1';
      }

      let typeCondition = '';
      if (hykOnly) {
        typeCondition = ' AND a.type = 4';
      } else if (akcOnly) {
        typeCondition = ' AND a.type = 0';
      }

      let predicateCondition = '';
      if (!params.allow_predicate) {
        predicateCondition = ` AND b.start_time < ${now}`;
      }

      const discountSort = params.discountSort !== 0 ? ` a.discount_rate ${params.discountSort === 1 ? 'ASC' : 'DESC'}` : null;
      const addPriceSort = params.addPriceSort !== 0 ? `  a.add_price ${params.addPriceSort === 1 ? 'ASC' : 'DESC'}` : null;
      const priceSort = params.priceSort !== 0 ? ` a.settlement_price ${params.priceSort === 1 ? 'ASC' : 'DESC'}` : null;
      const clickNumSort = params.clickSort !== 0 ? ` a.click_num ${params.clickSort === 1 ? 'ASC' : 'DESC'}` : null;
      const durationSort = params.durationSort !== 0 ? ` duration ${params.durationSort === 1 ? 'ASC' : 'DESC'}` : null;
      const commissionSort = params.commissionSort !== 0 ? ` a.akc_profit ${params.commissionSort === 1 ? 'ASC' : 'DESC'}` : null;
      const endTimeSort = params.endTimeSort !== 0 ? ` b.end_time ${params.endTimeSort === 1 ? 'ASC' : 'DESC'}` : null;

      let sortCondition = null;
      if (discountSort || addPriceSort || priceSort || clickNumSort || endTimeSort || durationSort || commissionSort) {
        sortCondition = discountSort ? ((sortCondition ? `${sortCondition} , ` : 'ORDER BY ') + discountSort) : sortCondition;
        sortCondition = addPriceSort ? ((sortCondition ? `${sortCondition} , ` : 'ORDER BY ') + addPriceSort) : sortCondition;
        sortCondition = priceSort ? ((sortCondition ? `${sortCondition} , ` : 'ORDER BY ') + priceSort) : sortCondition;
        sortCondition = clickNumSort ? ((sortCondition ? `${sortCondition} , ` : 'ORDER BY ') + clickNumSort) : sortCondition;
        sortCondition = endTimeSort ? ((sortCondition ? `${sortCondition} , ` : 'ORDER BY ') + endTimeSort) : sortCondition;
        sortCondition = durationSort ? ((sortCondition ? `${sortCondition} , ` : 'ORDER BY ') + durationSort) : sortCondition;
        sortCondition = commissionSort ? ((sortCondition ? `${sortCondition} , ` : 'ORDER BY ') + commissionSort) : sortCondition;
      }

      if (profitAndChoice) {
        sortCondition = (sortCondition ? `${sortCondition}, ` : 'ORDER BY ') + 'a.akc_profit / GREATEST(1,  a.settlement_price) DESC';
        sortCondition = (sortCondition ? `${sortCondition}, ` : 'ORDER BY ') + 'LENGTH(a.sku_list) DESC';
      }

      sortCondition = (sortCondition ? `${sortCondition} , ` : 'ORDER BY ') + 'a.qxb_sort DESC';

      let products = [];
      let totalCount = 0;

      await this.app.mysql.beginTransactionScope(async conn => {
        const countSQL = `SELECT COUNT(*) 
          FROM 
          group_buy_goods a, group_buy_goods_activity b
          WHERE
          a.own_activity_id = b.id AND 
          b.end_time > ${now}
          ${statusCondition}
          ${typeCondition}
          ${predicateCondition}
          ${nameCondition}
          ${discountCondition}
          ${addPriceCondition}
          ${priceCondition}
          ${clickNumCondition}
          ${durationCondition}
          ${commissionCondition}
          ${categoryCondition}`;

        const totalCountArr = await conn.query(countSQL);
        totalCount = totalCountArr && totalCountArr[0] ? Object.values(totalCountArr[0])[0] : 0;

        // 如果数量为0就不需要再查具体数据了
        if (totalCount > 0) {
          const querySQL = `SELECT a.*, b.start_time, b.end_time, b.cat_id, b.name as act_name, gbt.tag_name, (b.end_time - b.start_time) as duration
          FROM 
          group_buy_goods a, group_buy_goods_activity b,group_buy_tag gbt
          WHERE
          a.own_activity_id = b.id AND 
          b.cat_id = gbt.id AND
          b.end_time > ${now}
          ${statusCondition}
          ${typeCondition}
          ${predicateCondition}
          ${nameCondition} 
          ${discountCondition}
          ${addPriceCondition}
          ${priceCondition}
          ${clickNumCondition}
          ${durationCondition}
          ${commissionCondition}
          ${categoryCondition}
          ${sortCondition ? sortCondition : ''}
          ${limit}`;

          products = await conn.query(querySQL);
        }

        return { success: true };
      }, this.ctx);

      const targetProducts = [];

      for (const index in products) {
        const product = products[index];
        const skuList = JSON.parse(product.sku_list);

        product.sku_list = skuList;

        if (product.picture) {
          product.picture = JSON.parse(product.picture);
        }

        if (product.type !== 0) {
          if (product.type !== 4) {
            // type 4的商品库存和单个sku的库存是一样的
            let totalStock = 0;
            for (const skuIndex in skuList) {
              const sku = skuList[skuIndex];
              if (typeof sku.skuInventory === 'string') {
                totalStock += parseInt(sku.skuInventory);
              } else if (typeof sku.skuInventory === 'number') {
                totalStock += sku.skuInventory;
              }

              product.stock = totalStock;
            }
          }

          if (filterEmpty) {
            if (product.stock !== 0 || product.start_time > (Date.now() / 1000)) {
              targetProducts.push(product);
            }
          } else {
            targetProducts.push(product);
          }

          continue;
        }

        const querySkuList = [];
        const activityID = product.aikucun_activity_id;

        for (const skuIndex in skuList) {
          const sku = skuList[skuIndex];
          querySkuList.push(sku.skuId);
        }

        if (querySkuList.length > 0) {
          const result = await this.service.aikucun.queryStock({ liveId: activityID, skuIds: querySkuList });
          const resultCode = result.data.resultCode;
          const resData = result.data.data;

          if (resultCode === 999999 &&
            resData.liveId === activityID &&
            resData.inventoryList.length !== 0) {
            const inventoryList = resData.inventoryList;

            // 将对应的库存放入到返回商品列表的SKU列表里
            for (const inventoryIndex in inventoryList) {
              const inventory = inventoryList[inventoryIndex];
              const skuID = inventory.skuId;
              const stock = parseInt(inventory.currentStock);

              const sku = skuList.find(item => { return item.skuId === skuID; });
              sku.skuInventory = stock;

              let totalStock = product.stock || 0;
              totalStock += stock;
              product.stock = totalStock;
            }

            if (filterEmpty) {
              if (product.stock !== 0 || product.start_time > (Date.now() / 1000)) {
                targetProducts.push(product);
              }
            } else {
              targetProducts.push(product);
            }
          }
        }
      }

      return { code: 10000, data: targetProducts, total: totalCount };
    }

    // 更新商品加价信息
    async updateGoodsInfo(params) {
      const id = parseInt(params.id);
      const sort = params.sort;
      const appType = params.appType;
      const akcPrice = params.akcPrice;
      const akcSettlementPrice = params.akcSettlementPrice;
      const sortField = appType === 1 ? 'qxb_sort' : 'sort';
      const label = params.label || 0;
      // 0: 默认100%， 1:恢复最低佣金, -1：不修改佣金
      const chooseCommission = params.chooseCommission;
      // 计算加价金额
      const akcTagPrice = params.akcTagPrice;
      let add_price = parseFloat(params.addPrice).toFixed(1);
      let settlement_price = parseFloat(Number(akcPrice) + Number(add_price)).toFixed(1);
      let discount_rate = parseInt(settlement_price / akcTagPrice * 100);
      let only_settlement_price = this.getOnlySettlementPrice(akcTagPrice, settlement_price);
      // 加价金额大于100%， 团购价 = 单买价 = 原价
      if (discount_rate > 100) {
        add_price = akcTagPrice - akcPrice;
        only_settlement_price = akcTagPrice;
        settlement_price = akcTagPrice;
        discount_rate = 100;
      }

      // 计算佣金公式修改
      /** 时间 2019年11月1日
       * 新增逻辑，运营可以将商品的佣金置为最初始的佣金状态 chooseCommission=0，依旧是原本的逻辑
       */
      const akc_profit = Number(chooseCommission) === 0 ?
        parseFloat((settlement_price * 0.97 - akcSettlementPrice) * params.commissionRatio / 100).toFixed(1)
        : await this.culInitCommissionPrice(akcTagPrice, akcPrice, akcSettlementPrice);

      /** 2019年11月2日
       * 商品修改逻辑
       * 1、chooseCommission=1 不会重新计算佣金
       * 2、chooseCommission!=1, 加价金额大于建议售价的3%，佣金不为负数，重新计算佣金
       * 3、如果不满足条件1、2， 那么不会修改任何金额信息
       */
      let updateData = {};
      if (Number(chooseCommission) === -1) {
        updateData = {
          id,
          add_price,
          settlement_price,
          only_settlement_price,
          discount_rate,
          name: params.name,
          picture: params.picture,
          [sortField]: sort
        };
      } else if (params.commissionRatio >= 0 && params.commissionRatio <= 100 && akc_profit > 0 && (add_price / akcPrice) > 0.03) {
        updateData = {
          id,
          add_price,
          settlement_price,
          only_settlement_price,
          akc_profit,
          discount_rate,
          name: params.name,
          picture: params.picture,
          [sortField]: sort
        };
      } else {
        updateData = {
          id,
          name: params.name,
          picture: params.picture,
          [sortField]: sort
        };
      }
      await this.app.mysql.update('group_buy_goods', updateData);
      await this.updateTag({ id, type: 1, label });
    }

    // 上传爆款商品接口
    async uploadHotGoods(params) {
      const goods_id = params.goods_id;
      const activity_id = params.activity_id;
      const now = new Date().getTime() / 1000;
      const sql1 = `select a.id  from product_overall a , group_buy_goods b where a.product_id = b.id and  a.order_type = 2 and b.id = ${goods_id}`;
      const result_id = await this.app.mysql.query(sql1);
      const hot_id = params.hot_id;
      const itemId = result_id[0].id;
      const sql = `insert into group_buy_hot_list (user_virtual_id,release_time, hot_id, goods_id, activity_id, status) values (1, ${now},${hot_id}, ${itemId}, '${activity_id}', 1)
          on duplicate key update release_time = ${now}, status = 1`;
      await this.app.mysql.query(sql);
    }

    // 取消爆款商品接口
    async cancelHotGoods(params) {
      const goods_id = params.goods_id;
      const sql1 = `select a.id  from product_overall a , group_buy_goods b where a.product_id = b.id and  a.order_type = 2 and b.id = ${goods_id}`;
      const result_id = await this.app.mysql.query(sql1);
      const itemId = result_id[0].id;
      const sql = `update group_buy_hot_list set status = 0 where goods_id = ${itemId}`;
      await this.app.mysql.query(sql);
    }

    // 获取售后状态订单信息
    async afterSaleOrderList(params) {
      const ctx = this.ctx;
      const pageNum = params.page || 1;
      const pageSize = params.pageSize || 40;
      const statusArr = params.statusArr;
      const reasonArr = params.reasonArr;
      const orderCode = params.filterOrderCode;
      const condition = statusArr && statusArr.length > 0 ? `AND a.status IN (${statusArr.join()})` : '';
      const reasonCondition = reasonArr && reasonArr.length > 0 ? `AND a.reason IN ('${reasonArr.join('\',\'')}')` : '';
      const codeCondition = orderCode ? `AND b.order_code = ${orderCode}` : '';
      const limit = `LIMIT ${(pageNum - 1) * pageSize}, ${pageSize}`;
      let list = [];
      let totalCount = 0;
      if (condition || reasonCondition || codeCondition) {
        await this.app.mysql.beginTransactionScope(async conn => {
          const sql = `SELECT a.*, FROM_UNIXTIME(a.create_time, '%Y-%m-%d %H:%i:%S') AS create_date, FROM_UNIXTIME(b.create_time, '%Y-%m-%d %H:%i:%S') AS order_create_date, b.order_code, b.total_amount, b.title, b.people_name, b.status AS order_status, b.tp_order_code, b.after_sale_status AS order_after_sale_status, b.akc_order_detatil_id, b.type AS order_type, c.phone AS user_phone, c.name AS nickname, d.product_info 
                      FROM order_after_sale_akc a, \`order\` b, user c, order_info d
                      WHERE a.order_id = b.id 
                        AND b.id = d.order_id
                        AND b.user_id = c.id
                        ${condition} 
                        ${reasonCondition}
                        ${codeCondition}
                      ORDER BY a.create_time DESC 
                      ${limit}`;

          const cntSql = `SELECT COUNT(*)
                            FROM order_after_sale_akc a, \`order\` b 
                            WHERE a.order_id = b.id 
                              ${condition}`;
          const totalCountArr = await conn.query(cntSql);
          totalCount = totalCountArr && totalCountArr[0] ? Object.values(totalCountArr[0])[0] : 0;
          // 如果数量为0就不需要再查具体数据了
          if (totalCount > 0) {
            list = await conn.query(sql);
          }

          return { success: true };
        }, ctx);
      }

      return { list, totalCount };
    }

    // 创建一个品牌活动
    async createHotGoodsList(params) {
      // 文本介绍
      const text = params.text.replace('\'', '\\\'');
      const share_time = new Date(params.share_time).getTime() / 1000;
      const on_sale_time = new Date(params.on_sale_time).getTime() / 1000;
      const off_sale_time = new Date(params.on_sale_time).getTime() / 1000 + (60 * 60 * 24 * 30);
      const sort = params.sort;
      const appType = params.appType;
      const sql = `insert into group_buy_hot (share_time,on_sale_time,off_sale_time, sort, text, status, is_show, type)
        values (${share_time},${on_sale_time},${off_sale_time}, ${sort}, '${text}', 1, 1, ${appType}) `;
      const result = await this.app.mysql.query(sql);
      return result.insertId;
    }

    // 添加商品进爆款列表
    async addGoodsToHotList(params) {
      if (!params.hot_id) {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '缺少参数' };
      }
      if (!Array.isArray(params.itemList) || params.itemList.length === 0) {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '缺少商品数据' };
      }
      const hot_id = params.hot_id;
      const itemList = params.itemList;
      const type = params.type;
      const now = parseInt(new Date().getTime() / 1000);
      for (const index in itemList) {
        const item = itemList[index];
        const goods_id = item.item_id;
        const activity_id = item.activity_id;
        const sql1 = `select * from group_buy_hot_list where type = 1 and hot_id = ${hot_id} order by sort desc limit 1`;
        const result = await this.app.mysql.query(sql1);
        let sort = 0;
        if (result.length === 0) {
          sort = 1;
        } else {
          sort = (result[0].sort) + 1;
        }

        const sql2 = `select a.id  from product_overall a , group_buy_goods b where a.product_id = b.id and  a.order_type in (2,13) and b.id = ${goods_id}`;
        const result_id = await this.app.mysql.query(sql2);
        const itemId = result_id[0].id;
        const sql = `insert into group_buy_hot_list (hot_id,user_virtual_id, release_time, goods_id, activity_id, status,sort,type) values (${hot_id},1, ${now}, ${itemId}, '${activity_id}', 1, ${sort},${type})
          on duplicate key update release_time = ${now}, status = 1`;
        await this.app.mysql.query(sql);
      }
    }

    // 添加活动进爆款列表
    async andHotAct(params) {
      if (!Array.isArray(params.itemList) || params.itemList.length === 0) {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '缺少商品数据' };
      }
      const hot_id = 0;
      const type = params.type;
      const itemList = params.itemList;
      const show_time = parseInt(new Date().getTime() / 1000 + 7200);
      const now = parseInt(new Date().getTime() / 1000);
      for (const index in itemList) {
        const item = itemList[index];
        const goods_id = 0;
        const activity_id = item.activity_id;
        const sql1 = `select * from group_buy_hot_list where type = ${type} order by sort desc limit 1`;
        const result = await this.app.mysql.query(sql1);
        let sort = 0;
        if (result.length === 0) {
          sort = 1;
        } else {
          sort = (result[0].sort) + 1;
        }/*
        const sql2 = `select a.id  from product_overall a , group_buy_goods b where a.product_id = b.id and  a.order_type = 2 and b.id = ${goods_id}`;
        const result_id = await this.app.mysql.query(sql2);
        const itemId = result_id[0].id;*/
        const sql = `insert into group_buy_hot_list (hot_id,user_virtual_id, release_time, goods_id, activity_id, status,sort,type,show_time) values (${hot_id},1, ${now}, ${goods_id}, '${activity_id}', 1, ${sort},${type},${show_time})
          on duplicate key update release_time = ${now}, status = 1`;
        await this.app.mysql.query(sql);
      }
    }

    // 删除品牌爆款
    async delGoodsHotList(params) {
      const id = params.id;
      const sql = `update group_buy_hot set status = 0 where id = ${id}`;
      await this.app.mysql.query(sql);
    }

    // 删除品牌爆款
    async deleteGoodsHotList(params) {
      const id = params.id;
      const sql = `DELETE FROM group_buy_hot where id = ${id}`;
      const sqlDel = `DELETE FROM group_buy_hot_list where hot_id = ${id}`;
      await this.app.mysql.query(sql);
      await this.app.mysql.query(sqlDel);
    }

    // 添加品牌爆款
    async addGoodsHotList(params) {
      const id = params.id;
      const sql = `update group_buy_hot set status = 1 where id = ${id}`;
      await this.app.mysql.query(sql);
    }

    // 添加品牌爆款
    async selectActivity(params) {
      let list = [];
      let totalCount = 0;
      const id = params.hot_id;
      const type = params.type;

      const pageNum = params.page || 1;
      const pageSize = params.pageSize || 20;
      const limit = `LIMIT ${(pageNum - 1) * pageSize}, ${pageSize}`;
      const sql = `select a.name name ,b.show_time showTime ,b.sort ListSort,b.status,c.brand_logo_url brandLogoUrl,b.release_time shareTime ,b.id hotId,b.brand_url brandUrl,a.banner banner,b.activity_banner hotBanner
                          from group_buy_goods_activity a,group_buy_hot_list b ,group_buy_aikucun_brand c
                          where a.id= b.activity_id and b.hot_id =  ${id} and a.brand_id = c.id and type = ${type} order by b.sort desc
                          ${limit}`;
      list = await this.app.mysql.query(sql);
      const cntSql = `SELECT COUNT(*) 
                            from group_buy_goods_activity a,group_buy_hot_list b ,group_buy_aikucun_brand c
                            where a.id= b.activity_id and b.hot_id =  ${id} and a.brand_id = c.id and type = ${type}`;
      const totalCountArr = await this.app.mysql.query(cntSql);
      totalCount = totalCountArr && totalCountArr[0] ? Object.values(totalCountArr[0])[0] : 0;
      // 如果数量为0就不需要再查具体数据了
      if (totalCount > 0) {
        list = await this.app.mysql.query(sql);
      }
      return { list, totalCount };
    }

    // 添加品牌爆款
    async selectShare(params) {
      let list = [];
      let totalCount = 0;
      const id = params.hot_id;
      const pageNum = params.page || 1;
      const pageSize = params.pageSize || 20;
      const limit = `LIMIT ${(pageNum - 1) * pageSize}, ${pageSize}`;
      const sql = `select a.*,b.name userName,b.avatar_url avatarUrl 
                          from group_buy_hot_list a,user_virtual b
                          where  a.type = 3 and a.user_virtual_id = b.id order by a.sort desc
                          ${limit}`;
      list = await this.app.mysql.query(sql);
      const cntSql = `SELECT COUNT(*) 
                            from group_buy_hot_list 
                            where  type = 3`;
      const totalCountArr = await this.app.mysql.query(cntSql);
      totalCount = totalCountArr && totalCountArr[0] ? Object.values(totalCountArr[0])[0] : 0;
      // 如果数量为0就不需要再查具体数据了
      if (totalCount > 0) {
        list = await this.app.mysql.query(sql);
      }
      return { list, totalCount };
    }

    // 修改排序品牌爆款
    async updateSortGoodsHotList(params) {
      const id = params.id;
      const sort = params.sort;
      const text = params.text.replace('\'', '\\\'');
      const share_time = params.share_time;
      const on_sale_time = params.on_sale_time;
      const off_sale_time = params.off_sale_time;
      const sql = `update group_buy_hot set sort = ${sort},
                    share_time = ${share_time},
                    text = '${text}',
                    on_sale_time = ${on_sale_time},
                    off_sale_time = ${off_sale_time} 
                    where id = ${id}`;
      await this.app.mysql.query(sql);
    }

    // 修改爆款爆款商品内容
    async updateGoodsHotList(params) {
      const id = params.id;
      const brand_url = params.brand_url;
      const goods_name = params.goods_name.replace('\'', '\\\'');
      const img_url = params.img_url;
      const show_time = params.showTime;
      const sort = params.sort;
      const banner = params.banner;
      const shareContent = params.shareContent;
      const sql = `update group_buy_hot_list set brand_url = '${brand_url}',
                    goods_name = '${goods_name}',
                    img_url = '${img_url}',
                    activity_banner = '${banner}',
                    share_content = '${shareContent}',
                    show_time = '${show_time}',
                    sort = ${sort}
                    where id = ${id}`;
      await this.app.mysql.query(sql);
    }

    // 修改爆款爆款商品内容
    async updateShareHotList(params) {
      const id = params.id;
      const text = params.text.replace('\'', '\\\'');
      const reply_text = params.reply_text.replace('\'', '\\\'');
      const img_url = params.img_url;
      const sort = params.sort;
      const sql = `update group_buy_hot_list set text = '${text}',
                    reply_text = '${reply_text}',
                    img_url = '${img_url}',
                    sort = ${sort}
                    where id = ${id}`;
      await this.app.mysql.query(sql);
    }

    // 创建分享素材内容
    async createShareHotList(params) {
      const now = parseInt(new Date().getTime() / 1000);
      const text = params.text;
      const reply_text = params.reply_text;
      const img_url = params.img_url;
      const sql1 = 'select * from group_buy_hot_list where `type` = 3 order by sort desc limit 1';
      const result = await this.app.mysql.query(sql1);
      let sort = 0;
      if (result.length === 0) {
        sort = 1;
      } else {
        sort = (result[0].sort) + 1;
      }
      const sql = `insert into group_buy_hot_list (hot_id,user_virtual_id, release_time, activity_id, status,sort,type,text,reply_text,img_url) 
                        values (0,1, ${now},  '0', 1, ${sort},3,'${text}','${reply_text}','${img_url}')
                        on duplicate key update release_time = ${now}, status = 1`;
      await this.app.mysql.query(sql);
    }

    // 删除品牌爆款列表中某个商品
    async delGoods(params) {
      const id = params.id;
      const sql = `delete from group_buy_hot_list  where id = ${id}`;
      await this.app.mysql.query(sql);
    }

    // 查询品牌爆款商品列表
    async findGoodsHotList(params) {
      const status = params.status;
      let list = [];
      let totalCount = 0;
      const pageNum = params.page || 1;
      const pageSize = params.pageSize || 20;
      const limit = `LIMIT ${(pageNum - 1) * pageSize}, ${pageSize}`;
      const appType = params.appType;
      let condition = `WHERE a.type = ${appType}`;
      if (status === '' || status === 0 || status === 1) {
        if (status === 0 || status === 1) {
          condition += `AND a.status = ${status} `;
        }
        const sql = `SELECT tmp.*, GROUP_CONCAT(d.picture Separator '"||"') AS picture FROM (SELECT a.id,FROM_UNIXTIME(a.share_time,'%Y-%m-%d %H:%i:%S') AS share_time, a.sort, a.text, a.status, a.is_show, b.goods_id,FROM_UNIXTIME(a.off_sale_time,'%Y-%m-%d %H:%i:%S') AS off_sale_time,FROM_UNIXTIME(a.on_sale_time,'%Y-%m-%d %H:%i:%S') AS on_sale_time
                           FROM group_buy_hot a LEFT JOIN group_buy_hot_list b
                           ON a.id = b.hot_id ${condition}) tmp LEFT JOIN product_overall c 
                           ON tmp.goods_id = c.id  LEFT JOIN group_buy_goods d ON d.id = c.goods_id
                           GROUP BY tmp.id
                           ORDER BY tmp.sort DESC
                           ${limit}`;
        const cntSql = `SELECT COUNT(*) 
                              FROM group_buy_hot a
                              ${condition}`;
        const totalCountArr = await this.app.mysql.query(cntSql);
        totalCount = totalCountArr && totalCountArr[0] ? Object.values(totalCountArr[0])[0] : 0;
        // 如果数量为0就不需要再查具体数据了
        if (totalCount > 0) {
          list = await this.app.mysql.query(sql);
        }
        return { list, totalCount };
      } else {
        return { list, totalCount };
      }
    }

    // 查询品牌爆款商品列表
    async findHotGoods(params) {
      const hot_id = params.hot_id;
      const sql = `SELECT b.*,a.status hotStatus,a.id hotId,a.goods_name goodsName,a.brand_url brandUrl,a.img_url imgUrl,c.brand_logo_url brandLogoUrl, c.brand_name brandName , a.sort ListSort ,a.share_content shareContent
                    FROM group_buy_hot_list a,group_buy_goods   b,group_buy_aikucun_brand c,group_buy_goods_activity d,product_overall e
                    where a.hot_id = ${hot_id}
                    and a.goods_id = e.id
                    and b.own_activity_id = d.id
                    and d.brand_id = c.id
                    and e.product_id = b.id
                    order by a.sort desc`;
      const list = await this.app.mysql.query(sql);
      return list;
    }

    // 申请退款
    async afterSaleRefund(params) {
      let code = 10000;
      let msg = '成功';
      const now = Math.floor(Date.now() / 1000);
      // 先拿到申请退款的key
      let refund = await this.app.redis.get('db0').get(Constant.key.AKC_REFUND);
      if (!refund) {
        refund = 'qxc_shopping';
        this.app.redis.get('db0').set(Constant.key.AKC_REFUND, refund);
      }
      const orderCode = params.orderCode;
      const result = await this.ctx.curl(`${this.config.api.java_host}/pay/refund`, {
        method: 'POST',
        contentType: 'json',
        data: {
          key: refund,
          orderCode
        },
        dataType: 'json'
      });
      this.logger.info('退款结果:', result.data);
      const res = result.data;
      if (res.code === 10000) {
        // 退款成功，则更新售后状态信息
        await this.app.mysql.update('order_after_sale_akc', {
          id: params.id,
          status: 1,
          update_time: now,
          refund_status_time: now
        });
        msg = '退款成功';
      } else {
        code = res.code;
        msg = res.msg;
      }

      return { code, msg };
    }

    // 通过一次审核
    async afterSaleApprove(params) {
      this.logger.info('申请审核请求参数:', params);

      let code = 10000;
      let msg = '成功';
      let res;

      const proposed_final_reason = params.proposedReason;

      // 如果一个订单的商品数量大于1，就会有多个orderDetailId，
      // 目前爱库存的售后只能针对单个orderDetailId进行
      const orderDetailID = params.orderDetatilId;
      const detailIDs = orderDetailID.split(',');
      this.logger.info(`包含${detailIDs.length}个oderDetailId:`, detailIDs);

      for (const index in detailIDs) {
        const detailID = detailIDs[index];

        // 先尝试调用爱库存创建售后单的接口
        const akcParams = {
          orderId: params.orderId,
          orderDetatilId: detailID,
          picUrls: params.picUrls,
          description: params.description,
          refundReason: params.refundReason,
          applicationType: params.applicationType,
          isReceived: params.isReceived,
          amount: params.amount
        };

        this.logger.info('准备创建售后单:', akcParams);
        const now = Math.floor(Date.now() / 1000);
        const result = await this.service.aikucun.createAfterSaleBill(akcParams);
        this.logger.info('创建售后单:', result.data);

        res = result.data;
        if (res.resultCode === 999999) {
          // 创建售后单成功则记录售后相关的信息
          await this.app.mysql.update('order_after_sale_akc', {
            id: params.id,
            status: 3,
            update_time: now,
            application_no: res.data.applicationNo,
            create_params: JSON.stringify(akcParams),
            proposed_final_reason,
          });

          if (parseInt(index) === detailIDs.length - 1) {
            msg = '创建售后单成功，请检查售后单号';
          }
        } else if (res.resultCode === 600020) {
          this.logger.info('没有发货，可以直接退款');

          // 返回 “只有发货状态才允许发起售后”，说明还没有发货，可以直接申请退款
          const res = await this.afterSaleRefund(params);
          code = res.code;
          msg = res.msg;

          // 这个状态下，表示整个订单的商品都是未发货的。这个结论是基于目前我们
          // 的订单系统上，一个订单只能有一个SKU的商品，那么即使有多个orderDetailId
          // 也只是同一个商家的同一件商品的数量大于一而已。（除非商家分开单个商品发货,
          // 这里不考虑）如果订单可以包含多个SKU，那么这个结论就是错误的。这个情况下，
          // 无论退款是否成功，整个for循环都可以结束了
          if (code === 10000) {
            msg = '由于商品还没有发货，直接退款成功';
          }

          break;
        } else {
          code = res.resultCode;
          msg = detailIDs.length === 1 ? res.resultMessage : `发起售后时，其中一件商品申请失败：${res.resultMessage}`;
          break;
        }
      }

      // 对于多个orderDetailId的情况，这里返回data数据是最后一个申请成功
      // 的orderDetailId对应的售后单信息，整个订单的售后情况就绑定到这个
      // 售后单上，但实际上，每个orderDetailId的售后单都有可能失败，但是
      // 客服同学是不知道这个情况的，这是目前这种情况下售后的最大问题
      return { code, msg, data: { application_no: res.data && res.data.applicationNo ? res.data.applicationNo : '' } };
    }

    // 审核拒绝
    async afterSaleReject(params) {
      const now = parseInt(new Date().getTime() / 1000);
      await this.app.mysql.beginTransactionScope(async conn => {
        // 先更新售后表状态
        await conn.update('order_after_sale_akc', {
          id: params.id,
          status: 10,
          update_time: now,
          fail_reason: params.reason ? params.reason : ''
        });
        // 再更新订单表售后状态
        await conn.update('order', {
          id: params.orderId,
          after_sale_status: 3
        });
      }, this.ctx);
    }

    // 更新售后图片
    async updateAfterSaleImages(params) {
      const now = parseInt(new Date().getTime() / 1000);
      await this.app.mysql.update('order_after_sale_akc', {
        id: params.id,
        update_time: now,
        images: params.images
      });
    }

    // 上传退货物流单
    async uploadLogistics(params) {
      let code = 10000;
      let msg = '成功';
      // 先尝试调用爱库存创建售后单的接口
      const akcParams = {
        applicationNo: params.applicationNo,
        logisticsCompany: params.logisticsCompany,
        shipmentNo: params.shipmentNo,
        returnAddress: params.returnAddress,
        returnName: params.returnName,
        returnPhone: params.returnPhone,
      };
      this.logger.info('上传退货物流请求参数:', params);
      const now = parseInt(new Date().getTime() / 1000);
      const result = await this.service.aikucun.uploadlogistics(akcParams);
      this.logger.info('爱库存上传物流单返回数据:', result.data);
      const res = result.data;
      if (res.resultCode === 999999) {
        // 上传快递单成功则更新售后相关的信息
        await this.app.mysql.update('order_after_sale_akc', {
          id: params.id,
          status: 7,
          update_time: now
        });
        msg = '上传物流单成功';
      } else {
        code = res.resultCode;
        msg = res.resultMessage;
      }

      return { code, msg, data: { application_no: res.data && res.data.applicationNo ? res.data.applicationNo : '' } };
    }

    // 批量更新活动商品加价价格
    async updateActivityAddPriceRatio(params) {
      let code = 10000;
      let msg = '成功';
      // 加价新增字段，同时只能改一个
      const ratio = params.ratio;
      const addPriceParam = params.addPrice;
      // 0按照比率加价， 1按照加价价格加价
      const choose = params.choose;
      const commissionRatio = params.commissionRatio;
      // 0: 默认100%， 1:恢复最低佣金
      const chooseCommission = params.chooseCommission;
      const id = params.id;

      if (chooseCommission > 1 || chooseCommission < 0 || ratio < 3 || ratio > 1000 || commissionRatio > 100 || commissionRatio < 0 || typeof choose === 'undefined' || choose < 0 || choose > 1 || addPriceParam < 0) {
        code = 10001;
        msg = '非法的加价比率';
      } else {
        await this.app.mysql.beginTransactionScope(async conn => {
          const goodsList = await conn.select('group_buy_goods', {
            where: {
              own_activity_id: id
            }
          });

          // 2019年10月19日 新逻辑 加价之后如果折扣大于原价，那么折扣为10折，单买价=团购价=原价（前端控制）
          for (const i in goodsList) {
            const goods = goodsList[i];

            let addPrice = Number(choose) === 0 ? parseFloat(goods.akc_price * ratio / 100).toFixed(1) : parseFloat(addPriceParam).toFixed(1);
            let settlementPrice = parseFloat(goods.akc_price + Number(addPrice)).toFixed(1);

            let discount = parseInt(settlementPrice / goods.akc_tag_price * 100);

            let onlySettlementPrice = this.getOnlySettlementPrice(goods.akc_tag_price, settlementPrice);
            if (discount >= 100) {
              // settlementPrice = 0.95 * goods.akc_tag_price < goods.akc_price * 1.03 ? goods.akc_price * 1.03 : 0.95 * goods.akc_tag_price;
              // addPrice = settlementPrice - goods.akc_price;
              // discount = parseInt(settlementPrice / goods.akc_tag_price * 100);
              addPrice = goods.akc_tag_price - goods.akc_price;
              onlySettlementPrice = goods.akc_tag_price;
              settlementPrice = goods.akc_tag_price;
              discount = 100;
            }

            // 直接按照加价金额来计算，如果加价的金额小于3%，会导致部分团购价的97% < 供应商进货价，佣金会为负数
            // 为了避免负数佣金的情况，在加价价格计算后，发现金额异常的情况，停止对改商品的加价行为，保持其默认的3%
            /** 时间 2019年11月1日
             * 新增逻辑，运营可以将商品的佣金置为最初始的佣金状态 chooseCommission=0，依旧是原本的逻辑
             */
            const profit = Number(chooseCommission) === 0 ?
              parseFloat((settlementPrice * 0.97 - goods.akc_settlement_price) * commissionRatio / 100).toFixed(1)
              : await this.culInitCommissionPrice(goods.akc_tag_price, goods.akc_price, goods.akc_settlement_price);

            // 修复商品加价不能恢复3%的bug
            if (profit > 0 && (addPrice / goods.akc_price).toFixed(2) >= 0.03) {
              const sql = `UPDATE group_buy_goods 
              SET add_price = ${addPrice}, settlement_price = ${settlementPrice}, discount_rate = ${discount}, only_settlement_price = ${onlySettlementPrice}, akc_profit = ${profit}
              WHERE id = ${goods.id}`;
              await this.app.mysql.query(sql);
            }
          }
          const cfgSql = `INSERT INTO group_buy_goods_add_price_ratio (activity_id, price_ratio, commission_ratio) VALUES (${id}, ${ratio * 10}, ${commissionRatio * 10}) 
                          ON DUPLICATE KEY UPDATE price_ratio = ${ratio * 10}, commission_ratio = ${commissionRatio * 10}`;
          await this.app.mysql.query(cfgSql);
        }, this.ctx);
      }

      return { code, msg };
    }

    /**
     * 计算商品的最低佣金，加价比率按照 3%， 佣金比率按照 100%
     * 1、计算出最低比率的加价金额，最低为0
     *    不加价的条件：
     *      a.获取原始折扣， 大于等于95%
     *      b.理想折扣 大于98%
     *      c.加价金额小于0
     * 2、计算出最低比率加价金额下，团购价的最低金额
     * 3、根据最低团购价和供应商结算价，计算佣金 最低为0
     *    无佣金的情况
     *      a.佣金为负数
     * @param {原价} akc_tag_price
     * @param {供应商建议售价} akc_price
     * @param {供应商结算价} akc_settlement_price
     */
    async culInitCommissionPrice(akc_tag_price, akc_price, akc_settlement_price) {
      // 第一步：计算原始加价
      let addPrice = 0;
      // 获取原始折扣， 大于等于95% 不加价
      const sourceRatio = Number(akc_price / akc_tag_price).toFixed(2);
      if (sourceRatio < 0.95) {
        addPrice = akc_price * 0.03;
        const settPriceIdea = addPrice + akc_price;
        // 理想折扣 大于98% 不加价
        const akcRateIdea = Number(settPriceIdea / akc_tag_price).toFixed(2);
        if (akcRateIdea < 0.98) {
          if (Number(settPriceIdea).toFixed(0) < 101 && Number(settPriceIdea).toFixed(0) % 10 === 0) {
            addPrice = settPriceIdea - akc_price - 0.1;
          }
        }
        // 加价金额小于0 不加价
        if (addPrice < 0) {
          addPrice = 0;
        }
      }

      // 第二步：计算最低的结算价
      const minSettPrice = akc_price + addPrice;

      // 第三步：计算理想佣金
      let commissionIdea = minSettPrice * 0.97 - akc_settlement_price;
      commissionIdea = commissionIdea > 0 ? commissionIdea : 0;
      return commissionIdea.toFixed(1);
    }

    // 生成商品推广链接
    async genGoodsPromotionUrl(params) {
      let url;
      const domain = this.domainByUserType(params.userType);
      if (params.id && String(params.userId) && params.groupId) {
        // const goodsList = await this.app.mysql.select('group_buy_goods', {
        //   where: {
        //     id: params.id
        //   }
        // });
        const sql = `SELECT b.* FROM product_overall a, group_buy_goods b WHERE a.id = ${params.id} AND a.product_id = b.id;`;
        const goodsList = await this.app.mysql.query(sql);

        if (goodsList.length > 0) {
          const goods = goodsList[0];
          const buffer = new Buffer(String(params.userId), 'utf-8');
          const base64Str = buffer.toString('base64');
          url = `https://${domain}/shopping/index.html#/pages/goods/detail?activityId=${goods.own_activity_id}&productId=${params.id}&captainId=${base64Str}&channel=88${params.groupId}`;
        }
      }

      return url;
    }

    // 生成商品活动推广链接
    async genActivityPromotionUrl(params) {
      let url;
      const domain = this.domainByUserType(params.userType);
      if (params.id && String(params.userId)) {
        const buffer = new Buffer(String(params.userId), 'utf-8');
        const base64Str = buffer.toString('base64');
        url = `https://${domain}/shopping/index.html?from=singlemessage&isappinstalled=0#/pages/routeCenter/RouteCenter?aim=goodsList&captainId=${base64Str}&ownGoodsActivityId=${params.id}&channel=88${params.groupId}`;
      }

      return url;
    }

    // 获取售后原因列表
    async afterSaleReasonList() {
      const reasons = await this.app.mysql.select('config_after_sale_reason');
      return { code: 10000, msg: '成功', data: reasons };
    }

    // 更新订单状态
    async updateOrderStatus(params) {
      const recordID = params.id;
      const orderStatus = params.status;
      const now = parseInt(new Date().getTime() / 1000);

      if (!recordID || (orderStatus !== 0 && !orderStatus)) {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '参数非法' };
      }

      if (orderStatus === 7) {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '该状态已被废弃' };
      }

      const values = { id: recordID, status: orderStatus, update_time: now };
      const result = await this.app.mysql.update('order', values);

      return result.affectedRows === 1 ? { code: 10000, msg: '成功' } : {
        code: ErrCode.ERROR_CODE_DB_INSERT,
        msg: '更新失败'
      };
    }

    async updateACKAfterSaleOrder(params) {
      if (!params.hasOwnProperty('id')) {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '参数非法' };
      }

      const now = parseInt(new Date().getTime() / 1000);
      params.update_time = now;

      let orderAfterSaleStatus = 0;
      const alterOrderTable = params.hasOwnProperty('status');

      if (alterOrderTable) {
        if (!params.hasOwnProperty('order_id')) {
          return { code: ErrCode.ERROR_CODE_PARAM, msg: '设置售后状态需要一并提供订单ID' };
        }

        // 需要对售后状态作一些检查
        const status = params.status;

        // 11 用户主动取消
        const isOff = status === 11;

        // 10 失败
        const isFailed = status === 10;

        // 1 退款成功
        // 2 退邮费成功
        // 12 用户收到换货
        const isSuccess = status === 1 || status === 2 || status === 12;

        // 0 待审核
        // 3 待爱存库一审
        // 6 待用户提交物流信息
        // 7 待爱存库二审
        const isOn = status === 0 || status === 3 || status === 6 || status === 7;

        // 根据售后状态决定关联订单的售后状态
        // 默认使用未申请
        orderAfterSaleStatus = isOff ? 0 : (isOn ? 1 : (isSuccess ? 2 : (isFailed ? 3 : 0)));
      }

      let success = false;

      if (alterOrderTable) {
        await this.app.mysql.beginTransactionScope(async conn => {
          let result = await conn.update('order_after_sale_akc', params);

          if (result.affectedRows !== 1) {
            return { success: false };
          }

          result = await conn.update('order', {
            id: params.order_id,
            after_sale_status: orderAfterSaleStatus,
            update_time: now,
          });

          success = result.affectedRows === 1;
          return { success: true };
        }, this.ctx);
      } else {
        const result = await this.app.mysql.update('order_after_sale_akc', params);
        success = result.affectedRows === 1;
      }

      return success ? { code: 10000, msg: '成功' } : { code: ErrCode.ERROR_CODE_DB_INSERT, msg: '更新失败' };
    }

    // 更新自定义寄货信息
    async updateStoreDeliveryInfo(params) {
      const recordID = params.id;
      const code = params.delivery_info;
      const now = Date.now() / 1000;

      if (!recordID || !code) {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '参数非法' };
      }

      const result = await this.app.mysql.update('order_after_sale_akc', {
        id: recordID,
        update_time: now,
        delivery_info: code,
      });

      return result.affectedRows === 1 ? { code: 10000, msg: '成功' } : {
        code: ErrCode.ERROR_CODE_DB_INSERT,
        msg: '更新失败'
      };
    }

    // 更新商家回寄信息
    async updateSellerDeliveryInfo(params) {
      const recordID = params.id;
      const info = params.receiving_info;
      const now = Date.now() / 1000;

      if (!recordID || !info) {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '参数非法' };
      }

      const result = await this.app.mysql.update('order_after_sale_akc', {
        id: recordID,
        update_time: now,
        receiving_info: info,
      });

      return result.affectedRows === 1 ? { code: 10000, msg: '成功' } : {
        code: ErrCode.ERROR_CODE_DB_INSERT,
        msg: '更新失败'
      };
    }

    // 获取域名
    domainByUserType(type) {
      return type === 1 ? 'web.quexiangbao.com' : 'groupbuy.quexc.com';
    }

    // 计算单买价
    getOnlySettlementPrice(tagPrice, settlementPrice) {
      const discount = (settlementPrice / tagPrice).toFixed(2);
      let factor = 6;
      if (discount >= 0.3 && discount < 0.5) {
        factor = 4;
      } else if (discount >= 0.5 && discount < 0.7) {
        factor = 2.5;
      } else if (discount >= 0.7 && discount < 1) {
        factor = 2;
      }

      return Math.min(tagPrice, parseFloat(settlementPrice * (1 + Math.pow(1 - discount, (factor - discount) * 0.75))).toFixed(1));
    }

    async calcGoodsUnitPrice(goodsId, newSettlementPrice) {
      let price = newSettlementPrice + 2; // 默认值保证比拼团价高
      const res = await this.app.mysql.select('group_buy_goods', {
        where: {
          id: goodsId
        }
      });

      if (res.length > 0) {
        const goods = res[0];
        const { akc_tag_price } = goods;
        price = this.getOnlySettlementPrice(akc_tag_price, newSettlementPrice);
      } else {
        throw { code: Constant.ERROR_CODE_NO_RESULT, msg: '找不到相关的商品' };
      }

      return price;
    }

    // 获取售后单号
    async _genAfterSaleCode() {
      const res = await this.ctx.curl(`${this.config.api.java_host}/helper/generateOrderCode`, {
        method: 'POST',
        contentType: 'json',
        dataType: 'json',
        data: { type: 2 }, // 1拉新订单编号，2售后编号
      });

      const resData = res.data;
      if (resData.code !== 10000) {
        return { code: resData.code, msg: `申请新售后单号失败: ${resData.msg}` };
      }

      const afterSaleCode = resData.data;
      if (typeof afterSaleCode !== 'string' || afterSaleCode.length === 0) {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '新售后单号格式错误' };
      }

      return resData;
    }

    // 重新发起售后
    async restartAfterSale(params) {
      const afterSaleInfo = params.afterSale_info;

      if (!afterSaleInfo) {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '缺少原始的售后单数据' };
      }

      const status = afterSaleInfo.status;
      if (typeof status === 'undefined') {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '缺少售后单状态参数' };
      }

      const orderStatusList = await this.app.mysql.query('SELECT after_sale_status FROM \`order\` WHERE id = ?', [afterSaleInfo.order_id]);
      if (orderStatusList.length !== 1) {
        return { code: ErrCode.ERROR_CODE_DB_UNEXPECTED_RESULT_COUNT, msg: '售后单关联的订单数量超过1条' };
      }

      const orderStatus = orderStatusList[0].after_sale_status;
      if (orderStatus === 1) {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '关联的订单已在售后中，无需重复申请' };
      }

      // 5爱存库一审失败，9爱存库二审失败，10失败
      if (status !== 5 || status !== 9 || status !== 10) {
        const options = {
          id: afterSaleInfo.id,
          status: 10,
          fail_reason: '对应订单已经重新发起售后',
        };

        // 这里不需要修改订单售后状态，后面新建售后后会一并修改
        const result = await this.app.mysql.update('order_after_sale_akc', options);
        if (result.affectedRows !== 1) {
          return { code: ErrCode.ERROR_CODE_PARAM, msg: '修改原售后单状态失败' };
        }
      }

      // 生成售后单号
      const genAfterSaleCode = await this._genAfterSaleCode();
      if (genAfterSaleCode.code !== 10000) {
        return genAfterSaleCode;
      }

      const afterSaleCode = genAfterSaleCode.data;

      //  插入新的售后单数据
      const afterSaleOrder = {};
      afterSaleOrder.order_id = afterSaleInfo.order_id;
      afterSaleOrder.status = 0; // 待审核
      afterSaleOrder.create_time = Math.floor(Date.now() / 1000);
      afterSaleOrder.reason = afterSaleInfo.reason;
      afterSaleOrder.problem = afterSaleInfo.problem;
      afterSaleOrder.type = afterSaleInfo.type;
      afterSaleOrder.images = JSON.stringify(afterSaleInfo.images);
      afterSaleOrder.after_sale_no = afterSaleCode;

      const response = {};

      await this.app.mysql.beginTransactionScope(async conn => {
        let res = await conn.insert('order_after_sale_akc', afterSaleOrder);
        if (res.affectedRows !== 1 || !res.insertId) {
          response.code = ErrCode.ERROR_CODE_DB_INSERT;
          response.msg = '插入新售后单数据失败';
          return { sucess: false };
        }

        res = await conn.update('order', {
          id: afterSaleInfo.order_id,
          after_sale_status: 1, // 进行中
          update_time: Math.floor(Date.now() / 1000),
        });

        if (res.affectedRows !== 1) {
          response.code = ErrCode.ERROR_CODE_DB_INSERT;
          response.msg = '更新关联订单的售后状态失败';
          return { sucess: false };
        }

        response.code = 10000;
        response.msg = '成功';
        return { sucess: true };
      }, this.ctx);

      return response;
    }

    // 根据订单号直接发起售后
    async applyAfterSale(params) {
      const type = params.type;
      const orderCode = params.orderCode;

      if (typeof orderCode === 'undefined' || typeof type === 'undefined') {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '申请售后必须提交订单号和售后类型' };
      }

      const orderData = await this.app.mysql.select('order', { where: { order_code: orderCode } });
      if (!Array.isArray(orderData) || orderData.length === 0) {
        return { code: ErrCode.ERROR_CODE_DB_UNEXPECTED_RESULT_COUNT, msg: '查找订单信息失败' };
      }

      const order = orderData[0];

      // 如果当前订单的售后状态是售后中，不允许继续发起售后
      if (order.after_sale_status === 1) {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '该订单已经在售后中，请直接搜索' };
      }

      // 生成售后单号
      const genAfterSaleCode = await this._genAfterSaleCode();
      if (genAfterSaleCode.code !== 10000) {
        return genAfterSaleCode;
      }

      const status = 0; // 待审核
      const reason = params.reason || '';
      const problem = params.problem || '';
      const images = Array.isArray(params.images) ? JSON.stringify(params.images) : '';
      const create_time = Math.floor(Date.now() / 1000);
      const order_id = order.id;
      const after_sale_no = genAfterSaleCode.data;

      let response = {};
      await this.app.mysql.beginTransactionScope(async conn => {
        let res = await conn.insert('order_after_sale_akc', {
          order_id,
          status,
          create_time,
          reason,
          problem,
          images,
          type,
          after_sale_no
        });

        if (res.affectedRows !== 1) {
          response = { code: ErrCode.ERROR_CODE_DB_INSERT, msg: '保存新售后单数据失败' };
          return { success: false };
        }

        // 同时更新关联订单的售后状态
        res = await conn.update('order', { id: order_id, after_sale_status: 1 });
        if (res.affectedRows !== 1) {
          response = { code: ErrCode.ERROR_CODE_DB_UPDATE_FAILED, msg: '更新订单售后状态失败' };
          return { success: false };
        }

        response = { code: 10000, msg: '成功' };
        return { success: true };
      }, this.ctx);

      return response;
    }

    // 根据订单号或售后单信息取消售后
    async cancelAfterSale(params) {
      let afterSaleInfo = params.afterSale_info;
      const orderCode = params.order_code;
      const hasOrderCode = typeof orderCode !== 'undefined';
      let hasAfterSaleInfo = typeof afterSaleInfo !== 'undefined';

      if (!hasOrderCode && !hasAfterSaleInfo) {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '缺少参数' };
      }

      if (hasOrderCode && !hasAfterSaleInfo) {
        // 根据订单号来取消售后单
        const querySQL = 'SELECT a.*, b.akc_order_detatil_id FROM  order_after_sale_akc a , `order` b WHERE b.order_code = ? AND a.order_id = b.id';
        const afterSales = await this.app.mysql.query(querySQL, [`${orderCode}`]);
        if (afterSales.length === 0) {
          return { code: ErrCode.ERROR_CODE_NO_RESULT, msg: '无关联售后单' };
        } else if (afterSales.length === 1) {
          afterSaleInfo = afterSales[0];
        } else {
          const targetInfos = afterSales.filter(item => {
            return item.status !== 1 &&
              item.status !== 4 &&
              item.status !== 5 &&
              item.status !== 8 &&
              item.status !== 9 &&
              item.status !== 10 &&
              item.status !== 11;
          });

          // 只处理只有一条售后单的情况，不确定的情况
          // 让用户自行到售后单搜索处理
          if (targetInfos.length === 0) {
            return { code: ErrCode.ERROR_CODE_NO_RESULT, msg: '无符合条件的售后单，请联系开发人员' };
          } else if (targetInfos.length > 1) {
            return {
              code: ErrCode.ERROR_CODE_DB_UNEXPECTED_RESULT_COUNT,
              msg: '该订单有多于一条售后单正在处理中，请直接搜索售后单处理或联系开发人员'
            };
          }

          afterSaleInfo = targetInfos[0];
          hasAfterSaleInfo = true;
        }
      }

      if (!hasAfterSaleInfo) {
        console.log('无售后信息');
        return;
      }

      // 如果售后单无第三方单售后单号
      // 则不需要向爱库存发起请求
      if (afterSaleInfo.application_no) {
        if (!afterSaleInfo.akc_order_detatil_id) {
          return { code: ErrCode.ERROR_CODE_PARAM, msg: '订单缺少爱库存三级订单数据' };
        }

        const response = await this.service.aikucun.cancelAfterSaleBill({
          applicationNo: afterSaleInfo.application_no,
          orderDetailId: afterSaleInfo.akc_order_detatil_id
        });

        const resData = response.data;
        if (resData.resultCode !== 999999) {
          return { code: resData.resultCode, msg: resData.resultMessage || '取消爱库存售后单失败' };
        }
      }

      let response = {};

      await this.app.mysql.beginTransactionScope(async conn => {
        // 更新售后单状态
        let res = await conn.update('order_after_sale_akc', {
          id: afterSaleInfo.id,
          status: 10,
          fail_reason: '已由后台人员操作取消',
          update_time: Math.floor(Date.now() / 1000)
        });

        if (res.affectedRows !== 1) {
          response = { code: ErrCode.ERROR_CODE_DB_UPDATE_FAILED, msg: '更新售后单状态失败' };
          return { success: false };
        }

        // 更新订单售后状态
        res = await conn.update('order', {
          id: afterSaleInfo.order_id,
          after_sale_status: 0
        });

        if (res.affectedRows !== 1) {
          response = { code: ErrCode.ERROR_CODE_DB_UPDATE_FAILED, msg: '更新订单状态失败' };
          return { success: false };
        }

        response = { code: 10000, msg: '成功' };
        return { success: true };
      }, this.ctx);

      return response;
    }

    // 已经完成了手工退款
    async alreadyRefund(params) {
      const id = params.id;
      const order_id = params.order_id;
      const product = params.product;

      console.log('params', params);

      let response = {};
      await this.app.mysql.beginTransactionScope(async conn => {
        if (product.supplier_name !== '好衣库') {
          const status = await conn.select('order_after_sale_akc', {
            where: { id },
            columns: ['status'],
          });

          const orderStatus = Array.isArray(status) ? status[0].status : null;
          if (orderStatus !== 8) {
            response = { code: ErrCode.ERROR_CODE_PARAM, msg: '售后单状态非\"爱库存二审通过\"' };
            return { success: false };
          }
        }

        let updateStatus = await conn.update('order_after_sale_akc', {
          id,
          status: 1,
          fail_reason: '已由后台人员确认完成手工退款',
        });

        if (updateStatus.affectedRows !== 1) {
          response = { code: ErrCode.ERROR_CODE_DB_UPDATE_FAILED, msg: '更新售后单状态失败' };
          return { success: false };
        }

        updateStatus = await conn.update('order', {
          id: order_id,
          after_sale_status: 2,
        });

        if (updateStatus.affectedRows !== 1) {
          response = { code: ErrCode.ERROR_CODE_DB_UPDATE_FAILED, msg: '更新订单售后状态失败' };
          return { success: false };
        } else {
          response = { code: 10000, msg: '成功' };
          return { success: true };
        }
      }, this.ctx);

      console.log('ressssssss', response);
      return response;
    }

    async listCaptainGoods(params) {
      const results = {
        rowNum: 0,
        resultList: null
      };
      if (typeof undefined !== params.status && params.pageNum && params.pageSize) {
        const rowNum = await this.app.mysql.select('product', {
          where: { type: 5, status: params.status },
          columns: ['id']
        });

        const sortType = Number(params.status) === 1 ? ['sort', 'asc'] : ['update_time', 'desc'];
        let resultList;
        if (rowNum.length > 0) {
          resultList = await this.app.mysql.select('product', {
            where: { type: 5, status: params.status },
            columns: ['id', 'name', 'price', 'status', 'type', 'original_price', 'detail', 'image_url', 'postage', 'sort', 'stock'],
            orders: [sortType],
            limit: params.pageSize,
            offset: (params.pageNum - 1) * params.pageSize
          });
        }
        results.rowNum = rowNum.length;
        results.resultList = resultList;
      }
      return { code: 10000, data: results, msg: '成功' };
    }

    /**
     * 更新product表中的298信息
     * @param {} params
     */
    async updateCaptainGoods(params) {
      if (params.id && Number(params.type) === 5) {
        const row = {
          id: params.id,
          status: params.status,
          image_url: params.image_url,
          postage: params.postage,
          sort: params.sort,
          update_time: parseInt(new Date().getTime() / 1000)
        };
        if (params.name) {
          row.name = params.name;
        }
        if (params.image_url) {
          row.image_url = params.image_url;
        }
        if (typeof undefined !== params.postage || params.postage > 0) {
          row.postage = params.postage;
        }
        if (params.sort) {
          row.sort = params.sort;
        }

        const result = await this.app.mysql.update('product', row);
        if (result.affectedRows !== 1) {
          throw { code: Constant.ERROR_CODE_DB_UPDATE_FAILED, msg: '活动参数错误' };
        }
        return { code: 10000, msg: '成功' };
      }
      return { code: Constant.ERROR_CODE_VERIFY_FAIL, msg: '只支持298的商品修改' };
    }


    async createCaptainGoods(params) {
      // 新增开团礼包的活动信息的实体类
      const actName = params.act_name;
      const actDescription = params.act_description;
      const actStartTime = params.act_start_time;
      const actEndTime = params.act_end_time;
      const status = params.status;
      const brandId = 3501;
      let actNew;

      if (actName && actDescription && status) {
        const selectMaxActIdSQL = 'SELECT activity_id FROM group_buy_goods_activity WHERE activity_id LIKE \'tuan_zhang_li_bao_%\' order by id desc limit 1';
        const maxActStrId = await this.app.mysql.query(selectMaxActIdSQL);
        const activityStrId = maxActStrId[0].activity_id;
        let actNum = 0;
        const tempStrAct = 'tuan_zhang_li_bao_';
        if (typeof undefined !== activityStrId) {
          const maxId = activityStrId.replace(tempStrAct, '');
          actNum = Number(maxId) + 1;
        }
        actNew = {
          activity_id: tempStrAct + actNum,
          description: actDescription,
          cat_id: 1,
          start_time: actStartTime,
          end_time: actEndTime,
          create_time: parseInt(new Date().getTime() / 1000),
          update_time: parseInt(new Date().getTime() / 1000),
          status: params.status, // 活动商品的活动信息，活动不上架 ==-==
          name: actName,
          min_discount: 33,
          goods_num: 1,
          brand_id: brandId, // 团长大礼包的品牌ID, 测试环境和正式环境都是这个
          qxb_status: 0,
          is_all_goods: 1,
          channel: params.supplier_name === '爱库存' ? 1 : params.supplier_name === '好衣库' ? 2 : 3, // 渠道 1.爱库存,2好衣库,3自营
          wx_mini_program_show: 0 // 是否对微信可见
        };
      } else {
        throw { code: Constant.ERROR_IMPORT_DATA, msg: '活动参数错误' };
      }

      // 新增开团礼包的商品信息
      const goodsName = params.goods_name;
      const goodsDescription = params.goods_description;
      const akcTagPrice = 899;
      const settlementPrice = 298;
      const onlySettlementPrice = 899;
      const picture = params.picture;
      const detailPic = params.detail_pic;
      const supplierName = params.supplier_name;
      const supplierGoodsId = params.supplier_goods_id;
      const supplierGoodsName = params.supplier_goods_name;
      let goods;
      // 参数校验
      if (goodsName && goodsDescription && picture && akcTagPrice && settlementPrice && onlySettlementPrice) {
        goods = {
          product_id: actNew.activity_id + '_' + 0,
          akc_tag_price: akcTagPrice,
          category: '团长礼包',
          description: goodsDescription,
          picture: JSON.stringify(picture),
          name: goodsName,
          brand_size_url: '无',
          skus_attribute_list: null,
          sku_list: null,
          own_activity_id: null,
          status: 0,
          discount_rate: 33,
          settlement_price: settlementPrice,
          create_time: Date.parse(new Date()).toString().substr(0, 10),
          update_time: Date.parse(new Date()).toString().substr(0, 10),
          aikucun_activity_id: actNew.activity_id,
          aikucun_brand_id: brandId,
          type: 9,
          qxb_status: 0,
          supplier_name: supplierName,
          supplier_goods_id: supplierGoodsId,
          supplier_goods_name: supplierGoodsName,
          only_settlement_price: onlySettlementPrice,
          detail_picture: null
        };
        goods.detail_picture = (typeof undefined === detailPic) ? JSON.stringify(picture) : JSON.stringify(detailPic);
      } else {
        throw { code: Constant.ERROR_IMPORT_DATA, msg: '商品信息设置有误' };
      }

      // group_buy_sku表中的新增信息
      const inventory = 0;
      const color = params.color;
      const size = params.size;
      let sku;
      if (color && size) {
        const attributes = [
          {
            attributeName: '尺码',
            attributeValue: size
          }, {
            attributeName: '颜色',
            attributeValue: color
          }
        ];

        sku = {
          goods_id: null,
          sku_inventory: inventory,
          attribute_list: JSON.stringify(attributes),
          sku_id: goods.product_id + '_' + 0,
          settlement_price: settlementPrice,
          profit_price: 0,
          only_settlement_price: onlySettlementPrice
        };
      } else {
        throw { code: Constant.ERROR_IMPORT_DATA, msg: '商品的规格信息设置有误' };
      }

      // product表新增信息
      const autoBuy = params.auto_buy;
      const akcGroupBuyGoodsId = params.akc_group_buy_goods_id;
      const productNum = params.product_num;
      const stock = params.stock;
      const cardPic = params.card_pic;
      let product;
      if (typeof autoBuy !== undefined && stock && cardPic) {
        product = {
          name: goodsName,
          price: settlementPrice,
          add_day: 90,
          status: 1,
          type: 5,
          original_price: akcTagPrice,
          image_url: cardPic,
          postage: 0,
          stock,
          is_direct_sales: 1,
          newer_activity_id: 23,
          detail: null,
          sort: 0
        };
        if (Number(autoBuy) === 1) {
          if (akcGroupBuyGoodsId && productNum) {
            const selectGoodsSQL = `SELECT sku_list, type FROM group_buy_goods WHERE id = ${akcGroupBuyGoodsId}`;
            const skuListJsonArr = await this.app.mysql.query(selectGoodsSQL);
            if (skuListJsonArr.length > 0) {
              const skuListJson = skuListJsonArr[0];
              const goodsType = skuListJson.type;
              const skuJSONArr = JSON.parse(skuListJson.sku_list);

              if (Number(goodsType) === 0) {
                const productDetail = {
                  orderType: '2',
                  productId: akcGroupBuyGoodsId,
                  productNum,
                  skuId: skuJSONArr[0].skuId
                };
                product.detail = JSON.stringify(productDetail);
              } else if (Number(goodsType) === 4) {
                // 好衣库的sku id需要在商品详情后才能拿到真实的ID
                const hykInfo = await this.app.mysql.get('product_overall', { product_id: akcGroupBuyGoodsId, order_type: 13 });
                const goodsDetail = await this.ctx.curl(`${this.config.api.java_host}/groupBuy/getGoodsDetail`, {
                  method: 'POST',
                  contentType: 'json',
                  data: {
                    goodsId: hykInfo.id,
                    clientId: 'qxb_admin',
                    version: '1.0'
                  },
                  dataType: 'json'
                });
                const productDetail = {
                  orderType: '13',
                  productId: akcGroupBuyGoodsId,
                  productNum,
                  skuId: goodsDetail.data.data.skuList[0].skuId
                };
                product.detail = JSON.stringify(productDetail);
              } else {
                throw { code: Constant.ERROR_IMPORT_DATA, msg: '非爱库存/好衣库商品不允许自动下单' };
              }
            } else {
              throw { code: Constant.ERROR_IMPORT_DATA, msg: '查不到对应商品' };
            }
          } else {
            throw { code: Constant.ERROR_IMPORT_DATA, msg: '自动下单参数有误' };
          }
        }
      } else {
        throw { code: Constant.ERROR_IMPORT_DATA, msg: '商品信息设置有误' };
      }

      // 开启事务插入数据
      await this.app.mysql.beginTransactionScope(async conn => {
        // 插入活动信息 actNew
        const insertAct = await conn.insert('group_buy_goods_activity', actNew);
        if (insertAct.affectedRows === 1) {
          const actId = insertAct.insertId;
          // 插入298商品详情信息
          goods.own_activity_id = actId;
          goods.skus_attribute_list = sku.attribute_list;
          const goodsSkuList = [{
            attributeList: JSON.parse(goods.skus_attribute_list),
            skuId: sku.sku_id,
            skuInventory: 51
          }];

          goods.sku_list = JSON.stringify(goodsSkuList);
          const insertGoods = await conn.insert('group_buy_goods', goods);
          if (insertAct.affectedRows === 1) {
            const goodsId = insertGoods.insertId;
            // 插入SKU信息
            sku.goods_id = goodsId;
            const insertSku = await conn.insert('group_buy_sku', sku);
            if (insertSku.affectedRows !== 1) {
              throw { code: Constant.ERROR_CODE_DB_INSERT, msg: '新增商品规格失败' };
            }
            // 插入 product表中的信息
            const insertProduct = await conn.insert('product', product);
            if (insertProduct.affectedRows !== 1) {
              throw { code: Constant.ERROR_CODE_DB_INSERT, msg: '新增商品失败' };
            }
            const productId = insertProduct.insertId;
            // 插入product_overall 表中的信息
            const productOverAll = {
              product_id: goodsId,
              order_type: 9,
              goods_id: null,
              remark: null
            };
            const insertProductOverAll = await conn.insert('product_overall', productOverAll);
            if (insertProductOverAll.affectedRows === 1) {
              const goodsOverId = insertProductOverAll.insertId;
              const remarkStr = {
                goodsId: goodsOverId
              };
              productOverAll.product_id = productId;
              productOverAll.remark = JSON.stringify(remarkStr);
              productOverAll.goods_id = goodsId;
              const insertProductOverAllB = await conn.insert('product_overall', productOverAll);
              if (insertProductOverAllB.affectedRows !== 1) {
                throw { code: Constant.ERROR_CODE_DB_INSERT, msg: '新增商品失败' };
              }
            } else {
              throw { code: Constant.ERROR_CODE_DB_INSERT, msg: '新增商品1映射失败' };
            }
          } else {
            throw { code: Constant.ERROR_CODE_DB_INSERT, msg: '新增商品失败' };
          }

        } else {
          throw { code: Constant.ERROR_CODE_DB_INSERT, msg: '商品信息设置有误' };
        }
      }, this.ctx);
      const response = { code: 10000, msg: '成功' };
      return response;
    }

    async listTag() {
      const results = await this.app.mysql.select('group_buy_tag');
      return { code: 10000, data: results, msg: '成功' };
    }

    async listTagForWXMiniProgram() {
      const tagsJson = await this.app.redis.get('db0').get(Constant.key.AIKUCUN_TAG_QXB_WX_MINI);
      const tags = tagsJson ? JSON.parse(tagsJson) : {};
      return { code: 10000, data: tags, msg: '成功' };
    }

    async listBrand() {
      const results = await this.app.mysql.select('group_buy_aikucun_brand');
      return { code: 10000, data: results, msg: '成功' };
    }

    async createBrand(params) {
      const results = {};
      if (typeof undefined !== params.brand_name && typeof undefined !== params.brand_description && typeof undefined !== params.brand_logo_url) {
        const resultSelect = await this.app.mysql.get('group_buy_aikucun_brand', { brand_name: params.brand_name });
        if (resultSelect === null) {
          const brand = {
            brand_name: params.brand_name,
            brand_logo_url: params.brand_logo_url,
            description: params.brand_description,
            create_time: Date.parse(new Date()).toString().substr(0, 10)
          };
          const resultDB = await this.app.mysql.insert('group_buy_aikucun_brand', brand);
          if (resultDB.affectedRows !== 1) {
            throw { code: Constant.ERROR_CODE_VERIFY_FAIL, msg: '创建品牌错误' };
          }
          results.insertId = resultDB.insertId;
          results.brand_name = params.brand_name;
        } else {
          throw { code: Constant.ERROR_CODE_VERIFY_FAIL, msg: '该品牌已经存在' };
        }
      } else {
        throw { code: Constant.ERROR_CODE_VERIFY_FAIL, msg: '创建品牌参数错误' };
      }
      return { code: 10000, data: results, msg: '成功' };
    }

    // 自营活动的混合活动
    // 雀享优品的活动ID列表保存到redis db6中，own_act_and_no_goods_act_id_QXB
    async listOwnActNoOwnGoodsAct(params) {

      const pageNum = params.pageNum;
      const pageSize = params.pageSize;
      // 注释，这里是分端的，这里暂时不管分端的逻辑
      const ownActIds = await this.app.redis.get('db6').get(Constant.key.OWN_ACT_NO_OWN_ACTIVITY_QXB);
      const ownActJson = JSON.parse(ownActIds);
      const startIndex = (pageNum - 1) * pageSize;
      const endIndex = pageNum * pageSize;
      const partIds = ownActJson.slice(startIndex, endIndex);
      let result = [];
      if (partIds.length > 0) {
        result = await this.app.mysql.select('group_buy_goods_activity', {
          where: { id: partIds },
          columns: ['id', 'description', 'start_time', 'end_time', 'name', 'min_discount', 'goods_num', 'qxb_status', 'selected_nice_img', 'wx_mini_program_show'],
          orders: [['id', 'desc']]
        });
      }
      const results = { res: result, pageTotal: ownActJson.length };
      return { code: 10000, data: results, msg: '成功' };
    }

    async updateOwnActNoOwnGoodsAct(params) {
      const upParam = {};
      if (params.id !== null) {
        upParam.id = params.id;
        if (params.description !== null) {
          upParam.description = params.description;
        }
        if (params.start_time !== null) {
          upParam.start_time = params.start_time;
        }
        if (params.end_time !== null) {
          upParam.end_time = params.end_time;
        }
        if (params.name !== null) {
          upParam.name = params.name;
        }
        if (params.min_discount !== null) {
          upParam.min_discount = params.min_discount;
        }
        if (params.goods_num !== null) {
          upParam.goods_num = params.goods_num;
        }
        if (params.qxb_status !== null) {
          upParam.qxb_status = params.qxb_status;
        }
        if (params.selected_nice_img !== null) {
          upParam.selected_nice_img = params.selected_nice_img;
        }
        if (params.wx_mini_program_show !== null) {
          upParam.wx_mini_program_show = params.wx_mini_program_show;
        }
        if (params.description !== null) {
          upParam.description = params.description;
        }

        const result = await this.app.mysql.update('group_buy_goods_activity', upParam);
        if (result.affectedRows !== 1) {
          throw { code: Constant.ERROR_CODE_DB_UPDATE_FAILED, msg: '更新失败' };
        }
        return { code: 10000, msg: '成功' };

      } else {
        throw { code: Constant.ERROR_CODE_DB_UPDATE_FAILED, msg: '商品信息设置有误，无法更新' };
      }
    }

    async createOwnActNoOwnGoodsAct(params) {
      // 活动ID
      const brandId = params.brand_id;
      // 活动信息
      const actName = params.act_name;
      const actCatId = params.cat_id;
      const actDescription = params.act_description;
      const actStartTime = params.act_start_time;
      const actEndTime = params.act_end_time;
      const wxShow = params.act_wx_mini_program_show;
      const selectdImg = params.act_selected_nice_img;
      const goodsNum = params.act_goods_num;
      const minDiscount = params.act_min_discount;
      const finalActivityId = 'own-guan-fang-zi-ying-';
      let actId;
      if (actName && actCatId && actDescription && actEndTime && actStartTime
        && (typeof undefined !== wxShow) && goodsNum && minDiscount && brandId) {
        const selectSQL = 'SELECT activity_id FROM group_buy_goods_activity WHERE activity_id like \'own-guan-fang-zi-ying-%\' ORDER BY id desc limit 1;';
        const jsonArr = await this.app.mysql.query(selectSQL);
        let activityIdNum = 0;
        if (jsonArr.length === 1) {
          activityIdNum = 1 + Number(jsonArr[0].activity_id.replace(finalActivityId, ''));
        }
        const actMsg = {
          activity_id: finalActivityId + activityIdNum,
          description: actDescription,
          banner: null,
          statement_by_day: 0,
          cat_id: actCatId,
          start_time: actStartTime,
          end_time: actEndTime,
          create_time: Date.parse(new Date()).toString().substr(0, 10),
          update_time: Date.parse(new Date()).toString().substr(0, 10),
          status: 0,
          name: actName,
          min_discount: minDiscount,
          goods_num: goodsNum,
          brand_id: brandId,
          qxb_status: 0,
          is_all_goods: 1,
          selected_nice_img: selectdImg,
          wx_mini_program_show: wxShow,
          channel: 3
        };
        const result = await this.app.mysql.insert('group_buy_goods_activity', actMsg);
        actId = result.insertId;
        if (result.affectedRows !== 1) {
          throw { code: Constant.ERROR_CODE_DB_INSERT, msg: '新增活动错误' };
        }
      } else {
        throw { code: Constant.ERROR_CODE_DB_INSERT, msg: '活动信息设置有误' };
      }
      const ownActList = await this.app.redis.get('db6').get(Constant.key.OWN_ACT_NO_OWN_ACTIVITY_QXB);
      const ownActJson = JSON.parse(ownActList);
      ownActJson.splice(0, 0, Number(actId));
      this.app.redis.get('db6').set(Constant.key.OWN_ACT_NO_OWN_ACTIVITY_QXB, JSON.stringify(ownActJson));
      const response = { code: 10000, msg: '成功' };
      return response;
    }

    async createNoOwnGoods(params) {

      const ownActId = params.act_id;
      const goodsList = params.goodsIdList;
      const orderTypeLimit = [2, 6, 13];
      let productOverAllIds = [];
      if (ownActId && goodsList.length > 0) {
        const goodsIds = [];
        for (const iterator of goodsList) {
          const goodsId = iterator.goods_id;
          const orderType = Number(iterator.order_type);
          if (orderTypeLimit.indexOf(orderType) > -1) {
            goodsIds.push(goodsId);
          }
        }
        const resultsIds = await this.app.mysql.select('product_overall', {
          where: { product_id: goodsIds, order_type: orderTypeLimit },
          columns: ['id', 'product_id', 'order_type']
        });
        // 存放map key:product_id-order_type, value:id
        const overallMap = new Map();
        for (const iterator of resultsIds) {
          overallMap.set(iterator.product_id + '-' + iterator.order_type, iterator.id);
        }
        for (const iterator of goodsList) {
          const mapKey = iterator.goods_id + '-' + iterator.order_type;
          const values = overallMap.get(mapKey);
          if (values) {
            productOverAllIds.push(values);
          }
        }
      }

      const redisKey = Constant.key.OWN_ACT_NO_OWN_GOODS_QXB + ownActId;
      let ownGoodsJSONArr = await this.app.redis.get('db6').get(redisKey);
      if (ownGoodsJSONArr === null) {
        ownGoodsJSONArr = '[]';
      }
      const oldGoodsList = JSON.parse(ownGoodsJSONArr);
      productOverAllIds = productOverAllIds.concat(oldGoodsList);

      // 一个活动中的商品需要小于100个，超过100，将老的顶替掉
      const totalSize = productOverAllIds.length;
      if (totalSize > 100) {
        productOverAllIds = productOverAllIds.slice(0, 100);
      }
      this.app.redis.get('db6').set(redisKey, JSON.stringify(productOverAllIds));
      return { code: 10000, msg: '成功' };
    }

    /**
     * 根据orderID返回对应商品的数据，如果一个orderID关联多个商品，这个接口不可用
     * @param params
     * @returns {Promise<{msg: string, code: number}|{msg: string, code: number, data: *}>}
     */
    async productForAfterSaleOrder(params) {
      const order_id = params.order_id;
      if (!order_id) {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '缺少订单ID' };
      }

      const selectSql = 'SELECT * FROM group_buy_goods WHERE id = (SELECT product_id FROM order_info WHERE order_id = ?)';
      const products = await this.app.mysql.query(selectSql, [order_id]);
      const product = products.length > 0 ? products[0] : {};
      return { code: 10000, msg: '成功', data: product };
    }

    async listOwnActGoods(params) {
      let listInfo = [];
      if (typeof params.id !== 'undefined' && !isNaN(params.id)) {
        // 获取活动映射的ID列表
        const redisKey = Constant.key.OWN_ACT_NO_OWN_GOODS_QXB + params.id;
        let ownGoodsJSONArr = await this.app.redis.get('db6').get(redisKey);
        if (ownGoodsJSONArr === null) {
          ownGoodsJSONArr = '[]';
        }
        const oldGoodsList = JSON.parse(ownGoodsJSONArr);
        if (oldGoodsList.length > 0) {
          const columns = ' t0.id, t1.id as all_Id, t0.name ';
          const selestSQL = ` SELECT ${columns} FROM group_buy_goods t0 INNER JOIN product_overall t1 ON t1.id in (?) AND t0.id = t1.product_id  ORDER BY FIELD(t1.id,?)`;
          listInfo = await this.app.mysql.query(selestSQL, [oldGoodsList, oldGoodsList]);
        }
      } else {
        return { code: Constant.ERROR_CODE_PARAM, msg: '参数错误' };
      }
      return { code: 10000, msg: '成功', data: listInfo };
    }

    async updateGoodsSort(params) {
      if (typeof params.id !== 'undefined' && !isNaN(params.id) && typeof params.currentSort !== 'undefined' && !isNaN(params.currentSort) && typeof params.sortNew !== 'undefined' && !isNaN(params.sortNew)) {
        // 获取活动映射的ID列表
        const redisKey = Constant.key.OWN_ACT_NO_OWN_GOODS_QXB + params.id;
        let ownGoodsJSONArr = await this.app.redis.get('db6').get(redisKey);
        if (ownGoodsJSONArr === null) {
          ownGoodsJSONArr = '[]';
        }
        const oldGoodsList = JSON.parse(ownGoodsJSONArr);
        if (oldGoodsList.length > 0) {
          const goodsIdNew = oldGoodsList.splice(params.currentSort - 1, 1);

          oldGoodsList.splice(params.sortNew - 1, 0, goodsIdNew[0]);
          this.app.redis.get('db6').set(redisKey, JSON.stringify(oldGoodsList));
          return { code: 10000, msg: '成功' };
        }
      } else {
        return { code: Constant.ERROR_CODE_PARAM, msg: '参数错误' };
      }
      return { code: 10000, msg: '失败' };
    }

    async deleteGoodsSort(params) {
      if (typeof params.id !== 'undefined' && !isNaN(params.id) && typeof params.index !== 'undefined' && !isNaN(params.index)) {
        // 获取活动映射的ID列表
        const redisKey = Constant.key.OWN_ACT_NO_OWN_GOODS_QXB + params.id;
        let ownGoodsJSONArr = await this.app.redis.get('db6').get(redisKey);
        if (ownGoodsJSONArr === null) {
          ownGoodsJSONArr = '[]';
        }
        const oldGoodsList = JSON.parse(ownGoodsJSONArr);
        if (oldGoodsList.length > 0) {
          oldGoodsList.splice(params.index - 1, 1);
          this.app.redis.get('db6').set(redisKey, JSON.stringify(oldGoodsList));
          return { code: 10000, msg: '成功' };
        }
      } else {
        return { code: Constant.ERROR_CODE_PARAM, msg: '参数错误' };
      }
      return { code: 10000, msg: '失败' };
    }

    async ownActOwnGoodsActList(params) {
      let page = typeof params.page === null || isNaN(params.page) ? 1 : params.page;
      const pageSize = typeof params.pageSize === null || isNaN(params.pageSize) ? 20 : params.pageSize;
      page = (page - 1) * pageSize;
      const column = ' t0.id,t0.activity_id,t0.brand_id ,t0.description, t0.banner, t2.brand_name, t0.cat_id, FROM_UNIXTIME(t0.start_time) as start_time, t0.start_time as start_time_timestamp, t0.end_time as end_time_timestamp, FROM_UNIXTIME(t0.end_time) as end_time,t0.`name`,t0.min_discount, t0.goods_num, t0.brand_id, t0.wx_mini_program_show as wx_mini_program_show_value, if(t0.wx_mini_program_show=1, \'可见\', \'不可见\') as wx_mini_program_show, if(t0.qxb_status=1, \'上架\', \'下架\') as qxb_status, t1.tag_name, t2.brand_name ';
      const sql = `SELECT ${column} FROM group_buy_goods_activity t0 INNER JOIN group_buy_tag t1 ON t0.cat_id = t1.id INNER JOIN group_buy_aikucun_brand t2 ON t0.brand_id = t2.id WHERE t0.activity_id LIKE CONCAT(\'guan-fang-zi-ying-\', \'%\') order by t0.id desc limit ?,?`;
      const results = await this.app.mysql.query(sql, [page, pageSize]);
      return {
        code: 10000,
        msg: '成功',
        data: results
      };
    }
    async ownActOwnGoodsList(params) {
      if (typeof params.ownActId !== null && !isNaN(params.ownActId)) {
        const culumn = 'id,product_id,akc_tag_price,category,description,picture,akc_price,name,akc_settlement_price,akc_profit,brand_size_url,weight,volume,skus_attribute_list,sku_list,own_activity_id,sort,status,discount_rate,add_price,settlement_price,create_time,update_time,aikucun_activity_id,aikucun_brand_id,click_num,carry_flag,qxb_sort,type,stock,qxb_status,postage,supplier_name,supplier_goods_id,supplier_goods_name,only_settlement_price,detail_picture,own_brand_id';
        const sql = `SELECT ${culumn} FROM group_buy_goods WHERE own_activity_id = ? ORDER BY qxb_sort desc`;
        const results = await this.app.mysql.query(sql, [params.ownActId]);
        return {
          code: 10000,
          msg: '成功',
          data: results
        };
      }
      return {
        code: ErrCode.ERROR_CODE_PARAM,
        msg: '自营活动ID为空'
      };
    }

    async statusUpdateAct(params) {
      if (typeof params.ownActId !== null && !isNaN(params.ownActId) && typeof params.qxbStatus !== null && !isNaN(params.qxbStatus)) {
        const sql = 'UPDATE group_buy_goods_activity SET qxb_status = ? WHERE id = ?';
        await this.app.mysql.query(sql, [params.qxbStatus, params.ownActId]);
        return { code: 10000, msg: '成功' };
      }
      return { code: ErrCode.ERROR_CODE_PARAM, msg: '参数有误' };
    }

    async statusUpdateGoods(params) {
      if (typeof params.goodsId !== null && !isNaN(params.goodsId) && typeof params.qxbStatus !== null && !isNaN(params.qxbStatus)) {
        const sql = 'UPDATE group_buy_goods SET qxb_status = ? WHERE id = ?';
        await this.app.mysql.query(sql, [params.qxbStatus, params.goodsId]);
        return { code: 10000, msg: '成功' };
      }
      return { code: ErrCode.ERROR_CODE_PARAM, msg: '参数有误' };
    }

    async ownActEdit(params) {
      if (typeof params.id !== null && !isNaN(params.id)) {
        let changes = '';
        if (typeof params.description !== 'undefined') {
          changes = changes + ' description=' + params.description + ',';
        }
        if (typeof params.start_time !== 'null' && !isNaN(params.start_time)) {
          changes = changes + ' start_time=' + params.start_time + ',';
        }
        if (typeof params.end_time !== 'null' && !isNaN(params.end_time)) {
          changes = changes + ' end_time=' + params.end_time + ',';
        }
        if (typeof params.name !== 'undefined') {
          changes = changes + ' name=' + params.name + ',';
        }
        if (typeof params.min_discount !== 'null' && !isNaN(params.min_discount)) {
          changes = changes + ' min_discount=' + params.min_discount + ',';
        }
        if (typeof params.wx_mini_program_show !== 'null' && !isNaN(params.wx_mini_program_show)) {
          changes = changes + ' wx_mini_program_show=' + params.wx_mini_program_show + ',';
        }

        if (changes !== '') {
          const updateSql = `UPDATE group_buy_goods_activity SET ${changes.substring(0, changes.length - 1)} WHERE id = ${params.id}`;
          await this.app.mysql.query(updateSql);
        }
        return { code: 10000, msg: '成功' };
      }
      return { code: ErrCode.ERROR_CODE_PARAM, msg: '参数有误' };
    }

    async ownGoodsEdit(params) {
      if (typeof params.id !== null && !isNaN(params.id)) {
        let changes = '';
        if (typeof params.name !== 'undefined') {
          changes = changes + ' name=' + params.name + ',';
        }
        if (typeof params.description !== 'undefined') {
          changes = changes + ' description=' + params.description + ',';
        }
        if (typeof params.discount_rate !== 'null' && !isNaN(params.discount_rate)) {
          changes = changes + ' discount_rate=' + params.discount_rate + ',';
        }
        if (typeof params.supplier_name !== 'undefined') {
          changes = changes + ' supplier_name=' + params.supplier_name + ',';
        }
        if (typeof params.supplier_goods_id !== 'undefined') {
          changes = changes + ' supplier_goods_id=' + params.supplier_goods_id + ',';
        }
        if (typeof params.supplier_goods_name !== 'undefined') {
          changes = changes + ' supplier_goods_name=' + params.supplier_goods_name + ',';
        }
        if (params.settlement_price !== null && !isNaN(params.settlement_price)) {
          changes = changes + ' settlement_price=' + params.settlement_price + ',';
        }
        if (params.akc_tag_price !== null && !isNaN(params.akc_tag_price)) {
          changes = changes + ' akc_tag_price=' + params.akc_tag_price + ',';
        }
        if (params.only_settlement_price !== null && !isNaN(params.only_settlement_price)) {
          changes = changes + ' only_settlement_price=' + params.only_settlement_price + ',';
        }
        if (typeof params.picture !== 'undefined' && params.picture.length > 0) {
          changes = changes + ' picture=\'' + JSON.stringify(params.picture) + '\',';
        }
        if (typeof params.detail_picture !== 'undefined') {
          changes = changes + ' detail_picture=\'' + params.detail_picture + '\',';
        }

        if (changes !== '') {
          const updateSql = `UPDATE group_buy_goods SET ${changes.substring(0, changes.length - 1)} WHERE id = ${params.id}`;
          console.log('--------->' + updateSql);
          await this.app.mysql.query(updateSql);
        }
        return { code: 10000, msg: '成功' };
      }
      return { code: ErrCode.ERROR_CODE_PARAM, msg: '参数有误' };
    }

    async ownActAdd(params) {
      if (typeof params.description !== 'undefined'
      && typeof params.banner !== 'undefined' && params.banner.length > 0
      && typeof params.cat_id !== null && !isNaN(params.cat_id)
      && typeof params.start_time !== null && !isNaN(params.start_time)
      && typeof params.end_time !== null && !isNaN(params.end_time)
      && typeof params.name !== 'undefined'
      && typeof params.min_discount !== null && !isNaN(params.min_discount)
      && typeof params.goods_num !== null && !isNaN(params.goods_num)
      && typeof params.brand_id !== null && !isNaN(params.brand_id)
      && typeof params.wx_mini_program_show_value !== null && !isNaN(params.wx_mini_program_show_value)
      ) {
        // 获取最新的自营活动自营商品的activity id 用于计算下一个ID
        const baseActId = 'guan-fang-zi-ying-';
        const maxActIdSql = `SELECT activity_id FROM group_buy_goods_activity WHERE activity_id LIKE CONCAT(\'${baseActId}\','%') order by id desc limit 1`;
        const resultsMaxActId = await this.app.mysql.query(maxActIdSql);
        const resultsMaxActIdTemp = resultsMaxActId.length === 0 ? 0 : resultsMaxActId[0].activity_id;
        const activityId = baseActId + (Number(resultsMaxActIdTemp.replace(baseActId, '')) + 1);

        const insertDB = {
          description: params.description,
          cat_id: params.cat_id,
          start_time: params.start_time,
          end_time: params.end_time,
          name: params.name,
          min_discount: params.min_discount,
          goods_num: params.goods_num,
          brand_id: params.brand_id,
          wx_mini_program_show: params.wx_mini_program_show_value,
          activity_id: activityId,
          create_time: new Date().getTime() / 1000,
          update_time: new Date().getTime() / 1000,
          channel: 3,
          banner: JSON.stringify(params.banner)
        };

        const result = await this.app.mysql.insert('group_buy_goods_activity', insertDB);
        if (result.affectedRows === 1) {
          return { code: 10000, msg: '成功' };
        }
        return { code: ErrCode.ERROR_IMPORT_DATA, msg: '失败' };
      }
      return { code: ErrCode.ERROR_CODE_PARAM, msg: '参数有误' };
    }

    async ownGoodsAdd(params) {
      console.log('>>> ' + JSON.stringify(params));
      if (typeof params.akc_tag_price !== null && !isNaN(params.akc_tag_price)
      && typeof params.description !== 'undefined'
      && typeof params.picture !== 'undefined' && params.picture.length > 0
      && typeof params.name !== 'undefined'
      && typeof params.own_activity_id !== null && !isNaN(params.own_activity_id)
      && typeof params.settlement_price !== null && !isNaN(params.settlement_price)
      && typeof params.only_settlement_price !== null && !isNaN(params.only_settlement_price)
      && typeof params.discount_rate !== null && !isNaN(params.discount_rate)
      && typeof params.aikucun_activity_id !== 'undefined'
      && typeof params.aikucun_brand_id !== null && !isNaN(params.aikucun_brand_id)
      && typeof params.supplier_name !== 'undefined'
      && typeof params.supplier_goods_id !== 'undefined'
      && typeof params.supplier_goods_name !== 'undefined'
      && typeof params.akc_profit !== null && !isNaN(params.akc_profit)
      && typeof params.detail_picture !== 'undefined' && params.detail_picture.length > 0
      ) {
        // 获取该活动中最大的product id
        const maxProIdSql = `SELECT product_id FROM group_buy_goods WHERE own_activity_id = ${params.own_activity_id} ORDER BY id desc limit 1`;
        const resultsMaxProId = await this.app.mysql.query(maxProIdSql);
        let productId = '';
        if (resultsMaxProId.length > 0) {
          productId = params.aikucun_activity_id + '-' + (Number(resultsMaxProId[0].product_id.replace(params.aikucun_activity_id + '-', '')) + 1);
        } else {
          productId = params.aikucun_activity_id + '-' + 1;
        }

        const insertDB = {
          name: params.name,
          description: params.description,
          akc_tag_price: params.akc_tag_price,
          akc_profit: params.akc_profit,
          settlement_price: params.settlement_price,
          only_settlement_price: params.only_settlement_price,
          supplier_name: params.supplier_name,
          supplier_goods_id: params.supplier_goods_id,
          supplier_goods_name: params.supplier_goods_name,
          own_activity_id: params.own_activity_id,
          aikucun_activity_id: params.aikucun_activity_id,
          aikucun_brand_id: params.aikucun_brand_id,
          qxb_status: params.qxb_status,
          picture: JSON.stringify(params.picture),
          detail_picture: JSON.stringify(params.detail_picture),
          create_time: new Date().getTime() / 1000,
          update_time: new Date().getTime() / 1000,
          type: 3,
          discount_rate: params.discount_rate,
          weight: 1,
          volume: 1,
          brand_size_url: '无',
          category: '自营',
          product_id: productId
        };

        // 新增商品记录，商品全局ID记录
        await this.app.mysql.beginTransactionScope(async conn => {
          const result = await conn.insert('group_buy_goods', insertDB);
          console.log('....> ' + JSON.stringify(result));
          if (result.affectedRows === 1) {
            await conn.insert('product_overall', { product_id: result.insertId, order_type: 6, goods_id: result.insertId });
          }
        }, this.ctx);
        return { code: 10000, msg: '成功' };
      }
      return { code: ErrCode.ERROR_CODE_PARAM, msg: '参数有误' };
    }

    // 1 规格表新增记录， 价格判断 【页端判断】
    // 2 goods表的sku记录更新 【插入后全量更新】
    // 3 设置错误的SKU无法删除，只能下架商品再重建一个商品，或者将错误的SKU库存都改为0，不能删除SKU【设计到订单相关的问题，防止删除已经被购买的sku信息】
    // 4 批量新增
    async ownGoodsSkuAdd(params) {
      if (
        params.goods_id !== null && !isNaN(params.goods_id)
        && params.sku_inventory !== null && !isNaN(params.sku_inventory)
        && params.settlement_price !== null && !isNaN(params.settlement_price)
        && params.profit_price !== null && !isNaN(params.profit_price)
        && params.only_settlement_price !== null && !isNaN(params.only_settlement_price)
        && typeof params.product_id !== 'undefined'
        && params.attribute_list !== null && params.attribute_list.length > 0) {
        const productId = params.product_id;
        // 查询ID最大的SKU的sku_id
        const maxSkuIdSQL = `SELECT sku_id FROM group_buy_sku WHERE goods_id=${params.goods_id} ORDER BY id desc LIMIT 1`;
        const resultsMaxSkuId = await this.app.mysql.query(maxSkuIdSQL);
        let skuIdNum = 0;
        if (resultsMaxSkuId.length > 0) {
          skuIdNum = Number(resultsMaxSkuId[0].sku_id.replace(productId + '-', ''));
        }
        const sku_id = productId + '-' + (skuIdNum + 1);
        const attribute_list = JSON.stringify(params.attribute_list);
        // sku数据
        const insertSkuDB = {
          goods_id: params.goods_id,
          sku_inventory: params.sku_inventory,
          settlement_price: params.settlement_price,
          profit_price: params.profit_price,
          only_settlement_price: params.only_settlement_price,
          sku_id,
          attribute_list
        };

        await this.app.mysql.beginTransactionScope(async conn => {
          // 生产sku 记录信息
          const result = await conn.insert('group_buy_sku', insertSkuDB);
          if (result.affectedRows === 1) {
            const res = await this.updateSkuInfoBuyGoodsId(params.goods_id, conn);
            await conn.update('group_buy_goods', res);
          } else {
            return { code: ErrCode.ERROR_CODE_PARAM, msg: '新增sku失败' };
          }
        }, this.ctx);
        return { code: 10000, msg: '成功' };
      }
      return { code: ErrCode.ERROR_CODE_PARAM, msg: '参数有误' };
    }

    // 获取批量更新某商品的SKU信息对象，适用于事务中
    async updateSkuInfoBuyGoodsId(goods_id, conn) {
      const selectAllSkuSQL = `SELECT goods_id,sku_inventory,attribute_list,sku_id,settlement_price,profit_price,only_settlement_price FROM group_buy_sku WHERE goods_id = ${goods_id}`;
      const skus = await conn.query(selectAllSkuSQL);
      // group_buy_goods 表中的 skusAttributeList
      const skuSet = new Set();
      // group_buy_goods 表中的 skuList
      const skuList = [];
      for (const iterator of skus) {
        const attributeListTemp = [];
        // eslint-disable-next-line array-callback-return
        JSON.parse(iterator.attribute_list).map(function(sku) {
          // 这里的sku需要由对象转换为字符串
          skuSet.add(JSON.stringify(sku));
          attributeListTemp.push(sku);
        });

        const sku = {
          attributeList: attributeListTemp,
          skuId: iterator.sku_id,
          skuInventory: iterator.sku_inventory,
        };
        skuList.push(sku);
      }
      const skuSetNew = Array.from(skuSet).map(function(a) {
        return JSON.parse(a);
      });

      return { skus_attribute_list: JSON.stringify(skuSetNew), sku_list: JSON.stringify(skuList), id: goods_id };
    }

    async ownGoodsSkuSee(params) {
      if (params.goods_id !== null && !isNaN(params.goods_id)) {
        const results = await this.app.mysql.select('group_buy_sku', {
          where: { goods_id: params.goods_id },
          columns: ['id', 'goods_id', 'sku_inventory', 'attribute_list', 'sku_id', 'settlement_price', 'profit_price', 'only_settlement_price']
        });
        return { code: 10000, msg: '成功', data: results };
      } else {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '参数有误' };
      }
    }

    // 支持修改： 库存数量、规格名字
    async ownGoodsSkuEdit(params) {
      if (params.id !== null && !isNaN(params.id)
      && params.sku_inventory !== null && !isNaN(params.sku_inventory)
      && params.settlement_price !== null && !isNaN(params.settlement_price)
      && params.profit_price !== null && !isNaN(params.profit_price)
      && params.attribute_list !== null && params.attribute_list.length > 0
      && params.only_settlement_price !== null && !isNaN(params.only_settlement_price)) {

        const change = {
          id: params.id,
          sku_inventory: params.sku_inventory,
          settlement_price: params.settlement_price,
          profit_price: params.profit_price,
          only_settlement_price: params.only_settlement_price,
          attribute_list: JSON.stringify(params.attribute_list)
        };
        await this.app.mysql.beginTransactionScope(async conn => {
          // 生产sku 记录信息
          const result = await conn.update('group_buy_sku', change);
          if (result.affectedRows === 1) {
            const res = await this.updateSkuInfoBuyGoodsId(params.goods_id, conn);
            await conn.update('group_buy_goods', res);
          } else {
            return { code: ErrCode.ERROR_CODE_PARAM, msg: '新增sku失败' };
          }
        }, this.ctx);
        return { code: 10000, msg: '成功' };
      }
      return { code: ErrCode.ERROR_CODE_PARAM, msg: '参数有误' };
    }

    async batchGoodsBindOwnBrand(params) {

      if (params && typeof params.brand_id !== 'null' && !isNaN(params.brand_id && params.goods_ids && params.goods_ids.length > 0)) {
        const brandInfo = await this.app.mysql.get('brand', { id: params.brand_id, is_delete: 0 });
        if (brandInfo) {

          const updateSQL = 'UPDATE group_buy_goods SET own_brand_id = ? WHERE id in ?';
          await this.app.mysql.query(updateSQL, [params.brand_id, [params.goods_ids]]);
        } else {
          return { code: ErrCode.ERROR_CODE_PARAM, msg: '品牌信息不存在/已删除' };
        }
      } else {
        return { code: ErrCode.ERROR_CODE_PARAM, msg: '参数有误' };
      }
      return { code: 10000, msg: '成功' };
    }

    // 查询导出字段
    async putOutList(queries) {
      const catId = Number(queries.catId);
      const status = queries.status;
      const type = queries.type;
      const appType = queries.appType;
      const comingUp = queries.comingUp + '';
      const now = new Date().getTime() / 1000;
      const otherCatId = '(SELECT id FROM group_buy_tag WHERE admin_status IN(0,1))';
      let sortFieldStr = 'sort';
      let catSortFieldStr = 'cat_sort';
      let sortField = type === 1 ? 'sort' : 'cat_sort';
      let statusField = 'status';
      if (appType !== 2) {
        sortField = type === 1 ? 'qxb_sort' : 'qxb_cat_sort';
        statusField = 'qxb_status';
        sortFieldStr = 'qxb_sort';
        catSortFieldStr = 'qxb_cat_sort';
      }
      let condition = catId === 1 ? '' : catId === 10000 ? `AND a.cat_id  NOT IN ${otherCatId} ` : `AND a.cat_id = ${catId} `;
      if (comingUp === 'true') {
        condition += `AND a.start_time > ${now} `;
      }
      let listPriority = [];
      if (status === '' || status === 0 || status === 1) {
        if (status === 0) {
          condition += `AND a.${statusField} IN (0, -2) `;
        } else if (status === 1) {
          condition += `AND a.${statusField} = 1 `;
        } else {
          condition += `AND a.${statusField} != -1 `;
        }

        const brandTypePrioritySQL = `SELECT a.id as actId, a.name as actName, FROM_UNIXTIME(a.start_time) as startTime, FROM_UNIXTIME(a.end_time) as endTime, a.qxb_status, b.tag_name, c.brand_name as supBrandName, t4.brand_name as ownBrandName, gbg.id as goodsId, gbg.name as goodsName, gbg.settlement_price, gbg.only_settlement_price, gbg.akc_tag_price, gbg.discount_rate 
        FROM group_buy_goods_activity a 
        INNER JOIN group_buy_goods gbg ON a.id = gbg.own_activity_id 
        INNER JOIN group_buy_tag b ON a.cat_id = b.id  
        INNER JOIN group_buy_aikucun_brand c ON a.brand_id = c.id  
        LEFT JOIN brand t4 ON t4.id = c.brand_id 
        WHERE a.end_time > ${now} ${condition} group by gbg.id, a.id,b.id`;
        listPriority = await this.app.mysql.query(brandTypePrioritySQL);
      }
      const exportParam = {
        data: listPriority,
        headers: [
          { header: '活动ID', width: 10 },
          { header: '活动名', width: 10 },
          { header: '活动开始时间', width: 10 },
          { header: '活动结束时间', width: 10 },
          { header: '活动状态（1上架，0下架）', width: 10 },
          { header: '活动分类名', width: 10 },
          { header: '活动供应商品牌名', width: 10 },
          { header: '活动品牌库品牌名', width: 10 },
          { header: '商品ID', width: 20 },
          { header: '商品名', width: 20 },
          { header: '商品团购价', width: 10 },
          { header: '商品单买价', width: 10 },
          { header: '商品原价', width: 10 },
          { header: '商品折扣', width: 10 }
        ] };
      return await this.putOutExcel(exportParam);
    }

    async exportGoodsList(params) {
      const now = Math.floor(Date.now() / 1000);
      const filterEmpty = params.filterSoldOut;
      const categories = params.categories;
      const onSaleOnly = params.onSale_only;
      const hykOnly = params.hyk_only;
      const akcOnly = params.akc_only;
      let nameCondition = '';
      if (params.productName) {
        if (!isNaN(params.productName)) {
          nameCondition = ` AND a.id = ${params.productName}`;
        } else {
          nameCondition = ` AND a.name LIKE '%${params.productName}%'`;
        }
      }
      let discountCondition = '';

      if (typeof params.discount !== 'undefined' && params.discountFilter) {
        const discount = JSON.parse(params.discount);
        if (params.discountFilter === '~') {
          discountCondition = ` AND a.discount_rate >= ${discount[0]} AND a.discount_rate <= ${discount[1]}`;
        } else {
          discountCondition = ` AND a.discount_rate ${params.discountFilter} ${discount[0]}`;
        }
      }

      let addPriceCondition = '';
      if (typeof params.addPrice !== 'undefined'  && params.addPriceFilter) {
        const addPrice = JSON.parse(params.addPrice);
        if (params.addPriceFilter === '~') {
          addPriceCondition = ` AND a.add_price >= ${addPrice[0]} AND a.add_price <= ${addPrice[1]}`;
        } else {
          addPriceCondition = ` AND a.add_price ${params.addPriceFilter} ${addPrice[0]}`;
        }
      }


      let priceCondition = '';
      if (typeof params.price !== 'undefined' && params.priceFilter) {
        const price = JSON.parse(params.price);
        if (params.priceFilter === '~') {
          priceCondition = ` AND a.settlement_price >= ${price[0]} AND a.settlement_price <= ${price[1]}`;
        } else {
          priceCondition = ` AND a.settlement_price ${params.priceFilter} ${price[0]}`;
        }
      }

      let clickNumCondition = '';
      if (typeof params.clickNum !== 'undefined' && params.clickFilter) {
        const clickNum = JSON.parse(params.clickNum);
        if (params.clickFilter === '~') {
          clickNumCondition = ` AND a.click_num >= ${clickNum[0]} AND a.click_num <= ${clickNum[1]}`;
        } else {
          clickNumCondition = ` AND a.click_num ${params.clickFilter} ${clickNum[0]}`;
        }
      }
      // 关于活动结束时间的筛选

      let durationCondition = '';
      if (typeof params.durationNum !== 'undefined' && params.durationFilter) {
        const durationNum = JSON.parse(params.durationNum);
        if (params.durationFilter === '~') {
          durationCondition = ` AND (b.end_time - b.start_time)/3600 >= ${durationNum[0]} AND (b.end_time - b.start_time)/3600 <= ${durationNum[1]}`;
        } else {
          durationCondition = ` AND (b.end_time - b.start_time)/3600 ${params.durationFilter} ${durationNum[0]}`;
        }
      }

      // 关于佣金的筛选
      let commissionCondition = '';
      if (typeof params.commissionNum !== 'undefined' && params.commissionFilter) {
        const commissionNum = JSON.parse(params.commissionNum);
        if (params.commissionFilter === '~') {
          commissionCondition = ` AND a.akc_profit >= ${commissionNum[0]} AND a.akc_profit <= ${commissionNum[1]}`;
        } else {
          commissionCondition = ` AND a.akc_profit ${params.commissionFilter} ${commissionNum[0]}`;
        }
      }

      let categoryCondition = '';
      if (Array.isArray(categories) && categories.length !== 0) {
        categoryCondition = ` AND b.cat_id IN (${categories.join(',')})`;
      }

      let statusCondition = ' AND b.qxb_status != -1';
      if (onSaleOnly) {
        statusCondition = ' AND a.qxb_status = 1 AND b.qxb_status = 1';
      }

      let typeCondition = '';
      if (hykOnly) {
        typeCondition = ' AND a.type = 4';
      } else if (akcOnly) {
        typeCondition = ' AND a.type = 0';
      }

      let predicateCondition = '';
      if (!params.allow_predicate) {
        predicateCondition = ` AND b.start_time < ${now}`;
      }

      const querySQL = `SELECT b.id, b.name, a.id as goodsId,  a.name as goodsName, a.settlement_price, a.only_settlement_price, a.akc_tag_price, a.discount_rate, a.sku_list
                    , a.type, b.start_time, a.aikucun_activity_id
                    FROM 
                    group_buy_goods a, group_buy_goods_activity b,group_buy_tag gbt
                    WHERE
                    a.own_activity_id = b.id AND 
                    b.cat_id = gbt.id AND
                    b.end_time > ${now}
                    ${statusCondition}
                    ${typeCondition}
                    ${predicateCondition}
                    ${nameCondition} 
                    ${discountCondition}
                    ${addPriceCondition}
                    ${priceCondition}
                    ${clickNumCondition}
                    ${durationCondition}
                    ${commissionCondition}
                    ${categoryCondition}  GROUP BY a.id, b.id`;
      const products = await this.app.mysql.query(querySQL);
      const exportParam = {
        data: products,
        headers: [
          { header: '活动ID', width: 10 },
          { header: '活动名', width: 10 },
          { header: '商品ID', width: 20 },
          { header: '商品名', width: 20 },
          { header: '商品团购价', width: 10 },
          { header: '商品单买价', width: 10 },
          { header: '商品原价', width: 10 },
          { header: '商品折扣', width: 10 },
          { header: '规格', width: 10 },
          { header: '类型(0爱库存，4好衣库)', width: 10 },
          { header: '活动开始时间', width: 10 },
          { header: '活动ID', width: 10 }
        ] };
      return await this.putOutExcel(exportParam);
    }

    /**
     * 导出excel
     * @param{
     *  data:[], 数据列表
     *  sheetName: aaa, 可选参数
     *  headers: [] 列名，按照列表对象顺序传进来
     * }
     * @return excel文件的二进制流
     *  使用成功案例
     *  const ctx = this.ctx;
     *  const result = 二进制流
     *  ctx.set('Content-Type', 'application/octet-stream');
     *  ctx.acceptsCharsets('utf-8');
     *  ctx.attachment('文件名');
     *  ctx.body = result;
     */
    async putOutExcel(params) {
      const list = params.data;
      // 获取随机文件名
      const sheetName = params.sheetName === null ? 'sheet1' : params.sheetName;
      const workbook = new Excel.Workbook();
      const worksheet = workbook.addWorksheet(sheetName);
      worksheet.columns = params.headers;

      for (const index in list) {
        const info = list[index];
        const infoKeys = Object.keys(info);
        const infoValues = [];

        for (const key of infoKeys) {
          infoValues.push(info[key]);
        }

        worksheet.addRow(infoValues);
      }

      return workbook.xlsx.writeBuffer();
    }
  };
};