'use strict';

const Service = require('egg').Service;

class ClassroomService extends Service {
  async checkClass(params) {
    const pageSize = params.pageSize < 1 || params.pageSize > 30 ? 30 : params.pageSize;
    const page = (params.page - 1) * pageSize;
    const sql = `SELECT * FROM classroom  ORDER BY roomnumber  LIMIT ${page}, ${pageSize}`;
    const sum = `SELECT COUNT(*) as num FROM classroom`;
    const nowTime = Math.round(new Date() / 1000);
    const zerotime =new Date(new Date().toLocaleDateString()).getTime()/1000//获取当日零点时间戳
    const time1 =zerotime+30300;
    const time2 =zerotime+33600;
    const time3 =zerotime+38060;
    const time4 =zerotime+40500;
    const time5 =zerotime+50700;
    const time6 =zerotime+54000;
    const time7 =zerotime+57300;
    const time8 =zerotime+60600;
    const check =`SELECT * FROM approval_record WHERE time_stamp>=${zerotime}`;

    const conn = await this.app.mysql.beginTransaction(); // 初始化事务

    try {

      const total = await conn.query(sum);
      const results = await conn.query(sql); 
      await conn.commit(); // 提交事务
      return { msg: '成功', code: 10000, data: results,total};
    } catch (err) {
      console.log('----------事务执行失败----------');
      await conn.rollback(); // 一定记得捕获异常后回滚事务！！
      throw err;
    }


  }


  async deletClass(params){
    //删除教室
    const id = params.id;
    const results = await this.app.mysql.delete('classroom', {
      id:id,
    });
    return { msg: '删除成功', code: 10000, data: results};
  }


  async addClass(params){
    //添加教室
    const name = params.name;
    const number = params.number;
    const field = 'roomname,roomnumber,roomstate,roomstate_describe,truename,roomresult';
    const sql = `INSERT classroom(${field})VALUES('${name}',${number},0,'空','无',NULL)`;
    const results = await this.app.mysql.query(sql);
    return { msg: '插入成功', code: 10000, data: results};
  }
  async selectAll(params){
    //模糊搜索
    const number = params.roomnumber;
    const name = params.roomname;
    const state = params.state;
    const truenmame = params.truenmame;
    if (typeof params.page !== 'undefined' && typeof params.pageSize !== 'undefined') {
      let page = params.page < 1 ? 1 : params.page;
      const pageSize = params.pageSize < 1 || params.pageSize > 30 ? 30 : params.pageSize;
      page = (page - 1) * pageSize;
      let conditions = '';
      if(typeof number !== 'undefined' && number !== ''){
        conditions = conditions + ` AND roomnumber = ${number} `;
      }
      if(typeof name !== 'undefined' && name !== ''){
        conditions = conditions + ` AND roomname LIKE "%${name}%" `;
      }
      if(typeof state !== 'undefined' && state !== ''){
        conditions = conditions + ` AND roomstate_describe = "${state}" `;
      }
      if(typeof truenmame !== 'undefined' && truenmame !== ''){
        conditions = conditions + ` AND truename LIKE "%${truename}%" `;
      }
      const limit = `limit ${page}, ${pageSize}`;
      const sql = `SELECT * FROM classroom WHERE 1=1 `+ conditions + limit;
      const searchTotal = `SELECT COUNT(*) as sum FROM classroom WHERE 1=1 `+ conditions;
      // console.log(JSON.stringify('------'+sql+'---------'));
      const results = await this.app.mysql.query(sql);
      const stotal = await this.app.mysql.query(searchTotal);
      return {msg: '成功', code: 10000, data: results,stotal};
    }
  }

  async updateState(params){
    const roomnumber = params.roomnumber;
    const roomstate = params.roomstate;
    const roomresult= params.roomresult;
    const truename = params.truename;
    const describe = params.roomstate_describe
    const sql = `UPDATE classroom SET roomstate = ${roomstate},truename= '${truename}',roomresult='${roomresult}',roomstate_describe = '${describe}' WHERE roomnumber = ${roomnumber} `;
    const results = await this.app.mysql.query(sql);
    return{msg: '成功', code: 10000, data: results};
  }


}

module.exports = ClassroomService;
