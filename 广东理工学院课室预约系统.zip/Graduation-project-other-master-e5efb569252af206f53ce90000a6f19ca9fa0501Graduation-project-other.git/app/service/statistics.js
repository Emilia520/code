const Service = require('egg').Service;
const ErrCode = require('../utils/errorCode');
const checker = require('../utils/paramChecker');

const activities = {};

module.exports = () => {
  return class Statistics extends Service {
    async newerInfo(params = {}) {
      // 校验参数
      checker.check(checker.paramType.PARAM_TYPE_INT, params.activity_id, '活动ID');
      checker.check(checker.paramType.PARAM_TYPE_INT, params.action_id, '推广状态');

      const ctx = this.ctx;
      // 加载一次活动列表
      if (Object.keys(activities).length == 0) {
        const list = await this.app.mysql.select('newer_activity');
        console.log('加载活动列表', list);
        for (const i in list) {
          const activity = list[i];
          activities[activity.id] = activity;
        }
      }

      let list;
      let totalCountArr;
      await this.app.mysql.beginTransactionScope(async conn => {
        const conditionObj = this.parseQueryCondition(params);
        const mobile = this.getMobileParam(params);
        const orderTable = this.getOrderTable(params);
        const queryParam = '*';
        const countParam = 'COUNT(1)';
        const sql = 'SELECT {{param_replace}} FROM (SELECT d.id, d.name, d.phone, e.province, f.city, g.area, h.role_id, ' + mobile + "i.code, GROUP_CONCAT(CONCAT(b.remark, ' 时间：', FROM_UNIXTIME(a.time, '%Y-%m-%d %H:%i:%s')) Separator ',') AS detail FROM (SELECT * FROM record_newer_action " +
        conditionObj.tmpWhere +
        'GROUP BY order_code) tmp, record_newer_action a, action b,' + orderTable + ' c, user d, config_province e, config_city f, config_area g, user_role_relation h, user_invitation i WHERE tmp.order_code = a.order_code AND a.newer_action_id = b.id AND a.order_code = c.order_code AND c.user_id = d.id ' +
        conditionObj.where +
        'AND d.province_id = e.id AND d.city_id = f.id AND d.area_id = g.id AND d.id = h.user_id ' +
        conditionObj.roleWhere +
        'AND d.invitation_id = i.id GROUP BY a.order_code) aa ';
        list = await conn.query(sql.replace('{{param_replace}}', queryParam) + conditionObj.limit);
        totalCountArr = await conn.query(sql.replace('{{param_replace}}', countParam));
        return { success: true };
      }, ctx);
      return { list, totalCount: Object.values(totalCountArr[0])[0] };
    }

    getMobileParam(params) {
      let param = 'c.mobile AS mobile, ';
      if (params.activity_type === 2 && params.activity_id !== 10 && params.activity_id !== 2) {
        param = '';
      } else if (params.activity_type === 4) {
        param = 'c.phone AS mobile, ';
      }
      return param;
    }

    getOrderTable(params) {
      let tbl = 'order_newer';
      if (params.activity_type === 2 && params.activity_id !== 10 && params.activity_id !== 2) {
        tbl = 'order_newer_alipay';
      } else if (params.activity_type === 4) {
        tbl = 'order_newer_ctcc_card';
      }
      return tbl;
    }

    parseQueryCondition(params) {
      const whereConditions = [];
      const tmpWhereConditions = [];
      let where = '';
      let tmpWhere = '';
      let roleWhere = '';
      let limit = '';
      let start_time;
      let end_time;
      // 解析参数
      if (params.action_id > 0) {
        tmpWhereConditions.push('newer_action_id = ' + params.action_id + ' ');
      } else {
        let actions = [1, 2, 3, 4];
        if (params.activity_type == 0) {
          actions = [1, 2, 3, 4];
        } else if (params.activity_type == 1) {
          actions = [5, 6, 7];
        } else if (params.activity_type == 2) {
          actions = [13, 14];
        } else if (params.activity_type == 3) {
          actions = [16];
        } else if (params.activity_type == 4) {
          actions = [20];
        }
        tmpWhereConditions.push('newer_action_id IN (' + actions + ') ');
      }

      if (params.activity_id > 0) {
        const activity = activities[params.activity_id];
        start_time = activity.start_time;
        end_time = activity.end_time;
      }

      if (start_time && end_time) {
        tmpWhereConditions.push('time >= ' + start_time + ' ');
        tmpWhereConditions.push('time <= ' + end_time + ' ');
      }

      if (params.phone && params.phone.length > 0) {
        whereConditions.push('d.phone = ' + params.phone + ' ');
      }

      if (params.provinces && params.provinces.length > 0) {
        whereConditions.push('d.province_id IN (' + params.provinces.join(',') + ') ');
      }

      if (params.cities && params.cities.length > 0) {
        whereConditions.push('d.city_id IN (' + params.cities.join(',') + ') ');
      }

      if (params.areas && params.areas.length > 0) {
        whereConditions.push('d.area_id IN (' + params.areas.join(',') + ') ');
      }

      for (const i in tmpWhereConditions) {
        const condition = tmpWhereConditions[i];
        if (i == 0) {
          tmpWhere += 'WHERE ' + condition;
        } else {
          tmpWhere += 'AND ' + condition;
        }
      }

      for (const i in whereConditions) {
        const condition = whereConditions[i];
        where += 'AND ' + condition;
      }

      if (params.role_id) {
        roleWhere += 'AND h.role_id = ' + params.role_id + ' ';
      }

      const pageNum = params.pageNum != null ? params.pageNum : 1;
      const pageSize = params.pageSize != null ? params.pageSize : 10;
      limit += 'LIMIT ' + (pageNum - 1) * pageSize + ',' + pageSize;

      return { tmpWhere, where, roleWhere, limit };
    }
  };
};