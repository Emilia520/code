const Service = require('egg').Service;
const ErrCode = require('../utils/errorCode');
const utils = require('../utils/utils');
// let token = '9a2b38fad710ff355da5b658d3ef23e1';
let token = '';

module.exports = () => {
  return class YJiYun extends Service {
    async checkResultAndAuth(result) {
      if (result && result.data && result.data.code === '1000') {
        this.logger.info('认证失败，尝试重新登陆获取token');
        const authResult = await this.auth();
        if (authResult.code === 0 && authResult.token) {
          this.logger.info('重新登陆成功，token', authResult.token);
          return true;
        }
      }

      return false;
    }

    async sendWXGroupMsgImmediately(sendData = {}, config = {}) {
      const ctx = this.ctx;
      let result = { data: { code: '1', msg: '有机云token为空，请联系开发人员配置' } };
      if (config.sendType === 0) {
        sendData.communityCode = config.communityCode;
        sendData.groupWxids = config.groupWxidsStr.split(',');
      } else if (config.sendType === 1) {
        sendData.sender = [];
        sendData.sender.push({
          robotKey: config.robotKey,
          contactWxids: config.groupWxidsStr.split(',')
        });
      } else {
        this.logger.error('发送群消息配置有误', config);
        result.data.msg = '发送群消息配置有误';
        return result;
      }

      this.logger.info('将要发送消息', sendData);

      let token = await this.getToken();
      if (token) {
        result = await sendReq(token);
      }

      if (await this.checkResultAndAuth(result)) {
        token = await this.getToken();
        if (token) {
          result = await sendReq(token);
        }
      }
      return result;

      async function sendReq(token) {
        const url = config.sendType === 0 ? `https://www.yjiyun.com/oapi/community/send/msg?token=${token}` : `https://www.yjiyun.com/robotapi/msg/batch/send?token=${token}`;
        const result = await ctx.curl(url, {
          method: 'POST',
          contentType: 'json',
          data: sendData,
          dataType: 'json',
          timeout: 15000
        });

        return result;
      }
    }

    async communityCodeList() {
      const result = await this.app.mysql.select('tb_pid', {
        columns: ['id', 'pid'],
        where: {
          status: 1,
          type: 10
        }
      });

      return result;
    }

    async wxValidGroupList() {
      const ctx = this.ctx;
      const sql = 'select tmp.*, c.nickname from (select a.*, b.name, b.phone, b.type, d.name as cat_name from robot_group_info a, user b, robot_group_category d where a.enable = 1 and a.user_id = b.id and a.category = d.id) tmp left join robot c on tmp.robot_id = c.id';
      // const result = await this.app.mysql.select('robot_group_info', {
      //   where: {
      //     enable: 1
      //   }
      // });
      const result = await this.app.mysql.query(sql);

      return result;
    }

    // 转发小程序卡片
    async sendWXMiniProgram(params) {
      const ctx = this.ctx;
      const ret = await ctx.curl(`https://www.yjiyun.com/yunPortal/api/sendsmallprogram?token=${token}`, {
        method: 'POST',
        contentType: 'json',
        data: {
          robotKey: params.robotKey,
          sendSmallProgramData: params.data
        },
        dataType: 'json'
      });

      if (await this.checkResultAndAuth(ret)) {
        token = await this.getToken();
        if (token) {
          return await this.sendWXMiniProgram(params);
        }
      }

      return ret;
    }

    // 根据机器人ID查询机器人管理的所有的群
    async queryRobotGroups(params) {
      let list = [];
      let count = 0;
      const ctx = this.ctx;
      const page = params.page;
      const pageSize = params.pageSize;

      const ret = await ctx.curl(`https://www.yjiyun.com/robotapi/group/list?token=${token}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        data: {
          r: params.robotKey,
          n: pageSize || 10000,
          offset: page || 0,
        },
        dataType: 'json'
      });

      if (await this.checkResultAndAuth(ret)) {
        token = await this.getToken();
        if (token) {
          return await this.queryRobotGroups(params);
        }
      } else {
        if (ret && ret.data && ret.data.code === '0' && ret.data.model && ret.data.model.length > 0) {
          list = ret.data.model;
          count = ret.data.model.length;
        }
      }

      return { list, count };
    }

    async updateWXGroupList() {
      const ctx = this.ctx;
      const resultList = [];
      // 先获取当前在用的群列表
      const sql = 'select a.*, b.robot_key from robot_group_info a, robot b where a.enable > 0 and a.robot_id = b.id order by b.id;';
      const groupList = await this.app.mysql.query(sql);
      if (groupList.length === 0) {
        return { msg: '没有群要更新', data: [] };
      }
      // 建立两个内存映射对象方便后续更新
      const wxidMap = {};
      const robotKeyMap = {};
      for (const i in groupList) {
        const group = groupList[i];
        wxidMap[group.group_wxid] = {};
        robotKeyMap[group.robot_key] = {};
      }
      // 调用有机云接口查询每个机器人下的群信息
      for (const key in robotKeyMap) {
        const result = await this.queryRobotGroups({ robotKey: key });
        robotKeyMap[key] = result;
      }
      // 把请求到的数据更新到数据库中
      await this.app.mysql.beginTransactionScope(async conn => {
        for (const key in robotKeyMap) {
          const robotGroupInfo = robotKeyMap[key];
          for (const i in robotGroupInfo.list) {
            const groupInfo = robotGroupInfo.list[i];
            // 如果群id是需要更新的群，则更新
            if (wxidMap[groupInfo.wxid]) {
              resultList.push(groupInfo);
              const sql = `update robot_group_info set group_name = '${groupInfo.displayName}', group_member_count = ${groupInfo.groupMemberCount}, update_time = '${groupInfo.updateTime}', status = ${groupInfo.status} where group_wxid = '${groupInfo.wxid}'`;
              await conn.query(sql);
            }
          }
        }
      }, ctx);

      return { msg: 'ok', data: resultList };
    }

    async validGroupWxids(communityCode) {
      if (!communityCode) {
        return [];
      }

      const result = await this.app.mysql.select('robot_group_info', {
        columns: ['group_wxid'],
        where: {
          communityCode,
          enable: 1
        }
      });
      const list = result.map(item => {
        return item.group_wxid;
      });

      return list;
    }

    async auth() {
      const ctx = this.ctx;
      const ret = { code: -1, token: '' };
      const result = await ctx.curl('https://www.yjiyun.com/robotapi/client/auth', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        data: {
          accessKey: 'quexb',
          accessSecret: 'qwerdf'
        },
        dataType: 'json'
      });

      if (result && result.data && result.data.code === '0' && result.data.data.accessToken) {
        token = result.data.data.accessToken;
        ret.code = 0;
        ret.token = token;
        await this.app.mysql.update('config_read_data', { authorization: token }, { where: { type: 5 } });
      }

      return ret;
    }

    async getToken() {
      if (!token) {
        const result = await this.app.mysql.select('config_read_data', {
          where: {
            type: 5,
            status: 1
          },
          columns: ['authorization'],
          limit: 1
        });
        if (result.length > 0) {
          token = result[0].authorization;
        }
        console.log('getToken: ', token);
      }

      return token;
    }

    async updateRobotList() {
      const ctx = this.ctx;
      const token = await this.getToken();
      const result = await ctx.curl(`https://www.yjiyun.com/robotapi/robot/list?token=${token}`, {
        method: 'POST',
        dataType: 'json'
      });
      if (result && result.data && result.data.code === '0' && result.data.model.length > 0) {
        await this.app.mysql.beginTransactionScope(async conn => {
          for (const i in result.data.model) {
            const robotInfo = result.data.model[i];
            // const sql = utils.genInsertDupUpdateSql('robot', robotInfo, 'robotId');
            const sql = `INSERT INTO robot (nickname, alias_name, robot_key, head_img, robot_status, client_code, wxid, last_login_time) 
                        VALUES ('${robotInfo.nickName}', '${robotInfo.aliasName}', '${robotInfo.robotKey}', '${robotInfo.headImg}', ${robotInfo.robotStatus}, '${robotInfo.clientCode}', '${robotInfo.wxid}', '${robotInfo.lastLoginTime}') 
                        ON DUPLICATE KEY UPDATE nickname = '${robotInfo.nickName}', alias_name = '${robotInfo.aliasName}', head_img = '${robotInfo.headImg}', robot_status = '${robotInfo.robotStatus}', last_login_time = '${robotInfo.lastLoginTime}'`;
            await conn.query(sql);
          }
        }, ctx);
      }

      return result;
    }
  };
};