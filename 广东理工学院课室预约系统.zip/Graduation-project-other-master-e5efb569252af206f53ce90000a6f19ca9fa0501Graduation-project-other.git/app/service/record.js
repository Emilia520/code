'use strict';

const Service = require('egg').Service;

class RecordService extends Service {
  async historyRecord(params) {
    const name = params.name;
    const pageSize = params.pageSize < 1 || params.pageSize > 30 ? 30 : params.pageSize;
    const page = (params.page-1) * pageSize;
    const sql =` SELECT * FROM appoint_record WHERE username = '${name}' AND appoint_cancle = 0 ORDER BY order_id desc LIMIT ${page}, ${pageSize}`;
    const sum = `SELECT COUNT(*) as num FROM appoint_record`;
    // const results = await this.app.mysql.query(sql);
    // return { code: 10000, msg: '成功', data:results};
    
    // const time =new Date(new Date().toLocaleDateString()).getTime()/1000//获取当日零点时间戳     
    const time =Math.round(new Date() / 1000);  
    const conn = await this.app.mysql.beginTransaction(); // 初始化事务
    try { 
      let search = await conn.query(sql);
      for(let i=0;i<search.length;i++){
        if(search[i].time_stamp<time){
          const overTime = search[i].time_stamp;
          const change = ` UPDATE appoint_record SET appoint_state = 2 WHERE username = '${name}' AND time_stamp = ${overTime} AND appoint_state = 0 `;
          await conn.query(change);
        }
      }
      const results =await conn.query(sql); 
      const total = await conn.query(sum);
      await conn.commit(); // 提交事务
      return { code: 10000, msg: '成功', data:results,total};
    } catch (err) {
      // error, rollback
      console.log('----------事务执行失败----------');
      await conn.rollback(); // 一定记得捕获异常后回滚事务！！
      throw err;
    }
  }
  async updateState(params){
    const name = params.username;
    const roomnumber = params.roomnumber;
    const time =params.time_stamp;
    const sql = ` UPDATE appoint_record SET appoint_cancle = 1 WHERE username = '${name}' AND roomnumber = ${roomnumber} AND time_stamp = ${time} `;
    // console.log('-------'+sql+'-----');
    const result = await this.app.mysql.query(sql);
    return {code: 10000, msg: '成功', data:result}
  }

  //预约记录表模糊搜索
  async findRecord(params){
    const pageSize = params.pageSize < 1 || params.pageSize > 30 ? 30 : params.pageSize;
    const page = (params.page - 1) * pageSize;
    const roomname = params.roomname;
    const roomnumber = params.roomnumber;
    const state = params.appoint_state;
    const roomtime = params.appointTime;
    if (typeof params.page !== 'undefined' && typeof params.pageSize !== 'undefined') {
      let conditions = '';
      if(typeof roomnumber !== 'undefined' && roomnumber !== ''){
        conditions = conditions + ` AND roomnumber = ${roomnumber} `;
      }
      if(typeof roomname !== 'undefined' && roomname !== ''){
        conditions = conditions + ` AND roomname LIKE "%${roomname}%" `;
      }
      if(typeof state !== 'undefined' && state !== ''){
        conditions = conditions + ` AND appoint_state = ${state} `;
      }
      if(typeof roomtime !== 'undefined' && roomtime !==0&&typeof roomtime !==NaN && typeof roomtime !==null){
        conditions = conditions + ` AND roomtime = ${roomtime} `;
      }
      console.log('-------->'+conditions+'<--------');
      const limit = `limit ${page}, ${pageSize}`;
      const sql = `SELECT * FROM appoint_record WHERE 1=1 `+ conditions + limit;
      const results = await this.app.mysql.query(sql);
      const alltotal = `SELECT COUNT(*) as alltotal FROM appoint_record WHERE 1=1 `+conditions;
      const searchTotal = await this.app.mysql.query(alltotal);
      return {code: 10000, msg: '成功', data:results,searchTotal}
    }
  }
}

module.exports = RecordService;
