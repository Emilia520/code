const Service = require('egg').Service;

module.exports = () => {
  return class UserService extends Service {
    async info(params) {
      let totalCount = 0;
      let result = [];
      const phone = params.phone ? `and a.phone = ${params.phone} ` : '';
      const id = params.id ? `and a.id = ${params.id} ` : '';
      const name = params.name ? `and a.name like '%${params.name}%' ` : '';
      const role_id = params.role_id ? `and b.role_id = ${params.role_id} ` : '';
      const pageNum = params.pageNum || 1;
      const pageSize = params.pageSize || 10;
      const limit = `LIMIT ${(pageNum - 1) * pageSize}, ${pageSize}`;
      const sql = `select a.*,b.role_id, c.up_id,c.partner_id,c.captain_id from user a , user_role_relation b ,user_relation c where a.id = b.user_id and a.id = c.user_id ${phone} ${name} ${role_id}${id} ${limit}`;
      const sqlCount = `select count(*) from user a , user_role_relation b  where a.id = b.user_id ${phone} ${name} ${role_id} ${id} `;
      const count = await this.app.mysql.query(sqlCount);
      totalCount = count && count[0] ? Object.values(count[0])[0] : 0;
      if (totalCount > 0) {
        result = await this.app.mysql.query(sql);
      }
      return {
        pageNum,
        pageSize,
        totalNum: totalCount,
        data: result
      };
    }

    // 升级团长
    async upQxbCaptain(params) {
      const phoneList = [];
      phoneList.push(params.phone);
      const key = params.key;
      const result = await this.ctx.curl(`${this.config.api.java_host}/userUpGradeController/upQxbCaptain`, {
        method: 'POST',
        contentType: 'json',
        data: {
          phone: phoneList,
          key: key
        },
        dataType: 'json'
      });
      const data = result.data;
      return data;
    }
    // 升级合伙人
    async upQxbPartner(params) {
      const phoneList = [];
      phoneList.push(params.phone);
      const key = params.key;
      const result = await this.ctx.curl(`${this.config.api.java_host}/userUpGradeController/upQxbPartner`, {
        method: 'POST',
        contentType: 'json',
        data: {
          phone: phoneList,
          key: key
        },
        dataType: 'json'
      });
      const data = result.data;
      return data;
    }

    // 获取省市区
    async findRegion(params) {
      const result = await this.ctx.curl(`${this.config.api.java_host}/region/findAll`, {
        method: 'POST',
        contentType: 'json',
        data: {},
        dataType: 'json'
      });
      const data = result.data.data;
      return data;
    }

    // 检查邀请码
    async checkCode(params) {
      const code = params.code;
      const sql = `select * from user_invitation where code = '${code}'`;
      const result = await this.app.mysql.query(sql);
      if (result.length > 0) {
        return '邀请码已被使用';
      }
    }

    // 检查手机号
    async checkPhone(params) {
      const phone = params.phone;
      const sql = `select * from user where phone = '${phone}' and type = 1`;
      const result = await this.app.mysql.query(sql);
      if (result.length > 0) {
        return '手机号已被使用';
      }
    }

    // 创建用户
    async createUser(params) {
      const ctx = this.ctx;
      // 获取省市区
      const area_id = params.area_id;
      const phone = params.phone;
      const name = params.name;
      const avatar_url = params.avatar_url;
      const invitationCode = params.invitationCode;
      const role_id = params.role_id;
      const up_id = params.up_id;
      const ret = await this.app.mysql.beginTransactionScope(async conn => {
        const sql = `select b.id city_id, c.id province_id from config_area a,config_city b ,config_province c where a.id = ${area_id} and a.city_id = b.id and b.province_id = c.id`;
        const result = await conn.query(sql);
        const city_id = result[0].city_id;
        const province_id = result[0].province_id;
        // 创建邀请码
        const sqlCreateInvitationCode = `insert into user_invitation (code,status)value('${invitationCode}',1)`;
        await await conn.query(sqlCreateInvitationCode);
        const sqlSelectInvitationCode = `select id from user_invitation where code = '${invitationCode}'`;
        const invitationCodeIds = await conn.query(sqlSelectInvitationCode);
        const invitationCodeId = invitationCodeIds[0].id;
        const update_time = Date.parse(new Date()) / 1000;
        // 创建用户
        const sqlCreateUser = `insert into user (name,phone,avatar_url,area_id,city_id,province_id,type,invitation_id ,create_time)value('${name}','${phone}','${avatar_url}',${area_id},${city_id},${province_id},1,${invitationCodeId},${update_time})`;
        await await conn.query(sqlCreateUser);
        // 查询用户id
        const sqlSelectUser = `select id from user where phone = '${phone}' and type = 1`;
        const ids = await conn.query(sqlSelectUser);
        const id = ids[0].id;
        // 创建等级表
        const sqlCreateUserRole = `insert into user_role_relation (user_id,role_id)value(${id},${role_id})`;
        await await conn.query(sqlCreateUserRole);
        // 创建等级记录表
        const role_name = role_id === 1 ? 'vip1' : role_id === 2 ? 'vip2' : 'vip3';
        const sqlCreateUserRoleRecord = `insert into user_role_record (user_id,role_name,update_time)value(${id},'${role_name}',${update_time})`;
        await await conn.query(sqlCreateUserRoleRecord);
        // 创建关系表
        const captain_id = role_id === 1 ? 0 : id;
        const sqlCreateUserRelation = `insert into user_relation (user_id,partner_id,up_id,relation_link,captain_id)value(${id},-1,-1,'-',${captain_id})`;
        await await conn.query(sqlCreateUserRelation);
        // 创建账户
        const sqlCreateUserAccount = `insert into account (user_id)value(${id})`;
        await await conn.query(sqlCreateUserAccount);
      }, ctx);
    }
  };
};