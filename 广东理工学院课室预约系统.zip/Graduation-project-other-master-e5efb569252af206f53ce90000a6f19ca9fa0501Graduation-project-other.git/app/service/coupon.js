const Service = require('egg').Service;

module.exports = () => {
  return class Coupon extends Service {
    async update() {
      const ctx = this.ctx;
      const url = ctx.app.config.api.coupon_host + '/njia/coupon/categorys';
      // 获取优惠券的目录信息
      const result = await ctx.curl(url, {
        dataType: 'json'
      });
      const data = result.data;
      console.log('request url : ', url);
      console.log('result data : ', data);
      const categorys = [];

      // 解析返回数据为自有对象
      if (data.code === 200 && data.data.list != null) {
        this.convertCategorys(data.data.list, categorys);
      }

      // 写入数据库
      const ret = await this.app.mysql.beginTransactionScope(async conn => {
        for (const i in categorys) {
          const category = categorys[i];
          await conn.insert('coupon_categorys', category);
        }
        return { success: true };
      }, ctx);

      return ret;
    }

    async updateCoupon(categoryId) {
      const ctx = this.ctx;
      const url = ctx.app.config.api.coupon_host + '/njia/coupon/vip?firstCategoryId=' + categoryId + '&page=0&size=100';
      // 获取优惠券的目录信息
      const result = await ctx.curl(url, {
        dataType: 'json'
      });
      const data = result.data;
      console.log('request url : ', url);
      console.log('result data : ', data);
      const coupons = [];
      // 解析返回数据为自有对象
      if (data.code === 200 && data.data.list != null) {
        this.convertCoupons(data.data.list, coupons);
      }

      // 写入数据库
      const ret = await this.app.mysql.beginTransactionScope(async conn => {
        for (const i in coupons) {
          const coupon = coupons[i];
          const sql = 'REPLACE INTO coupon (coupon.id, coupon.category_id, coupon.title, coupon.desc, coupon.detail, coupon.money, coupon.start_time, coupon.end_time, coupon.url, coupon.url_type, coupon.remark, coupon.status, coupon.limit) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);';
          // await conn.insert('coupon', coupon);
          conn.query(sql, [coupon.id, coupon.category_id, coupon.title, coupon.desc, coupon.detail, coupon.money, coupon.start_time, coupon.end_time, coupon.url, coupon.url_type, coupon.remark, coupon.status, coupon.limit]);
        }
        return { success: true };
      }, ctx);

      return ret;
    }

    // Private Method
    convertCategorys(origins, targets) {
      for (const i in origins) {
        const category = origins[i];
        targets.push({
          id: category.id,
          name: category.categoryName,
          logo: category.categoryLogo,
          parent_id: category.parentId
        });

        if (category.childCategorys != null && category.childCategorys.length > 0) {
          this.convertCategorys(category.childCategorys, targets);
        }
      }
    }

    convertCoupons(origins, targets) {
      for (const i in origins) {
        const coupon = origins[i];
        const startDate = new Date(coupon.startTime);
        const endDate = new Date(coupon.endTime);
        targets.push({
          id: coupon.id,
          category_id: coupon.secondCategoryId,
          title: coupon.couponTitle,
          desc: coupon.couponDesc,
          detail: coupon.couponDetail,
          money: coupon.couponMoney,
          limit: coupon.couponLimit,
          start_time: (startDate.getTime() + startDate.getTimezoneOffset() * 60000) / 1000,
          end_time: (endDate.getTime() + endDate.getTimezoneOffset() * 60000) / 1000,
          url: coupon.couponUrl,
          url_type: coupon.couponUrlType,
          remark: coupon.remark,
          status: coupon.status
        });
      }
    }
  };
};