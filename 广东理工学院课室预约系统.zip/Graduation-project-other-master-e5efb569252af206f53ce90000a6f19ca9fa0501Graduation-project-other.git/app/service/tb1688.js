const Service = require('egg').Service;
const ErrCode = require('../utils/errorCode');
const utils = require('../utils/utils');
const crypto = require('crypto');

module.exports = () => {
  return class Tb1688 extends Service {
    // 遍历爬取类目信息
    async updateCategories(parentIds = [0]) {
      if (parentIds.length > 0) {
        for (const i in parentIds) {
          const parentId = parentIds[i];
          const result = await this.getCategory({ categoryID: parentId });
          if (result.data.succes && result.data.categoryInfo && result.data.categoryInfo[0]) {
            const catIds = [];
            const catInfo = result.data.categoryInfo[0];
            if (catInfo.childCategorys && catInfo.childCategorys.length > 0) {
              await this.app.mysql.beginTransactionScope(async conn => {
                for (const i in catInfo.childCategorys) {
                  const cat = catInfo.childCategorys[i];
                  catIds.push(cat.id);
                  const sql = `INSERT INTO tb_1688_product_category (cat_id, cat_name, parent_id) 
                      SELECT ${cat.id}, '${cat.name}', ${parentId}
                        FROM DUAL
                        WHERE NOT EXISTS (SELECT id FROM tb_1688_product_category WHERE cat_id = ${cat.id});`;
                  await conn.query(sql);
                }
              });
            }
            // 如果是叶子就不用递归查询了
            if (!catInfo.isLeaf && catIds.length > 0) {
              await this.updateCategories(catIds);
            }
          }
        }
      }
    }
    // 获取一级分类列表
    async catList() {
      return await this.app.mysql.select('tb_1688_product_category', {
        where: {
          parent_id: 0
        },
        columns: ['id', 'cat_id', 'cat_name'],
        orders: [['sort', 'desc']]
      });
    }
    /** *********** 商品相关 start ************/
    // 类目查询
    async getCategory(params) {
      return await this.sendRequest('com.alibaba.product/alibaba.category.get', params);
    }

    // 商品列表查询
    async goodsList(params) {
      const result = await this.sendRequest('com.alibaba.p4p/alibaba.cps.listOverPricedOffer', params);
      return { list: result.data.result, totalCount: result.data.totalRow };
    }

    // 商品详情查询
    async goodsDetail(params) {
      const result = await this.sendRequest('com.alibaba.product/alibaba.cpsMedia.productInfo', params);
      return result.data;
    }

    // 价格雷达
    async goodsPriceRadar(params) {
      const result = await this.sendRequest('com.alibaba.p4p/alibaba.cps.listPriceRadarOffer', params);
      return { list: result.data.result };
    }

    // 营销活动信息查询
    async goodsDetailActivity(params) {
      const result = await this.sendRequest('com.alibaba.p4p/alibaba.cps.queryOfferDetailActivity', params);
      return result.data.result;
    }

    // 关注商品
    async goodsFollow(params) {
      const result = await this.sendRequest('com.alibaba.product/alibaba.product.follow', params);
      return result.data;
    }

    // 取消关注商品
    async goodsUnfollow(params) {
      const result = await this.sendRequest('com.alibaba.product/alibaba.product.unfollow.crossborder', params);
      return result.data;
    }
    /** *********** 商品相关 end ************/

    async sendRequest(method, params) {
      const { ctx, config } = this;
      // 1.补全参数
      params.access_token = config.tb1688.access_token;
      // 2.构造签名因子
      const urlPath = `${config.tb1688.base_path}/${method}/${config.tb1688.app_key}`;
      let valStr = '';
      const keys = Object.keys(params).sort();
      for (const i in keys) {
        const key = keys[i];
        valStr += `${key}${params[key]}`;
      }
      // 3.合并两个签名因子
      const oriStr = `${urlPath}${valStr}`;
      // 4.对合并后的签名因子执行hmac_sha1算法
      const hash = crypto.createHmac('sha1', config.tb1688.app_secret);
      hash.update(oriStr);
      const sign = hash.digest('hex').toUpperCase();
      // 5.发请求
      params._aop_signature = sign;
      const result = await ctx.curl(`${config.tb1688.base_url}/${method}/${config.tb1688.app_key}`, {
        method: 'POST',
        dataType: 'json',
        data: params,
      });

      return result;
    }
  };
};