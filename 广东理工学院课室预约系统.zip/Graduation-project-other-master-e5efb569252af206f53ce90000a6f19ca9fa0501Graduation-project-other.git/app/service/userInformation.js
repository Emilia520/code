'use strict';
const Service = require('egg').Service;
const crypto = require('crypto');
const ErrCode = require('../utils/errorCode');
class UserInformationService extends Service {
  async searchMs(params) {
    const name = params.name;
    const sql = `SELECT t0.truename,t0.registration_date,t1.contact,t1.number,t1.type,t1.telephone FROM admin_user t0, user_information t1 WHERE t0.account_name = t1.account_name AND t0.account_name='${name}'`
    const results = await this.app.mysql.query(sql);
    return { msg: '成功', code: 10000, data: results };
  }
  async changeMS(params){
    //修改信息
    console.log(JSON.stringify(params));
    const name = params.name;
    const telephone = params.telephone;
    const contact = params.contact;
    const sql = `UPDATE user_information SET telephone = ${telephone},contact = '${contact}' WHERE account_name = '${name}'`;
    const results = await this.app.mysql.query(sql);
    return { msg: '成功', code: 10000, data: results };
  }
  async updatePs(params){
    //修改密码
    const name = params.name;
    //md5加密
    let password = '';
    if(params.password!==null&&params.password!==undefined){
      const hash = crypto.createHash('md5');
      hash.update(params.password);
      password = hash.digest('hex');
    }
    const sql =`SELECT password_sign FROM admin_user WHERE account_name ='${name}'`;
    const results = await this.app.mysql.query(sql);
    if(password===results[0].password_sign){
      let apassword = '';
      if(params.apassword!==null&&params.apassword!==undefined){
        const ahash = crypto.createHash('md5');
        ahash.update(params.apassword);
        apassword = ahash.digest('hex');
      }
      const change = `UPDATE admin_user SET password_sign = '${apassword}' WHERE account_name = '${name}'`;
      const bechange = await this.app.mysql.query(change);
      return { msg: '成功', code: 10000, data: bechange };
    }else{
      console.log('------密码不正确-------');

      return { msg: '密码不正确', code:ErrCode.ERROR_CODE_PARAM };
    }

  }
}

module.exports = UserInformationService;
