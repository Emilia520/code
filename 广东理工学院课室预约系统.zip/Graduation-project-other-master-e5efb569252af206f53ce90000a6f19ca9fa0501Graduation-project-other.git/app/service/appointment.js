'use strict';

const Service = require('egg').Service;

class AppointmentService extends Service {
  async insertTime(params) {
    //先查询是否有该日的课室预约，没有就插入
    const name = params.roomname;
    const number = params.roomnumber;
    const appoinTime = params.appoinTime;
    let conditions= '';
    const field = 'roomnumber,roomname,time_solt,time_number,appoint_date,appwhether,time_stamp';//需要插入的字段名
    const time1 = appoinTime+30300;
    const time2 = appoinTime+33600;
    const time3 = appoinTime+38060;
    const time4 = appoinTime+40500;
    const time5 = appoinTime+50700;
    const time6 = appoinTime+54000;
    const time7 = appoinTime+57300;
    const time8 = appoinTime+60600;
    if(typeof number !== 'undefined' && number !== ''){
      conditions = conditions + ` AND roomnumber = ${number} `;
    }
    if(typeof name !== 'undefined' && name !== ''){
      conditions = conditions + ` AND roomname = "${name}" `;
    }

    const conn = await this.app.mysql.beginTransaction(); // 初始化事务
    const sql = ` SELECT * FROM classroom WHERE 1=1 `+conditions;//查询classroom表看是否有该教室
    const exist = ` SELECT * FROM class_time WHERE appoint_date = ${appoinTime} `+conditions;
    
    
    try { 
      if(appoinTime!==undefined&&appoinTime!==null){
        let results = '';
        const room = await conn.query(sql);
        // console.log('--------'+JSON.stringify(room)+'-------');
        if(room.length!==0&&conditions!==""){ 
          const search = await conn.query(exist);
          const roomname = room[0].roomname;
          const roomnumber = room[0].roomnumber;
          if(search.length===0){//查询是否有当日记录，有就直接返回，没有添加8条，再返回
            const add1 = `INSERT INTO class_time(${field})VALUES(${roomnumber},'${roomname}','8:25-9:10',1,${appoinTime},0,${time1})`;
            const add2 = `INSERT INTO class_time(${field})VALUES(${roomnumber},'${roomname}','9:20-10:05',2,${appoinTime},0,${time2})`;
            const add3 = `INSERT INTO class_time(${field})VALUES(${roomnumber},'${roomname}','10:20-11:05',3,${appoinTime},0,${time3})`;
            const add4 = `INSERT INTO class_time(${field})VALUES(${roomnumber},'${roomname}','11:15-12:00',4,${appoinTime},0,${time4})`;
            const add5 = `INSERT INTO class_time(${field})VALUES(${roomnumber},'${roomname}','14:05-14:50',5,${appoinTime},0,${time5})`;
            const add6 = `INSERT INTO class_time(${field})VALUES(${roomnumber},'${roomname}','15:00-15:45',6,${appoinTime},0,${time6})`;
            const add7 = `INSERT INTO class_time(${field})VALUES(${roomnumber},'${roomname}','15:55-16:40',7,${appoinTime},0,${time7})`;
            const add8 = `INSERT INTO class_time(${field})VALUES(${roomnumber},'${roomname}','16:50-17:30',8,${appoinTime},0,${time8})`;
            await conn.query(add1);
            await conn.query(add2);
            await conn.query(add3);
            await conn.query(add4);
            await conn.query(add5);
            await conn.query(add6);
            await conn.query(add7);
            await conn.query(add8);
            const check =  ` SELECT * FROM class_time WHERE appoint_date = ${appoinTime} `+conditions;
            const nowTime = Math.round(new Date() / 1000);
            const change = ` UPDATE class_time SET appwhether = 2 WHERE time_stamp<${nowTime}`;
            const checkData = await conn.query(check);
            for(let i=0;i<checkData.length;i++){
              let appwhether = checkData[i].appwhether;
              if(appwhether===0||appwhether===1){
                await conn.query(change);

              }
            }
            const allData = ` SELECT * FROM class_time WHERE appoint_date = ${appoinTime} `+conditions;
            results = await conn.query(allData);
          }else{
            const check =  ` SELECT * FROM class_time WHERE appoint_date = ${appoinTime} `+conditions;
            const nowTime = Math.round(new Date() / 1000);
            const change = ` UPDATE class_time SET appwhether = 2 WHERE time_stamp<${nowTime}`;
            const checkData = await conn.query(check);
            for(let i=0;i<checkData.length;i++){
              let appwhether = checkData[i].appwhether;
              if(appwhether===0||appwhether===1){
                await conn.query(change);

              }
            }
            
            results = await conn.query(exist);//有记录直接返回
          }
           
        }else{
          return {code:6001,msg:'没有该课室'};
        }
          await conn.commit(); // 提交事务
          return { code: 10000, msg: '成功', data:results};
      }
    } catch (err) {
      // error, rollback
      console.log('----------执行失败----------');
      await conn.rollback(); // 一定记得捕获异常后回滚事务！！
      throw err;
    }
  }
  async recordAppiont(params){
    const name = params.name;
    const truename = params.truename;
    const type = params.type;
    const roomname = params.roomname;
    const roomnumber = params.roomnumber;
    const timesolt = params.time_solt;
    const timenumber = params.time_number;
    const roomresult = params.roomresult;
    const time = Math.round(new Date() / 1000);//获取当前时间戳
    const roomtime = params.roomtime;
    const timestamp = params.time_stamp
    const field = 'username,truename,type,roomnumber,roomname,roomresult,time_solt,time_number,order_time,roomtime,appoint_state,time_stamp,appoint_cancle';
    const sql = ` INSERT INTO appoint_record(${field})VALUES('${name}','${truename}',${type},${roomnumber},'${roomname}','${roomresult}','${timesolt}',${timenumber},${time},${roomtime},0,${timestamp},0) `;
    const results = await this.app.mysql.query(sql);
    return { code: 10000, msg: '成功', data:results};
  }
  //判断是否已经预约
   async judgeAppiont(params){
    //  console.log(JSON.stringify(params));
    const name = params.name;
    const roomtime = params.appoint_date;
    const timenumber = params.time_number;
    const roomnumber = params.roomnumber;
    const sql = ` SELECT * FROM appoint_record WHERE username='${name}' AND roomnumber = ${roomnumber} AND roomtime = ${roomtime} AND time_number = ${timenumber} AND appoint_cancle = 0 `;
    let judege = await this.app.mysql.query(sql);
    // console.log('-------'+JSON.stringify(judege)+'-------');
    let result =[{}];
    if(judege.length===0){
      result=[{record:0}];
    }else{
      result=[{record:1}];
    }
    return { code: 10000, msg: '成功', data:result};
  }
}

module.exports = AppointmentService;
