const Service = require('egg').Service;
const Constant = require('../utils/constant');
const ErrCode = require('../utils/errorCode');

module.exports = () => {
  return class RobotMiniProgram extends Service {
    constructor(ctx) {
      super(ctx);
      this.msgMap = {};
      this.msgResultMap = {};
      this.duration = 60 * 60; // 消息发送间隔为每个机器人每12分钟发送15个群
      this.maxGroupNums = 15; // 每个机器人一次最多转发15个群
      this.restored = false; // 主要记录首次使用上述数据时有没进行数据恢复，只有初始化为false，以后一直为true
    }

    async getData() {
      if (!this.restored) {
        this.msgMap = JSON.parse(await this.app.redis.get('db2').get(Constant.key.MINI_PROGRAM_MSG_QUEUE) || '{}');
        this.msgResultMap = JSON.parse(await this.app.redis.get('db2').get(Constant.key.MINI_PROGRAM_MSG_RESULT) || '{}');
        this.restored = true;
      }

      return { msgMap: this.msgMap, msgResultMap: this.msgResultMap };
    }

    async setData(data) {
      const { msgMap, msgResultMap } = data;
      await this.app.redis.get('db2').set(Constant.key.MINI_PROGRAM_MSG_QUEUE, JSON.stringify(msgMap));
      await this.app.redis.get('db2').set(Constant.key.MINI_PROGRAM_MSG_RESULT, JSON.stringify(msgResultMap));
    }

    // sendData的结构为{"aliasName":"jueli23","programName":"华为随行","senderList":["甜甜甜"],"leaveMsg":"你好"}
    async addMsgToQueue(msg) {
      if (!msg) {
        throw { code: ErrCode.ERROR_CODE_PARAM, msg: '小程序卡片消息参数错误' };
      }

      // 获取发送消息所需要的群活码、pid、群等信息
      const info = await this.service.robot.getPidInfo(msg);
      if (info.length === 0) {
        await this.service.robot.updateMsgStatus(msg, Constant.robotMsgStatus.FAILED, '获取不到相应的pid信息');
        return;
      }

      const { msgMap, msgResultMap } = await this.getData();
      // 开始遍历所有需要发送的群，构造发送体进入转发队列等候转发，并且构造结果体以便发送完成后记录发送结果
      for (const i in info) {
        const obj = info[i];
        if (!obj.robotKey) {
          continue;
        }

        if (!msgMap[obj.robotKey]) {
          msgMap[obj.robotKey] = { lastSendTime: null, dataList: [] };
        }

        const groupList = obj.groupNames.split('||');
        msgMap[obj.robotKey].dataList.push({
          id: msg.id,
          aliasName: msg.from_friend,
          programName: msg.desc,
          senderList: groupList,
          leaveMsg: msg.send_text
        });

        if (!msgResultMap[msg.id]) {
          msgResultMap[msg.id] = { total: 0, complete: 0, success: [], fail: [], reasons: [] };
        }

        msgResultMap[msg.id].total += groupList.length;
      }

      await this.setData({ msgMap, msgResultMap });
    }

    async scheduleSendMsg() {
      const now = new Date().getTime() / 1000;
      const { msgMap, msgResultMap } = await this.getData();
      const updateMsgs = [];
      for (const robotKey in msgMap) {
        const item = msgMap[robotKey];
        // 如果该机器人没发送过消息或者距离上一次发送消息已经超过约定时长，则允许触发下一次发送消息
        if ((!item.lastSendTime || now - item.lastSendTime >= this.duration) && item.dataList.length > 0) {
          let delCount = 0;
          const sendDatas = [];
          let groupCount = 0;
          for (const data of item.dataList) {
            const length = data.senderList.length;
            const remainCount = this.maxGroupNums - groupCount;
            if (length <= remainCount) {
              sendDatas.push(data);
              groupCount += length;
              ++delCount;
            } else {
              const sendData = JSON.parse(JSON.stringify(data));
              groupCount += remainCount;
              sendData.senderList = data.senderList.splice(0, remainCount);
              sendDatas.push(sendData);
            }

            if (groupCount >= this.maxGroupNums) {
              break;
            }
          }

          if (delCount > 0) {
            item.dataList.splice(0, delCount);
          }
          // 把筛选出来的消息进行发送
          for (const data of sendDatas) {
            const length = data.senderList.length;
            const msgId = data.id;
            delete data.id;
            const result = await this.service.yjiyun.sendWXMiniProgram({
              robotKey,
              data
            });

            if (result && result.data) {
              if (result.data.code === '0') {
                msgResultMap[msgId].success = msgResultMap[msgId].success.concat(data.senderList);
              } else {
                msgResultMap[msgId].fail = msgResultMap[msgId].fail.concat(data.senderList);
                msgResultMap[msgId].reasons.push(result.data.msg || `错误码:${result.data.code}` || '未知错误');
              }
            } else {
              msgResultMap[msgId].fail = msgResultMap[msgId].fail.concat(data.senderList);
              msgResultMap[msgId].reasons.push('未知错误:可能是网络错误');
            }

            msgResultMap[msgId].complete += length;
            updateMsgs.push(msgId);
            item.lastSendTime = now;
          }
        }
      }

      const hasUpdateds = Array.from(new Set(updateMsgs));
      await this.app.mysql.beginTransactionScope(async conn => {
        let complete = false;
        for (const msgId of hasUpdateds) {
          let status = Constant.robotMsgStatus.QUEUE;
          if (msgResultMap[msgId].total === msgResultMap[msgId].complete) {
            if (msgResultMap[msgId].fail.length === 0) {
              status = Constant.robotMsgStatus.SUCCESS;
            } else if (msgResultMap[msgId].success.length === 0) {
              status = Constant.robotMsgStatus.FAILED;
            } else {
              status = Constant.robotMsgStatus.SUCCESS_PARTIALLY;
            }

            complete = true;
          }

          const reasons = Array.from(new Set(msgResultMap[msgId].reasons));
          const reason = `预计发送群：${msgResultMap[msgId].total}个\n已发送群：${msgResultMap[msgId].complete}个\n失败群：${msgResultMap[msgId].fail.length}个\n可能失败原因:${reasons.join(',')}`;
          await this.service.robot.updateMsgStatus({ id: msgId }, status, reason, conn);
          // 如果任务完成就把结果对象清掉
          if (complete) {
            delete msgResultMap[msgId];
          }
        }
      }, this.ctx);

      await this.setData({ msgMap, msgResultMap });
    }
  };
};