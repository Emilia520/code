const Service = require('egg').Service;
const ErrorCode = require('../utils/errorCode');

module.exports = () => {
  return class SecKill extends Service {
    /**
     * 返回秒杀详情列表
     * @param params
     * @returns {Promise<{msg: string, code: number, data: *}>}
     * 其中data包含了从日期到秒杀记录列表的映射，日期timestamp
     * 字段精确到天
     * data: [
     *   {date: timestamp, seckill_list: [seckillList1, seckillList2, ...]},
     *   {date: timestamp2, seckill_list: [seckillList3, seckillList4, ..]},
     *   ...
     * ]
     *
     * 另外，seckillList到内容是一条完整的秒杀记录：
     * seckillList: {
     *   seckill_id: 1,
     *   seckill_status: 1,
     *   show_time: 1,
     *   stop_time: 2,
     *   product_list: [],   // 包含了该秒杀时段的全部商品信息
     * }
     *
     */
    async getSeckillList(params) {
      console.log('params', params);
      const timeRange = params.dateRange;
      const seckill_id = params.seckill_id;

      let seckillView = 'SELECT id AS seckill_id, show_time, stop_time, status AS seckill_status, type AS seckill_type, remark AS seckill_remark FROM seckill WHERE type = 0';
      if (Array.isArray(timeRange) && timeRange.length === 2) {
        const beginMillisecond = timeRange[0];
        const endMillisecond = timeRange[1];

        if (typeof beginMillisecond === 'number' && typeof endMillisecond === 'number') {
          const beginTime = Math.floor(beginMillisecond / 1000);
          const endTime = Math.floor(endMillisecond / 1000);
          if (beginTime === endTime) {
            // 24小时内容的数据
            seckillView += ` AND ((show_time-${beginTime} BETWEEN 0 AND 86400) OR (stop_time-${beginTime} BETWEEN 0 AND 86400))`;
          } else {
            seckillView += ` AND (show_time BETWEEN ${beginTime} AND ${endTime}) OR (stop_time BETWEEN ${beginTime} AND ${endTime})`;
          }
        }
      } else if (typeof seckill_id === 'number') {
        seckillView += ` AND id = ${seckill_id}`;
      }

      const seckillProductView = `SELECT a.*,
      b.seckill_price, 
      b.product_overall_id, 
      b.seckill_profit, 
      b.seckill_inventory, 
      b.total_inventory,  
      b.percentage_robbed, 
      b.sort AS seckill_product_sort,
      b.status AS seckill_product_status 
      FROM (${seckillView}) a LEFT JOIN seckill_product b 
      ON a.seckill_id = b.seckill_id`;

      const overallView = 'SELECT id AS seckill_product_overall_id, product_id AS seckill_product_id FROM product_overall WHERE order_type = 2 OR order_type = 6 OR order_type = 13';
      const querySQL = `SELECT k.*, d.* FROM
       (SELECT s.*, e.seckill_product_id, e.seckill_product_overall_id
        FROM 
        (${seckillProductView}) s LEFT JOIN (${overallView}) e 
        ON s.product_overall_id = e.seckill_product_overall_id) k LEFT JOIN group_buy_goods d
        ON k.seckill_product_id = d.id 
        ORDER BY k.show_time ASC, k.seckill_product_sort DESC`;
      console.log(querySQL);

      const res = {};
      let current = { product_list: [] };
      const seckillList = await this.app.mysql.query(querySQL);

      seckillList.forEach(seckill => {
        if (typeof seckill.picture === 'string') {
          seckill.picture = JSON.parse(seckill.picture);
        }

        if (typeof seckill.sku_list === 'string') {
          seckill.sku_list = JSON.parse(seckill.sku_list);
        }

        if (current.hasOwnProperty('seckill_id') && current.seckill_id !== seckill.seckill_id) {
          // 归类秒杀记录的日期
          _classifyDataMap(res, current);
          current = { product_list: [] };
          _copySeckillList(current, seckill);
        } else {
          // 合并秒杀记录的商品列表
          _copySeckillList(current, seckill);
        }

        // 最后一条数据要处理一下
        if (seckillList.indexOf(seckill) === seckillList.length - 1) {
          _classifyDataMap(res, current);
        }
      });

      // 压成数组
      const result = [];
      Object.keys(res).forEach(key => {
        const item = { date: parseInt(key), seckill_list: res[key] };
        result.push(item);
      });

      function _copySeckillList(target, seckill) {
        target.seckill_id = seckill.seckill_id;
        target.show_time = seckill.show_time;
        target.stop_time = seckill.stop_time;
        target.seckill_status = seckill.seckill_status;
        target.product_list = target.product_list || [];
        if (typeof seckill.seckill_product_id === 'number') {
          target.product_list.push(seckill);
        }
      }

      function _classifyDataMap(target, seckillList) {
        const seckillDate = new Date(seckillList.show_time * 1000);
        const belongDate = new Date(seckillDate.getFullYear(), seckillDate.getMonth(), seckillDate.getDate()).getTime();
        const belongDateList = target[belongDate] || [];
        const tempStore = {};

        Object.assign(tempStore, seckillList);
        belongDateList.push(tempStore);
        target[belongDate] = belongDateList;
      }

      return { code: 10000, msg: '成功', data: result };
    }

    /**
     * 新建秒杀记录，不包含任何商品
     * @param params
     * @returns {Promise<{msg: string, code: number}>}
     */
    async createSeckillLists(params) {
      const status = 1;
      const type = 0;
      const timeArray = params.times;

      console.log(params);

      let response = { code: 10000, msg: '成功' };

      await this.app.mysql.beginTransactionScope(async conn => {
        for (const index in timeArray) {
          const item = timeArray[index];

          const show_time = item.beginTime;
          const stop_time = item.endTime;
          const remark = item.remark;

          if (typeof show_time !== 'number' || typeof stop_time !== 'number') {
            return { code: ErrorCode.ERROR_CODE_PARAM, msg: '缺少参数' };
          }

          const options = { show_time, stop_time, status, type };
          if (remark) {
            options.remark = remark;
          }

          const addRes = await conn.insert('seckill', options);
          if (addRes.affectedRows !== 1) {
            response = { code: ErrorCode.ERROR_CODE_DB_INSERT, msg: '数据库插入失败' };
            return { success: false };
          }
        }

        return { success: true };
      }, this.ctx);

      return response;
    }

    /**
     * 向秒杀记录中(批量)添加数据，当某条商品发生错误时，
     * data中的product_id表示出错商品关联的数据表ID
     * @param params
     * @returns {Promise<{msg: string, code: number}>}
     */
    async addProductToSeckillList(params) {
      const seckill_id = params.seckillID;
      const productList = params.productList;
      console.log(params);

      if (typeof seckill_id !== 'number' || !Array.isArray(productList)) {
        return { code: ErrorCode.ERROR_CODE_PARAM, msg: '缺少参数' };
      }

      let response = { code: 10000, msg: 'msg' };
      await this.app.mysql.beginTransactionScope(async conn => {
        for (const index in productList) {
          const product = productList[index];
          const { product_id, seckill_price, seckill_profit, seckill_inventory, sort, remark } = product;
          const originPrice = product.product.akc_tag_price;
          const seckill_only_price = this.service.groupbuy.getOnlySettlementPrice(originPrice, seckill_price);

          if (typeof product_id !== 'number' || !seckill_price || !seckill_profit || !seckill_inventory || (!sort && sort !== 0)) {
            response = { code: ErrorCode.ERROR_CODE_PARAM, msg: '商品列表缺少关键数据', data: { product_id } };
            return { success: false };
          }

          const total_inventory = seckill_inventory;
          const product_overall = await conn.get('product_overall', { product_id });
          if (typeof product_overall.id !== 'number') {
            response = {
              code: ErrorCode.ERROR_CODE_DB_UNEXPECTED_RESULT_COUNT,
              msg: '该商品没有对应的Overall ID',
              data: { product_id }
            };
            return { success: false };
          }

          const product_overall_id = product_overall.id;
          const options = {
            product_overall_id,
            seckill_only_price,
            seckill_inventory,
            seckill_price,
            seckill_profit,
            seckill_id,
            total_inventory,
            sort,
            status: 1,
            create_time: Date.now() / 1000,
          };

          console.log(options);

          if (remark) {
            options.remark = remark;
          }

          const addRes = await conn.insert('seckill_product', options);
          if (addRes.affectedRows !== 1) {
            response = { code: ErrorCode.ERROR_CODE_DB_INSERT, msg: '插入数据失败', data: { product_id } };
            return { success: false };
          }
        }
        return { success: true };
      }, this.ctx);

      return response;
    }

    /**
     * 更新秒杀记录的商品数据
     * @param params
     * @returns {Promise<{msg: string, code: number}>}
     */
    async updateProductInSeckillList(params) {
      const seckill_id = params.seckill_id;
      const product_id = params.product_id;
      const product = params.seckill_info;
      console.log(params);

      if (typeof seckill_id !== 'number' || typeof product_id !== 'number' || !product) {
        return { code: ErrorCode.ERROR_CODE_PARAM, msg: '缺少参数' };
      }

      const { seckill_profit, seckill_price, seckill_inventory, sort, remark, status } = product;
      const rows = { update_time: Date.now() / 1000 };

      if (remark) {
        rows.remark = remark;
      }

      if (seckill_profit) {
        rows.seckill_profit = seckill_profit;
      }

      if (seckill_price) {
        rows.seckill_price = seckill_price;
      }

      if (seckill_inventory) {
        rows.seckill_inventory = seckill_inventory;
      }

      if (sort || sort === 0) {
        rows.sort = sort;
      }

      if (status || status === 0) {
        rows.status = status;
      }

      if (Object.keys(rows).length <= 1) {
        return { code: ErrorCode.ERROR_CODE_PARAM, msg: '无需要更新的字段' };
      }

      console.log(rows);

      let response = { code: 10000, msg: '成功' };

      await this.app.mysql.beginTransactionScope(async conn => {
        const product_overall = await conn.get('product_overall', { product_id });
        if (typeof product_overall.id !== 'number') {
          response = {
            code: ErrorCode.ERROR_CODE_DB_UNEXPECTED_RESULT_COUNT,
            msg: '该商品没有对应的Overall ID',
            data: { product_id }
          };
          return { success: false };
        }

        if (seckill_price) {
          const result = await conn.select('group_buy_goods', {
            columns: ['akc_tag_price'],
            where: { id: product_id },
          });

          if (result.length !== 1) {
            response = { code: ErrorCode.ERROR_CODE_DB_UNEXPECTED_RESULT_COUNT, msg: '获取商品价格失败' };
            return { success: false };
          }

          const price = result[0].akc_tag_price;
          rows.seckill_only_price = this.service.groupbuy.getOnlySettlementPrice(price, seckill_price);
        }

        const product_overall_id = product_overall.id;
        const where = { seckill_id, product_overall_id };

        const updateRes = await conn.update('seckill_product', rows, { where });
        if (updateRes.affectedRows !== 1) {
          response = { code: ErrorCode.ERROR_CODE_DB_UNEXPECTED_RESULT_COUNT, msg: '数据库更新失败' };
          return { success: false };
        }

        return { success: true };
      }, this.ctx);

      return response;
    }

    /**
     * 从秒杀记录中删除一个商品
     * @param params
     * @returns {Promise<{msg: string, code: number}>}
     */
    async removeProductFromSeckillList(params) {
      const seckill_id = params.seckill_id;
      const product_id = params.product_id;

      if (typeof seckill_id !== 'number' || typeof product_id !== 'number') {
        return { code: ErrorCode.ERROR_CODE_PARAM, msg: '缺少参数' };
      }

      let response = { code: 10000, msg: '成功' };

      await this.app.mysql.beginTransactionScope(async conn => {
        const product_overall = await conn.get('product_overall', { product_id });
        if (typeof product_overall.id !== 'number') {
          response = {
            code: ErrorCode.ERROR_CODE_DB_UNEXPECTED_RESULT_COUNT,
            msg: '该商品没有对应的Overall ID',
            data: { product_id }
          };
          return { success: false };
        }

        const product_overall_id = product_overall.id;
        const updateRes = await conn.delete('seckill_product', { seckill_id, product_overall_id });
        if (updateRes.affectedRows !== 1) {
          response = { code: ErrorCode.ERROR_CODE_DB_UNEXPECTED_RESULT_COUNT, msg: '数据库更新失败' };
          return { success: false };
        }

        return { success: true };
      }, this.ctx);

      return response;
    }
  };
};