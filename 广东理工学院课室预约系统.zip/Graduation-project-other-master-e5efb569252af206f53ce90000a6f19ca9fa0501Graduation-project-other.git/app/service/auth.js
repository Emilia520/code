/**
 * 用户身份验证
 * Created by ocean on 18/05/30
 */

const Service = require('egg').Service;
const ErrCode = require('../utils/errorCode');
const crypto = require('crypto');

module.exports = () => {
  return class Auth extends Service {
    /**
     * 生成 Token
     * @param {Object} data
     */
    createToken(data) {
      return this.app.jwt.sign(data, this.app.config.jwt.secret, {
        expiresIn: '24h'
      });
    }

    getAccessToken() {
      const bearerToken = this.ctx.request.header.authorization;
      return bearerToken && bearerToken.replace('Bearer ', '');
    }

    /**
     * 验证token的合法性
     * @param {String} token
     */
    async verifyToken() {
      const ret = {
        code: 10000,
        msg: ''
      };
      const token = this.getAccessToken();
      await new Promise((resolve, reject) => {
        this.app.jwt.verify(token, this.app.config.jwt.secret, function(err, decoded) {
          if (err) {
            ret.code = ErrCode.ERROR_CODE_VERIFY_FAIL;
            ret.msg = err.message;
          } else {
            ret.msg = decoded;
          }
          resolve(ret);
        });
      });
      return ret;
    }

    async verifyUserInfo(username, password) {
      let ret = {
        code: 10000,
        msg: '登录成功'
      };
      const hash = crypto.createHash('md5');
      hash.update(password);
      const password_sign = hash.digest('hex');
      const sql = 'SELECT * FROM admin_user a, admin_role b WHERE a.account_name = "' +
        username +
        '" AND a.password_sign = "' +
        password_sign +
        '" AND a.role_id = b.id';
      const result = await this.app.mysql.query(sql);

      if (result.length > 0) {
        const token = this.createToken({ id: result[0].id });
        ret.authorization = token;
        ret.role = result[0].role_id;
      } else {
        ret = {
          code: ErrCode.ERROR_CODE_ACCOUNT_OR_PW_ERROR,
          msg: '账号或者密码错误',
        };
      }

      return ret;
    }
  };
};
