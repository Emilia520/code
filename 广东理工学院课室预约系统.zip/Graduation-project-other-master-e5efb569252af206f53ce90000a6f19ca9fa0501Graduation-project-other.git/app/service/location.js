const Service = require('egg').Service;

module.exports = () => {
  return class Location extends Service {
    async provinces() {
      const sql = 'SELECT a.id, a.province AS label FROM config_province a;';
      const list = await this.app.mysql.query(sql);
      return list;
    }

    async cities() {
      const sql = 'SELECT a.id, a.city AS label FROM config_city a;';
      const list = await this.app.mysql.query(sql);
      return list;
    }

    async areas() {
      const sql = 'SELECT a.id, a.area AS label FROM config_area a;';
      const list = await this.app.mysql.query(sql);
      return list;
    }

    async regions() {
      const sql = 'SELECT a.id AS province_id, a.province, b.id AS city_id, b.city, c.id AS area_id, c.area FROM config_province a, config_city b, config_area c WHERE a.id = b.province_id AND b.id = c.city_id;';
      const list = await this.app.mysql.query(sql);
      const regions = [];
      let curProvinceId = 0;
      let curCityId = 0;
      let curProvince = {};
      let curCity = {};
      for (const i in list) {
        const item = list[i];
        const area = { id: item.area_id, area: item.area };
        if (item.province_id === curProvinceId) {
          if (curProvince.cities == null) {
            curProvince.cities = [];
          }

          if (item.city_id === curCityId) {
            if (curCity.areas == null) {
              curCity.areas = [];
            }

            curCity.areas.push(area);
          } else {
            curCityId = item.city_id;
            curCity = { id: item.city_id, city: item.city, areas: [area] };
            curProvince.cities.push(curCity);
          }
        } else {
          curCityId = item.city_id;
          curCity = { id: item.city_id, city: item.city, areas: [area] };
          curProvinceId = item.province_id;
          curProvince = { id: item.province_id, province: item.province, cities: [curCity] };
          regions.push(curProvince);
        }
      }

      return regions;
    }
  };
};