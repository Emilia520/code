/**
 * 选品列表相关接口
 */

const Service = require('egg').Service;
const Constant = require('../utils/constant');
const ErrorCode = require('../utils/errorCode');
const Utils = require('../utils/utils');

module.exports = () => {
  return class ChoiceList extends Service {
    /**
     * 向数据库插入一条选品队列数据
     * @param listName 选品队列名称，不能为空
     * @returns {Promise<{code: number, msg: string}>}
     */
    async addChoiceList(listName) {
      if (!listName) {
        return { code: ErrorCode.ERROR_CODE_PARAM, msg: '缺少选品队列名称参数' };
      }

      let data = {};

      await this.app.mysql.beginTransactionScope(async conn => {
        let result = await conn.select('choice_product_list', { where: { list_name: listName } });
        if (result.length !== 0) {
          data = { code: ErrorCode.ERROR_CODE_DB_INSERT, msg: '存在同名的选品队列' };
          return;
        }

        result = await conn.insert('choice_product_list', { list_name: listName, create_time: Date.now() / 1000 });
        data = result.affectedRows === 1 ? {
          code: 10000,
          msg: '成功',
          data: { insert_id: result.insertId }
        } :
          {
            code: ErrorCode.ERROR_CODE_DB_INSERT,
            msg: '数据库插入失败',
          };
      }, this.ctx);

      return data;
    }

    /**
     * 查询选品队列
     * @param params 选品队列筛选参数
     * @returns {Promise<array>} 返回一个按照updateTime降序排序的数组
     */
    async choiceList(params) {
      // 对null数据进行sort的方案参考：
      // https://stackoverflow.com/questions/2051602/mysql-orderby-a-number-nulls-last
      let selectSQL = 'SELECT a.id AS list_id, a.list_name, b.item_pic, b.item_id, b.item_platform, b.item_sort' +
        ' FROM choice_product_list a LEFT JOIN choice_list_sort b ON a.id = b.choice_list_id' +
        ' ORDER BY a.create_time DESC, -b.item_sort DESC';

      const listName = params ? params.list_name : null;
      if (listName) {
        selectSQL += `WHERE a.list_name = ${listName}`;
      }

      const results = await this.app.mysql.query(selectSQL);
      const choiceLists = [];

      for (const index in results) {
        const record = results[index];
        const choiceList = choiceLists.length === 0 ? {} : choiceLists[choiceLists.length - 1];
        const optLastObj = choiceList.choice_list_id === record.list_id; // 如果当前记录ID和缓存中最后一个ID相同，表示商品队列不为空，正在处理
        const currentList = optLastObj ? choiceList : {};

        currentList.choice_list_id = record.list_id;
        currentList.list_name = record.list_name;

        if (record.item_id !== null && record.item_sort !== null && record.item_platform !== null) {
          const itemList = currentList.item_list || []; // 一条选品列表中的全部商品数据
          const item = {}; // 当前操作的商品数据，

          item.item_id = record.item_id;
          item.item_sort = record.item_sort;
          item.item_platform = record.item_platform;
          item.pic_url = record.item_pic;

          itemList.push(item);
          currentList.item_list = itemList;
        }

        if (choiceLists.length === 0 || !optLastObj) {
          choiceLists.push(currentList);
        }
      }

      return choiceLists;
    }

    /**
     * 筛选指定时间范围和位置上的选品日历数据
     * @param params
     * tagID 首页支持分类如精选等的ID 可选
     * serviceID 该分类下具体的业务ID，如爆款等，和tagID共同决定一个具体的选品库位置 可选
     * beginTime 筛选的开始时间，一般是当月第一天 可选
     * endTime 筛选的结束时间，一般是当月的最后一天 可选
     * @returns {Promise<Object>} 参考注释中的数据结构
     */
    async choiceListCalendar(params) {
      let selectSQL = 'SELECT a.id AS choice_list_id, a.list_name, b.date_time, b.state, b.service_id, b.tag_id, c.item_id, c.item_platform, c.item_sort, c.item_pic' +
        ' FROM choice_product_list a LEFT JOIN choice_list_pos b LEFT JOIN choice_list_sort c' +
        ' ON a.id = b.choice_list_id AND c.choice_list_id = b.choice_list_id';

      let filter = null;
      if (params.tagID && params.serviceID) {
        filter = `WHERE b.tag_id = ${params.tagID} AND b.service_id = ${params.serviceID}`;
      }

      if (params.hasOwnProperty('beginTime')) {
        filter = (filter === null ? '' : filter) + ` ${filter === null ? 'WHERE' : 'AND'} b.date_time >= ${params.beginTime}`;
      }

      if (params.hasOwnProperty('endTime')) {
        filter = (filter === null ? '' : filter) + ` ${filter === null ? 'WHERE' : 'AND'} b.date_time <= ${params.endTime}`;
      }

      if (filter) {
        selectSQL += filter;
      }

      selectSQL += ' ORDER BY -c.item_sort DESC';
      console.log('Select : ', selectSQL);

      const results = await this.app.mysql.query(selectSQL);
      const calendar = {};

      // 按照日期索选品列表
      // 数据结构：
      // {
      //    date：[{
      //          choice_list_id : {
      //               list_name
      //              offer_pos
      //              item_list :  [ { item_id, item_platform, item_sort }, ... ]
      //             }, ...
      //    }], ...
      // }
      for (const index in results) {
        const record = results[index];
        const choiceListForDate = calendar[record.date_time] || [];
        const repeated = choiceListForDate.find(item => {
          return item.tag_id === record.tag_id && item.service_id === record.service_id && item.choice_list_id !== record.choice_list_id;
        });

        // 如果同一日期下，包含了2条或以上同样选品位置（即tag_id和service_id 相同）
        // 但ID不相同记录，则直接返回出错，这种场景不允许出现
        if (repeated) {
          return { code: ErrorCode.ERROR_CODE_DB_UNEXPECTED_RESULT_COUNT, msg: '同一日期下包含了2条以上相同的选品队列' };
        }

        const choiceList = choiceListForDate.find(item => { return item.choice_list_id === record.choice_list_id; }) || {};
        const targetIndex = choiceListForDate.indexOf(choiceList);

        choiceList.choice_list_id = record.choice_list_id;
        choiceList.list_name = record.list_name;
        choiceList.tag_id = record.tag_id;
        choiceList.service_id = record.service_id;
        choiceList.state = record.state;

        if (record.item_id !== null && record.item_sort !== null && record.item_platform !== null) {
          const itemList = choiceList.item_list || []; // 一条选品列表中的全部商品数据
          const item = {}; // 当前操作的商品数据，

          item.item_id = record.item_id;
          item.item_sort = record.item_sort;
          item.item_platform = record.item_platform;

          // 从内向外拼装数据
          itemList.push(item);
          choiceList.item_list = itemList;
        }

        if (targetIndex === -1) {
          choiceListForDate.push(choiceList);
        } else {
          choiceListForDate[targetIndex] = choiceList;
        }

        calendar[record.date_time] = choiceListForDate;
      }

      return { code: 10000, msg: '成功', data: calendar };
    }

    /**
     * 插入 一条选品日历数据
     * @param params
     * dateTime 插入的时间，Date类型。
     * choiceListID 关联到该日期的选品库ID
     * serviceID 资源业务如爆款的ID
     * tagID 资源位分类如精选tag的ID
     * @returns {Promise<Object>} { code: 返回码，msg: 返回信息}
     */
    async addCalendar(params) {
      if (!params ||
        !params.hasOwnProperty('dateTime') ||
        !params.hasOwnProperty('choiceListID') ||
        !params.hasOwnProperty('serviceID') ||
        !params.hasOwnProperty('tagID')) {
        return { code: ErrorCode.ERROR_CODE_PARAM, msg: '添加选品日历缺少参数' };
      }

      const querySQL = `SELECT COUNT(*) FROM choice_list_pos WHERE date_time = ${params.dateTime}`;
      const result = await this.app.mysql.query(querySQL);

      if (result !== 0) {
        return { code: ErrorCode.ERROR_CODE_DB_UNEXPECTED_RESULT_COUNT, msg: '数据库中存在相同日期到选品日历' };
      }

      const insertParam = {
        date_time: params.dateTime,
        choice_list_id: params.choiceListID,
        service_id: params.serviceID,
        tag_id: params.tagID,
        state: 0,
      };

      const addResult = await this.app.mysql.insert('choice_list_pos', insertParam);
      return addResult.affectedRows === 1 ?
        { code: 10000, msg: '插入成功' } :
        { code: ErrorCode.ERROR_CODE_DB_INSERT, msg: '插入选品日历数据失败' };
    }

    /**
     * 将选品列表拷贝到一个资源位上
     * @param dateTime 日期时间戳，单位秒，日期精确到天即可
     * @param offerPos
     * @param choiceList
     * @returns {Promise<boolean>} true 拷贝成功，false 拷贝失败
     */
    async copyChoiceList(dateTime, offerPos, choiceList) {
      if (!dateTime || !offerPos || !choiceList) {
        // 日期和投放位置唯一确定一个投放资源位
        return false;
      }

      // 被复制的选品列表需要手动操作一次上架才会被下发到客户端
      const result = await this.app.mysql.insert('choice_list_pos', {
        date_time: dateTime,
        offer_pos: offerPos,
        choice_list_id: choiceList.choice_list_id,
        state: 1
      });

      return result.affectedRows === 1;
    }

    /**
     * 删除选品列表或从指定投放位置日历上移除这个选品列表
     * @param choiceList 需要删除或移除的选品列表数据
     * @param offerPos 指定的投放位置，传入-1表示全部投放位置
     * @param dateTime 指定的日期， 传入-1表示全部日期
     * @returns {Promise<Object>} true 删除成功，false 删除失败
     */
    async deleteChoiceList(choiceList, offerPos = -1, dateTime = -1) {
      if (!choiceList) {
        return { code: ErrorCode.ERROR_CODE_PARAM, msg: '不能删除空的选品队列' };
      }

      await this.app.mysql.beginTransactionScope(async conn => {
        if (offerPos === -1 && dateTime === -1) {
          // 如果没有指定投放位置和日期，则表示完全删除选品库，需要3张表同时操作
          await conn.delete('choice_product_list', { id: choiceList.choice_list_id });
          await conn.delete('choice_list_pos', { choice_list_id: choiceList.choice_list_id });
          await conn.delete('choice_list_sort', { choice_list_id: choiceList.choice_list_id });
        } else {
          // 否则从资源位表中删除
          const deleteParam = {};
          offerPos !== -1 ? deleteParam.offer_pos = offerPos : null;
          dateTime !== -1 ? deleteParam.date_time = dateTime : null;

          await conn.delete('choice_list_pos', deleteParam);
        }
      }, this.ctx);

      return { code: 10000, msg: '成功' };
    }

    /**
     * 按指定动作操作选品列表中的商品队列
     * @param choiceList 需要调整选品队列
     * @param itemID 商品ID，对应各个sku库中的商品唯一ID
     * @param itemPlatform 商品所属平台
     * @param opt 操作动作，参考constant.js
     * @returns {Promise<Object>}
     */
    async optChoiceListItem(choiceList, itemList, opt) {
      console.log('item list,', itemList);
      if (!choiceList) {
        return { code: ErrorCode.ERROR_CODE_PARAM, msg: '缺少参数' };
      }

      if (!Array.isArray(itemList) || itemList.length === 0) {
        return { code: ErrorCode.ERROR_CODE_PARAM, msg: '缺少商品数据' };
      }

      switch (opt) {
        case Constant.choiceListItemOpt.ADD: {
          await this.app.mysql.beginTransactionScope(async conn => {
            for (const index in itemList) {
              const item = itemList[index];
              const choiceItem = {
                choice_list_id: choiceList.choice_list_id,
                item_id: item.item_id,
                item_platform: item.item_platform,
                item_sort: item.item_sort,
                item_pic: item.pic_url
              };

              // 插入选品列表数据
              const result = await conn.insert('choice_list_sort', choiceItem);
              if (result.affectedRows !== 1) {
                throw { code: ErrorCode.ERROR_CODE_DB_INSERT, msg: '一条或多条数据写入失败' };
              }

              if (!item.item_detail) {
                throw { code: ErrorCode.ERROR_CODE_DB_INSERT, msg: '选品缺少SKU信息' };
              }

              // 将关联的商品SKU数据插入到对应的SKU表
              if (item.item_platform === Constant.platform.TB) {
                const tbItem = item.item_detail;
                tbItem.small_images = JSON.stringify(tbItem.small_images);
                tbItem.commission_rate = tbItem.commission_rate * 10;

                const sql = Utils.genReplaceSql('sku_tb', tbItem);
                if (!sql) {
                  throw { code: ErrorCode.ERROR_CODE_DB_INSERT, msg: '生成淘宝SKU插入SQL出错' };
                }

                await conn.query(sql);
              } else if (item.item_platform === Constant.platform.PDD) {
                const pddItem = item.item_detail;

                pddItem.goods_gallery_urls = JSON.stringify(pddItem.goods_gallery_urls);
                pddItem.opt_ids = JSON.stringify(pddItem.opt_ids);
                pddItem.cat_ids = JSON.stringify(pddItem.cat_ids);

                const sql = Utils.genReplaceSql('sku_pdd', pddItem);
                if (!sql) {
                  throw { code: ErrorCode.ERROR_CODE_DB_INSERT, msg: '生成拼多多SKU插入SQL出错' };
                }

                await conn.query(sql);
              }
            }
          }, this.ctx);

          return { code: 10000, msg: '成功' };
        }

        case Constant.choiceListItemOpt.REMOVE: {
          const item = itemList[0];
          const sql = `DELETE FROM choice_list_sort WHERE choice_list_id = ${choiceList.choice_list_id} AND item_id = ${item.item_id} AND item_platform = ${item.item_platform}`;
          await this.app.mysql.query(sql);

          return { code: 10000, msg: '成功' };
        }

        case Constant.choiceListItemOpt.FORWARD:
        case Constant.choiceListItemOpt.BACKWARD: {
          const item = itemList[0];
          await this.app.mysql.beginTransactionScope(async conn => {
            const sql = genSql(choiceList, item, opt);
            const list = await conn.query(sql);
            if (list.length === 2) {
              const tmpSort = list[0].item_sort;
              list[0].item_sort = list[1].item_sort;
              list[1].item_sort = tmpSort;
              await this.app.mysql.update('choice_list_sort', list[0]);
              await this.app.mysql.update('choice_list_sort', list[1]);
            }
          }, this.ctx);
          return { code: 10000, msg: '成功' };
        }

        default:
          return { code: ErrorCode.ERROR_CODE_PARAM, msg: '非法操作' };
      }

      function changePddItemToSkuItem(pddItem) {
        const now = parseInt(new Date().getTime() / 1000);
        return {
          goods_id: pddItem.goods_id,
          category_id: pddItem.category_id,
          goods_name: pddItem.goods_name,
          sold_quantity: pddItem.sold_quantity,
          goods_photo: pddItem.goods_thumbnail_url,
          shop_name: pddItem.mall_name,
          commission_rate: pddItem.promotion_rate,
          coupon_discount: pddItem.coupon_discount,
          zk_final_price: pddItem.min_group_price,
          ori_price: pddItem.min_normal_price,
          coupon_total_quantity: pddItem.coupon_total_quantity,
          coupon_remain_quantity: pddItem.coupon_remain_quantity,
          coupon_start_time: pddItem.coupon_start_time,
          coupon_end_time: pddItem.coupon_end_time,
          coupon_info: pddItem.coupon_discount + '',
          platform: 1,
          available: 1,
          is_delete: 0,
          create_time: now,
          update_time: now
        };
      }

      function changeTbItemToSkuItem(tbItem) {
        const now = parseInt(new Date().getTime() / 1000);
        return {
          goods_id: tbItem.num_iid,
          category_id: tbItem.category_id,
          goods_name: tbItem.title,
          sold_quantity: tbItem.tk_total_sales,
          goods_photo: tbItem.pict_url,
          shop_name: tbItem.shop_title,
          commission_rate: tbItem.commission_rate * 100,
          coupon_discount: tbItem.coupon_amount * 100,
          zk_final_price: tbItem.zk_final_price * 100,
          ori_price: tbItem.reserve_price * 100,
          coupon_total_quantity: tbItem.coupon_total_count,
          coupon_remain_quantity: tbItem.coupon_remain_count,
          coupon_start_time: new Date(tbItem.coupon_start_time).getTime() / 1000,
          coupon_end_time: new Date(tbItem.coupon_end_time).getTime() / 1000,
          coupon_info: tbItem.coupon_info,
          platform: 2,
          available: 1,
          is_delete: 0,
          create_time: now,
          update_time: now
        };
      }

      function genSql(choiceList, item, op) {
        let sql;
        if (op === Constant.choiceListItemOpt.FORWARD) {
        // 上移
          sql = `SELECT * FROM choice_list_sort WHERE choice_list_id = ${choiceList.choice_list_id} AND item_sort <= ${item.item_sort} ORDER BY item_sort DESC LIMIT 2`;
        } else if (op === Constant.choiceListItemOpt.BACKWARD) {
        // 下移
          sql = `SELECT * FROM choice_list_sort WHERE choice_list_id = ${choiceList.choice_list_id} AND item_sort >= ${item.item_sort} ORDER BY item_sort LIMIT 2`;
        }
        return sql;
      }
    }

    async detail(params) {
      const id = params.id;
      const page = params.page > 1 ? params.page - 1 : 0;
      const pageSize = params.pageSize ? params.pageSize : 10;
      const data = { code: ErrorCode.ERROR_CODE_PARAM, msg: '参数错误' };

      if (id) {
        await this.app.mysql.beginTransactionScope(async conn => {
          const infos = await conn.select('choice_product_list', {
            where: {
              id
            }
          });

          if (!infos || infos.length < 1) {
            data.code = ErrorCode.ERROR_CODE_QUERY;
            data.msg = `获取不到${id}对应的选品库信息`;
            return;
          }

          data.info = infos[0];
          const sql = `SELECT a.choice_list_id, a.item_platform, a.item_sort, b.* 
                      FROM choice_list_sort a, guide_goods b
                      WHERE a.choice_list_id = ${id}
                        AND a.item_id = b.goods_id
                        AND a.item_platform = b.platform
                      ORDER BY a.item_sort
                      LIMIT ${page * pageSize}, ${pageSize}`;
          data.info.goodsList = await this.app.mysql.query(sql);
          const cntSql = `SELECT COUNT(*) FROM choice_list_sort WHERE choice_list_id = ${id}`;
          const totalCountArr = await this.app.mysql.query(cntSql);
          data.info.goodsCount = totalCountArr && totalCountArr[0] ? Object.values(totalCountArr[0])[0] : 0;
          data.code = 10000;
          data.msg = '成功';
        }, this.ctx);
      }
      return data;
    }

    /**
     * 更新当天日期下所有选品列表中的商品信息，避免商品信息过期
     * @returns {Promise<void>}
     */
    async updateChoiceListProduc() {
      const dateTime = Math.floor(Date.now() / 1000);
      const result = await this.choiceListCalendar({ beginTime: dateTime, endTime: dateTime });
      const choiceLists = result.data;

      if (!Array.isArray(choiceLists)) {
        return;
      }

      const tbProductList = [];
      const pddProductList = [];

      choiceLists.forEach(choiceList => {
        const tbProducts = choiceList.item_list.filter(item => {
          return item.item_platform === Constant.platform.TB && tbProductList.indexOf(item) === -1;
        });

        const pddProducts = choiceList.item_list.filter(item => {
          return item.item_platform === Constant.platform.PDD && pddProductList.indexOf(item) === -1;
        });

        tbProductList.push(tbProducts);
        pddProductList.push(pddProducts);
      });

      const pddIDs = [];
      pddProductList.forEach(item => {
        pddIDs.push(item.item_id);
      });

      if (pddIDs.length !== 0) {
        const response = await Service.pdd.goodsList({ goods_id_list: pddIDs });
        const products = response.goods_list;
        const now = Math.floor(Date.now() / 1000);

        const updateSQLs = [];
        if (Array.isArray(products) && products.length !== 0) {
          products.forEach(product => {
            product.qx_update_time = now;
            product.goods_gallery_urls = JSON.stringify(product.goods_gallery_urls);
            product.opt_ids = JSON.stringify(product.opt_ids);
            product.cat_ids = JSON.stringify(product.cat_ids);

            const sql = Utils.genReplaceSql('sku_pdd', product);
            updateSQLs.push(sql);
          });

          if (updateSQLs.length !== 0) {
            await this.app.mysql.beginTransactionScope(async conn => {
              for (const index in updateSQLs) {
                const sql = updateSQLs[index];
                await conn.query(sql);
              }
            });
          }
        }
      }

      if (tbProductList.length !== 0) {
        const updateSQLs = [];

        for (const index in tbProductList) {
          const product = tbProductList[index];
          const tbProduct = await Service.tb.goodsList({ para: product.item_id });

          if (tbProduct.data.error !== '0' || !Array.isArray(tbProduct.result_list)) {
            continue;
          }

          const resultList = tbProduct.result_list;
          if (resultList.length <= 0) {
            continue;
          }

          const data = resultList[0];

          if (data.coupon_info) {
            const couponArr = data.coupon_info.replace('元', '').replace('满', '').split('减');
            if (couponArr.length > 1) {
              const coupon_start_fee = parseFloat(couponArr[0]);
              const coupon_amount = parseFloat(couponArr[1]);
              if (data.zk_final_price >= coupon_start_fee && data.zk_final_price - coupon_amount >= 0) {
                data.coupon_price = data.zk_final_price - coupon_amount;
                data.coupon_price = Number(data.coupon_price).toFixed(2);
              }
            }
          }

          data.small_images = JSON.stringify(data.small_images);
          data.commission_rate = data.commission_rate * 10;

          const sql = Utils.genReplaceSql('sku_tb', data);
          updateSQLs.push(sql);
        }

        if (updateSQLs.length !== 0) {
          await this.app.mysql.beginTransactionScope(async conn => {
            for (const index in updateSQLs) {
              const sql = updateSQLs[index];
              await conn.query(sql);
            }
          });
        }
      }
    }
  };
};
