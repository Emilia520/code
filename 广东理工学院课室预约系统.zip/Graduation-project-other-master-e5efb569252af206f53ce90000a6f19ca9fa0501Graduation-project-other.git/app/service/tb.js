const Service = require('egg').Service;
const ErrCode = require('../utils/errorCode');
const checker = require('../utils/paramChecker');
const Constant = require('../utils/constant');
const TopClient = require('../lib/taobao/api/topClient.js').TopClient;
const utils = require('../utils/utils');
const fs = require('fs');
const urlencode = require('urlencode');

module.exports = () => {
  return class Tb extends Service {
    async importCat(params) {
      if (!(params && params.item_cats && params.item_cats.item_cat)) {
        return { success: false, msg: '参数错误' };
      }
      const ctx = this.ctx;
      const ret = await this.app.mysql.beginTransactionScope(async conn => {
        for (const i in params.item_cats.item_cat) {
          const category = params.item_cats.item_cat[i];
          await conn.insert('tb_cat', category);
        }
      }, ctx);

      return { success: true };
    }

    async goodsList(params) {
      const ctx = this.ctx;
      // 淘宝联盟官方接口
      // const result = await this.sendRequest('taobao.tbk.item.get', { fields: 'num_iid,title,pict_url,small_images,reserve_price,zk_final_price,user_type,provcity,item_url,seller_id,volume,nick', q: '精选' });
      // console.log('return ', result);
      // if (result.results && result.results.n_tbk_item) {
      //   ret.list = result.results.n_tbk_item;
      //   ret.totalCount = result.results.total_results;
      // }

      // 维易淘客接口
      let data = {
        vekey: this.app.config.tb.vekey,
        pid: this.app.config.tb.default_pid
      };
      data = Object.assign(data, params);
      // 如果是搜索关键词，就忽略分类信息
      if (data.para) {
        data.para = urlencode(data.para);
        delete data.cat;
      }
      let url = 'http://apis.vephp.com/super?';
      const keys = Object.keys(data);
      for (const i in keys) {
        const key = keys[i];
        const val = data[key];
        if (val) {
          url += `${key}=${val}&`;
        }
      }

      const result = await ctx.curl(url.slice(0, url.length - 1), {
        method: 'GET',
        dataType: 'json'
      });

      return result;
    }

    // 淘宝热销高佣商品
    async hotSaleList(params) {
      const ctx = this.ctx;
      // 维易淘客接口
      let data = {
        vekey: this.app.config.tb.vekey
      };
      data = Object.assign(data, params);
      data.topcate = encodeURIComponent(data.topcate);
      let url = 'http://apis.vephp.com/products?';
      const keys = Object.keys(data);
      for (const i in keys) {
        const key = keys[i];
        const val = data[key];
        if (val) {
          url += `${key}=${val}&`;
        }
      }
      // const result = await ctx.curl(url.slice(0, url.length - 1), {
      const result = await ctx.curl(url.slice(0, url.length - 1), {
        method: 'GET',
        dataType: 'json'
      });
      console.log('234567890', result);
      return result;
    }

    // 生成淘宝单品转链
    async genPromotionUrl(params) {
      const ctx = this.ctx;
      const ret = {};
      // 维易淘客接口
      const data = {
        vekey: this.app.config.tb.vekey,
      };
      const result = await ctx.curl('http://api.vephp.com/hcapi', {
        data: Object.assign(data, params),
        dataType: 'json'
      });

      return result;
    }
    // 获取推广信息
    async genPromoteInfo(pid, goods_id) {
      let info = {};
      const isRid = pid.indexOf('mm_') === -1;
      const realPid = isRid ? this.app.config.tb.default_pid : pid;
      const params = { pid: realPid, para: goods_id };
      if (isRid) {
        params.relationId = pid;
      }
      const result = await this.genPromotionUrl(params);

      if (result.data && result.data.data) {
        info = result.data.data;
      }

      return info;
    }
    // 获取淘口令
    async getTkl(pid, goods_id) {
      const info = await this.genPromoteInfo(pid, goods_id);
      return info.tbk_pwd;
    }

    // 生成商品通用发单模版
    // async genCommonTemplate(goods) {
    //   const price = this.getCouponPrice(goods);
    //   goods.coupon_price = price;
    //   return await this.service.image.composeTbPoster(goods, Constant.tbBgImgUrl);
    // }

    // 根据淘口令生成二维码
    async genQRCode(goods, tkl) {
      if (!goods || !goods.pict_url || !tkl) {
        return null;
      }

      return await this.service.image.genQRCodeTmpPath(await this.genPromotePageUrl(goods, tkl));
    }

    // 生成中间页链接
    async genPromotePageUrl(goods, tkl) {
      if (!goods || !goods.pict_url || !tkl) {
        return null;
      }
      const pic = encodeURIComponent(goods.pict_url);
      return `https://midpage.quexiangbao.com?taowords=${tkl}&pic=${pic}`;
    }

    // 合成通用模版和二维码
    // async composePict(template, qrCode) {
    //   const tmpPath = await this.service.image.composeTbQr(template, qrCode);
    //   const img = fs.createReadStream(tmpPath);
    //   return await this.service.image.uploadImage(img);
    // }

    // 根据pid生成淘宝单品发单图
    // async genSharedPict(params) {
    //   if (!params.pid) {
    //     throw { code: ErrCode.ERROR_CODE_PARAM, msg: '缺少参数pid' };
    //   } else if (!params.para) {
    //     throw { code: ErrCode.ERROR_CODE_PARAM, msg: '缺少参数para' };
    //   }
    //   // 先查询商品信息
    //   let now = new Date().getTime();
    //   let goods = {};
    //   let result = await this.goodsList(params);
    //   console.log('查询商品时间:', new Date().getTime() - now + 'ms');
    //   if (result.data && result.data.error == '0' && result.data.data) {
    //     if (Array.isArray(result.data.data) && result.data.data.length > 0) {
    //       goods = result.data.data[0];
    //     } else {
    //       goods = result.data.data;
    //     }
    //     if (!goods.reserve_price || !goods.zk_final_price) {
    //       throw { code: ErrCode.ERROR_CODE_REMOTE, msg: '查询到的商品信息缺少价格参数或者参数key发生改变' };
    //     }
    //   } else {
    //     throw { code: ErrCode.ERROR_CODE_REMOTE, msg: result.data.msg || '查询商品信息失败' };
    //   }
    //   // 然后开始转链获取对应的淘口令
    //   let tkl = '';
    //   now = new Date().getTime();
    //   result = await this.genPromotionUrl(params);
    //   console.log('转链时间:', new Date().getTime() - now + 'ms');
    //   if (result.data && result.data.data && result.data.data.tbk_pwd) {
    //     tkl = result.data.data.tbk_pwd;
    //   } else {
    //     throw { code: ErrCode.ERROR_CODE_REMOTE, msg: result.data.msg || '淘宝获取淘口令失败' };
    //   }
    //   // 结合淘口令模版生成二维码图片
    //   // const coupon_price = this.getCouponPrice(goods);
    //   // const text = Constant.tklTempl.replace('{reserve_price}', goods.reserve_price)
    //   //   .replace('{zk_final_price}', coupon_price >= 0 ? coupon_price : goods.zk_final_price)
    //   //   .replace('{tb_tkl}', tkl);
    //   const pic = encodeURIComponent(goods.pict_url);
    //   const text = `https://midpage.quexiangbao.com?taowords=${tkl}&pic=${pic}`;
    //   now = new Date().getTime();
    //   const qrCode = await this.service.image.genQRCodeTmpPath(text);
    //   console.log('生成二维码时间:', new Date().getTime() - now + 'ms');
    //   if (!qrCode) {
    //     throw { code: ErrCode.ERROR_CODE_REMOTE, msg: '生成二维码失败' };
    //   }
    //   // 真正生成图片
    //   now = new Date().getTime();
    //   const imgPath = await this.service.image.composeTbPoster(goods, Constant.tbBgImgUrl, qrCode);
    //   console.log('生成图片时间:', new Date().getTime() - now + 'ms');
    //   if (!imgPath) {
    //     utils.deleteFile(qrCode);
    //     throw { code: ErrCode.ERROR_CODE_REMOTE, msg: '生成发单图失败' };
    //   }
    //   // 上传生成的分享图片
    //   now = new Date().getTime();
    //   const img = fs.createReadStream(imgPath);
    //   const url = await this.service.image.uploadImage(img);
    //   console.log('上传图片时间:', new Date().getTime() - now + 'ms');
    //   // 成功后删除临时文件
    //   utils.deleteFile(qrCode);
    //   utils.deleteFile(imgPath);
    //   return url;
    // }

    async sendRequest(method, params) {
      const client = new TopClient({
        appkey: this.config.tb.app_key,
        appsecret: this.config.tb.app_secret,
        url: this.config.tb.url
      });

      return new Promise(resolve => {
        client.execute(method, params, function(error, response) {
          if (!error) {
            //   console.log(response);
            resolve(response);
          } else {
            //   console.log(error);
            resolve(error);
          }
        });
      });
    }

    async summaryData(params) {
      const condition = parseQueryCondition(params);
      const sql = `SELECT FROM_UNIXTIME(a.order_create_time, "%Y-%m-%d") AS order_date, a.tk_status AS order_status, COUNT(1) AS order_count, SUM(a.alipay_total_price) AS order_amount_sum 
        FROM order_guide_tb a 
        ${condition.where} 
        GROUP BY order_date, order_status ORDER BY order_date`;
      console.log(sql);
      const list = await this.app.mysql.query(sql);
      return { list };

      function parseQueryCondition(params) {
        let where = '';
        if (params.start_time && params.end_time) {
          where += 'WHERE a.order_create_time >= ' + params.start_time + ' AND a.order_create_time <= ' + params.end_time;
        }

        return { where };
      }
    }

    getCouponPrice(goods) {
      let price = null;
      if (goods.coupon_info) {
        const tmpStr = goods.coupon_info.replace('元', '').replace('满', '');
        const tmpArr = tmpStr.split('减');
        if (tmpArr.length > 1) {
          const coupon_start_fee = parseFloat(tmpArr[0]);
          const coupon_amount = parseFloat(tmpArr[1]);

          if (goods.zk_final_price >= coupon_start_fee && goods.zk_final_price - coupon_amount >= 0) {
            price = Number(goods.zk_final_price - coupon_amount).toFixed(2);
          }
        }
      }
      return price;
    }
  };
};