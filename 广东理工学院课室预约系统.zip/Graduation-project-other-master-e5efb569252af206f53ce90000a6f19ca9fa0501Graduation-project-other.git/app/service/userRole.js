'use strict';

const Service = require('egg').Service;

class UserRoleService extends Service {
  async userInfo(params) {
    const pageSize = params.pageSize < 1 || params.pageSize > 20 ? 20 : params.pageSize;
    const page = (params.page - 1) * pageSize;
    const limit = `limit ${page}, ${pageSize}`;
    const sql = ` SELECT *FROM user_information WHERE 1=1 ` + limit;
    const sqltotal = `SELECT COUNT(*) as total FROM user_information`;
    const results = await this.app.mysql.query(sql);
    const total = await this.app.mysql.query(sqltotal);
    return { code: 10000, msg: '成功', data: results, total };
  }

  async selectInfo(params) {
    if (typeof params.page !== 'undefined' && typeof params.pageSize !== 'undefined') {
      let page = params.page < 1 ? 1 : params.page;
      const pageSize = params.pageSize < 1 || params.pageSize > 30 ? 30 : params.pageSize;
      page = (page - 1) * pageSize;
      const truename = params.truename;
      const id = params.id;
      const account_name = params.account_name;
      const type = params.type;
      const telephone = params.telephone;
      let conditions = '';
      if (typeof truenmame !== 'undefined' && truenmame !== '') {
        conditions = conditions + ` AND truename LIKE "%${truename}%" `;
      }
      if (typeof account_name !== 'undefined' && account_name !== '') {
        conditions = conditions + ` AND account_name LIKE "%${account_name}%" `;
      }
      if (typeof type !== 'undefined' && type !== 0) {
        conditions = conditions + ` AND type = ${type} `;
      }
      if (typeof telephone !== '' && telephone !== 0 && telephone !== undefined) {
        conditions = conditions + ` AND telephone = ${time} `;
      }
      if (typeof id !== '' && id !== 0 && id !== undefined) {
        conditions = conditions + ` AND id = ${id} `;
      }

      const limit = `limit ${page}, ${pageSize}`;
      const sql = `SELECT * FROM user_information WHERE 1=1 ` + conditions + limit;
      const searchTotal = `SELECT COUNT(*) as sum FROM user_information WHERE 1=1 ` + conditions;
      const results = await this.app.mysql.query(sql);
      const stotal = await this.app.mysql.query(searchTotal);
      return { code: 10000, msg: '成功', data: results, stotal };

    }
  }
  async userRecord(params) {
    const truename = params.truename;
    const number = params.number;
    const id = params.id;
    const account_name = params.account_name;
    const type = params.usertype;
    let role_id = 3;
    if (type === 3) {
      role_id = 2;
    }
    const sql = `UPDATE user_information SET truename = '${truename}',number = ${number},type = ${type},role_id = ${role_id} WHERE id = ${id} `;
    const adminUser = ` UPDATE admin_user SET truename = '${truename}',type = ${type},role_id = ${role_id} WHERE account_name = '${account_name}' `;
    const conn = await this.app.mysql.beginTransaction(); // 初始化事务
    try {
      await this.app.mysql.query(sql);
      await this.app.mysql.query(adminUser);
      await conn.commit(); // 提交事务
      return { code: 10000, msg: '成功', data: '修改成功' };
    } catch (err) {
      // error, rollback
      console.log('----------事务执行失败----------');
      await conn.rollback(); // 一定记得捕获异常后回滚事务！！
      throw err;
    }
  }

}

module.exports = UserRoleService;
