'use strict';

const Service = require('egg').Service;

class ExamineService extends Service {
  async userAppiont(params) {
    const pageSize = params.pageSize < 1 || params.pageSize > 30 ? 30 : params.pageSize;
    const page = (params.page - 1) * pageSize;
    const limit = `limit ${page}, ${pageSize}`;
    const time = Math.round(new Date() / 1000);
    const check = `SELECT time_stamp,appoint_state FROM appoint_record`;
    const overTime = ` UPDATE appoint_record SET appoint_state=2 WHERE time_stamp < ${time} AND appoint_state=0`;
    const sql = ` SELECT * FROM appoint_record WHERE appoint_state = 0 AND appoint_cancle = 0  ORDER BY roomtime ` + limit;
    const sum = ` SELECT COUNT(*) as total FROM appoint_record WHERE appoint_state = 0 AND appoint_cancle = 0`;
    const conn = await this.app.mysql.beginTransaction(); // 初始化事务
    try {
      const checkdata = await conn.query(check);
      for (let i = 0; i < checkdata.length; i++) {
        let state = checkdata[i].appoint_state;
        if (state === 0) {
          await conn.query(overTime);
        }
      }
      const results = await conn.query(sql);
      const total = await conn.query(sum);
      await conn.commit(); // 提交事务
      return { code: 10000, msg: '成功', data: results, total };

    } catch (err) {
      console.log('----------事务执行失败----------');
      await conn.rollback(); // 一定记得捕获异常后回滚事务！！
      throw err;
    }
  }

  async successAppiont(params) {
    const truename = params.truename;
    const roomresult = params.roomresult;
    const roomname = params.roomname;
    const approver = params.adimname;
    const username = params.username;
    const type = params.type;
    const ctime = params.order_time;//提交时间
    const stamp = params.time_stamp;//预约时间的时间戳
    const roomtime = params.roomtime;//预约日期
    const solt = params.time_solt;//预约时间段
    const userInfo = ` SELECT id,number FROM user_information WHERE account_name='${username}'`;
    const field = 'roomnumber,roomname,approver,username,userid,number,truename,order_id,type,roomresult,order_time,time_stamp,roomtime,time_solt,whether_pass';
    //修改预约记录表
    const id = params.order_id;
    const roomnumber = params.roomnumber;
    const change = ` UPDATE appoint_record SET appoint_state = 1 WHERE order_id=${id} AND roomnumber = ${roomnumber} `;
    //修改class_time表
    const changeApp = ` UPDATE class_time SET appwhether = 1 WHERE roomnumber=${roomnumber} AND appoint_date=${roomtime} AND time_stamp=${stamp} `;

    const conn = await this.app.mysql.beginTransaction(); // 初始化事务
    try {
      const information = await conn.query(userInfo);
      const userid = information[0].id;
      const number = information[0].number;
      await conn.query(change);
      const approval = `INSERT INTO approval_record(${field})VALUES(${roomnumber},'${roomname}','${approver}','${username}',${userid},${number},'${truename}',${id},${type},'${roomresult}',${ctime},${stamp},${roomtime},'${solt}',1)`;
      await conn.query(approval);
      await conn.query(changeApp);
      const results = [{ result: 1 }];
      await conn.commit(); // 提交事务
      return { code: 10000, msg: '成功', data: results };
    } catch (err) {
      console.log('----------事务执行失败----------');
      await conn.rollback(); // 一定记得捕获异常后回滚事务！！
      throw err;
    }

  }

  async failedAppiont(params) {
    const truename = params.truename;
    const roomresult = params.roomresult;
    const roomname = params.roomname;
    const approver = params.adimname;
    const username = params.username;
    const type = params.type;
    const ctime = params.order_time;//提交时间
    const stamp = params.time_stamp;//预约时间的时间戳
    const roomtime = params.roomtime;//预约日期
    const solt = params.time_solt;//预约时间段
    const userInfo = ` SELECT id,number FROM user_information WHERE account_name='${username}'`;
    const field = 'roomnumber,roomname,approver,username,userid,number,truename,order_id,type,roomresult,order_time,time_stamp,roomtime,time_solt,whether_pass';
    //修改预约记录表
    const id = params.order_id;
    const roomnumber = params.roomnumber;
    const change = ` UPDATE appoint_record SET appoint_state = 3 WHERE order_id=${id} AND roomnumber = ${roomnumber} `;
    //修改class_time表
    const changeApp = ` UPDATE class_time SET appwhether = 0 WHERE roomnumber=${roomnumber} AND appoint_date=${roomtime} AND time_stamp=${stamp} `;

    const conn = await this.app.mysql.beginTransaction(); // 初始化事务
    try {
      const information = await conn.query(userInfo);
      const userid = information[0].id;
      const number = information[0].number;
      await conn.query(change);
      const approval = `INSERT INTO approval_record(${field})VALUES(${roomnumber},'${roomname}','${approver}','${username}',${userid},${number},'${truename}',${id},${type},'${roomresult}',${ctime},${stamp},${roomtime},'${solt}',2)`;
      await conn.query(approval);
      await conn.query(changeApp);
      const results = [{ result: 1 }];
      await conn.commit(); // 提交事务
      return { code: 10000, msg: '成功', data: results };
    } catch (err) {
      console.log('----------事务执行失败----------');
      await conn.rollback(); // 一定记得捕获异常后回滚事务！！
      throw err;
    }

  }

  async selectOther(params) {
    if (typeof params.page !== 'undefined' && typeof params.pageSize !== 'undefined') {
      let page = params.page < 1 ? 1 : params.page;
      const pageSize = params.pageSize < 1 || params.pageSize > 30 ? 30 : params.pageSize;
      page = (page - 1) * pageSize;
      const number = params.snumber;
      const roomname = params.sroomname;
      const type = params.stype;
      const username = params.susername;
      const truename = params.struename;
      const time = params.sdateTime;
      const time_number = params.timesolt;
      let conditions = '';
      if (typeof number !== 'undefined' && number !== '') {
        conditions = conditions + ` AND roomnumber = ${number} `;
      }
      if (typeof roomname !== 'undefined' && roomname !== '') {
        conditions = conditions + ` AND roomname LIKE "%${roomname}%" `;
      }
      if (typeof username !== 'undefined' && username !== '') {
        conditions = conditions + ` AND username LIKE "${username}" `;
      }
      if (typeof truenmame !== 'undefined' && truenmame !== '') {
        conditions = conditions + ` AND truename LIKE "%${truename}%" `;
      }
      if (typeof type !== 'undefined' && type !== 0) {
        conditions = conditions + ` AND type = ${type} `;
      }
      if (typeof time !== '' && time !== 0 && time !== undefined) {
        conditions = conditions + ` AND roomtime = ${time} `;
      }
      if (typeof time_number !== '' && time_number !== 0 && time_number !== undefined) {
        conditions = conditions + ` AND time_number = ${time_number} `;
      }
      const limit = `limit ${page}, ${pageSize}`;
      const sql = `SELECT * FROM appoint_record WHERE appoint_state = 0 AND appoint_cancle = 0 ` + conditions + limit;
      const searchTotal = `SELECT COUNT(*) as sum FROM appoint_record WHERE appoint_state = 0 AND appoint_cancle = 0 ` + conditions;
      const results = await this.app.mysql.query(sql);
      const stotal = await this.app.mysql.query(searchTotal);
      return { code: 10000, msg: '成功', data: results, stotal };

    }
  }



  //修改课室状态定时任务1
  async changeState(params) {
    const nowTime = Math.round(new Date() / 1000);
    const zerotime = new Date(new Date().toLocaleDateString()).getTime() / 1000//获取当日零点时间戳
    const search = ` SELECT * FROM approval_record WHERE roomtime = ${zerotime}`;
    const searchApp = await this.app.mysql.query(search);
    if (searchApp.length !== 0) {
      for (let i = 0; i < searchApp.length; i++) {
        const truename = searchApp[i].truename;
        const roomresult = searchApp[i].roomresult;
        const roomnumber = searchApp[i].roomnumber;
        const time_stamp = searchApp[i].time_stamp;
        var rnumber = searchApp[i].roomnumber;
        if (time_stamp === nowTime) {
          const change = ` UPDATE classroom SET roomstate = 1,roomstate_describe='使用中',truename='${truename}',roomresult='${roomresult}' WHERE roomnumber=${roomnumber} `;
          await this.app.mysql.query(change);
          console.log('------>修改课室成功<-----');
          setTimeout(() => {
            this.updateNull({ number: rnumber });
            console.log('------>执行了setTime<-----');
          }, 2700000);
        } else {
          console.log('------>时间不相等<-----' + 'now:' + nowTime + ' ' + 'stamp:' + time_stamp);
        }
      }
      return;
    } else {
      console.log('----->当前没有预约<-----');
      return;
    }
  }

  //45分钟后修改课室状态为空
  async updateNull(params) {
    const roomnumber = params.number;
    const changeNull = ` UPDATE classroom SET roomstate = 0,roomstate_describe='空',truename='无',roomresult='无' WHERE roomnumber=${roomnumber} `;
    await this.app.mysql.query(changeNull);
    console.log('------->2');
    return;
  }


}


module.exports = ExamineService;
