'use strict';

const Service = require('egg').Service;

class AppReordService extends Service {
  async listReord(params) {
    const pageSize = params.pageSize < 1 || params.pageSize > 20 ? 20 : params.pageSize;
    const page = (params.page - 1) * pageSize;
    const limit = `limit ${page}, ${pageSize}`;
    const sql = ` SELECT * FROM appoint_record WHERE 1=1 ORDER BY  order_time DESC `+ limit;
    const sqltotal = `SELECT COUNT(*) as total FROM appoint_record`;
    const results = await this.app.mysql.query(sql);
    const total = await this.app.mysql.query(sqltotal);
    return { code: 10000, msg: '成功', data:results,total };
  }

  async ownList(params){
    if (typeof params.page !== 'undefined' && typeof params.pageSize !== 'undefined') {
        let page = params.page < 1 ? 1 : params.page;
        const pageSize = params.pageSize < 1 || params.pageSize > 30 ? 30 : params.pageSize;
        page = (page - 1) * pageSize;
        const truename = params.truename;
        const roomnumber = params.roomnumber;
        const roomname = params.roomname;
        const username = params.username;
        const roomtime = params.roomtime;
        let conditions = '';
        if(typeof truenmame !== 'undefined' && truenmame !== ''){
            conditions = conditions + ` AND truename LIKE "%${truename}%" `;
          }
          if(typeof roomname !== 'undefined' && roomname !== ''){
            conditions = conditions + ` AND roomname LIKE "%${roomname}%" `;
          }
          if(typeof username !== 'undefined' && username !== ''){
            conditions = conditions + ` AND username = '${username}' `;
          }
          if(typeof roomnumber !== 'undefined' && roomnumber !== ''&& roomnumber !==0){
            conditions = conditions + ` AND roomnumber = ${roomnumber} `;
          }
          if(typeof roomtime !== 'undefined' && roomtime !== ''&& roomtime !==0){
            conditions = conditions + ` AND roomtime = ${roomtime} `;
          }
          const limit = `limit ${page}, ${pageSize}`;
          const sql = `SELECT * FROM appoint_record WHERE 1=1 `+ conditions + limit;
          const searchTotal = `SELECT COUNT(*) as stotal FROM appoint_record WHERE 1=1 `+ conditions;
          console.log(JSON.stringify(sql));
          const results = await this.app.mysql.query(sql);
          const stotal = await this.app.mysql.query(searchTotal);
          return { code: 10000, msg: '成功', data:results,stotal};  
    
      }
     
  }
}

module.exports = AppReordService;
