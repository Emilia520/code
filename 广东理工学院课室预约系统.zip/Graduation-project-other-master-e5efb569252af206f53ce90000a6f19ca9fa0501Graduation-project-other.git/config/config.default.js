const path = require('path');
const fs = require('fs');
module.exports = app => {
  const exports = {};

  exports.siteFile = {
    '/favicon.ico': fs.readFileSync(path.join(app.baseDir, 'app/web/asset/images/favicon.ico'))
  };

  exports.view = {
    cache: false
  };

  // jwt配置
  exports.jwt = {
    enable: false,
    secret: 'q.u.e.x.b_a.d.m.i.n'
  };

  exports.vuessr = {
    layout: path.join(app.baseDir, 'app/web/view/layout.html'),
    renderOptions: {
      // 告诉 vue-server-renderer 去 app/view 查找异步 chunk 文件
      basedir: path.join(app.baseDir, 'app/view')
    }
  };

  exports.logger = {
    consoleLevel: 'DEBUG',
    dir: path.join(app.baseDir, 'logs')
  };

  exports.static = {
    prefix: '/public/',
    dir: path.join(app.baseDir, 'public')
  };

  exports.bodyParser = {
    jsonLimit: '1mb',
    formLimit: '50mb'
  };

  exports.keys = '123456';

  exports.middleware = [
    'access', 'errorHandler', 'userAuth','compress'
  ];
  exports.compress={
    threshold:10
  };
  exports.multipart = {
    mode: 'stream',
    fields: 50,
    fileSize: '10mb'
  };

  exports.pdd = {
    client_id: '05e4a2ee4f4043ec8fae7e34ef1a8113',
    secret: '9b408bd1412b285863e5d99ce2c8a70e4041d789'
  };

  exports.tb = {
    vekey: 'V00001240Y06093915',
    default_pid: 'mm_221570169_174550027_105985800151',
    app_key: '25230633',
    app_secret: '7db6edc90927988cbcd9add05b11f7dc',
    url: 'https://eco.taobao.com/router/rest',
    special_invite_code: 'UQ8F9I',
    relation_invite_code: 'F54EB8'
  };

  exports.tb1688 = {
    app_key: '3458083',
    app_secret: 'YqEGCSZohyhl',
    base_url: 'http://gw.open.1688.com/openapi/param2/1',
    base_path: 'param2/1',
    access_token: '8a89bbcc-fa0f-4b98-af14-22f50526ec63'
  };

  return exports;
};
