/**
 * 生产环境配置
 *
 * 最终生效的配置为 prod + default（前者覆盖后者）
 */
const ip = require('ip');
module.exports = app => {
  const exports = {};

  const localIP = ip.address();
  const domainWhiteList = [];
  [17001, 9000, 9001].forEach(port => {
    domainWhiteList.push(`http://localhost:${port}`);
    domainWhiteList.push(`http://127.0.0.1:${port}`);
    domainWhiteList.push(`http://${localIP}:${port}`);
  });

  exports.security = {
    domainWhiteList,
    csrf: {
      enable: false,
      headerName: 'x-csrf-token', // 通过 header 传递 CSRF token 的默认字段为 x-csrf-token
    }
  };

  exports.mysql = {
    client: {
      // host
      // host: 'rm-wz9nijk43u5zzwgb46o.mysql.rds.aliyuncs.com',
      host:'localhost',
      // 端口号
      port: '3306',
      // 用户名
      user: 'root',
      // 密码
      // password: 'Oep6SV@zBxvF',
      password:'123456',
      // 数据库名
      database: 'copyxtt',
      // 是否启用加密密码
      encryptPassword: false,
      connector: 'mysql',
      dateStrings: true,
      connectionLimit: 10,
      timezone: '+08:00',
      charset: 'UTF8MB4'
      // dialect: 'mysql'
    },
    // 是否加载到 app 上，默认开启
    app: true,
    // 是否加载到 agent 上，默认关闭
    agent: false,
    sequelizeLog: true
  };

  // exports.redis = {
  //   clients: {
  //     db0: { // 存放时效性短的数据
  //       port: 6379, // Redis port
  //       host: 'r-wz977e0b60befb44.redis.rds.aliyuncs.com',
  //       password: 'MhDls@SEe0Bl',
  //       db: 0,
  //     },
  //     db1: { // 存放用户数据
  //       port: 6379, // Redis port
  //       host: 'r-wz977e0b60befb44.redis.rds.aliyuncs.com',
  //       password: 'MhDls@SEe0Bl',
  //       db: 1,
  //     },
  //     db2: { // 存放业务数据
  //       port: 6379, // Redis port
  //       host: 'r-wz977e0b60befb44.redis.rds.aliyuncs.com',
  //       password: 'MhDls@SEe0Bl',
  //       db: 2,
  //     }
  //   }
  // };
  exports.redis = {
    clients: {
      db0: { // 存放时效性短的数据
        port: 6378, // Redis port
        host: '172.18.247.25',
        password: 'MhDls@SEe0Bl',
        db: 0,
      },
      db1: { // 存放用户数据
        port: 6378, // Redis port
        host: '172.18.247.25',
        password: 'MhDls@SEe0Bl',
        db: 1,
      },
      db2: { // 存放业务数据
        port: 6378, // Redis port
        host: '172.18.247.25',
        password: 'MhDls@SEe0Bl',
        db: 2,
      },
      db3: { // 存放业务数据
        port: 6378, // Redis port
        host: '172.18.247.25',
        password: 'MhDls@SEe0Bl',
        db: 3,
      },
      db6: { // 商品信息映射
        port: 6378, // Redis port
        host: '172.18.247.25',
        password: 'MhDls@SEe0Bl',
        db: 6,
      }
    }
  };

  exports.api = {
    img_host: 'https://xttapi.lexj.com',
    coupon_host: 'https://api.fenxianglife.com',
    java_host: 'https://xttapi.lexj.com'
  };

  exports.akc = {
    app_key: 'ak45e3b70fd1264af7',
    secret: 'c41a47aab7a34f03938c1ce2a02e7bef',
    base_url: 'https://open.aikucun.com/open/api'
  };

  exports.zt = {
    userId: '569',
    secret: 'fe2cab789114eee8c4f68a5ba7b2d31cad901284272591bcd67e28b859b56f99',
    base_url: 'http://112.126.90.197:7360/unicomAync/'
  };

  return exports;
};
