exports.static = true;

exports.vuessr = {
  enable: true,
  package: 'egg-view-vue-ssr'
};

exports.mysql = {
  enable: true,
  package: 'egg-mysql'
};

exports.redis = {
  enable: true,
  package: 'egg-redis',
};

exports.jwt = {
  enable: true,
  package: 'egg-jwt',
};

exports.proxyagent = {
  enable: true,
  package: 'egg-development-proxyagent',
};
