const path = require('path');
const ip = require('ip');

module.exports = app => {
  const exports = {};

  exports.static = {
    maxAge: 0 // maxAge 缓存，默认 1 年
  };

  exports.development = {
    watchDirs: ['build'], // 指定监视的目录（包括子目录），当目录下的文件变化的时候自动重载应用，路径从项目根目录开始写
    ignoreDirs: ['app/web', 'public', 'config'] // 指定过滤的目录（包括子目录）
  };

  exports.logview = {
    dir: path.join(app.baseDir, 'logs')
  };

  const localIP = ip.address();
  const domainWhiteList = [];
  [7001, 9000, 9001].forEach(port => {
    domainWhiteList.push(`http://localhost:${port}`);
    domainWhiteList.push(`http://127.0.0.1:${port}`);
    domainWhiteList.push(`http://${localIP}:${port}`);
  });

  exports.security = {
    domainWhiteList,
    csrf: {
      enable: false,
      headerName: 'x-csrf-token', // 通过 header 传递 CSRF token 的默认字段为 x-csrf-token
    }
  };

  exports.mysql = {
    client: {
      // host
      // host: '47.107.106.243',
      host: 'localhost',
      // 端口号
      port: '3306',
      // 用户名
      user: 'root',
      // 密码
      // password: 'L2QroQ',
      password: '123456',
      // 数据库名
      database: 'copyxtt',
      // 是否启用加密密码
      encryptPassword: false,
      connector: 'mysql',
      dateStrings: true,
      connectionLimit: 10,
      timezone: '+08:00',
      // dialect: 'mysql'
    },
    // 是否加载到 app 上，默认开启
    app: true,
    // 是否加载到 agent 上，默认关闭
    agent: false,
    sequelizeLog: true
  };

  // exports.redis = {
  //   clients: {
  //     db0: { // 存放时效性短的数据
  //       port: 6379, // Redis port
  //       host: '47.107.106.243',
  //       password: 'o58YyL',
  //       db: 0,
  //     },
  //     db1: { // 存放用户数据
  //       port: 6379, // Redis port
  //       host: '47.107.106.243',
  //       password: 'o58YyL',
  //       db: 1,
  //     },
  //     db2: { // 存放业务数据
  //       port: 6379, // Redis port
  //       host: '47.107.106.243',
  //       password: 'o58YyL',
  //       db: 2,
  //     },
  //     db3: { // 资源数据
  //       port: 6379, // Redis port
  //       host: '47.107.106.243',
  //       password: 'o58YyL',
  //       db: 3,
  //     },
  //     db6: { // 商品信息映射
  //       port: 6379, // Redis port
  //       host: '47.107.106.243',
  //       password: 'o58YyL',
  //       db: 6,
  //     }
  //   }
  // };

  // exports.api = {
  //   img_host: 'http://xttapi.lexj.com',
  //   coupon_host: 'https://api.fenxianglife.com',
  //   java_host: 'https://apitest.quexb.com'
  // };

  // exports.akc = {
  //   app_key: 'ak267f1671f4754353',
  //   secret: '2dfdd3836e1c459bb08ca0344cf5141b',
  //   base_url: 'https://open.akucun.com/open/api'
  // };

  // exports.zt = {
  //   userId: '569',
  //   secret: 'fe2cab789114eee8c4f68a5ba7b2d31cad901284272591bcd67e28b859b56f99',
  //   base_url: 'http://112.126.90.197:7360/unicomAync/'
  // };

  return exports;
};
