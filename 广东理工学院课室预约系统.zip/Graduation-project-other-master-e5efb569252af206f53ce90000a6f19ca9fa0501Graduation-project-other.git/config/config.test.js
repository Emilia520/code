

module.exports = app => {
  const exports = {};

  return exports;
};
