<!--
1. 提交问题前，如果是使用问题,建议请先阅读: README.md 和 http://hubcarl.github.io/easywebpack
2. 如果是一个新需求，请提供：详细需求描述，最好是有伪代码实现。
3. 如果是一个 BUG，请提供：关键信息(平台, 版本)和复现步骤，如果可以，提供一个最小可复现的代码仓库，方便排查问题。
4. 相关使用文档: https://zhuanlan.zhihu.com/easywebpack
5. 欢迎加入 eggjs + webpack QQ交流群: 433207205
-->
